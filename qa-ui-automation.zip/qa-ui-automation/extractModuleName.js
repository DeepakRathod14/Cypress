const extractModuleName = (commitMessage) => {
	if (!commitMessage) {
		console.error('No commit message provided');
		process.exit(1);
	}
	
	const match = commitMessage.match(/\[module: ([^\]]+)\]/);
	return match ? match[1] : null;
};

const commitMessage = process.argv[2];
const moduleName = extractModuleName(commitMessage);

console.log(moduleName);
