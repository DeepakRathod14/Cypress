export const rqt = {
	'Get': 'GET',
	'Post': 'POST',
	'Put': 'PUT',
	'Delete': 'DELETE',
	'Patch': 'PATCH'
};

export const button = {
	'singleSignOn': 'Log in with SSO',
	'login': 'LOGIN',
	'next': 'NEXT'
};

export const envTag = {
	'Prod_EU': '@Prod_EU',
	'Prod_NA': '@Prod_NA',
	'Regression': '@Regression',
	'CTS': '@CTS',
	'Prod_NA_Test': '@Prod_NAE',
	'Migrated': '@Migrated'
};

export const input = {
	email: '#Input_Email',
	password: '#Input_Password',
	code: '#Input_Code'
};

export const gridLtr = {
	filterIcon: 'ul[role="menu"] [data-testid="FilterAltIcon"]',
	filterInput: '.MuiDataGrid-filterFormValueInput input[placeholder="Filter value"]',
	firstFilterOption:  'ul.MuiAutocomplete-listbox > li:nth-child(1)',
	getFilterOption: (index) => `ul.MuiAutocomplete-listbox > li:nth-child(${index})`,
	getCheckBoxByIndex: (index) => `div[data-rowindex="${index}"] div span input`,
	gridToolBarRemoveButton: 'button[data-testid="filter-button"]',
	gridFilterPanelRemoveAllButton: '.MuiDataGrid-panelFooter > :nth-child(2)',
};

// QA Environment URL is below 
export const baseUrl = 'https://qaplatform.connectwise.com';
export const baseUrlQA = 'https://qaplatform.connectwise.com';
export const baseUrlNA = 'https://control.itsupport247.net';
export const baseUrlEU = 'https://euplatform.connectwise.com';

