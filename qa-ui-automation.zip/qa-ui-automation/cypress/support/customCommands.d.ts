declare namespace Cypress {
  interface Chainable<Subject> {
    singleSignOnUsing1SecMail(email: String, password: String): Chainable<any>
    ssoLogin(email: String, password: String, getCodeFromMailProvider: any): Chainable<any>
    rewriteHeaders(): Chainable<any>
  }
}