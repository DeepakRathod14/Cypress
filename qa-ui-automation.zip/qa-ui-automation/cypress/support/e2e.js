// ***********************************************************
// This example support/e2e.js is processed and
// Loaded automatically before your test files.
//
// This is a great place to put global configuration and
// Behavior that modifies Cypress.
//
// You can change the location of this file or turn off
// Automatically serving support files with the
// 'supportFile' configuration option.
//
// You can read more here:
// https://on.cypress.io/configuration
// ***********************************************************

// Import commands.js using ES2015 syntax:
import './commands';

// Alternatively you can use CommonJS syntax:
// Require('./commands')

import 'cypress-mochawesome-reporter/register';
import 'cypress-real-events';
import '@mmisty/cypress-allure-adapter/support';

import { ApiHelper, LoginHelper } from '../fixtures';

require('@cypress/grep')();
require('cy-verify-downloads').addCustomCommand();


// Hide fetch/XHR requests
const app = window.top;
if (!app.document.head.querySelector('[data-hide-command-log-request]')) {
	const style = app.document.createElement('style');
	style.innerHTML =
        '.command-name-request, .command-name-xhr { display: none }';
	style.setAttribute('data-hide-command-log-request', '');

	app.document.head.appendChild(style);
}

/**
 * This hook will contain set of steps needed to run before each test
 * Method is responsible for login with default user or custom user
 * @example login to the application, check if user is logged in, etc.
 */
beforeEach(() => {
	const currentModule = Cypress.env('module-metadata');

	if (!currentModule && !currentModule?.customUser) {
		new LoginHelper().loginDefaultMigratedUser_1secmail();
	} else {
		new LoginHelper().loginCustomMigratedUser_1secmail(currentModule.customUser);
	}

	// Set common interceptors here
	new ApiHelper().setAliasForGraphQL('GraphQL/', 'ResourceSelector', 'resourceSelector');
    
});

before (() => {
	cy.rewriteHeaders();
});