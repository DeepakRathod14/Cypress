// ***********************************************
// This example commands.js shows you how to
// Create various custom commands and overwrite
// Existing commands.
//
// For more comprehensive examples of custom
// Commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

import 'cypress-file-upload';

const { button, input, baseUrlQA, baseUrlNA, baseUrlEU } = require('../constants');

// Custom Commands goes here

/**
 * Command for using Single Sign On ITS Portal.
 * Pass OTP extraction method of email provider as third parameter.
 */
Cypress.Commands.add('ssoLogin', (email, password, getCodeFromMailProvider) => {
	cy.session(email,
		() => {	

			let url;
			let env = Cypress.env('environment');
			if(env === 'QA'){
				url = baseUrlQA;				
			}
			else if(env === 'PROD-NA'){
				url = baseUrlNA;				
			}
			else if(env === 'PROD-EU'){
				url = baseUrlEU;				
			}

			cy.visit(url + '/login.asp');

			// new screen button click
			cy.contains(button.singleSignOn).should('be.visible').click();

			cy.get(input.email).should('be.visible').type(email);
			cy.contains(button.next).click();

			cy.get(input.password).type(password);
			cy.contains(button.login).click();

			if (getCodeFromMailProvider) {
				getCodeFromMailProvider(email);
				cy.contains(button.login).should('be.visible').click();
			}

			
			//cy.reload();

			cy.wait(5000);

			cy.contains('Workstations & Servers', { timeout: 30000 }).should('be.visible');

			cy.getCookie('sso-token').should('exist');

		},
		{
			cacheAcrossSpecs: true,
			validate() {
				cy.getCookie('sso-token').should('exist');
				cy.url().then((currentUrl) => {
					if (currentUrl === 'about:blank') {
						cy.url().should('contain', 'about:blank');
					} else if (currentUrl.includes('qaplatform.connectwise.com')) {
						cy.url().should('contain', 'qaplatform.connectwise.com');
					}
				});
			}
		},
	);

});

Cypress.Commands.add('rewriteHeaders', () => {
	cy.intercept('*', (req) =>
		req.on('response', (res) => {
			const setCookies = res.headers['set-cookie'];
			res.headers['set-cookie'] = (
				Array.isArray(setCookies) ? setCookies : [setCookies]
			)
				.filter((x) => x)
				.map((headerContent) =>
					headerContent.replace(
						/Secure;/gi,
						'secure; samesite=none;'
					)
				);
		})
	);
});