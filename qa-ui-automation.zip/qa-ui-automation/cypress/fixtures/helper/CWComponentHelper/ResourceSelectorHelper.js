import GridHelper from '../GridHelper';
import InputButtonHelper from '../InputButtonHelper';

/**
 * Helper class for interacting with CW Resource Selector Component.
 * Extends the GridHelper class.
 */
class ResourceSelectorHelper extends GridHelper {
	constructor() {
		super();

		this.inputButton = new InputButtonHelper();
	}

    resourceTypeOptionsArray = () => {
    	return ['companies', 'sites', 'deviceGroups', 'devices', 'alldevices'];
    }

    resourceTypeSitesArray = () => {
    	return ['sites'];
    }

    /**
     * Function to select a resource from the resource selector.
     * @param {string} resourceSelector - Selector for the resource selector.
     * @param {number} index - Index of the resource to select.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectResourceByIndex = (rowSelector, index) => {
    	return this.selectRowByIndexWithCheckbox(rowSelector, index);
    };

    /**
     * Function to select the first resource from the resource selector.
     * @param {string} resourceSelector - Selector for the resource selector.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectFirstResource = (rowSelector) => {        
    	return this.selectRowByIndexWithCheckbox(rowSelector, 0);
    };

    /**
     * Function to select multiple resources using array of indices from the resource selector.
     * @param {string} resourceSelector - Selector for the resource selector.
     * @param {number[]} indices - Array of indices of the resources to select.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectMultipleResourcesByIndex = (rowSelector, indices) => {
    	return this.getElement(rowSelector).then(() => {
    		for (const index of indices) {
    			this.selectRowByIndexWithCheckbox(rowSelector, index);
    		}
    	});
    };

    /**
     * Function to select one or more resources by passing text as array from the resource selector.
     * @param {string} resourceSelector - Selector for the resource selector.
     * @param {string[]} texts - Array of texts of the resources to select. 
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectResourcesByText = (rowSelector, texts) => {
    	return this.getElement(rowSelector).each((element) => {
    		for (const text of texts) {
    			if (element.text().includes(text)) {
    				this.selectRowByIndexWithCheckbox(rowSelector, element.index());
    			}
    		}
    	});
    };

    /**
     * Function to select Resource Type from the resource selector.
     * @param {string} resourceType - Resource Type to select.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectResourceType = ({ resourceType }) => {
    	return this.inputButton.checkInputButton(`input[value='${resourceType}']`);
    };

    /**
     * Function to select Company Resource Type from the resource selector.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectCompanyResourceType = () => {
    	return this.selectResourceType({ resourceType: 'companies' });
    };

    /**
     * Function to select Sites Resource Type from the resource selector.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectSitesResourceType = () => {
    	return this.selectResourceType({ resourceType: 'sites' });
    };

    /**
     * Function to select Device Groups Resource Type from the resource selector.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectDeviceGroupResourceType = () => {
    	return this.selectResourceType({ resourceType: 'deviceGroups' });
    };

    /**
     * Function to select Devices Resource Type from the resource selector.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectDeviceResourceType = () => {
    	return this.selectResourceType({ resourceType: 'devices' });
    };

    /**
     * Function to select All Devices Resource Type from the resource selector.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    selectAllResourcesResourceType = () => {
    	return this.selectResourceType({ resourceType: 'alldevices' });
    };

    /**
     * Function to save Selection of resource selector.
     * @returns {void}
     */
    saveResources = () => {
    	return this.buttonHelper.clickButtonUsingText('Save Selection');
    };

    /**
     * Function to cancel Selection of resource selector.
     * @returns {void}
     */
    cancelResources = () => {
    	return this.buttonHelper.clickButtonUsingText('Cancel');
    };

    /**
     * Function to search for the resource on the Select Target Endpoints
     * @param {string} searchString - Resource Name
     * @returns {void}
     */
    searchResourceByName = (locator, searchString) => {
		const dataTestId = this.wrapDataTestId(locator);
		this.getElementWithIndex(dataTestId, 0).click();
		return this.getElement('.MuiInputBase-root.MuiInput-root.MuiInput-underline.MuiInputBase-adornedStart.MuiInputBase-adornedEnd').type(searchString);       
	}

}

export default ResourceSelectorHelper;