/* eslint-disable no-mixed-spaces-and-tabs */
/* eslint-disable camelcase */
import { input, rqt } from '../../constants';
import CommonHelper from './CommonHelper';
class LoginHelper extends CommonHelper{

	constructor() {
		super();
		// loading user data using cy.fixture
		cy.fixture(`data/${this.env}/user-credentials.json`).as('user-data');
	}

    /**
     * Login with custom migrated user having 1secmail verification.
     * @param {string} customUserName - Name of the custom user to login with.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    loginCustomMigratedUser_1secmail = (customUserName) => {
    	cy.get('@user-data').then((users) => {
    		const customUser = users?.migrated[customUserName];
			if (!customUser) {
				// preventing test case to fail if no user data found
				throw new Error(`No user data found for given ${this.env} environment and ${customUserName} user`);
			}
    		this.ssoLogin1SecMail(customUser);
    	});
    }

    /**
     * Login with default migrated user having 1secmail verification.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    loginDefaultMigratedUser_1secmail = () => {
    	cy.get('@user-data').then((users) => {
    		var defaultUser;

    		if (this.thread) {
    			defaultUser = users?.migrated[`user_${this.thread}`];
    		} else {
    			defaultUser = users?.migrated['user_default'];
    		}

			if (!defaultUser) {
				// preventing test case to fail if no user data found
				throw new Error(`No default user data found for given ${this.env} environment`);
			}
    		this.ssoLogin1SecMail(defaultUser);
    	});
    }

    /**
s     * Return the user with respect to the data sent in parameters
     * if threadIndex is set i.e. parallel execution then set user based on thread index
     * else if custom flag is set then set user based on preference
     * else set default user from `user-credentials.json`
     */
    getUserBasedOnData = (users, {threadIndex, customFlag, customUserIndex}) => {
    	if (customFlag) {
    		return users.migrated[`user_${customUserIndex}`];
    	} else if (threadIndex) {
    		return users.migrated[`user_${threadIndex}`];
    	} else {
    		return users.migrated['user_default'];
    	}
    }

    ssoLogin1SecMail(user) {
    	cy.wrap(user).as('currUserData');
    	user.verificationCodeEnabled
    		? cy.ssoLogin(user.email, user.password, this.get1SecMailCode)
    		: cy.ssoLogin(user.email, user.password, null);
    }

    logout() {
    	cy.get('*[class^="its-top-right-menu__list__item"]').last().realHover();
    	cy.contains('Sign out').click();
    	cy.contains('YES').click();
    }

    get1SecMailCode(email) {
    	// extract User from email
    	const user = email.split('@')[0];

    	// 1secmail third party APIS
    	const URL = `https://www.1secmail.com/api/v1/?&domain=1secmail.com&login=${user}&action`;
    	const getMessageId = `${URL}=getMessages`;

    	// buffer wait
    	cy.wait(10000);

    	// get code from API 
    	cy.request(rqt.Get, getMessageId).its('body[0].id')
    		.then(id => cy.request(rqt.Get, `${URL}=readMessage&id=${id}`).its('body.body'))
    		.then((body) => {
    			const code = body.split('\n')[0].split(':')[1].trim() ?? '';
    			// debugger
    			cy.get(input.code).type(code);
    		});
    }
}

export default LoginHelper;