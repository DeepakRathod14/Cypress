import CommonHelper from './CommonHelper';
import DropDownHelper from './DropDownHelper';
import ButtonHelper from './ButtonHelper';
import { gridLtr } from '../../constants';

/**
 * Helper class for interacting with grids.
 * Extends the CommonHelper class.
 */
class GridHelper extends CommonHelper {
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.dropdownHelper = new DropDownHelper();
	}

	/**
	 * Function to select a row in the grid.
	 * @param {string} gridSelector - Selector for the grid element.
	 * @param {number} rowIndex - Index of the row to select.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	selectRow = (gridSelector, rowIndex) => {
		const checkboxSelector = `${gridSelector} tbody tr:nth-child(${rowIndex}) td:first-child input[type="checkbox"]`;
		return this.getElement(checkboxSelector).click({ force: true });
	};

	/**
	 * Function to check if a column is visible in the grid.
	 * @param {string} gridSelector - Selector for the grid element.
	 * @param {number} columnIndex - Index of the column to check.
	 * @returns {boolean} - True if the column is visible, false otherwise.
	 */
	isColumnVisible = (gridSelector, columnIndex) => {
		const columnSelector = `${gridSelector} thead th:nth-child(${columnIndex})`;
		return this.getElement(columnSelector).should('be.visible');
	};

	/**
	 * Function to check if the columns appear in the correct order in the grid.
	 * @param {string} gridSelector - Selector for the grid element.
	 * @param {Array<number>} columnOrder - Array of column indices representing the expected order.
	 * @returns {boolean} - True if the columns appear in the correct order, false otherwise.
	 */
	checkColumnOrder = (gridSelector, columnOrder) => {
		const headerSelector = `${gridSelector} thead th`;
		return this.getElements(headerSelector).then((headers) => {
			const actualOrder = headers.map((_, index) => index + 1);
			return JSON.stringify(actualOrder) === JSON.stringify(columnOrder);
		});
	};

	/**
	 * Function to validate the data in the grid.
	 * @param {string} gridSelector - Selector for the grid element.
	 * @param {Array<Array<string>>} expectedData - Expected data in the grid.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	validateGridData = (gridSelector, expectedData) => {
		const rowSelector = `${gridSelector} tbody tr`;
		return this.getElements(rowSelector).each((row, rowIndex) => {
			const columns = row.find('td');
			expectedData[rowIndex].forEach((expectedValue, columnIndex) => {
				expect(columns.eq(columnIndex)).to.have.text(expectedValue);
			});
		});
	};

	/**
	 * Function to change the view of the grid and assert the row height changes.
	 * @param {string} gridSelector - Selector for the grid element.
	 * @param {string} view - The view to switch to (comfortable, standard, compact).
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	changeGridView = (rowSelector, view) => {
		// Assert that the row height changes based on the view
		this.getElement(rowSelector).each((row) => {
			switch (view) {
				case 2:
					cy.wrap(row).should('have.css', 'height', '67px');
					break;
				case 1:
					cy.wrap(row).should('have.css', 'height', '52px');
					break;
				case 0:
					cy.wrap(row).should('have.css', 'height', '36px');
					break;
				default:
					throw new Error('Invalid view specified');
			}
		});
	};

	/**
	 * Function to scroll grid to the end.
	 * @param {string} gridScrollSelector - Selector for the grid element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	scrollGridToBottom = (gridScrollSelector) => {
		this.getElement(gridScrollSelector).scrollTo('bottom');
	};

	/**
	 * Function to scroll grid to the start.
	 * @param {string} gridScrollSelector - Selector for the grid element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	scrollGridToTop = (gridScrollSelector) => {
		this.getElement(gridScrollSelector).scrollTo('top');
	};

	scrollGridToFirstTop = (gridScrollSelector) => {
		this.getElement(gridScrollSelector).first().scrollTo('top');
	};

	/**
	 * Function to calculate the row count.
	 * @param {string} rowSelector - Selector for the row element.
	 * @param {string} gridScrollSelector - Selector for the grid element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getRowCount = (gridScrollSelector, rowSelector) => {
		this.scrollGridToBottom(gridScrollSelector);
		cy.wait(100);
		this.getElement(rowSelector)
			.last()
			.then((lastRow) => {
				const rowIndex = lastRow.attr('data-rowindex');
				cy.log(`Row index of the last row: ${rowIndex}`);
			});
	};

	/**
	 * Function to get the row count element from UI.
	 * @param {string} rowSelector - Selector for the row element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getRowCountElement = (rowCountSelector) => {
		return this.getElement(rowCountSelector);
	};

	/**
	* Function to get the row checkbox
	* @param {string} rowInputSelector - Selector for the row checkbox.
	* @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	*/
	getRowCheckbox = (rowInputSelector) => {
		return this.getElement(rowInputSelector);
	};

	/**
	 * Function to validate first row exists.
	 * @param {string} rowSelector - Selector for the row element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	validateFirstRowExists = (rowSelector) => {
		return this.getElementWithIndexAndAssertion(rowSelector, 0, 'exist');
	};

	/**
	 * Function to validate last row exists.
	 * @param {string} gridScrollSelector - Selector for the grid element.
	 * @param {string} rowSelector - Selector for the row element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	validateLastRowExists = (gridScrollSelector, rowSelector) => {
		this.scrollGridToBottom(gridScrollSelector);
		cy.wait(100);
		return this.getElement(rowSelector).last().should('exist');
	};

	/**
	 * Function to select a row with a specific index.
	 * @param {string} rowSelector - Selector for the row element.
	 * @param {number} rowIndex - Index of the row to select.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	selectRowByIndex = (rowSelector, rowIndex) => {
		return this.getElementWithIndex(rowSelector, rowIndex).check();
	};

	/**
	 * Function to select a row with a specific index using checkbox.
	 * @param {string} rowSelector - Selector for the row element.
	 * @param {number} rowIndex - Index of the row to select.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	selectRowByIndexWithCheckbox = (rowSelector, rowIndex) => {
		return this.getElementWithIndex(rowSelector, rowIndex).find('input').check({ force: true });
	}

	deselectRowByIndexWithCheckbox = (rowSelector, rowIndex) => {
		return this.getElementWithIndex(rowSelector, rowIndex).find('input').uncheck({ force: true });
	}

	validateRowIndexHasText = (rowSelector, rowIndex, text) => {
		return this.getElementWithIndex(rowSelector, rowIndex).should('contain.text', text);
	};

	/**
	 * Function to get a row with a specific index.
	 * @param {string} rowSelector - Selector for the row element.
	 * @param {number} rowIndex - Index of the row to select.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getRowByIndex = (rowSelector, rowIndex) => {
		return this.getElementWithIndex(rowSelector, rowIndex);
	};

	/**
	 * Function to filter a column in the grid using dropdown helper.
	 * @param {string} filterButtonSelector - Selector for the filter button element.
	 * @param {string} filterSelector - Selector for the filter element.
	 * @param {string} columnName - Name of the column to filter.
	 * @param {string} operator - Operator to use for filtering.
	 * @param {string} value - Value to filter by.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	filterColumn = (
		filterButtonSelector,
		filterSelector,
		columnName,
		operator,
		value
	) => {
		this.buttonHelper.clickButtonWithIndex(filterButtonSelector, 1);
		this.dropdownHelper.selectDropdownValue(filterSelector, 1, columnName);
		this.dropdownHelper.selectDropdownValue(filterSelector, 2, operator);
		this.dropdownHelper.selectDropdownValue(filterSelector, 3, value);
	};

	/**
	 * Function to sort a column in the grid.
	 * @param {string} columnHeaderSelector - Selector for the header element.
	 * @param {number} columnIndex - Index of the column to sort.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	sortColumn = (columnHeaderSelector, columnIndex) => {
		return this.getElement(columnHeaderSelector).eq(columnIndex).click();
	};

	/**
	 * Function to hide a column in the grid.
	 * @param {string} panelSelector - Selector for the panel element.
	 * @param {number} columnIndex - Index of the column to sort.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	hideColumn = (panelSelector, columnIndex) => {
		return this.getElement(panelSelector).eq(columnIndex).click();
	};

	/**
	 * Function to search in the grid.
	 * @param {string} searchIconSelector - Selector for the search icon element.
	 * @param {string} entryName - Entry name to search for.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	searchEntryInGrid = (searchIconSelector, entryName) => {
		this.buttonHelper
			.clickButton(searchIconSelector);
		this.getElement('.MuiDataGrid-toolbarContainer')
			.find('input[type=\'search\']')
			.type(entryName);
	};

	searchEntryInGridNew = (searchIconSelector, entryName) => {
		this.getElement(searchIconSelector)
			.type(entryName);
	};


	/**
	 * Function to get the text from the first row based on column index.
	 * @param {string} rowSelector - Selector for the row element.
	 * @param {string} cellSelector - Selector for the cell element.
	 * @param {number} columnIndex - Index of the column to sort.
	 */
	getTextFromFirstRowBasedOnColumnIndex = (rowSelector, cellSelector, columnIndex) => {
		return this.getRowByIndex(rowSelector, 0).find(cellSelector).eq(columnIndex).invoke('text').then((text) => {
			return text;
		});
	};

	/**
	 * Function to check if the sorting arrow is visible on a given field.
	 * @param {string} field - Name of the field to check.
	 * @param {object} fieldMap - Mapping of field names to column indices.
	 * @param {string} sortingOrder - Sorting order to check for.	
	 */
	checkIfSortingArrowIsVisibleOnGivenField(field, fieldMap, sortingOrder) {
		let iconLocator;

		if (sortingOrder === 'ascending') {
			iconLocator = 'ArrowUpwardIcon';

			this.getElement(this.wrapDataTestId(iconLocator))
				.eq(fieldMap[field])
				.should('be.visible');
		} else {
			iconLocator = 'ArrowDownwardIcon';
			this.getElement(this.wrapDataTestId(iconLocator))
				.should('be.visible');
		}

	}

	/**
	 * Function to click on cell contents from the first row based on column index.
	 * @param {string} rowSelector - Selector for the row element.
	 * @param {string} cellSelector - Selector for the cell element.
	 * @param {number} columnIndex - Index of the column to sort.
	 */
	clickOnTextFromFirstRowBasedOnColumnIndex = (rowSelector, cellSelector, columnIndex) => {
		return this.getRowByIndex(rowSelector, 0).find(cellSelector).eq(columnIndex).invoke('text').then((text) => {
			cy.contains(text).click();
		});
	};

	/**
	 * Returns columnName wrapped with data-field attribute.
	 * @param {string} columnName - The columnName to be wrapped.
	 * @returns {string} - The wrapped locator.
	 */
	wrapGridColumn(columnName) {
		return `div[data-field=${columnName}] .MuiDataGrid-columnHeaderTitleContainer`;
	}

	/**
	 * Returns columnName wrapped with data-field attribute and menu button.
	 * @param {string} columnName - The columnName to be wrapped.
	 * @returns {string} - The wrapped locator.
	 */
	wrapFilterMenu(columnName) {
		return `div[data-field=${columnName}] div.MuiDataGrid-menuIcon button`;
	}

	/**
	 * Returns columnName wrapped with data-field attribute and filter icon of popup.
	 * @param {string} columnName - The columnName to be wrapped.
	 * @returns {string} - The wrapped locator.
	 */
	wrapColumnFilterIcon(columnName) {
		return `div[data-field=${columnName}] svg[data-testid="FilterAltIcon"]`;
	}

	/**
	 * Returns columnName wrapped with data-field attribute and svg with data-testid.
	 * @param {string} columnName - The locator to be wrapped.
	 * @param {sortBy} sortBy - values should be ascending or descending
	 * @returns {string} - The wrapped locator.
	 */
	wrapSortButtonByColumnName(columnName, sortBy) {
		const sortOrder = {
			ascending: 'ArrowUpwardIcon',
			descending: 'ArrowDownwardIcon'
		};
		return `div[data-field=${columnName}] svg[data-testid="${sortOrder[sortBy]}"]`;
	}

	/**
	 * Function helps to get the data content of any row with mentioned column name, 
	 * this will not break even when we change the column order. 
	 * Returns locator wrapped with rowindex & data-field 
	 * @param {number} rowIndex - wrapped with rowIndex.
	 * @param {string} column Name - wrapped with data-field
	 * @returns {string} - The wrapped locator.
	 */
	wrapGridContent(rowIndex, colName) {
		return `[data-rowindex="${rowIndex}"] > [data-field="${colName}"] div.MuiDataGrid-cellContent`
	}

	/**
	 * Function will check if data grid content is visible at give locators
	 * @param {number} rowIndex - wrapped with rowIndex.
	 * @param {string} column Name - wrapped with data-field
	 * @returns {string} - The wrapped locator.
	 */
	checkGridsDataPresent(rowIndex, colName) {
		return this.checkElementIsVisible(this.wrapGridContent(rowIndex, colName));
	}

	/**
	 * Function is used to validate the filtering on a MUI data grid that has column filtering enabled with a collection type. The steps to validate the filtering are as follows:
	 * 1. Open the filters popup by clicking on the menu icon near the column header.
	 * 2. Click on the filter option, which will open the filter popup with the default selected column.
	 * 3. Select the first option from the dropdown or collection and also get the first option.
	 * 4. Expect that the first selected option should be present in the first row and the given column of the grid.
	 * @param {string} columnName 
	 * @param {number} optionIndex
	 */
	validateGridCollectionFilters(columnName, optionIndex) {
		const ltrColName = this.wrapFilterMenu(columnName);
		this.buttonHelper.getElement(ltrColName).click({ force: true });
		this.buttonHelper.clickButton(gridLtr.filterIcon);
		this.buttonHelper.clickButton(gridLtr.filterInput);
		// select the option and given by index
		const selectOption = gridLtr.getFilterOption(optionIndex);
		this.getTextOfElement(selectOption).then((text) => {
			this.buttonHelper.clickButton(selectOption);
			// Check the first row of the grid to see if the text is present
			// cy.get(this.wrapGridContent(0, columnName)).should('have.text', text.trim());
			// Check if the filter icon is visible
			this.checkElementIsVisible(this.wrapColumnFilterIcon(columnName));
		});
	}

	checkMuiDataGridRowByIndex(rowIndex) {
		this.buttonHelper.clickButton(gridLtr.getCheckBoxByIndex(rowIndex));
	}
	/**
	 * Function to validate sorting order by validating sort icon by given column name
	 * @param {string} columnName to check on which sorting is applied 
	 * @param {string} sortOrder values should be ascending or descending
	 */
	checkSortingIsVisible(columnName, sortOrder) {
		this.checkElementIsVisible(this.wrapSortButtonByColumnName(columnName, sortOrder));
	}

	/**
	 * Function to removes all applied filters
	 */
	removeAllFilters() {
		this.buttonHelper.clickButton(gridLtr.gridToolBarRemoveButton);
		this.buttonHelper.clickButton(gridLtr.gridFilterPanelRemoveAllButton);
		this.buttonHelper.clickButton(gridLtr.gridFilterPanelRemoveAllButton);
	}
}

export default GridHelper;

