import CommonHelper from './CommonHelper';

/**
 * Helper class for interacting with toasts.
 * Extends the CommonHelper class.
 */
class ToastHelper extends CommonHelper {
    /**
     * Function to check if a toast is visible.
     * @param {string} toastSelector - Selector for the toast to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    checkToastIsVisible = (toastSelector) => {
        return this.checkElementIsNotVisible(toastSelector);
    };

    /**
     * Function to check if a toast is visible with a specific text.
     * @param {string} toastSelector - Selector for the toast to check.
     * @param {string} text - Text to check for in the toast.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    checkToastIsVisibleWithText = (toastSelector, text) => {
        return this.checkElementIsVisibleWithText(toastSelector, text);
    };

    /**
     * Function to check if a toast has a specific color.
     * @param {string} toastSelector - Selector for the toast to check.
     * @param {string} color - Color to check for in the toast.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    checkToastAttributeColor = (toastSelector, color) => {
        return this.getElement(toastSelector).should('have.css', 'color', color);
    };

    /**
     * Function to check if a toast has an icon.
     * @param {string} toastSelector - Selector for the toast to check.
     * @param {string} iconSelector - Selector for the icon to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    checkToastHasIcon = (toastSelector, iconSelector) => {
        return this.getElement(toastSelector).find(iconSelector).should('be.visible');
    };

    /**
     * Function to check if a toast has a specific color and icon.
     * @param {string} toastSelector - Selector for the toast to check.
     * @param {string} iconSelector - Selector for the icon to check.
     * @param {string} color - Color to check for in the toast.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    checkToastAttributeAndIcon = (toastSelector, iconSelector, color) => {
        return this.checkToastAttributeColor(toastSelector, color).find(iconSelector).should('be.visible');
    };

    /**
     * Function to check if a toast is visible with a specific text and icon.
     * @param {string} toastSelector - Selector for the toast to check.
     * @param {string} iconSelector - Selector for the icon to check.
     * @param {string} message - Text to check for in the toast.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    validateToastMessage(toastSelector, iconSelector, message) {
        this.checkToastIsVisibleWithText(toastSelector, message);
        this.checkElementIsVisible(iconSelector);
    };

}


export default ToastHelper;