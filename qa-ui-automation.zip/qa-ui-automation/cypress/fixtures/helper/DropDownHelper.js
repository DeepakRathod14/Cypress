import CommonHelper from './CommonHelper';

class DropDownHelper extends CommonHelper {
    /**
    * Function to select a value from a dropdown.
    * @param {string} dropdownSelector - Selector for the dropdown element.
    * @param {number} index - Index of the dropdown element.
    * @param {string} value - Value to select from the dropdown.
    * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
    */
    selectDropdownValue = (dropdownSelector, index, value) => {
    	return this.getElementWithIndex(dropdownSelector, index).select(value);
    };

    /**
     * Function to get a dropdown element and select a value from it.
     * @param {string} dropDownFieldSelector - Selector for the dropdown field.
     * @param {string} dropdownSelector - Selector for the dropdown element.
     * @param {string} value - Value to select from the dropdown.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    getDropDownAndSelectValue = (dropDownFieldSelector, dropdownSelector, value) => {
    	this.getElement(dropDownFieldSelector).click();
    	this.getElement(dropdownSelector)
    		.last()
    		.contains(value)
    		.click();
    };

    getDropDownAndVerifySelectedValue = (dropDownFieldSelector, dropdownSelector, value) => {
    	this.getElement(dropDownFieldSelector).click();
    	this.getElement(dropdownSelector)
            .find('li[aria-selected=\'true\']')            
            .contains(value)
            .last()
            .contains(value)
            .click();
    };

    /**
     * Function to get a dropdown element and select the first value from it.
     * @param {string} dropDownFieldSelector - Selector for the dropdown field.
     * @param {string} dropdownSelector - Selector for the dropdown element.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    getDropDownAndSelectFirstValue = (dropDownFieldSelector, dropdownSelector) => {
    	this.getElement(dropDownFieldSelector).click();        
    	this.getElement(dropdownSelector)
    		.last()
    		.find('li')
    		.first()
    		.click();
    };

}

export default DropDownHelper;

