import { faker } from '@faker-js/faker';
import { baseUrlQA, baseUrlEU, baseUrlNA } from '../../constants';

/**
 * Helper class for common Cypress operations.
 */
class CommonHelper {

	constructor() {
		this.env = Cypress.env('environment');
		this.thread = Cypress.env('thread') ?? null;
	}

	/**
	 * Get fake name.
	 * @returns {string} - The fake name.
	 */
	getFakeName = () => {
		return 'FAKE_' + faker.string.alphanumeric({ length: 10 });
	};

	/**
	 * Get fake number based on length.
	 * @param {number} length - The length of the fake number.
	 * @returns {number} - The fake number.
	 */
	getFakeNumber = (length) => {
		return faker.number({ length: length });
	};

	/**
	 * Get fake date and time.
	 * @returns {string} - The fake date and time.
	 */
	getFakeDateAndTime = () => {
		return faker.date.future().toString();
	};

    /**
     * Get fake date.
     * @returns {string} - The fake date.
     */
    getFakeDate = () => {
    	return faker.date.future().toDateString();
    };

    /**
     * Get future fake date and time.
     * @returns {string} - The future fake date and time.
     */
    getFutureFakeDateTime = () => {
    	return faker.date.future().toString();
    };

    /**
     * Get future fake date and time in ISO format.
     * @returns {string} - The future fake date and time in ISO format.
     */
    getFutureFakeDateTimeIso = () => {
        return faker.date.future().toISOString();
    };

    /**
     * Get fake description.
     * @returns {string} - The fake description.
     */
    getFakeDescription = () => {
    	return 'FAKE_DESCRIPTION: ' + faker.word.words({ count: 5 });
    };

    /**
     * Get fake message.
     * @param {number} length - The length of the fake message.
     */
    getFakeMessage = (length) => {
    	return 'FAKE_MESSAGE: ' + faker.word.words({ count: length });
    };

	/**
	 * Get fake alphanumeric value.
	 * @param {number} count - The count of the fake value.
	 * @returns {string} - The fake value.
	 */
	getFakeValue = (count) => {
		return faker.string.alphanumeric(count);
	};

    /**
     * Get fake UUID.
     * @returns {string} - The fake UUID.
     */
    getFakeUuid = () => {
    	return faker.string.uuid();
    };
    
    /**
     * Get future formatted date
     * @returns {string} - The future formatted date.
     * @example 'Sep 30 2029 11 00 PM'
     */
    getFormattedFakeDate = () => {
    	const dateTime = this.getFutureFakeDateTime().split(' ').slice(1, 5);
    
    	//format time
    	const time = dateTime[3].split(':');
    	let hour = parseInt(time[0]) > 12 ? (parseInt(time[0]) - 12).toString() : time[0];
    	if(hour.length === 1) hour = '0' + hour;

    	return `${dateTime[0]} ${dateTime[1]} ${dateTime[2]} ${hour} ${time[1]} PM`;
    };

	/**
	 * Sets up the test module metadata.
	 * @param {object} setupObject - The setup object to be set.
	 * @returns {void}
	 */
	setup = (setupObject) => {
		Cypress.env('module-metadata', setupObject);
	}

	/**
	 * Cleans up the test module metadata.
	 * @returns {void}
	 */
	cleanup = () => {
		Cypress.env('module-metadata', null);
	}

	/**
	 * Returns value wrapped with data-value attribute.
	 */
	wrapDataValue(value) {
		return `[data-value="${value}"]`;
	}

	/**
	 * Returns locator wrapped with data-testid attribute.
	 * @param {string} locator - The locator to be wrapped.
	 * @returns {string} - The wrapped locator.
	 */
	wrapDataTestId(locator) {
		return `[data-testid="${locator}"]`;
	}

	/**
	 * Returns locator wrapped with data-cy attribute.
	 * @param {string} locator - The locator to be wrapped.
	 * @returns {string} - The wrapped locator.
	 */
	wrapDataCy(locator) {
		return `[data-cy="${locator}"]`;
	}

	/**
	 * Navigates to the page if the current URL does not match the URL to navigate to.
	 * @param {string} module - The URL to navigate to.
	 * @returns {void}
	 */
	navigateToPageOnCheck = (module) => {
		this.navigateToPage(module);
    	cy.contains(module).should('be.visible');
	};

	navigateToPage = (module) => {
		cy.fixture('data/portal.json').then((links) => {
			const URL = links[module];
			cy.url().then((currURL) => {
				if (!this.stripQueryParams(currURL).endsWith(this.stripQueryParams(URL))) {	
					cy.visit(this.getEnvUrl() + URL);
				}
			});
		});    	
	};

	getEnvUrl(){        
        let url;
            if(this.env === "QA"){
                url = baseUrlQA;
            }
            else if(this.env === "PROD-NA"){
                url = baseUrlNA;
            }
            else if(this.env === "PROD-EU"){
                url = baseUrlEU;
            }
        return url;
    }

	/**
     * Closes all present elements with the given locator.
     * @param {string} closeIconLocator - The locator of the close icon.
     * @returns {void}
     */
	closeOpenElements(closeIconLocator) {
		this.getElement('body').then(($body) => {
			if($body.find(closeIconLocator).length > 0) {
				this.getElement(closeIconLocator).then((icons) => {
					cy.wrap(icons).each((icon) => {
						cy.wrap(icon).click();
					});
				});
			}
		});
	}

	/**
     * Checks if Grid Api is loaded and returns flag as well as response.
     * @param {string} alias - The alias of the API.
     * @param {boolean} gridApiFlag - The flag to check if the API is loaded.
     * @param {object} gridApiResponse - The response of the API.
     * @returns {void}
     */
	checkOnGridApiAndSaveResponse(alias, classInstFlag, classInstResponse) {
		if (!classInstFlag) {
			cy.wait(alias, {timeout: 25000}).then((response) => {
				classInstResponse = response;
				classInstFlag = true;
				cy.wrap({ classInstFlag, classInstResponse }).as('checkOnGridApiAndSaveResponse');
			});
		} else {
			cy.wrap({ classInstFlag, classInstResponse }).as('checkOnGridApiAndSaveResponse');
		}
        
	}

    /**
     * Strips query parameters from the URL.
     * @param {string} url - The URL to strip query parameters from.
     * @returns {string} - The URL without query parameters.
     */
    stripQueryParams = (url) => url.split('?')[0]

    /**
     * Gets an element using the locator.
     * @param {string} locator - The locator of the element.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    getElement = (locator) => {
    	return cy.get(locator);
    };

    /**
     * Gets first element using the locator.
     * @param {string} locator - The locator of the element.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    getFirstElement = (locator) => {
    	return cy.get(locator).first();
    };

    /**
     * Gets last element using the locator.
     * @param {string} locator - The locator of the element.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    getLastElement = (locator) => {
    	return cy.get(locator).last();
    };

	/**
	 * Gets an element using the locator and text.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithText = (locator, text) => {
		return cy.get(locator).contains(text);
	}

	/**
	 * Gets an element using the locator and index.
	 * @param {string} locator - The locator of the element.
	 * @param {number} index - The index of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.   
	 */
	getElementWithIndex = (locator, index) => {
		return cy.get(locator).eq(index);
	}

	/**
	 * Gets an element using the locator, text and index.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} index - The index of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithTextAndIndex = (locator, text, index) => {
		return cy.get(locator).contains(text).eq(index);
	}

	/**
	 * Gets an element using the locator and wait time.
	 * @param {string} locator - The locator of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.   
	 */
	getElementWithWait = (locator, waitTime) => {
		return cy.get(locator, { timeout: waitTime });
	}

	/**
	 * Gets an element using the locator, text and wait time.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithTextAndWait = (locator, text, waitTime) => {
		return cy.get(locator).contains(text, { timeout: waitTime });
	}

	/**
	 * Gets an element using the locator with assertion.
	 * @param {string} locator - The locator of the element.
	 * @param {string} assertion - The assertion to be performed on the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithAssertion = (locator, assertion) => {
		return cy.get(locator).should(assertion);
	}

	/**
	 * Gets an element using the locator, text and assertion.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {string} assertion - The assertion to be performed on the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithTextAndAssertion = (locator, text, assertion) => {
		return cy.get(locator).contains(text).should(assertion);
	}

	/**
	 * Gets an element using the locator, index and assertion.
	 * @param {string} locator - The locator of the element.
	 * @param {number} index - The index of the element.
	 * @param {string} assertion - The assertion to be performed on the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithIndexAndAssertion = (locator, index, assertion) => {
		return cy.get(locator).eq(index).should(assertion);
	}

	/**
	 * Gets an element using the locator, text, index and assertion.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} index - The index of the element.
	 * @param {string} assertion - The assertion to be performed on the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithTextIndexAndAssertion = (locator, text, index, assertion) => {
		return cy.get(locator).contains(text).eq(index).should(assertion);
	}

	/**
	 * Gets an element using the locator, wait time and assertion.
	 * @param {string} locator - The locator of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @param {string} assertion - The assertion to be performed on the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithWaitAndAssertion = (locator, waitTime, assertion) => {
		return cy.get(locator, { timeout: waitTime }).should(assertion);
	}

	/**
	 * Gets an element using the locator, text, wait time and assertion.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @param {string} assertion - The assertion to be performed on the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithTextWaitAndAssertion = (locator, text, waitTime, assertion) => {
		return cy.get(locator).contains(text, { timeout: waitTime }).should(assertion);
	}

	/**
	 * Gets an element using the locator, index, wait time and assertion.
	 * @param {string} locator - The locator of the element.
	 * @param {number} index - The index of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @param {string} assertion - The assertion to be performed on the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithIndexWaitAndAssertion = (locator, index, waitTime, assertion) => {
		return cy.get(locator).eq(index, { timeout: waitTime }).should(assertion);
	}

	getElementWithIndexAndWait = (locator, index, waitTime) => {
		return cy.get(locator).eq(index, { timeout: waitTime });
	}

	/**
	 * Gets an element using the locator, text, index, wait time and assertion.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} index - The index of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @param {string} assertion - The assertion to be performed on the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementWithTextIndexWaitAndAssertion = (locator, text, index, waitTime, assertion) => {
		return cy.get(locator).contains(text).eq(index, { timeout: waitTime }).should(assertion);
	}

	/**
	 * Gets an element using the locator and checks if it is visible.
	 * @param {string} locator - The locator of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsVisible = (locator) => {
		return cy.get(locator).scrollIntoView().should('be.visible');
	}

	/**
	 * Gets an element using the locator, text and checks if it is visible.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsVisibleWithText = (locator, text) => {
		return cy.get(locator).contains(text).should('be.visible');
	}

	/**
	 * Gets an element using the locator, index and checks if it is visible.
	 * @param {string} locator - The locator of the element.
	 * @param {number} index - The index of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsVisibleWithIndex = (locator, index) => {
		return cy.get(locator).eq(index).should('be.visible');
	}

	/**
	 * Gets an element using the locator, text, index and checks if it is visible.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} index - The index of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsVisibleWithTextAndIndex = (locator, text, index) => {
		return cy.get(locator).contains(text).eq(index).should('be.visible');
	}

	/**
	 * Gets an element using the locator, wait time and checks if it is visible.
	 * @param {string} locator - The locator of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsVisibleWithWait = (locator, waitTime) => {
		return cy.get(locator, { timeout: waitTime }).should('be.visible');
	}

	/**
	 * Gets an element using the locator, text, wait time and checks if it is visible.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsVisibleWithTextAndWait = (locator, text, waitTime) => {
		return cy.get(locator).contains(text, { timeout: waitTime }).should('be.visible');
	}

	/**
	 * Gets an element using the locator, index, wait time and checks if it is visible.
	 * @param {string} locator - The locator of the element.
	 * @param {number} index - The index of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsVisibleWithIndexAndWait = (locator, index, waitTime) => {
		return cy.get(locator).eq(index, { timeout: waitTime }).should('be.visible');
	}

	/**
	 * Gets an element using the locator, text, index, wait time and checks if it is visible.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} index - The index of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsVisibleWithTextIndexAndWait = (locator, text, index, waitTime) => {
		return cy.get(locator).contains(text).eq(index, { timeout: waitTime }).should('be.visible');
	}

	/**
	 * Gets an element using the locator and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsNotVisible = (locator) => {
		return cy.get(locator).should('not.be.visible');
	}

	/**
	 * Gets an element using the locator and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementNotExist = (locator) => {
		return cy.get(locator).should('not.exist');
	}

	/**
	 * Gets an element using the locator, text and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsNotVisibleWithText = (locator, text) => {
		return cy.get(locator).contains(text).should('not.be.visible');
	}

	/**
	 * Gets an element using the locator, index and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @param {number} index - The index of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsNotVisibleWithIndex = (locator, index) => {
		return cy.get(locator).eq(index).should('not.be.visible');
	}

	/**
	 * Gets an element using the locator, text, index and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} index - The index of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsNotVisibleWithTextAndIndex = (locator, text, index) => {
		return cy.get(locator).contains(text).eq(index).should('not.be.visible');
	}

	/**
	 * Gets an element using the locator, wait time and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.   
	 */
	checkElementIsNotVisibleWithWait = (locator, waitTime) => {
		return cy.get(locator, { timeout: waitTime }).should('not.be.visible');
	}

	/**
	 * Gets an element using the locator, text, wait time and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.   
	 */
	checkElementIsNotVisibleWithTextAndWait = (locator, text, waitTime) => {
		return cy.get(locator).contains(text, { timeout: waitTime }).should('not.be.visible');
	}

	/**
	 * Gets an element using the locator, index, wait time and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @param {number} index - The index of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	checkElementIsNotVisibleWithIndexAndWait = (locator, index, waitTime) => {
		return cy.get(locator).eq(index, { timeout: waitTime }).should('not.be.visible');
	}

	/**
	 * Gets an element using the locator, text, index, wait time and checks if it is not visible.
	 * @param {string} locator - The locator of the element.
	 * @param {string} text - The text of the element.
	 * @param {number} index - The index of the element.
	 * @param {number} waitTime - The wait time for the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.   
	 */
	checkElementIsNotVisibleWithTextIndexAndWait = (locator, text, index, waitTime) => {
		return cy.get(locator).contains(text).eq(index, { timeout: waitTime }).should('not.be.visible');
	}

	/**
	 * Gets the text of an element using the locator.
	 * @param {string} locator - The locator of the element.
	 * @returns {Cypress.Chainable<string>} - The Cypress chainable object representing the text of the element.
	 */
	getTextOfElement = (locator) => {
		return cy.get(locator).invoke('text');
	}

	/**
	 * Refreshes the page.
	 */	
	pageReload = () => {
		cy.reload();
	}

	/**
	 * Gets the element based on attribute 'datatestid'.
	 * @param {string} locator - The locator of the element.
	 * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
	 */
	getElementBydatatestid = (elementdatatestid) => {
		return this.getElement(this.wrapDataTestId(elementdatatestid));
	}

	/**
	 * Get future formateed date for manual patch approval
	 * @returns {string} - The future formatted date.
	 * @example '09/30/2025-11:00 PM'
	 */
	getFormattedDate = () => {
    	const dateTime = this.getFutureFakeDateTime().split(' ').slice(1, 5);
    	//format time
    	const time = dateTime[3].split(':');
    	let hour = parseInt(time[0]) > 12 ? (parseInt(time[0]) - 12).toString() : time[0];
    	if(hour.length === 1) hour = '0' + hour;
    	return `${this.getMonthNumber(dateTime[0])}/${dateTime[1]}/${dateTime[2]}-${hour}:${time[1]} PM`;
    };
	
	/**
	 * Get Month no id 2 digit format from month name
	 * @param {*} monthName 
	 * @returns Month no id
	 */
	getMonthNumber = (monthName) => {
		const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		const monthIndex = months.findIndex(month => month.toLowerCase().startsWith(monthName.toLowerCase()));
		if (monthIndex !== -1) {
			const monthNumber = monthIndex + 1;
			return monthNumber.toString().padStart(2, '0');
			// Adding 1 to match the month numbers (1-12) 
			//// Using padStart to ensure 2-digit format with leading zeros
		} else {
			return -1;
			// Return -1 if the month name is not found
		}
	}  

	/**
	 * Get future formateed date for manual patch approval
	 * @returns {string} - The future formatted date.
	 * @example '09/30/2025-11:00 PM'
	 */
	getFormattedDate = () => {
    	const dateTime = this.getFutureFakeDateTime().split(' ').slice(1, 5);
    	//format time
    	const time = dateTime[3].split(':');
    	let hour = parseInt(time[0]) > 12 ? (parseInt(time[0]) - 12).toString() : time[0];
    	if(hour.length === 1) hour = '0' + hour;
    	return `${this.getMonthNumber(dateTime[0])}/${dateTime[1]}/${dateTime[2]}-${hour}:${time[1]} PM`;
    };
	
	/**
	 * Get Month no id 2 digit format from month name
	 * @param {*} monthName 
	 * @returns Month no id
	 */
	getMonthNumber = (monthName) => {
		const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
		const monthIndex = months.findIndex(month => month.toLowerCase().startsWith(monthName.toLowerCase()));
		if (monthIndex !== -1) {
			const monthNumber = monthIndex + 1;
			return monthNumber.toString().padStart(2, '0');
			// Adding 1 to match the month numbers (1-12) 
			//// Using padStart to ensure 2-digit format with leading zeros
		} else {
			return -1;
			// Return -1 if the month name is not found
		}
	}  

	/**
     * Get month's name from no.
     * @returns {string} - Month name.
     */
	getMonthName = (monthNumber) => {
		const date = new Date();
 		date.setMonth(monthNumber - 1); 
 		// Adjust month number to zero-based index
 		return date.toLocaleString('default', { month: 'long' });
	};

	/**
     * Get today's date and time.
     * @returns {string} - The future fake date and time.
     */
	getCurrentDate = () => {
		const currentDate = new Date();
		return currentDate.getFullYear() + '-' + (currentDate.getMonth() + 1) + '-' + currentDate.getDate();
	};
}

export default CommonHelper;
