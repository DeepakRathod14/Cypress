import CommonHelper from './CommonHelper';

/**
 * Helper class for interacting with buttons.
 * Extends the CommonHelper class.
 */
class ButtonHelper extends CommonHelper {
    /**
     * Function to click a button.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @returns {void}
     */
    clickButton = (buttonSelector) => {
    	this.getElement(buttonSelector).click();
    };

    /**
     * Function to click a button using specific text.
     * @param {string} text - The text to match against the button element.
     * @returns {void}
     */
    clickButtonUsingText = (text) => {
    	return cy.contains(text).click();
    };

    /**
     * Function to click a button with specific text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @returns {void}
     */
    clickButtonWithText = (buttonSelector, text) => {
    	this.getElementWithText(buttonSelector, text).click();
    };

    /**
     * Function to click a button with specific index.
     * 
     * @param {string} buttonSelector 
     * @param {string} index 
     * @returns {void}
     */
    clickButtonWithIndex = (buttonSelector, index) => {
    	this.getElementWithIndex(buttonSelector, index).click();
    }

    /**
     * Function to click a button with specific text and index.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @returns {void}
     */
    clickButtonWithTextAndIndex = (buttonSelector, text, index) => {
    	this.getElementWithTextAndIndex(buttonSelector, text, index).click();
    }

    /**
     * Function to click a button with specific wait time.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @returns {void}
     */
    clickButtonWithWait = (buttonSelector, waitTime) => {
    	this.getElementWithWait(buttonSelector, waitTime).click();
    }

    /**
     * Function to click a button with specific text and wait time.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @returns {void}
     */
    clickButtonWithTextAndWait = (buttonSelector, text, waitTime) => {
    	this.getElementWithTextAndWait(buttonSelector, text, waitTime).click();
    }

    /**
     * Function to click a button with specific assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    clickButtonWithAssertion = (buttonSelector, assertion) => {
    	this.getElementWithAssertion(buttonSelector, assertion).click();
    }

    /**
     * Function to click a button with specific text and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    clickButtonWithTextAndAssertion = (buttonSelector, text, assertion) => {
    	this.getElementWithTextAndAssertion(buttonSelector, text, assertion).click();
    }

    /**
     * Function to click a button with specific index and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     */
    clickButtonWithIndexAndAssertion = (buttonSelector, index, assertion) => {
    	this.getElementWithIndexAndAssertion(buttonSelector, index, assertion).click();
    }

    /**
     * Function to click a button with specific text, index and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    clickButtonWithTextIndexAndAssertion = (buttonSelector, text, index, assertion) => {
    	this.getElementWithTextIndexAndAssertion(buttonSelector, text, index, assertion).click();
    }

    /**
     * Function to click a button with specific wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    clickButtonWithWaitAndAssertion = (buttonSelector, waitTime, assertion) => {
    	this.getElementWithWaitAndAssertion(buttonSelector, waitTime, assertion).click();
    }

    /**
     * Function to click a button with specific text, wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    clickButtonWithTextWaitAndAssertion = (buttonSelector, text, waitTime, assertion) => {
    	this.getElementWithTextWaitAndAssertion(buttonSelector, text, waitTime, assertion).click();
    }

    /**
     * Function to click a button with specific index, wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    clickButtonWithIndexWaitAndAssertion = (buttonSelector, index, waitTime, assertion) => {
    	this.getElementWithIndexWaitAndAssertion(buttonSelector, index, waitTime, assertion).click();
    }

    /** 
     * Function to click a button with specific text, index, wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @returns {void}
    */
    clickButtonWithTextAndWait = (buttonSelector, text, waitTime) => {
    	this.getElementWithTextAndWait(buttonSelector, text, waitTime).click();
    }

    /**
     * Function to click a button with specific text, index and wait time.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @returns {void}
     */
    clickButtonWithTextAndIndexAndWait = (buttonSelector, text, index, waitTime) => {
    	this.getElementWithTextAndIndex(buttonSelector, text, index, waitTime).click();
    }

    /**
     * Function to click a button with specific text, index, wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    clickButtonWithTextAndIndexWaitAndAssertion = (buttonSelector, text, index, waitTime, assertion) => {
    	this.getElementWithTextIndexWaitAndAssertion(buttonSelector, text, index, waitTime, assertion).click();
    }

    /**
     * Function to hover over a button.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @returns {void}
     */
    hoverButton = (buttonSelector) => {
    	this.getElement(buttonSelector).realHover();
    }

    /**
     * Function to hover over a button with specific text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @returns {void}
     */
    hoverButtonWithText = (buttonSelector, text) => {
    	this.getElementWithText(buttonSelector, text).realHover();
    }

    /**
     * Function to hover over a button with specific index.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @returns {void}
     */
    hoverButtonWithIndex = (buttonSelector, index) => {
    	this.getElementWithIndex(buttonSelector, index).realHover();
    }

    /**
     * Function to hover over a button with specific text and index.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @returns {void}
     */
    hoverButtonWithTextAndIndex = (buttonSelector, text, index) => {
    	this.getElementWithTextAndIndex(buttonSelector, text, index).realHover();
    }

    /**
     * Function to hover over a button with specific wait time.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @returns {void}
     */
    hoverButtonWithWait = (buttonSelector, waitTime) => {
    	this.getElementWithWait(buttonSelector, waitTime).realHover();
    }

    /**
     * Function to hover over a button with specific text and wait time.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @returns {void}
     */
    hoverButtonWithTextAndWait = (buttonSelector, text, waitTime) => {
    	this.getElementWithTextAndWait(buttonSelector, text, waitTime).realHover();
    }

    /**
     * Function to hover over a button with specific assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    hoverButtonWithAssertion = (buttonSelector, assertion) => {
    	this.getElementWithAssertion(buttonSelector, assertion).realHover();
    }

    /** 
     * Function to hover over a button with specific text and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
    */
    hoverButtonWithTextAndAssertion = (buttonSelector, text, assertion) => {
    	this.getElementWithTextAndAssertion(buttonSelector, text, assertion).realHover();
    }

    /**
     * Function to hover over a button with specific index and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    hoverButtonWithIndexAndAssertion = (buttonSelector, index, assertion) => {
    	this.getElementWithIndexAndAssertion(buttonSelector, index, assertion).realHover();
    }

    /**
     * Function to hover over a button with specific text, index and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    hoverButtonWithTextIndexAndAssertion = (buttonSelector, text, index, assertion) => {
    	this.getElementWithTextIndexAndAssertion(buttonSelector, text, index, assertion).realHover();
    }

    /**
     * Function to hover over a button with specific wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    hoverButtonWithWaitAndAssertion = (buttonSelector, waitTime, assertion) => {
    	this.getElementWithWaitAndAssertion(buttonSelector, waitTime, assertion).realHover();
    }

    /**
     * Function to hover over a button with specific text, wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
    */
    hoverButtonWithTextWaitAndAssertion = (buttonSelector, text, waitTime, assertion) => {
    	this.getElementWithTextWaitAndAssertion(buttonSelector, text, waitTime, assertion).realHover();
    }

    /** 
     * Function to hover over a button with specific index, wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
    */
    hoverButtonWithIndexWaitAndAssertion = (buttonSelector, index, waitTime, assertion) => {
    	this.getElementWithIndexWaitAndAssertion(buttonSelector, index, waitTime, assertion).realHover();
    }

    /**
     * Function to hover over a button with specific text, index, wait time and assertion.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    hoverButtonWithTextIndexWaitAndAssertion = (buttonSelector, text, index, waitTime, assertion) => {
    	this.getElementWithTextIndexWaitAndAssertion(buttonSelector, text, index, waitTime, assertion).realHover();
    }

    /**
     * Function to hover over a button and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonAndAssertTooltipIsVisible = (buttonSelector, tooltipSelector) => {
    	this.getElement(buttonSelector).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific text and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextAndAssertTooltipIsVisible = (buttonSelector, text, tooltipSelector) => {
    	this.getElementWithText(buttonSelector, text).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific index and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithIndexAndAssertTooltipIsVisible = (buttonSelector, index, tooltipSelector) => {
    	this.getElementWithIndex(buttonSelector, index).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific text, index and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextAndIndexAndAssertTooltipIsVisible = (buttonSelector, text, index, tooltipSelector) => {
    	this.getElementWithTextAndIndex(buttonSelector, text, index).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific wait time and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithWaitAndAssertTooltipIsVisible = (buttonSelector, waitTime, tooltipSelector) => {
    	this.getElementWithWait(buttonSelector, waitTime).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific text, wait time and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextWaitAndAssertTooltipIsVisible = (buttonSelector, text, waitTime, tooltipSelector) => {
    	this.getElementWithTextAndWait(buttonSelector, text, waitTime).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific assertion and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithAssertionAndAssertTooltipIsVisible = (buttonSelector, assertion, tooltipSelector) => {
    	this.getElementWithAssertion(buttonSelector, assertion).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific text, assertion, and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextAndAssertionAndAssertTooltipIsVisible = (buttonSelector, text, assertion, tooltipSelector) => {
    	this.getElementWithTextAndAssertion(buttonSelector, text, assertion).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
    * Function to hover over a button with specific index, assertion, and assert tooltip is visible.
    * 
    * @param {string} buttonSelector - The selector of the button element.
    * @param {number} index - The index of the button element.
    * @param {string} assertion - The assertion to match against the button element.
    * @param {string} tooltipSelector - The selector of the tooltip element.
    * @returns {void}
    */
    hoverButtonWithIndexAndAssertionAndAssertTooltipIsVisible = (buttonSelector, index, assertion, tooltipSelector) => {
    	this.getElementWithIndexAndAssertion(buttonSelector, index, assertion).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific text, index, assertion, and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextIndexAndAssertionAndAssertTooltipIsVisible = (buttonSelector, text, index, assertion, tooltipSelector) => {
    	this.getElementWithTextIndexAndAssertion(buttonSelector, text, index, assertion).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific wait time, assertion, and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithWaitAndAssertionAndAssertTooltipIsVisible = (buttonSelector, waitTime, assertion, tooltipSelector) => {
    	this.getElementWithWaitAndAssertion(buttonSelector, waitTime, assertion).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button with specific text, wait time, assertion, and assert tooltip is visible.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextWaitAndAssertionAndAssertTooltipIsVisible = (buttonSelector, text, waitTime, assertion, tooltipSelector) => {
    	this.getElementWithTextWaitAndAssertion(buttonSelector, text, waitTime, assertion).realHover();
    	this.getElement(tooltipSelector).should('be.visible');
    }

    /**
     * Function to hover over a button and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonAndAssertTooltipText = (buttonSelector, tooltipSelector, tooltipText) => {
    	this.getElement(buttonSelector).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to hover over a button with specific text and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextAndAssertTooltipText = (buttonSelector, text, tooltipSelector, tooltipText) => {
    	this.getElementWithText(buttonSelector, text).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /** 
     * Function to hover over a button with specific index and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
    */
    hoverButtonWithIndexAndAssertTooltipText = (buttonSelector, index, tooltipSelector, tooltipText) => {
    	this.getElementWithIndex(buttonSelector, index).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to hover over a button with specific text, index and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextAndIndexAndAssertTooltipText = (buttonSelector, text, index, tooltipSelector, tooltipText) => {
    	this.getElementWithTextAndIndex(buttonSelector, text, index).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to hover over a button with specific wait time and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonWithWaitAndAssertTooltipText = (buttonSelector, waitTime, tooltipSelector, tooltipText) => {
    	this.getElementWithWait(buttonSelector, waitTime).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to hover over a button with specific text, wait time and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextWaitAndAssertTooltipText = (buttonSelector, text, waitTime, tooltipSelector, tooltipText) => {
    	this.getElementWithTextAndWait(buttonSelector, text, waitTime).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to hover over a button with specific assertion and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonWithAssertionAndAssertTooltipText = (buttonSelector, assertion, tooltipSelector, tooltipText) => {
    	this.getElementWithAssertion(buttonSelector, assertion).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to hover over a button with specific text, assertion, and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextAndAssertionAndAssertTooltipText = (buttonSelector, text, assertion, tooltipSelector, tooltipText) => {
    	this.getElementWithTextAndAssertion(buttonSelector, text, assertion).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to hover over a button with specific index, assertion, and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonWithIndexAndAssertionAndAssertTooltipText = (buttonSelector, index, assertion, tooltipSelector, tooltipText) => {
    	this.getElementWithIndexAndAssertion(buttonSelector, index, assertion).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to hover over a button with specific text, index, assertion, and assert tooltip has text.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @param {string} tooltipSelector - The selector of the tooltip element.
     * @param {string} tooltipText - The text to match against the tooltip element.
     * @returns {void}
     */
    hoverButtonWithTextIndexAndAssertionAndAssertTooltipText = (buttonSelector, text, index, assertion, tooltipSelector, tooltipText) => {
    	this.getElementWithTextIndexAndAssertion(buttonSelector, text, index, assertion).realHover();
    	this.getElement(tooltipSelector).should('have.text', tooltipText);
    }

    /**
     * Function to check if a button is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @returns {void}
     */
    checkButtonIsDisabled = (buttonSelector) => {
    	this.getElement(buttonSelector).should('be.disabled');
    }

    /**
     * Function to check if a button with specific text is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @returns {void}
     */
    checkButtonWithTextIsDisabled = (buttonSelector, text) => {
    	this.getElementWithText(buttonSelector, text).should('be.disabled');
    }

    /**
     * Function to check if a button with specific index is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @returns {void}
     */
    checkButtonWithIndexIsDisabled = (buttonSelector, index) => {
    	this.getElementWithIndex(buttonSelector, index).should('be.disabled');
    }

    /**
     * Function to check if a button with specific text and index is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @returns {void}
     */
    checkButtonWithTextAndIndexIsDisabled = (buttonSelector, text, index) => {
    	this.getElementWithTextAndIndex(buttonSelector, text, index).should('be.disabled');
    }

    /**
     * Function to check if a button with specific wait time is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @returns {void}
     */
    checkButtonWithWaitIsDisabled = (buttonSelector, waitTime) => {
    	this.getElementWithWait(buttonSelector, waitTime).should('be.disabled');
    }

    /**
     * Function to check if a button with specific text and wait time is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @returns {void}
     */
    checkButtonWithTextAndWaitIsDisabled = (buttonSelector, text, waitTime) => {
    	this.getElementWithTextAndWait(buttonSelector, text, waitTime).should('be.disabled');
    }

    /**
     * Function to check if a button with specific assertion is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    checkButtonWithAssertionIsDisabled = (buttonSelector, assertion) => {
    	this.getElementWithAssertion(buttonSelector, assertion).should('be.disabled');
    }

    /**
     * Function to check if a button with specific text and assertion is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    checkButtonWithTextAndAssertionIsDisabled = (buttonSelector, text, assertion) => {
    	this.getElementWithTextAndAssertion(buttonSelector, text, assertion).should('be.disabled');
    }

    /**
     * Function to check if a button with specific index and assertion is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    checkButtonWithIndexAndAssertionIsDisabled = (buttonSelector, index, assertion) => {
    	this.getElementWithIndexAndAssertion(buttonSelector, index, assertion).should('be.disabled');
    }

    /**
     * Function to check if a button with specific text, index and assertion is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} index - The index of the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    checkButtonWithTextIndexAndAssertionIsDisabled = (buttonSelector, text, index, assertion) => {
    	this.getElementWithTextIndexAndAssertion(buttonSelector, text, index, assertion).should('be.disabled');
    }

    /**
     * Function to check if a button with specific wait time and assertion is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    checkButtonWithWaitAndAssertionIsDisabled = (buttonSelector, waitTime, assertion) => {
    	this.getElementWithWaitAndAssertion(buttonSelector, waitTime, assertion).should('be.disabled');
    }

    /**
     * Function to check if a button with specific text, wait time and assertion is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {string} text - The text to match against the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    checkButtonWithTextWaitAndAssertionIsDisabled = (buttonSelector, text, waitTime, assertion) => {
    	this.getElementWithTextWaitAndAssertion(buttonSelector, text, waitTime, assertion).should('be.disabled');
    }

    /**
     * Function to check if a button with specific index, wait time and assertion is disabled.
     * 
     * @param {string} buttonSelector - The selector of the button element.
     * @param {number} index - The index of the button element.
     * @param {number} waitTime - The wait time for the button element.
     * @param {string} assertion - The assertion to match against the button element.
     * @returns {void}
     */
    checkButtonWithIndexWaitAndAssertionIsDisabled = (buttonSelector, index, waitTime, assertion) => {
    	this.getElementWithIndexWaitAndAssertion(buttonSelector, index, waitTime, assertion).should('be.disabled');
    }

}

export default ButtonHelper;
