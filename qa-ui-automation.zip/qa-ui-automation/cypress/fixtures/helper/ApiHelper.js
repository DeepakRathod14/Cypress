import { rqt } from '../../constants';

class ApiHelper {

	constructor() {
		this.env = Cypress.env('environment');
	}

    /**
     * Returns the response of a GET API request with a given URL
     * @param {string} apiUrl - The URL of the API request to get
     * @param {object} headers - The headers of the API request to get
     * @param {object} auth - The auth of the API request to get
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
    getUrl = ({ apiUrl, headers, auth }) => {
        cy.log(apiUrl);
    	return cy.request({
    		method: rqt.Get,
    		url: apiUrl,
    		headers: headers ?? null,
    		auth: auth ?? null,
    		followRedirect: false,
    	});
    };

    /**
     * Returns the response of a PATCH API request with a given URL
     * @param {string} apiUrl - The URL of the API request to get
     * @param {object} headers - The headers of the API request to get
     * @param {object} auth - The auth of the API request to get
     * @param {string} body - The body of the API request to patch
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
    patchUrl = ({ apiUrl, headers, auth, body }) => {
        cy.log(apiUrl);
    	return cy.request({
    		method: rqt.Patch,
    		url: apiUrl,
    		headers: headers ?? null,
    		auth: auth ?? null,
    		followRedirect: false,
            body: body ?? null
    	});
    };

     /**
     * Returns the response of a GET API request with a given URL
     * @param {string} apiUrl - The URL of the API request to get
     * failOnStatusCode - If you do not want status codes to cause failures pass the option
     * @param {object} headers - The headers of the API request to get
     * @param {object} auth - The auth of the API request to get
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
     invalidGet = ({ apiUrl, headers, auth }) => {
        cy.log(apiUrl);
    	return cy.request({
    		method: rqt.Get,
    		url: apiUrl,
            failOnStatusCode: false,
    		headers: headers ?? null,
    		auth: auth ?? null,
    		followRedirect: false,
    	});
    };

     /**
     * Returns the response of a POST API request with a given URL
     * @param {string} apiUrl - The URL of the API request to post
     * @param {object} headers - The headers of the API request to post
     * @param {object} auth - The auth of the API request to post
     * @param {object} body - The body of the API request to post
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
     postUrl = ({ apiUrl, headers, auth, body }) => {
    	return cy.request({
    		method: rqt.Post,
    		url: apiUrl,
    		headers: headers ?? null,
    		auth: auth ?? null,
    		body: body ?? null,
    		followRedirect: false,
    		timeout: 10000,
    	});
    };

    /**
     * Returns the response of a POST API request with a given invalidURL
     * @param {string} apiUrl - The URL of the API request to post
     * failOnStatusCode - If you do not want status codes to cause failures pass the option
     * @param {object} headers - The headers of the API request to post
     * @param {object} auth - The auth of the API request to post
     * @param {object} body - The body of the API request to post
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
    invalidPost = ({ apiUrl, headers, auth, body }) => {
    	return cy.request({
    		method: rqt.Post,
    		url: apiUrl,
            failOnStatusCode: false,
    		headers: headers ?? null,
    		auth: auth ?? null,
    		body: body ?? null,
    		followRedirect: false,
    		timeout: 10000,
    	});
    };

    /**
     * Returns the response of a PUT API request with a given URL
     * @param {string} apiUrl - The URL of the API request to put
     * @param {object} headers - The headers of the API request to put
     * @param {object} auth - The auth of the API request to put
     * @param {object} body - The body of the API request to put
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
    putUrl = ({ apiUrl, headers, auth, body }) => {
    	return cy.request({
    		method: rqt.Put,
    		url: apiUrl,
    		headers: headers ?? null,
    		auth: auth ?? null,
    		body: body ?? null,
    		followRedirect: false,
    	});
    };

    /**
     * Returns the response of a PUT API request with a given URL
     * @param {string} apiUrl - The URL of the API request to put
     * failOnStatusCode - If you do not want status codes to cause failures pass the option
     * @param {object} headers - The headers of the API request to put
     * @param {object} auth - The auth of the API request to put
     * @param {object} body - The body of the API request to put
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
    invalidPut = ({ apiUrl, headers, auth, body }) => {
    	return cy.request({
    		method: rqt.Put,
    		url: apiUrl,
            failOnStatusCode: false,
    		headers: headers ?? null,
    		auth: auth ?? null,
    		body: body ?? null,
    		followRedirect: false,
    	});
    };

    /**
     * Returns the response of a DELETE API request with a given URL
     * @param {string} apiUrl - The URL of the API request to delete
     * @param {object} headers - The headers of the API request to delete
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
    deleteUrl = ({ apiUrl, headers }) => {
    	return cy.request({
    		method: rqt.Delete,
    		url: apiUrl,
    		headers: headers ?? null,
    		followRedirect: false,
    	});
    };

    /**
     * Returns the response of a DELETE API request with a given URL
     * @param {string} apiUrl - The URL of the API request to delete
     * failOnStatusCode - If you do not want status codes to cause failures pass the option
     * @param {object} headers - The headers of the API request to delete
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request
     */
    invalidDelete = ({ apiUrl, headers }) => {
    	return cy.request({
    		method: rqt.Delete,
    		url: apiUrl,
            failOnStatusCode: false,
    		headers: headers ?? null,
    		followRedirect: false,
    	});
    };

    /**
     * Mocks all API requests with a given URL and method
     * @param {string} apiUrl - The URL of the API request to mock
     * @param {string} apiMethod - The method of the API request to mock
     * @param {number} mockStatusCode - The status code to mock the API request with
     * @param {object} mockResponse - The response to mock the API request with
     */
    mockApiRequest({ apiUrl, apiMethod, mockStatusCode, mockHeaders, mockResponse }) {
    	cy.intercept(apiMethod, apiUrl, ((request) => {
    		request.reply({
    			statusCode: mockStatusCode ?? request.statusCode,
    			headers: mockHeaders ?? request.headers,
    			body: mockResponse ?? request.body,
    		});
    	}));
    }

    /**
     * Mocks all API requests with a given URL and method using a fixture file
     * @param {string} apiUrl - The URL of the API request to mock
     * @param {string} apiMethod - The method of the API request to mock
     * @param {number} mockStatusCode - The status code to mock the API request with
     * @param {string} fixtureFileName - The name of the fixture file to mock the API request with
     */
    mockApiRequestUsingFixtureFile = ({ apiUrl, apiMethod, mockStatusCode, mockHeaders, fixtureFileName }) => {
    	cy.intercept(apiMethod, apiUrl, ((request) => {
    		request.reply({
    			statusCode: mockStatusCode ?? request.statusCode,
    			headers: mockHeaders ?? request.headers,
    			fixture: fixtureFileName,
    		});
    	}));
    };

    /**
     * Mocks a GraphQL API request with a given URL, method, and query name.
     * @param {string} apiUrl - The URL of the GraphQL API request to mock
     * @param {string} queryName - The name of the query to mock
     * @param {number} mockStatusCode - The status code to mock the GraphQL API request with
     * @param {object} mockResponse - The response to mock the GraphQL API request with
     */
    mockGraphQLRequest({ apiUrl, queryName, mockStatusCode, mockHeaders, mockResponse }) {
    	cy.intercept(rqt.Post, apiUrl, ((request) => {
    		if (request.body?.query && request.body.query.includes(queryName)) {
    			request.reply({
    				statusCode: mockStatusCode ?? request.statusCode,
    				headers: mockHeaders ?? request.headers,
    				body: mockResponse ?? request.body
    			});
    		}
    	}));
    }

    /**
     * Mocks a GraphQL API request with a given URL, method, and query name using a fixture file.
     * @param {string} apiUrl - The URL of the GraphQL API request to mock
     * @param {string} queryName - The name of the query to mock
     * @param {number} mockStatusCode - The status code to mock the GraphQL API request with
     * @param {string} fixtureFileName - The name of the fixture file to mock the GraphQL API request with
     */
    mockGraphQLRequestUsingFixtureFile = ({ apiUrl, queryName, mockStatusCode, mockHeaders, fixtureFileName }) => {
    	cy.intercept(rqt.Post, apiUrl, ((request) => {
    		if (request.body?.query && request.body.query.includes(queryName)) {
    			request.reply({
    				statusCode: mockStatusCode ?? request.statusCode,
    				headers: mockHeaders ?? request.headers,
    				fixture: fixtureFileName,
    			});
    		}
    	}));
    };

    /**
     * Generates a JWT token based on current user's SSO Token cookie.
     * @returns {Cypress.Chainable<Cypress.Response<any>>} - The response of the API request.
     */
    generateJWTToken = () => {
    	return cy.getCookie('sso-token').then((sso) => {
    		return cy.fixture(`data/${this.env}/api.json`).then((urls) => {
    			this.getUrl({
    				apiUrl: urls['Authorization'] + '/v1/sso/users/token',
    				headers: {
    					'Content-Type': 'application/json',
    					'Connection': 'keep-alive',
    					'Authorization': 'Bearer '+sso.value,
    				},
    			}).then((response) => {
                    Cypress.env('jwt', response.body.token);
                    return response;
                });
    		});
    	}); 
    };

    setAliasForApi(requestType, endUrl, alias ) {
    	return cy.intercept(requestType, `**/${endUrl}`).as(alias);
    }

    setAliasForGraphQL(endUrl, queryName, alias) {
    	return cy.intercept(rqt.Post, `**/${endUrl}`, (req) => {
    		if (req.body?.query && req.body.query.includes(queryName)) {
    			req.alias = alias;
    		}
    	});
    }
}

export default ApiHelper;