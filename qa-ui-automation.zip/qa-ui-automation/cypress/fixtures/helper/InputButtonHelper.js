import CommonHelper from './CommonHelper';

/**
 * Helper class for interacting with input buttons.
 * Extends the CommonHelper class.
 */
class InputButtonHelper extends CommonHelper {
    /**
     * Function to check an input button.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    checkInputButton = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).check({ force: true });
    };

    /**
     * Function to uncheck an input button.
     * @param {string} inputButtonSelector - Selector for the input button to uncheck.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    uncheckInputButton = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).uncheck({ force: true });
    };

    /**
     * Function to check an input button if it is unchecked, or uncheck it if it is checked.
     * @param {string} inputButtonSelector - Selector for the input button to toggle.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    toggleInputButton = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).click({ force: true });
    };

    /**
     * Function to check if an input button is checked.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonChecked = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('be.checked');
    };

    /**
     * Function to check if an input button is unchecked.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonUnchecked = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('not.be.checked');
    };

    /**
     * Function to check if an input button is disabled.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonDisabled = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('be.disabled');
    };

    /**
     * Function to check if an input button is enabled.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonEnabled = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('not.be.disabled');
    };

    /**
     * Function to check if an input button is visible.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonVisible = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('be.visible');
    };

    /**
     * Function to check if an input button is not visible.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonNotVisible = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('not.be.visible');
    };

    /**
     * Function to check if an input button is focused.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonFocused = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('have.focus');
    };

    /**
     * Function to check if an input button is not focused.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonNotFocused = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('not.have.focus');
    };

    /**
     * Function to check if an input button is checked and visible.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonCheckedAndVisible = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('be.checked').and('be.visible');
    };

    /**
     * Function to check if an input button is unchecked and visible.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonUncheckedAndVisible = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('not.be.checked').and('be.visible');
    };

    /**
     * Function to check if an input button is checked and not visible.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonCheckedAndNotVisible = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('be.checked').and('not.be.visible');
    };

    /**
     * Function to check if an input button is unchecked and not visible.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonUncheckedAndNotVisible = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('not.be.checked').and('not.be.visible');
    };

    /**
     * Function to check if an input button is disabled and visible.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    isInputButtonDisabledAndVisible = (inputButtonSelector) => {
    	return this.getElement(inputButtonSelector).should('be.disabled').and('be.visible');
    };

    /**
     * Function to check if an input button is check and vaidate.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
    */
    checkInputButtonAndValidate = (inputButtonSelector) => {
    	this.checkInputButton(inputButtonSelector);
    	this.isInputButtonCheckedAndVisible(inputButtonSelector);
    };

    /**
     * Function to uncheck an input button and validate.
     * @param {string} inputButtonSelector - Selector for the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
    */
    uncheckInputButtonAndValidate = (inputButtonSelector) => {
    	this.uncheckInputButton(inputButtonSelector);
    	this.isInputButtonUncheckedAndVisible(inputButtonSelector);
    };

    /**
     * Function to check an input button using the label.
     * @param {string} labelSelector - Selector for the label of the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    checkInputButtonUsingLabel = (labelSelector) => {
    	return this.getElement(labelSelector).click({ force: true });
    };

    /**
     * Function to uncheck an input button using the label.
     * @param {string} labelSelector - Selector for the label of the input button to uncheck.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    uncheckInputButtonUsingLabel = (labelSelector) => {
    	return this.getElement(labelSelector).click({ force: true });
    };

    /**
     * Function to check an input button using the label and validate.
     * @param {string} labelSelector - Selector for the label of the input button to check.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    checkInputButtonUsingLabelAndValidate = (labelSelector) => {
    	this.checkInputButtonUsingLabel(labelSelector);
    	this.isInputButtonCheckedAndVisible(labelSelector);
    };

    /**
     * Function to uncheck an input button using the label and validate.
     * @param {string} labelSelector - Selector for the label of the input button to uncheck.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    uncheckInputButtonUsingLabelAndValidate = (labelSelector) => {
    	this.uncheckInputButtonUsingLabel(labelSelector);
    	this.isInputButtonUncheckedAndVisible(labelSelector);
    };

}

export default InputButtonHelper;
