import CommonHelper from './CommonHelper';

/**
 * Helper class for interacting with input fields.
 * Extends the CommonHelper class.
 */
class InputFieldHelper extends CommonHelper {
    /**
     * Function to get an input field.
     * @param {string} inputFieldSelector - Selector for the input field to get.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    getInputField = (inputFieldSelector) => {
    	return this.getElement(inputFieldSelector);
    };

    /**
     * Function to get input field value.
     * @param {string} inputFieldSelector - Selector for the input field to get.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    getInputFieldValue = (inputFieldSelector) => {
    	return this.getElement(inputFieldSelector).invoke('val');
    };

    /**
     * Function to clear an input field.
     * @param {string} inputFieldSelector - Selector for the input field to clear.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    clearInputField = (inputFieldSelector) => {
    	return this.getElement(inputFieldSelector).clear();
    };

    /**
     * Function to type into an input field.
     * @param {string} inputFieldSelector - Selector for the input field to type into.
     * @param {string} text - Text to type into the input field.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    typeIntoInputField = (inputFieldSelector, text) => {
    	return this.getElement(inputFieldSelector).type(text);
    };

    /**
     * Function to type into an input field and press enter.
     * @param {string} inputFieldSelector - Selector for the input field to type into.
     * @param {string} text - Text to type into the input field.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    typeIntoInputFieldAndPressEnter = (inputFieldSelector, text) => {
    	return this.getElement(inputFieldSelector).type(`${text}{enter}`);
    };

    /**
     * Function to type into an input field and press tab.
     * @param {string} inputFieldSelector - Selector for the input field to type into.
     * @param {string} text - Text to type into the input field.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    typeIntoInputFieldAndPressTab = (inputFieldSelector, text) => {
    	return this.getElement(inputFieldSelector).type(`${text}{tab}`);
    };

    /**
     * Function to type into an input field and press escape.
     * @param {string} inputFieldSelector - Selector for the input field to type into.
     * @param {string} text - Text to type into the input field.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    typeIntoInputFieldAndPressEscape = (inputFieldSelector, text) => {
    	return this.getElement(inputFieldSelector).type(`${text}{esc}`);
    };

    /**
     * Function to type into an input field and press space.
     * @param {string} inputFieldSelector - Selector for the input field to type into.
     * @param {string} text - Text to type into the input field.
     * @returns {Cypress.Chainable<JQuery<HTMLElement>>} - The Cypress chainable object representing the element.
     */
    typeIntoInputFieldAndPressSpace = (inputFieldSelector, text) => {
    	return this.getElement(inputFieldSelector).type(`${text}{space}`);
    };

}

export default InputFieldHelper;
