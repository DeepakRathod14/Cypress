/* eslint-disable max-len */
import DRTestHelper from '../helper/DRTestHelper';
// import { ltr } from '../helper/constants';

describe('GIVEN DR Test Automation', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var drTestHelper = new DRTestHelper();
	drTestHelper.setupHooks();

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
        
		it('UI : DR : Verify DR Test is available in left navigation Menu under data protection and redirect to DR Test URL', { tags: ['@sanity'] },() => {
			cy.allure().tms('FALC-T967');
			drTestHelper.checkDRTestTab();
		});

		it('DR : UI : LISTDRPAGE :Validate that on loading the DR test Page it should contain all columns like ,Test Name,Vendor,Last Execution Date,Status,Result,Created By,Created On "Disaster Recovery Runbooks"',{ tags: ['@sanity'] }, () => {
			cy.allure().tms('FALC-T1035');
			// drTestHelper.validateDRTestPage();
		});

		it('DR : UI : LISTDRPAGE :Validate that we are able to effectively search the DR test items',{ tags: ['@sanity'] },()=> {
			cy.allure().tms('FALC-T1051');
			// drTestHelper.enterFieldByPlaceholder(ltr.SearchField,ltr.SearchKeyword);
			// drTestHelper.validateSearch('autoDRTest1');
		});

		it('DR : UI : GETDRReport Validate that on clicking on the DR test it navigates to test report page displaying the DR tests information we have 4 coloumns Device name, status, Execution start time , execution end time , Link to access device information',{ tags: ['@sanity'] },()=>{
			cy.allure().tms('FALC-T1052');
			cy.wait(3000);
			// drTestHelper.ClickOnRow(ltr.Row,ltr.ColumnTestName);
			// drTestHelper.validateDRTestReportPage();
		});

	});

});