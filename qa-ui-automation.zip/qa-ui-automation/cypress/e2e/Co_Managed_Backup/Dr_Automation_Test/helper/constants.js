export const moduleMetaData = {
	customUser: 'user_backupDashboard'
};
export const ltr = {
	LeftNevDataProtection: 'LockOutlinedIcon',
	LeftNevDRTest: '[data-testid="navbar__item dr-test"]',
	Row : 'div[role="row"][aria-rowindex="2"]',
	ColumnTestName:'[data-field="testName"] > .MuiBox-root',
	SearchKeyword: 'auto',
	SearchField: 'Search'
};
export const moduleMetaData1 = {
	DRTitle: 'Disaster Recovery Runbooks',
	TestName: 'Test Name',
	Vendor: 'Vendor',
	LastExecutionDate: 'Last Execution Date',
	Status: 'Status',
	Result: 'Result',
	CreatedBy: 'Created By',
	CreatedOn: 'Created On',
	Action: 'Action',
	AddDRTest: 'Add DR Test',
	DRTestReport: 'DR Test Report',
	DRDeviceName: 'Device Name',
	ExecutionStartTime: 'Execution Start Time',
	ExecutionEndTime: 'Execution End Time',
	Link: 'Link To Access Device'
};