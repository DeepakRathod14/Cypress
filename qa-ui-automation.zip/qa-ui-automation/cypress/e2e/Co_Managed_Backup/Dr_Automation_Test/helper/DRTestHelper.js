/* eslint-disable no-mixed-spaces-and-tabs */
import { ButtonHelper, CommonHelper ,GridHelper } from '../../../../fixtures';
import { ltr, moduleMetaData, moduleMetaData1} from './constants';

class DRTestHelper extends CommonHelper {
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.gridHelper = new GridHelper();
	}

	setupHooks() {
		before(() => {
			this.setup(moduleMetaData);
		});
	}

	wrapACtionMenuIcon (rowIndex,ColumnName) {
		this.checkElementIsVisible('[data-rowindex='+rowIndex+']>'+ColumnName).should('be.visible');
		return '[data-rowindex='+rowIndex+']>'+ColumnName;
	}

	ClickOnRow = (rowIndex,ColumnName) => {
		cy.get(rowIndex).find(ColumnName).click();
	}

	enterTextMessage(element,text){
    	cy.get(element).clear().type(text);
    	cy.get('body').click(0,0);
	}
    
	enterFieldByPlaceholder(element,text){
		cy.wait(3000);
    	cy.get('input[placeholder='+element+']').type(text); 
    	cy.get('body').click(0,0);
	}

	checkDRTestTab() {
		this.getElement(this.wrapDataTestId(ltr.LeftNevDataProtection)).click();
		this.checkElementIsVisibleWithText(ltr.LeftNevDRTest,'DR Test');
		this.getElement(ltr.LeftNevDRTest).click();
	}

	validateDRTestPage(){
		cy.contains(moduleMetaData1.DRTitle).should('be.visible');
		cy.contains(moduleMetaData1.TestName).should('be.visible');
		cy.contains(moduleMetaData1.Vendor).should('be.visible');
		cy.contains(moduleMetaData1.LastExecutionDate).should('be.visible');
		cy.contains(moduleMetaData1.Status).should('be.visible');
		cy.contains(moduleMetaData1.Result).should('be.visible');
		cy.contains(moduleMetaData1.CreatedBy).should('be.visible');
		cy.contains(moduleMetaData1.CreatedOn).should('be.visible');
		cy.contains(moduleMetaData1.Action).should('be.visible');
		cy.contains(moduleMetaData1.AddDRTest).should('be.visible');
	}

	validateSearch(text){
		cy.contains(text).should('be.visible');
	}

	validateDRTestReportPage(){
		cy.contains(moduleMetaData1.DRTestReport).should('be.visible');
		cy.contains(moduleMetaData1.DRDeviceName).should('be.visible');
		cy.contains(moduleMetaData1.Status).should('be.visible');
		cy.contains(moduleMetaData1.ExecutionStartTime).should('be.visible');
		cy.contains(moduleMetaData1.ExecutionEndTime).should('be.visible');
		cy.contains(moduleMetaData1.Link).should('be.visible');
	}
}

export default DRTestHelper;