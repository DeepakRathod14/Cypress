import StandaloneProductHelper from '../helper/StandaloneProductHelper';

describe('GIVEN Device Landing Page', { tags: ['@Regression', '@MUI'] }, () => {
	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var standaloneHelp = new StandaloneProductHelper();
	standaloneHelp.setupHooks();

	context(
		'WHERE user is migrated/SSO BCDR Product ',
		{ tags: ['@Migrated'] },
		() => {
			it('Verify user is able to see the Device page :- Download Agent,Assign to Another Site, Backup Tab, Integration Tab', () => {
				cy.allure().tms('FALC-T876');
				standaloneHelp.validateDevicePage();
			});
			it('Verify user is able to see the Companies Management pages under left menu', () => {
				cy.allure().tms('FALC-T877');
				standaloneHelp.validateManagement();
			});
			it('Verify user is able to see the Packages,Policy pages under left menu', () => {
				cy.allure().tms('FALC-T880,FALC-T879');
				standaloneHelp.clickEndpoints();
				standaloneHelp.validatePolicy();
				standaloneHelp.validatePackages();
			});
			it('Verify user is able to see the Integration pages under left menu', () => {
				cy.allure().tms('FALC-T878');
				standaloneHelp.validateIntegration();
			});
		}
	);
});
