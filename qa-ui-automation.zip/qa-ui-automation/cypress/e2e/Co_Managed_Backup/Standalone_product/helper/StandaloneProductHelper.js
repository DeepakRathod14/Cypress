/* eslint-disable no-mixed-spaces-and-tabs */
import {CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper} from '../../../../fixtures';
import { lct, moduleMetaData } from './constants';

class StandaloneProductHelper extends CommonHelper {
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
	}

	setupHooks() {
		before(() => {
			this.setup(moduleMetaData);
		});
	}

    clickLeftArrow = () => {
    	this.getElement(lct.LeftArrow).click();
    };

    clickEndpoints = () => {
    	this.getElement(this.wrapDataTestId(lct.LeftNevEndpoints)).click();
    };

    validateDevicePage() {
    	cy.contains('Manage').click();
    	cy.contains('Download Agent').should('be.visible');
    	cy.contains('Assign to Another Site').should('be.visible');
    	cy.contains('Uninstall Agent (Max 5)').should('be.visible');
    	this.checkElementIsVisible(this.wrapDataTestId(lct.BackupTab));
    	this.checkElementIsVisible(this.wrapDataTestId(lct.IntegrationTab));
    }

    validateManagement() {
    	this.getElement(this.wrapDataTestId(lct.LeftClientManagement)).click();
    	this.checkElementIsVisible(this.wrapDataTestId(lct.LeftCompanyManagement));
    }

    validateIntegration() {
    	this.getElement(this.wrapDataTestId(lct.LeftNevIntegrations)).click();
    	this.checkElementIsVisible(this.wrapDataTestId(lct.MyIntegration));
    	this.checkElementIsVisible(
    		this.wrapDataTestId(lct.LeftNevAsioIntegration)
    	);
    }

    validatePolicy() {
    	this.checkElementIsVisible(this.wrapDataTestId(lct.LeftPolicies));
    }

    validatePackages() {
    	this.checkElementIsVisible(this.wrapDataTestId(lct.LeftPackages));
    }
}
export default StandaloneProductHelper;
