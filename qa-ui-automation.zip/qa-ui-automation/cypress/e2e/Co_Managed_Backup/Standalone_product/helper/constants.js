export const moduleMetaData = {
	customUser: 'BCDR_Standalone',
};
export const lct = {
	MyIntegration: 'navbar__item my-integrations',
	LeftNevAsioIntegration: 'navbar__item asio-integrations',
	ProductTab: '[id="productName_label"]',
	LeftArrow: '[data-testid="menu-icon"]',
	LeftNevIntegrations: 'navbar__item integrations',
	LeftNevEndpoints: 'navbar__item endpoints',
	LeftPolicies: 'navbar__item policies',
	LeftPackages: 'navbar__item packages',
	LeftClientManagement: 'navbar__level-item clients',
	LeftCompanyManagement: 'navbar__level-item companies',
	TrialDropDown: '[id="lock-button"]',
	AcronisTrialOption:
    '[id="INTEGRATION-TRIAL_Acronis_Cyber_Protect_Visibility_root"]',
	VeeamTrialOption: '[id="VEEAM-TRIAL_Integration_Visibility_root"]',
	AxcientTrialOption: '[id="AXCIENT-TRIAL_Integration_Visibility_root"]',
	LeftExploreIntegrations: 'navbar__item explore-integrations',
	BackupTab: 'bdr',
	IntegrationTab: 'integrations',
};
