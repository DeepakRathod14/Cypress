/* eslint-disable no-mixed-spaces-and-tabs */


import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper } from '../../../../fixtures';
import { lct, requiredParms} from './constants';

class SaaSBackupHelper extends CommonHelper {
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.commonHelper = new CommonHelper();
	}
	ClickOnElement = (ele) =>{
		this.getElement(ele).click();
	}
	
	clickOnElementByDataTestID = (element) => {
    	var ele = this.commonHelper.wrapDataTestId(element);
    	this.getElement(ele).click();
	};
	isCreateNewAccountVisible = (element) => {
		var ele = this.commonHelper.wrapDataTestId(element);
    	this.checkElementIsVisible(ele).should('be.enabled');
	}

	checkGridSortingOrder(columnName,order) {
		if(order == 'descending'){
			this.buttonHelper.clickButton(this.gridHelper.wrapGridColumn(columnName));
			this.buttonHelper.clickButton(this.gridHelper.wrapGridColumn(columnName));
		
		}else if(order == 'ascending'){
			this.buttonHelper.clickButton(this.gridHelper.wrapGridColumn(columnName));
			
		}
		
		this.gridHelper.checkSortingIsVisible(columnName, order);
	}
	wrapACtionMenuIcon (rowIndex,ColumnName) {
		this.checkElementIsVisible('[data-rowindex='+rowIndex+']>'+ColumnName).should('be.visible');
		return '[data-rowindex='+rowIndex+']>'+ColumnName;

	}
	ClickOnRow = (rowIndex,ColumnName) => {
		this.getElement(this.wrapACtionMenuIcon(rowIndex,ColumnName)).click();
	}
    initialLandingSetup= (pagename) => {
    	this.navigateToPageOnCheck(pagename);
    }
    verifypageconatinstext(text){
    	cy.contains(text);
    }
    selectCompanyandSiteName(name){
    	cy.contains(lct.ClickOnCompanyAndSiteDropDown, name).click();

    }
    enterTextMessage(element,text){
		
    	cy.get(element).clear().type(text) ;
    	cy.get('body').click(0,0);
    }
    enterFieldByPlaceholder(element,text){
    	cy.get('input[placeholder='+element+']').type(text); 
    	cy.get('body').click(0,0);
    }
    selectDatacenter(locator){
    	var ele = this.commonHelper.wrapDataTestId(locator);
    	this.getElement(ele).click();
    }
    selectelementfromlist(locator,ele){
    	cy.get(locator).contains(ele).click();
    	
    }
	isStartFreeTrialVisible = (locator) => {
		var ele = this.commonHelper.wrapDataTestId(locator);
    	this.checkElementIsVisible(ele).should('be.enabled');
	}

	ClickonOKTerminateAlert = () => {
		cy.get(lct.TerminateAlertText).should('contain.text', 'Are you sure you want to terminate SaaS Backup Account?').click();
		cy.get(this.wrapDataTestId(lct.TerminateOK)).click();
	}
	verifytheTitle = (title,expmsg) =>{
		cy.get(title).should('exist').and('have.text', expmsg);
	}
	verifyNoSkipFilesFound(){
		cy.get(lct.GetSkipFileswindow).should('exist') .and('contain.text', 'No files were skipped');
	}

	verifySkippedFilesInformation(search){
		if(search == 'standard'){
			cy.get(lct.GetTableContent4SkipFileWindow).contains('td', 'AuditLogs').should('exist') .next().should('contain.text', requiredParms.AuditLogsSkippedFilesInfo);
 
		}else if(search == 'Microsoft 365'){
			cy.get(lct.GetTableContent4SkipFileWindow).contains('td', 'Outlook').should('exist') .next().should('contain.text', requiredParms.OutlookSkipedFileInfo);
			cy.get(lct.GetTableContent4SkipFileWindow).contains('td', 'OneDrive').should('exist') .next().should('contain.text', requiredParms.OneDriveSkipedFileInfo);
			cy.get(lct.GetTableContent4SkipFileWindow).contains('td', 'PublicFolders').should('exist') .next().should('contain.text',requiredParms.PublicFoldersSkipedFileInfo );
 
		}
		
	}

	ApplyFilterOnColumns(expectedRes,ColName,ColExpValue,Operator,ExpOperatorValue,ValueDet){
		this.clickonFiltersDropDown(ColName,ColExpValue);
		this.clickonFiltersDropDown(Operator,ExpOperatorValue);
		if((Operator == 'is not any of')||(Operator == 'is any of') ){
			cy.get(lct.OperatorDroPDown).click();
			cy.get(lct.HiddenOperatorValues).invoke('show');
			cy.get(lct.SelectOperatorDropDown).contains(ValueDet).click();
			
		}else if((Operator != 'is empty') && (Operator != 'is not empty')){
			cy.get(lct.EnterValueInFilter).find('input').clear().type(ValueDet);
		}
		cy.get('body').click(0,0);	
		this.validateExpectedRowsinDataGrids(expectedRes);		
	}
	
	clickonFiltersDropDown(ColName,ColExpValue){
		cy.get('select')
			.each(($el) => {
				cy.wrap($el).find('option').then(options => {
					if (options.text().includes(ColName)) { 
						cy.wrap($el).select(ColName).should('have.value', ColExpValue); 
					}
				});
			});
	}
	validateExpectedRowsinDataGrids(expectedRes){
		if(expectedRes == 'NoRows'){
			cy.get(lct.NoRowsInDataGrid).should('contain.text', 'No results found.');
		
		}else{
			return cy.get(lct.GetRowsInfo).then((rows) => {
				cy.log('The rows lenght', rows.length);
				expect(rows.length).to.be.greaterThan(0);
			});
		}
	}
	applyFilteronBackupSizeOrRetentionColumn(expectedRes,ColName,ColExpValue,Operator,ExpOperatorValue,FilterFd,ApplySizeorRetentionDet,UnitsDropDown,ApplyUnitsDet){
		this.clickonFiltersDropDown(ColName,ColExpValue);
		this.clickonFiltersDropDown(Operator,ExpOperatorValue);
	    cy.get(FilterFd).type(ApplySizeorRetentionDet);
		
		cy.get(UnitsDropDown).click(); 
		cy.get('ul[role="listbox"]').find('li[data-value="'+ApplyUnitsDet+'"]').click({force: true});
		cy.get('body').type('{esc}');	
		this.validateExpectedRowsinDataGrids(expectedRes);

	}
	validateConnectorTypeInformation(expectedRow,expectedRes,ExpectedSearchName){
		if(expectedRes == 'NoRows'){
			cy.get(expectedRow).should('contain.text', 'No results found.');
		
		}else{
			return cy.get(expectedRow).then((rows) => {
				cy.log('The rows lenght', rows.text());
				expect(rows.length).to.be.greaterThan(0);
				expect(rows.text()).to.contains(ExpectedSearchName);
			});
		}
	}
}
export default SaaSBackupHelper;