export const moduleMetaData = {
	SaaSBackup: 'SaaS Backup',
	customUser: 'user_command'
	
};

export const moduleMetaData2 = {
	SaaSBackup: 'SaaS Backup',
	customUser: 'technician_command'
	
};

export const moduleMetaData3 = {
	SaaSBackup: 'SaaS Backup',
	customUser: 'clientmanagment_command'
	
};
export const lct = {
	'StartFreeTrial': 'home-page-trial-btn',
	'CreateNewAccount': 'home-page-create-btn',
	'ClickOnConnectColumn' : '[data-field="connect"] svg.MuiSvgIcon-root>path',
	'ClickOnActionColumn' : '[data-field="action"] svg.MuiSvgIcon-root>path',
	'ConnectFromHomePage' : 'menu-item-connect',
	'TerminateAccount': 'menu-item-terminate',
	'TerminateAccountConfirm' : 'terminate-btn',
	'ClickOnCompanyAndSiteDropDown' : '[role="option"]',
	'CreateSaaSBackupPage' : 'SaaS Backup',
	'SelectCompnayDropDown' : 'company-select',
	'SelectSiteNameDropDpown' : 'site-select',
	'ClientSaaSSiteName' : '#al3',
	'EmailName' : '#al',
	'ValidEmailRetentionGrid' : 'valid-retention',
	'EditEmail' : 'enter-email',
	'RetentionPlaceholder' : 1,
	'DatacenterDropDown' : 'dc-select',
	'AllDatacenterandAzureADlists' : 'li.MuiButtonBase-root.MuiMenuItem-root.MuiMenuItem-gutters.css-1562gki',
	'MicroEntraIdDropdown' : 'name-select',
	'InvalidEmailErrMsg' : 'Invalid Email format',
	'InvalidRentionErrmsg' : 'Retention can be between 1-999 only',
	'SaveAndConnect' : 'create-account-btn',
	'ClickOnConnectSvg' : 'connector-grid-connect',
	'EditAccount' : 'menu-item-edit',
	'ExpandChildMenus' :  '[data-rowindex=0]>[data-field="__detail_panel_toggle__"] >button > svg',
	'FiltersBtn' : 'filter-button',
	'ConnectorStatusTab' : 'connector-tab',
	'SearchName' : 'Search',
	'RowsAvailableInSaaSBackupGrid' : 'div.MuiDataGrid-row',
	'ExpectedConnectorTypeRows' : '[data-rowindex=1]>[data-field="workloadType"]',
	'DeleteFilter' : 'button[aria-label="Delete"]',
	'GetRowsInfo' : 'div.MuiDataGrid-row',
	'NoRowsInDataGrid' : '.MuiDataGrid-overlay',
	'OperatorDroPDown' : 'div.MuiAutocomplete-endAdornment > .MuiButtonBase-root',
	'EnterValueInFilter' : '.MuiDataGrid-filterForm',
	'HiddenOperatorValues' : '[placeholder="Filter value"]',
	'SelectOperatorDropDown' : '.base-Popper-root',
	'TerminatedAccounts' : 'saas-terminated-account-btn',
	'GetInput4RetentionFd' : '#retentionValue',
	'BackupSizeRetentionFd' : '#sizeValue',
	'RetentionUnitsDropDown' : '[data-testid="retention-unit-select"]',
	'BackupSizeUnitsDropDown' : '[data-testid="backup-size-unit-select"]',
	'ClickOnSkipedFile' :  '[data-rowindex=1]>[data-field="skippedFiles"] svg',
	'GetSkipFileWindow' : '#alert-dialog-title',
	'ClickOnDownloadReport' : 'edit-retention-accept-btn',
	'GetSkipFileswindow' : 'div[role="alert"]',
	'GetTableContent4SkipFileWindow' : 'table[aria-label="simple table"]'
	

};


export const requiredParms ={

	'Email' : 'Test@gmail.com',
	'InvalidEmailId' : 'test',
	'YearRetention' : 1,
	'3YearsRetention' : 3,
	'LessThan3YearsRetention' : 2,
	'MoreThan3YearsRetention' : 5,
	'InvalidRetention' : 1000,
	'CompanyName1' : 'Company01',
	'Site1' : 'Company01Site01',
	'Canda_DC' : 'Canada',
	'UK_DC': 'United Kingdom',
	'AU_DC' : 'Australia',
	'US_DC': 'United States',
	'EU_DC' : 'Europe (EU)',
	'StandardAzureAD' : 'Standard',
	'AdvancedAzureAD' : 'Advanced',
	'InvalidSiteName' : 'InvalidSite',
	'InvalidName' : 'InvalidName',
	'ValidSiteName' : 'ABC Company Site01-ModifiedSite',
	'ValidClientSiteSaaSName' : '1AutomationCompany01Site0SAASAcountName118',
	'ValidCompanyName' : 'ABC Company-ModifiedName',
	'SiteNameStartsWith' : 'Automatio',
	'SiteNameEndsWith' : 'Site01',
	'SiteNameIsAnyOf' : 'ABC Company Site01-ModifiedSite',
	'ConenctorStatus' : 'ConenctorStatus',
	'TerminatedAccounts' : 'TerminatedAccounts',
	'SaaSBackupAccounts' : 'SaaSBackupAccounts',
	'SkipFileWindowmsg' : 'Details of Skipped Files',
	'OutlookSkipedFileInfo' : 'Failed to get folder content / file: Outlook (28 occurrences)',
	'OneDriveSkipedFileInfo' :'Failed to get folder content / file: OneDrive (29 occurrences)',
	'PublicFoldersSkipedFileInfo' : 'Failed to get folder content / file: PublicFolders (1 occurrences)',
	'AuditLogsSkippedFilesInfo' : 'Failed to get folder content / file: AuditLogs (1 occurrences)'
};
export const filterdet ={

	'MicrosoftEntraID' : ' Entra',
	'Microsoft365' : '365',
	'MicrosoftDynamics365' : 'Dynamics',
	'GoogleWorkspace' : 'Google Workspace',
	'Salesforce' : 'Salesforce',
	'InvalidSiteName' : 'InvalidSite',
	'ValidSiteName' : 'AutomationCompany01Site01',
	'SiteNameStartsWith' : 'Automatio',
	'SiteNameEndsWith' : 'Site01',
	'SiteNameIsAnyOf' : 'AutomationCompany01Site01',
	'AccountTypeIsActive' : 'Active',
	'AccountTypeIsTrial' : 'Trial',
	'SiteColumn' : 'Site',
	'CompanyCloumn' : 'Company',
	'ClientSiteSaaSNameColumn' : 'Client SaaS Site Name',
	'HealthColumn' : 'Health',
	'AccountTypeColumn' : 'Account Type',
	'DataCenterColumn' : 'Data Center',
	'RetntionColumn' : 'Retention (Years)',
	'ConnectorRetention' : 'Retention',
	'ConnectorTypeColumn' : 'Connector Type',
	'ConnectorNameColumn' : 'Connector Name',
	'BackupCoverageColumn' : 'Backup Coverage',
	'StatusColumn' : 'Status',
	'BackupSizeColumn' : 'Backup Size',
	'IsAnyOf' : 'is any of',
	'InNotAnyOf' : 'is not any of',
	'Contains' : 'contains',
	'Equals' : 'equals',
	'StartsWith' : 'starts with',
	'EndsWith' : 'ends with',
	'IsEmpty' : 'is empty',
	'IsnotEmpty': 'is not empty',
	'ExpectedNoRows' : 'NoRows',
	'ExpectedRowsAvailable' : 'RowsAvailable',
	'EqualTo' : '=',
	'NotEqualTo' : '!=',
	'GreaterThan' : '>',
	'LessThan' : '<',
	'GreaterThanOrEqualto' : '>=',
	'LessThanOrEqualto' : '<=',
	'GreaterThanOperator' : 'greater than',
	'LessThanOperator' : 'less than',
	'EqualsOperator' : 'equals'

};
export const eleValues = {
	//values
	'AccountType' : 'status',
	'ClientSaaSSiteName' :  'endClientSiteName',
	'Company' : 'companyName',
	'DataCenter': 'dataCenter',
	'DateInitiated' : 'createdOn',
	'Health' : 'health',
	'Retention' : 'retention',
	'Site' : 'siteName',
	'BackupCoverage' : 'protectedUsers',
	'ConnectorName' :'workloadName',
	'ConnectorType' : 'workloadType',
	'Status' : 'backupStatus',
	'BackupSize' : 'backupSize',
	'isnotanyof' : 'isNotAnyOf',
	'isanyof' : 'isAnyOf',
	'contains' : 'contains',
	'equals' : 'equals',
	'startswith' : 'startsWith',
	'endswith' : 'endsWith',
	'isempty' : 'isEmpty',
	'isnotempty' : 'isNotEmpty',
	'EqualTo' : '=',
	'NotEqualTo' : '!=',
	'GreaterThan' : '>',
	'LessThan' : '<',
	'GreaterThanOrEqualto' : '>=',
	'LessThanOrEqualto' : '<=',
	'GreaterThanOperator' : 'greaterThan',
	'LessThanOperator' : 'lessThan',
	'EqualsOperator' : 'equals'
	
	
};

	