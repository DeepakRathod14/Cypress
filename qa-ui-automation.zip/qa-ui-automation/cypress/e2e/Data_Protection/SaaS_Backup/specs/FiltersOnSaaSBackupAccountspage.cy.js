/* eslint-disable max-len */
import { afterEach } from 'mocha';
import SaaSBackupHelper from '../helper/SaaSBackupHelper';
import { moduleMetaData,eleValues,lct,filterdet,requiredParms } from '../helper/constants';

describe('GIVEN SaaS Backup Page',{tags:['@regression']},()=>{

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	var saasBackupHelper = new SaaSBackupHelper();
	context('WHEN the user is SSO migrated partner',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		 });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Apply Filter on the site column using contains with the valid site name',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17293');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.Contains,eleValues.contains,filterdet.ValidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Contains" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17294');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.Contains,eleValues.contains,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the  Site column can be filtered using the "Equals" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17295');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.Equals,eleValues.equals,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Site  column can be filtered using the "Equals" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17296');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.Equals,eleValues.equals,requiredParms.ValidSiteName);
		});
		
		it('THEN Verify that the  Site column can be filtered using the "Starts with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17297');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.StartsWith,eleValues.startswith,requiredParms.ValidSiteName);
		});
		it('THEN Verify that the  Site  column can be filtered using the "Starts with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17298');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the  Site column can be filtered using the "Ends with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17299');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.EndsWith,eleValues.endswith,requiredParms.SiteNameEndsWith);
		});
		it('THEN Verify that the Site SaaS can be filtered using the "Ends with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17300');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidSiteName);
		});
		
		it('THEN Verify that the Site SaaS  column can be filtered using the "Is Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17301');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidSiteName);
		});

		it('THEN Verify that the Site SaaS column can be filtered using the "Is Not Empty" condition for the command partner. ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17302');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidSiteName);
		});

		     
	});
	
	//Apply Filter on the Health, Data Center and Acount Type Columns
	context('WHEN Apply filter on the Account Type, Health and Data Center columns on the SaaS Back up account Data Grid',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
				
		  });
		  beforeEach (()=> {
			//Landing the create an SaaS Backup Page
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Account Type column can be filtered to get Active Accounts in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17303');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.AccountTypeColumn,eleValues.AccountType,filterdet.InNotAnyOf,eleValues.isnotanyof,filterdet.AccountTypeIsActive);
		   });
		it('THEN Apply Filter on the US data Center using not any of  in the SaaS Backup tab for the Command Partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17304');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.DataCenterColumn,eleValues.DataCenter,filterdet.InNotAnyOf,eleValues.isnotanyof,'Europe');
		});
		it('THEN Verify that the US Data Center column can be filtered using the "Is Any Of" condition in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17305');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.DataCenterColumn,eleValues.DataCenter,filterdet.IsAnyOf,eleValues.isanyof,'Europe');
		});

		it('THEN Verify that the Health column can be filtered using the "Is Any Of" condition to get the "Success" value in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17306');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.HealthColumn,eleValues.Health,filterdet.IsAnyOf,eleValues.isanyof,'Success');
		});
		it('THEN Verify that the Health column can be filtered using the "Is Any Of" condition to get the "Unknown" value in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17307');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.HealthColumn,eleValues.Health,filterdet.IsAnyOf,eleValues.isanyof,'Unknown');
		});
	
	});
	
	// Apply Filter on the Client Site SaaS Name Filter
	context('WHEN Apply filter on the Client site saas name column on the SaaS Back up account Data Grid',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		});
		  beforeEach (()=> {
			//Landing the create an SaaS Backup Page
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			cy.wait(1000);

			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Contains" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17284');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Contains,eleValues.contains,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Equals" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17285');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Equals,eleValues.equals,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Starts with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17286');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Equals,eleValues.equals,requiredParms.ValidClientSiteSaaSName);
		});
		
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Starts with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17287');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.StartsWith,eleValues.startswith,requiredParms.SiteNameStartsWith);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Starts with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17288');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Ends with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17289');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.EndsWith,eleValues.endswith,requiredParms.SiteNameEndsWith);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Ends with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17290');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidSiteName);
		});
		
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Is Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17291');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidSiteName);
		});

		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Is Not Empty" condition for the command partner. ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17292');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidSiteName);
		});

		
        
	});
	context('WHEN Apply filter on the Company name column on the SaaS Back up account Data Grid',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		 });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			cy.wait(1000);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Company column can be filtered using the "Contains" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17308');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.Contains,eleValues.contains,requiredParms.ValidCompanyName);
		   });
		it('THEN Verify that the Company column can be filtered using the "Contains" operator with an invalid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17309');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.Contains,eleValues.contains,requiredParms.InvalidName);
		});
		it('THEN Verify that the Company column can be filtered using the "Equals" operator with an invalid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17310');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.Equals,eleValues.equals,requiredParms.InvalidName);
		});
		it('THEN Verify that the Company column can be filtered using the "Equals" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17311');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.Equals,eleValues.equals,requiredParms.ValidCompanyName);
		});
		
		it('THEN Verify that the Company column can be filtered using the "Starts with" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17312');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.StartsWith,eleValues.startswith,requiredParms.ValidCompanyName);
		});
		it('THEN Verify that the Company column can be filtered using the "Starts with" operator with an invalid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17313');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidName);
		});
		it('THEN Verify that the Company column can be filtered using the "Ends with" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17314');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.EndsWith,eleValues.endswith,requiredParms.CompanyName1);
		});
		it('THEN Verify that the Company column can be filtered using the "Ends with" operator with an invalid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17315');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidName);
		});
		
		it('THEN Verify that the Company column can be filtered using the "Is Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17316');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidName);
		});

		it('THEN Verify that the Company column can be filtered using the "Is Not Empty" condition for the command partner. ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17317');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidName);
		});

		     
	});
	// Apply Filter on the Retention in years Column
	context('WHEN Apply filter on the Retetnion column on the SaaS Back up account Data Grid',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
			
		  });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			cy.wait(1000);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Retention column can be filtered using the "=" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17318');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.RetntionColumn,eleValues.Retention,filterdet.EqualTo,eleValues.EqualTo,1);
		   });
		it('THEN Verify that the Retention column can be filtered using the ">" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17319');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.RetntionColumn,eleValues.Retention,filterdet.GreaterThan,eleValues.GreaterThan,1);
		   });
		it('THEN Verify that the Retention column can be filtered using the "<" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17320');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.RetntionColumn,eleValues.Retention,filterdet.LessThan,eleValues.LessThan,1);
		   });
		it('THEN Verify that the Retention column can be filtered using the "<=" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17321');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.RetntionColumn,eleValues.Retention,filterdet.LessThanOrEqualto,eleValues.LessThanOrEqualto,1);
		});
		it('THEN Verify that the Retention column can be filtered using the ">=" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17322');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.RetntionColumn,eleValues.Retention,filterdet.GreaterThanOrEqualto,eleValues.GreaterThanOrEqualto,1);
		});
		it('THEN Verify that the Site column can be filtered using the "Is Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17323');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.RetntionColumn,eleValues.Retention,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidSiteName);
		});

		it('THEN Verify that the Site column can be filtered using the "Is Not Empty" condition for the command partner. ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17324');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.RetntionColumn,eleValues.Retention,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidSiteName);
		});

		     
	});

});