import SaaSBackupHelper from '../helper/SaaSBackupHelper';
import { moduleMetaData, lct,moduleMetaData2, moduleMetaData3 } from '../helper/constants';

describe('GIVEN Monitoring Landing Page', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var saasBackupHelper = new SaaSBackupHelper();
	context('WHERE user is Primary super admin & migrated/SSO ', { tags: ['@Migrated'] }, () => {
		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
			
		  });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);

		  });
		  //test case starts here 
		it('THEN Verify user is able to see the SaaSBackup page under data protection menu', ()=>{
			
			cy.allure().tms('');
			saasBackupHelper.isStartFreeTrialVisible(lct.StartFreeTrial);
			saasBackupHelper.isCreateNewAccountVisible(lct.CreateNewAccount);
		
		});
		
		
	});
	context.skip('WHERE user is technician & migrated/SSO', { tags: ['@Migrated'] }, () => {

		/** 
		 * Base hooks defined for pre and post conditions
		 * before, beforeEach, after, afterEach
		 * NOTE: User will login through the technician role 
		 */
       
		before (()=>{
			saasBackupHelper.setup(moduleMetaData2);
			
		  });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData2.SaaSBackup);

		  });
        
		//test case starts here 
		it('THEN Verify user is able to see the SaaSBackup page under data protection menu', ()=>{
			cy.allure().tms('');
			saasBackupHelper.isStartFreeTrialVisible(lct.StartFreeTrial);
			saasBackupHelper.isCreateNewAccountVisible(lct.CreateNewAccount);
		              
		});
		
	});
	context.skip('WHERE user is client site manager & migrated/SSO', { tags: ['@Migrated'] }, () => {
		before (()=>{
			saasBackupHelper.setup(moduleMetaData3);
			
		  });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData3.SaaSBackup);

		  });
        
		//test case starts here 
		it('THEN Verify user is able to see the SaaSBackup page under data protection menu', ()=>{
			cy.allure().tms('');
			saasBackupHelper.isStartFreeTrialVisible(lct.StartFreeTrial);
			saasBackupHelper.isCreateNewAccountVisible(lct.CreateNewAccount);
		});
		
	});
});

