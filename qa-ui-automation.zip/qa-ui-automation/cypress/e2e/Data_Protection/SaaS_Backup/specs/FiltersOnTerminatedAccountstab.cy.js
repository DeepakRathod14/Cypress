/* eslint-disable max-len */
import { afterEach } from 'mocha';
import SaaSBackupHelper from '../helper/SaaSBackupHelper';

import { moduleMetaData,eleValues,lct,filterdet,requiredParms } from '../helper/constants';

describe('WHEN Command partner and go to the SaaS Backup Page',{tags:['@regression']},()=>{

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	var saasBackupHelper = new SaaSBackupHelper();

	context('WHEN Go to the Terminated Accounts page',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		});
		beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			cy.wait(1000);
			saasBackupHelper.clickOnElementByDataTestID(lct.TerminatedAccounts);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
            
		});

		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
        
		});
		it('THENApply Filter on the Company column using contains with the valid Company name for the command partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17253');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.Contains,eleValues.contains,requiredParms.ValidCompanyName);
		});
		it('THEN Apply Filter on the Company column using Contains operator using the invalid Company name for the command partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17254');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.Contains,eleValues.contains,requiredParms.InvalidName);
		});
		it('THEN Apply Filter on the Company column using Equals operator using the invalid Company name for the command partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17255');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.Equals,eleValues.equals,requiredParms.InvalidName);
		});
		it('THEN Apply Filter on the Company column using Equals operator using the valid Company name for the command partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17256');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.Equals,eleValues.equals,requiredParms.ValidCompanyName);
		});
    
		it('THEN Apply Filter on the Company column using Starts with operator using the valid Company name for the command partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17257');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.StartsWith,eleValues.startswith,requiredParms.ValidCompanyName);
		});
		it('THEN Apply Filter on the Company column using Starts with operator using the Invalid Company name for the command partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17258');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidName);
		});
		it('THEN  Apply Filter on the Company column using Ends with operator using the valid Company name for the command partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17259');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.EndsWith,eleValues.endswith,requiredParms.ValidCompanyName);
		});
		it('THEN Apply Filter on the Company column using Ends with operator using the valid Company name for the command partner',{tags:['@reg']},()=>{
			cy.allure().tms('/BDR-T17260');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidName);
		});
    
		it('THEN Apply Filter on the Company Column using the is empty for the command partner ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17261');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidName);
		});

		it('THEN Apply Filter on the Company Column using the is not empty for the command partner ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17262');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidName);
		});

         
	});
	context('GIVEN Terminated accounts page ',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		});
		beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.TerminatedAccounts);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
            
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
        
		});
		it('THEN Verify that the Site column can be filtered using the "Contains" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17263');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.Contains,eleValues.contains,filterdet.ValidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Contains" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17264');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.Contains,eleValues.contains,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Equals" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17265');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.Equals,eleValues.equals,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Equals" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17266');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.Equals,eleValues.equals,requiredParms.ValidSiteName);
		});
    
		it('THEN Verify that the Site column can be filtered using the "Starts with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17267');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.StartsWith,eleValues.startswith,requiredParms.ValidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Starts with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17268');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Ends with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17269');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.EndsWith,eleValues.endswith,requiredParms.SiteNameEndsWith);
		});
		it('THEN Verify that the Site column can be filtered using the "Ends with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17270');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidSiteName);
		});
    
		it('THEN Verify that the Site column can be filtered using the "Is Empty" condition for the command partner. ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17271');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidSiteName);
		});

		it('THEN Verify that the Site column can be filtered using the "Is Not Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17272');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidSiteName);
		});

         
	});
	// Apply Filter on the Client Site SaaS Name Filter
	context('GIVN Terminated SaaS Backup Accounts page',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		});
		beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.TerminatedAccounts);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
        
		});

		afterEach(() =>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
        
		});
    
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Contains" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17273');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Contains,eleValues.contains,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Equals" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17274');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Equals,eleValues.equals,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Equals" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17275');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Equals,eleValues.equals,requiredParms.ValidClientSiteSaaSName);
		});
    
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Starts with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17276');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.StartsWith,eleValues.startswith,'Info');
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Starts with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17277');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Ends with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17278');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.EndsWith,eleValues.endswith,requiredParms.SiteNameEndsWith);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Ends with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17279');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidSiteName);
		});
    
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Is Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17280');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidSiteName);
		});

		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Is Not Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17281');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidSiteName);
		});
	});

	context('GIVEN Terminated accounts page',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		});
		beforeEach (()=> {
			//Landing the create an SaaS Backup Page
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.TerminatedAccounts);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		});
    
		it('THEN Apply Filter on the US data Center using not any of  in the SaaS Backup tab for the Command Partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17282');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.DataCenterColumn,eleValues.DataCenter,filterdet.InNotAnyOf,eleValues.isnotanyof,'Europe');
		});
		it('THEN Apply Filter on the US data Center using is any of  in the SaaS Backup tab for the Command Partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17283');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.DataCenterColumn,eleValues.DataCenter,filterdet.IsAnyOf,eleValues.isanyof,'Europe');
		});


	});

});
         


         

