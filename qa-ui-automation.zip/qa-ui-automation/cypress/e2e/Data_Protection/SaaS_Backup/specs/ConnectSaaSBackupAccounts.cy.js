/* eslint-disable max-len */
import SaaSBackupHelper from '../helper/SaaSBackupHelper';
import SaaSBackupAccountsCommonCodehelper from '../CommonCodeHelper/SaaSBackupCommoncodehelper';
import { moduleMetaData,lct,requiredParms } from '../helper/constants';


describe('GIVEN SaaS Backup Page ',{tags:['@regression']},()=>{

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	var saasBackupHelper = new SaaSBackupHelper();
	var commonCodehelper = new SaaSBackupAccountsCommonCodehelper();
	const random = '1' + Math.random().toString().substr(2, 9);
	const clientSaaSName = random + 'AutoMationClientSitSaaSName';
	const email = random + 'test@Gmail.com';

	context('WHEN the user is SSO migrated partner',{ tags: ['@Regression', '@Migrated'] },()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
			
			
		  });
		  beforeEach (()=> {
			//Landing the create an SaaS Backup Page
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			cy.wait(1000);
			 

		});
		it('THEN Verify that Clicking on the Connect for the SaaS Back up account is working',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T16556');
			commonCodehelper.createSaaSBackupAccountCommonCode('Active','Standard','Europe',lct.CreateNewAccount,clientSaaSName,email,requiredParms.YearRetention,requiredParms.CompanyName1,requiredParms.Site1);
			saasBackupHelper.checkGridSortingOrder('createdOn','descending');
		    saasBackupHelper.ClickOnRow(0,lct.ClickOnConnectColumn);
			saasBackupHelper.ClickOnRow(0,lct.ClickOnActionColumn);
			saasBackupHelper.clickOnElementByDataTestID(lct.TerminateAccount);
			saasBackupHelper.clickOnElementByDataTestID(lct.TerminateAccountConfirm);
			
			
		});
		it('THEN Verify that Clicking on the Connect for the Trial SaaS Back up account is working',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T16556');
			commonCodehelper.createSaaSBackupAccountCommonCode('Active','Advanced','United States',lct.CreateNewAccount,clientSaaSName,email,requiredParms.YearRetention,requiredParms.CompanyName1,requiredParms.Site1);
			saasBackupHelper.checkGridSortingOrder('createdOn','descending');
			saasBackupHelper.ClickOnRow(0,lct.ClickOnConnectColumn);
			saasBackupHelper.ClickOnRow(0,lct.ClickOnActionColumn);
			saasBackupHelper.clickOnElementByDataTestID(lct.TerminateAccount);
			saasBackupHelper.clickOnElementByDataTestID(lct.TerminateAccountConfirm);
			
		});
		
	});

});