import SaaSBackupHelper from '../helper/SaaSBackupHelper';
import { moduleMetaData, lct} from '../helper/constants';

describe('GIVEN SaaSBackup Landing Page', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var saasBackupHelper = new SaaSBackupHelper();
	context('WHERE user is Primary super admin & migrated/SSO ', { tags: ['@Migrated'] }, () => {
		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
			
		  });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);

		  });
		  //test case starts here 
		it('THEN Verify search on the Advanced Connector type is showing the  data grids', ()=>{
			
			cy.allure().tms('BDR-T17326');
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.enterFieldByPlaceholder(lct.SearchName,'Advanced');
			saasBackupHelper.validateConnectorTypeInformation(lct.ExpectedConnectorTypeRows,'RowsAvailable','Advanced');
			
		});

		
		it('THEN Verify search on the Standard Connector type is showing in the data grids', ()=>{
			
			cy.allure().tms('BDR-T17325');
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.enterFieldByPlaceholder(lct.SearchName,'Standard');
			saasBackupHelper.validateConnectorTypeInformation(lct.ExpectedConnectorTypeRows,'RowsAvailable','Standard');
			
		});
	});
	
});

