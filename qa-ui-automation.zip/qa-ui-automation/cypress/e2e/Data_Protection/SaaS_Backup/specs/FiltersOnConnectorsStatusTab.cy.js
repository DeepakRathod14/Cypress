/* eslint-disable max-len */
/* eslint-disable no-mixed-spaces-and-tabs */

import { afterEach } from 'mocha';
import SaaSBackupHelper from '../helper/SaaSBackupHelper';
import { moduleMetaData,eleValues,lct,filterdet,requiredParms} from '../helper/constants';

describe('GIVEN Connector Status Page',{tags:['@regression']},()=>{

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	var saasBackupHelper = new SaaSBackupHelper();
	context('WHEN Apply filter',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		});
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Site column can be filtered using the "Contains" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17211');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.Contains,eleValues.contains,filterdet.ValidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Contains" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17212');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.Contains,eleValues.contains,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Equals" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17213');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.Equals,eleValues.equals,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Equals" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17214');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.Equals,eleValues.equals,requiredParms.ValidSiteName);
		});
		
		it('THEN Verify that the Site column can be filtered using the "Starts with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17215');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.StartsWith,eleValues.startswith,requiredParms.ValidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Starts with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17216');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Site column can be filtered using the "Ends with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17217');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.EndsWith,eleValues.endswith,requiredParms.SiteNameEndsWith);
		});
		it('THEN Verify that the Site column can be filtered using the "Ends with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17218');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidSiteName);
		});
		
		it('THEN Verify that the Site column can be filtered using the "Is Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17219');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.SiteColumn,eleValues.Site,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidSiteName);
		});

		it('THEN Verify that the Site column can be filtered using the "Is Not Empty" condition for the command partner. ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17220');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.SiteColumn,eleValues.Site,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidSiteName);
		});
	});
	context('WHEN Apply filter on the Backup Coverage column',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		 });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Backup Coverage column can be filtered using the "=" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17221');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.BackupCoverageColumn,eleValues.BackupCoverage,filterdet.Equals,eleValues.equals,46);
		});
		it('THEN Verify that the Backup Coverage column can be filtered using the ">" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17222');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.BackupCoverageColumn,eleValues.BackupCoverage,filterdet.GreaterThan,eleValues.GreaterThan,45);
		});
		it('THEN Verify that the Backup Coverage column can be filtered using the "<" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17223');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.BackupCoverageColumn,eleValues.BackupCoverage,filterdet.LessThan,eleValues.LessThan,1);
		});
		it('THEN Verify that the Backup Coverage column can be filtered using the "<=" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17224');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.BackupCoverageColumn,eleValues.BackupCoverage,filterdet.LessThanOrEqualto,eleValues.LessThanOrEqualto,46);
		});
		it('THEN Verify that the Backup Coverage column can be filtered using the ">=" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17225');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.RetntionColumn,eleValues.Retention,filterdet.GreaterThanOrEqualto,eleValues.GreaterThanOrEqualto,1);
		});
		it('THEN Verify that the Backup Coverage column can be filtered using the "Is Empty" condition for the command partner. ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17226');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.BackupCoverageColumn,eleValues.BackupCoverage,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidSiteName);
		});

		it('THEN Verify that the Backup Coverage column can be filtered using the "Is Not Empty" condition for the command partner. ',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17227');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.BackupCoverageColumn,eleValues.BackupCoverage,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidSiteName);
		});

		     
	});

	context('WHEN go to the Connector Status Page',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
			
			
		  });
		  beforeEach (()=> {
			//Landing the create an SaaS Backup Page
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Contains" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17228');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Contains,eleValues.contains,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Equals" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17229');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Equals,eleValues.equals,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Equals" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17230');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.Equals,eleValues.equals,requiredParms.ValidClientSiteSaaSName);
		});
		
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Starts with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17231');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.StartsWith,eleValues.startswith,requiredParms.SiteNameStartsWith);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Starts with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17232');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidSiteName);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Ends with" operator with a valid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17233');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.EndsWith,eleValues.endswith,requiredParms.SiteNameEndsWith);
		});
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Ends with" operator with an invalid site name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17234');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidSiteName);
		});
		
		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Is Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17235');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidSiteName);
		});

		it('THEN Verify that the Client Site SaaS Name column can be filtered using the "Is Not Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17236');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ClientSiteSaaSNameColumn,eleValues.ClientSaaSSiteName,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidSiteName);
		});
	});
	context('WHEN go to the Connector Status page',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
		});
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Connector Type column can be filtered to get "Microsoft Entra ID" in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17237');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ConnectorTypeColumn,eleValues.ConnectorType,filterdet.InNotAnyOf,eleValues.isnotanyof,filterdet.MicrosoftEntraID);
		});
		it('THEN Verify that the Connector Type column can be filtered to get "Microsoft 365 Connector" in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17238');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.ConnectorTypeColumn,eleValues.ConnectorType,filterdet.IsAnyOf,eleValues.isanyof,filterdet.Microsoft365);
		});
		it('THEN Verify that the Connector Type column can be filtered using "Is Any Of" to get "Microsoft Dynamics 365" in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17239');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ConnectorTypeColumn,eleValues.ConnectorType,filterdet.IsAnyOf,eleValues.isanyof,filterdet.MicrosoftDynamics365);
		});

		it('THEN Verify that the Connector Type column can be filtered using "Is Any Of" to get "SalesForce accounts" in the SaaS Backup tab for the Command Partner',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17240');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.ConnectorTypeColumn,eleValues.ConnectorType,filterdet.IsAnyOf,eleValues.isanyof,filterdet.Salesforce);
		});
	
	});
	
	context('WHEN Go to Connector status page',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
	    });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Company column can be filtered using the "Contains" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17241');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.Contains,eleValues.contains,requiredParms.ValidCompanyName);
		});
		it('THEN Verify that the Company column can be filtered using the "Contains" operator with an invalid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17242');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.Contains,eleValues.contains,requiredParms.InvalidName);
		});
		it('THEN Verify that the Company column can be filtered using the "Equals" operator with an invalid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17243');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.Equals,eleValues.equals,requiredParms.InvalidName);
		});
		it('THEN Verify that the Company column can be filtered using the "Equals" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17244');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.Equals,eleValues.equals,requiredParms.ValidCompanyName);
		});
		
		it('THEN Verify that the Company column can be filtered using the "Starts with" operator with a valid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17245');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.StartsWith,eleValues.startswith,requiredParms.ValidCompanyName);
		});
		it('THEN Verify that the Company column can be filtered using the "Starts with" operator with an invalid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17246');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.StartsWith,eleValues.startswith,requiredParms.InvalidName);
		});
		it('THEN Verify that the Company column can be filtered using the "Ends with" operator with an invalid company name for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17248');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.EndsWith,eleValues.endswith,requiredParms.InvalidName);
		});

		
		it('THEN Verify that the Company column can be filtered using the "Is Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17249');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedNoRows,filterdet.CompanyCloumn,eleValues.Company,filterdet.IsEmpty,eleValues.isempty,requiredParms.InvalidName);
		});

		it('THEN Verify that the Company column can be filtered using the "Is Not Empty" condition for the command partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17250');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.CompanyCloumn,eleValues.Company,filterdet.IsnotEmpty,eleValues.isnotempty,requiredParms.InvalidName);
		});

	});

	context('WHEN go to the Connector Status',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
	    });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Connector Type column can be filtered to get "Microsoft Entra ID" in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17252');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.StatusColumn,eleValues.Status,filterdet.InNotAnyOf,eleValues.isnotanyof,'Failed');
		});
		it('THEN Verify that the Connector Type column can be filtered to get "Microsoft Entra ID" in the SaaS Backup tab for the Command Partner.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17251');
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.StatusColumn,eleValues.Status,filterdet.IsAnyOf,eleValues.isanyof,'Success');
		});

	
	});
	
	
	context('WHEN go to the Connector Status',()=>{

		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
	    });
		  beforeEach (()=> {
			//Landing the create an SaaS Backup Page
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
		});
		afterEach(()=>{
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ClickOnElement(lct.DeleteFilter);
		
		});
		it('THEN Verify that the Backup Size column can be filtered using the "greater than" condition with a value in MB.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17202');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedRowsAvailable,filterdet.BackupSizeColumn,eleValues.BackupSize,eleValues.GreaterThanOperator,filterdet.GreaterThanOperator,lct.BackupSizeRetentionFd,10,lct.BackupSizeUnitsDropDown, 'MB');
		});
		it('THEN Verify that the Backup Size column can be filtered using the "greater than" condition with a value in KB.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17203');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedRowsAvailable,filterdet.BackupSizeColumn,eleValues.BackupSize,eleValues.GreaterThanOperator,filterdet.GreaterThanOperator,lct.BackupSizeRetentionFd,10,lct.BackupSizeUnitsDropDown, 'KB');
		});
		it('THEN Verify that the Backup Size column can be filtered using the "less than" condition with a value in GB.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17204');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedRowsAvailable,filterdet.BackupSizeColumn,eleValues.BackupSize,eleValues.LessThanOperator,filterdet.LessThanOperator,lct.BackupSizeRetentionFd,1,lct.BackupSizeUnitsDropDown, 'GB');
		});
		it('THEN Verify that the Backup Size column can be filtered using the "greater than" condition with a value in TB.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17205');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedNoRows,filterdet.BackupSizeColumn,eleValues.BackupSize,eleValues.GreaterThanOperator,filterdet.GreaterThanOperator,lct.BackupSizeRetentionFd,1,lct.BackupSizeUnitsDropDown, 'TB');
		});
		it('THEN Verify that the Backup Size column can be filtered using the "greater than" condition with a value in PB',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17206');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedNoRows,filterdet.BackupSizeColumn,eleValues.BackupSize,eleValues.GreaterThanOperator,filterdet.GreaterThanOperator,lct.BackupSizeRetentionFd,1,lct.BackupSizeUnitsDropDown, 'PB');
		});
		it('THEN Verify that the Retention column can be filtered using the "greater than" condition with a value in Days.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17207');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedRowsAvailable,filterdet.ConnectorRetention,eleValues.Retention,eleValues.GreaterThanOperator,filterdet.GreaterThanOperator,lct.GetInput4RetentionFd,10,lct.RetentionUnitsDropDown, 'Days');
		});

		it('THEN Verify that the Retention column can be filtered using the "greater than" condition with a value in Years.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17208');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedRowsAvailable,filterdet.ConnectorRetention,eleValues.Retention,eleValues.LessThanOperator,filterdet.LessThanOperator,lct.GetInput4RetentionFd,1,lct.RetentionUnitsDropDown, 'Years');
		});
		it('THEN Verify that the Retention column can be filtered using the "less than" condition with a value in Months.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17210');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedRowsAvailable,filterdet.ConnectorRetention,eleValues.Retention,eleValues.LessThanOperator,filterdet.LessThanOperator,lct.GetInput4RetentionFd,10,lct.RetentionUnitsDropDown, 'Months');
		});

		it('THEN Verify that the Retention column can be filtered using the "equals" condition with a value in Months.',{tags:['@reg']},()=>{
			cy.allure().tms('BDR-T17209');
			saasBackupHelper.applyFilteronBackupSizeOrRetentionColumn(filterdet.ExpectedRowsAvailable,filterdet.ConnectorRetention,eleValues.Retention,eleValues.EqualsOperator,filterdet.EqualsOperator,lct.GetInput4RetentionFd,10,lct.RetentionUnitsDropDown, 'Months');
		});
	
	});



});