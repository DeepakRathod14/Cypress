import SaaSBackupHelper from '../helper/SaaSBackupHelper';
import { moduleMetaData, lct, requiredParms} from '../helper/constants';
import { eleValues,filterdet } from '../helper/constants';


describe('GIVEN Monitoring Landing Page', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var saasBackupHelper = new SaaSBackupHelper();
	context('WHERE user is Primary super admin & migrated/SSO ', { tags: ['@Migrated'] }, () => {
		before (()=>{
			saasBackupHelper.setup(moduleMetaData);
			
		  });
		  beforeEach (()=> {
			saasBackupHelper.initialLandingSetup(moduleMetaData.SaaSBackup);
			saasBackupHelper.clickOnElementByDataTestID(lct.ConnectorStatusTab);
			
		  });
		it('THEN Verify that skip files information is showing when applied status is success for the Microsoft 365 connector', ()=>{
			cy.allure().tms('BDR-T17198');
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.StatusColumn,eleValues.Status,filterdet.IsAnyOf,eleValues.isanyof,'Success');
			saasBackupHelper.enterFieldByPlaceholder(lct.SearchName,'Microsoft 365');
			saasBackupHelper.ClickOnElement(lct.ClickOnSkipedFile);
			saasBackupHelper.verifytheTitle(lct.GetSkipFileWindow,requiredParms.SkipFileWindowmsg);
			saasBackupHelper.verifySkippedFilesInformation('Microsoft 365');
			
		});
		it('THEN Verify that skip files information is showing when applied status is success for the standard connector', ()=>{
			cy.allure().tms('BDR-T17195');
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.StatusColumn,eleValues.Status,filterdet.IsAnyOf,eleValues.isanyof,'Success');
			saasBackupHelper.enterFieldByPlaceholder(lct.SearchName,'standard');
			saasBackupHelper.ClickOnElement(lct.ClickOnSkipedFile);
			saasBackupHelper.verifytheTitle(lct.GetSkipFileWindow,requiredParms.SkipFileWindowmsg);
			saasBackupHelper.verifySkippedFilesInformation('standard');
			
		});
		it('THEN Verify that no skip files information is showing when applied status is unknown for the standard connector', ()=>{
		 cy.allure().tms('BDR-T17197');
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.StatusColumn,eleValues.Status,filterdet.IsAnyOf,eleValues.isanyof,'Unknown');
			saasBackupHelper.enterFieldByPlaceholder(lct.SearchName,'standard');
			saasBackupHelper.ClickOnElement(lct.ClickOnSkipedFile);
			saasBackupHelper.verifyNoSkipFilesFound();
			
		});
		it('THEN Verify that skip files information is showing when applied status is success for the Advanced connector', ()=>{
			cy.allure().tms('BDR-T17196');
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.StatusColumn,eleValues.Status,filterdet.IsAnyOf,eleValues.isanyof,'Success');
			saasBackupHelper.enterFieldByPlaceholder(lct.SearchName,'advanced');
			saasBackupHelper.ClickOnElement(lct.ClickOnSkipedFile);
			saasBackupHelper.verifyNoSkipFilesFound();
			
		});
		it('THEN Verify that user can able to click on the Download full report from the skip files window', ()=>{
			cy.allure().tms('BDR-T17196');
			saasBackupHelper.clickOnElementByDataTestID(lct.FiltersBtn);
			saasBackupHelper.ApplyFilterOnColumns(filterdet.ExpectedRowsAvailable,filterdet.StatusColumn,eleValues.Status,filterdet.IsAnyOf,eleValues.isanyof,'Success');
			saasBackupHelper.enterFieldByPlaceholder(lct.SearchName,'standard');
			saasBackupHelper.ClickOnElement(lct.ClickOnSkipedFile);
			saasBackupHelper.clickOnElementByDataTestID(lct.ClickOnDownloadReport);
		});

	
	});


	
});

