/* eslint-disable no-mixed-spaces-and-tabs */

const { CommonHelper } = require('../../../../fixtures');

import SaaSBackupHelper from '../helper/SaaSBackupHelper';
import { lct } from '../helper/constants';


class SaaSBackupAccountsCommonCodehelper extends CommonHelper{
	constructor(){
		super();
		this.saasBackupHelper = new SaaSBackupHelper();
	}
	createSaaSBackupAccountCommonCode(accountType,AzureType,Datacenter,CreateAccount,clientSiteSaaSName,email,retention,company,site){

    	cy.log('Click on the Start A trial button/ Create a SaaS Backup Account');
    	this.saasBackupHelper.clickOnElementByDataTestID(CreateAccount);
		cy.log('Create a SaaS Back up page is showing successfully ');
    	this.saasBackupHelper.verifypageconatinstext(lct.CreateSaaSBackupPage);
		
    	cy.log('Click on the Company drop down  ');
    	this.saasBackupHelper.clickOnElementByDataTestID(lct.SelectCompnayDropDown);
    	cy.log('Select the Company name');
		this.saasBackupHelper.selectCompanyandSiteName(company);

    	cy.log('Click on the Site drop down  ');
    	this.saasBackupHelper.clickOnElementByDataTestID(lct.SelectSiteNameDropDpown);
    	cy.log('Select the Comany Site');
    	this.saasBackupHelper.selectCompanyandSiteName(site);
	    cy.log('Select the Client SaaS Site Name');
    	this.saasBackupHelper.enterTextMessage(lct.ClientSaaSSiteName,clientSiteSaaSName);
		cy.log('Enter the Email Detail');
    	this.saasBackupHelper.enterTextMessage(lct.EmailName,email);
		cy.log('Enter the Retention');
    	this.saasBackupHelper.enterFieldByPlaceholder(lct.RetentionPlaceholder,retention);
		cy.log('Enter the Data Center Drop down');
    	this.saasBackupHelper.selectDatacenter(lct.DatacenterDropDown);
		cy.log('Select the Data Center');
    	this.saasBackupHelper.selectelementfromlist(lct.AllDatacenterandAzureADlists,Datacenter);

    	
		if( accountType == 'Active'){
			cy.log('Click on the Microsoft Entra ID connectpr');
			this.saasBackupHelper.clickOnElementByDataTestID(lct.MicroEntraIdDropdown);

			cy.log('Choose  Microsoft Entra ID connectp');
			this.saasBackupHelper.selectelementfromlist(lct.AllDatacenterandAzureADlists,AzureType);
		}
		cy.log('Click on The Save And Connect');
		this.saasBackupHelper.clickOnElementByDataTestID(lct.SaveAndConnect);
	}


	EditSaaSBackupAcocuntCommonCode(actualClientSiteSaaSName,clientSiteSaaSName,email,accountType,AzureType){
		cy.log('Verifying the editing the valid SaaS Backup Account');
		this.saasBackupHelper.getTextMessage4Elements(lct.ClientSaaSSiteName,actualClientSiteSaaSName);
		cy.log('Enter Edit the Client SaaS Site Name');
		this.saasBackupHelper.enterTextMessage(lct.ClientSaaSSiteName,clientSiteSaaSName);
		cy.log('Enter the Email Detail');
		this.saasBackupHelper.enterTextMessage(lct.EmailName,email);

		if( accountType == 'Active'){

			//Click on the MicroSoft Entra ID
			cy.log('Click on the Microsoft Entra ID connectpr');
			this.saasBackupHelper.clickOnElementByDataTestID(lct.MicroEntraIdDropdown);

			cy.log('Choose  Microsoft Entra ID connectp');
			this.saasBackupHelper.selectelementfromlist(lct.AllDatacenterandAzureADlists,AzureType);
		}

	}



}export default SaaSBackupAccountsCommonCodehelper;