export const moduleMetaData = {
	name: 'Communicator',
	customUser: 'user_1',
};

export const ltr = {
	'addNewButton': 'communicator-add-button',
	'deleteIconButton': 'communicator-delete-icon-button',
	'deleteButton': 'communicator-delete-button',
	'sendButton': 'communicator-send-button',
	'grid': 'communicator-data-grid',
	'radioButton': 'communicator-radio',
	'card': 'communicator-summary-card',
	'checkbox': 'communicator-checkbox',
	'addReplyButton': 'communicator-static-options-button',
	'cancelButton': 'communicator-cancel-button',

	'messageField': '#messageText',

	'gridContent': '.MuiDataGrid-virtualScroller',
	'gridRow': '.MuiDataGrid-row',
	'paperRoot': '.MuiPaper-root',
	'columnHeaders': '.MuiDataGrid-columnHeaders',
	'toast': '.MuiAlert-message',
	'selectRowCount': '.MuiDataGrid-selectedRowCount',
	'rowCount': '.MuiDataGrid-rowCount',
	'toolbarContainer': '.MuiDataGrid-toolbarContainer',
	'dialogContent': '.MuiDialogContent-root',
	'error': '.Mui-error',

	'checkBox': 'CheckBoxOutlineBlankIcon',
	'successIcon': 'SuccessOutlinedIcon',
	'searchIcon': 'SearchOutlinedIcon',
	'arrowUpIcon': 'ArrowUpwardIcon',
	'arrowDownIcon': 'ArrowDownwardIcon',
	'closeIcon': 'CloseIcon',

	'inputField': 'input[type="text"]',
	'dateField': 'input[placeholder="MMMM DD, YYYY hh:mm aa"]',

};

export const txt = {
	'delete': 'Delete',
	'successMessage': 'The message has been sent successfully',
	'errorMaxMessageLength200': 'You have exceeded the maximum number of 200 characters, please reduce the number of characters',
	'deleteSuccessMessage': 'Message has been deleted',
	'now': 'Now',
	'later': 'Later',
	'freeFlowTextReply': 'Free-flow text reply',
	'staticOptionsReply': 'Static options reply',
};

export const atr = {

};

export const fieldIndex = {
	'Message': '0',
	'From': '1',
	'Date Sent': '2',
	'Scheduled Date': '3',
	'Read / Total': '4',
	'Reply': '5',
	'Action': '6',
};
