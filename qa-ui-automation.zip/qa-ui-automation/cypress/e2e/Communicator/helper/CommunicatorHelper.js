import CommunicatorDataHelper from './CommunicatorDataHelper';
import { fieldIndex, ltr, moduleMetaData, txt } from './constants';

import { ApiHelper, CommonHelper, ButtonHelper, GridHelper, InputButtonHelper, InputFieldHelper, ResourceSelectorHelper, ToastHelper } from '../../../fixtures';
import { rqt } from '../../../constants';

/**
 * Helper class for Communicator module
 * @class
 * @extends CommonHelper
 */
class CommunicatorHelper extends CommonHelper {
	constructor() {
		super();

		this.button = new ButtonHelper();
		this.inputButton = new InputButtonHelper();
		this.inputField = new InputFieldHelper();
		this.toast = new ToastHelper();
		this.grid = new GridHelper();
		this.apiHelper = new ApiHelper();

		this.resourceSelector = new ResourceSelectorHelper();
		this.dataHelper = new CommunicatorDataHelper();

		this.getCommunicatorMessages = null;
	}

	setupHooks() {
		before(() => {
			// this.interceptApi();
		});

		beforeEach(() => {
			this.navigateToPageOnCheck(moduleMetaData.name);
			// this.checkOnGridApiAndSaveResponse('@getMessages', this.isGetMessagesLoaded, this.getCommunicatorMessages);

			// cy.get('@checkOnGridApiAndSaveResponse').then((result) => {
			//     this.isGetMessagesLoaded = result.classInstFlag;
			//     this.getCommunicatorMessages = result.classInstResponse;
			// });
		});
	}

	setupHooksSingleTestCase() {
		beforeEach(() => {
			this.interceptApi();
		});
	}

	cleanupHooks() {
		after(() => {
			cy.wait(1000);
			this.grid.searchEntryInGrid(this.wrapDataTestId(ltr.searchIcon), 'FAKE_');
			cy.wait(1000);
			this.getElement(this.wrapDataTestId(ltr.grid)).then(($grid) => {
				if ($grid.find(ltr.gridRow).length > 0) {
					this.clickOnGridSelectAll();
					this.clickOnDeleteButtonGrid();
					this.clickOnDeleteButton();
				}
			});
		});
		afterEach(() => {
			this.closeOpenElements(this.wrapDataTestId(ltr.closeIcon));
			cy.wait(1000);
			this.closeOpenElements(this.wrapDataTestId(ltr.cancelButton));
		});
	}

	interceptApi() {
		this.apiHelper.setAliasForApi(rqt.Get, '**messages?noCache=*', 'getMessages').then(() => {
			this.isGetMessagesLoaded = false;
		});
	}

	getData() {
		return this.testData;
	}

	setData(testData) {
		this.testData = testData;
	}

	createCommunicatorTestData(fields) {
		let testData = fields
			? this.dataHelper.generateBaseData().setTestData(fields).getTestData()
			: this.dataHelper.generateBaseData().getTestData();

		this.setData(testData);
		return this;
	}

	clickOnAddNewMessageButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.addNewButton));
	}

	selectFirst5Resources() {
		this.getElement(ltr.dialogContent).should('contain.text', 'Device Name').find(ltr.gridRow).then((rows) => {
			cy.wrap(rows).each((row, index) => {
				if (index < 5) {
					cy.wrap(row).find('input').check();
				}
			});
		});
	}

	typeMessage(message) {
		this.inputField.clearInputField(ltr.messageField);
		this.inputField.typeIntoInputField(ltr.messageField, message);
	}

	typeLaterDateTime(laterTime) {
		this.getFirstElement(ltr.dateField).type(laterTime.split(' ').join(''));
	}

	typeExpirationDateTime(expirationTime) {
		this.getLastElement(ltr.dateField).type(expirationTime.split(' ').join(''));
	}

	clickOnSendButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.sendButton));
	}

	clickOnRadioButton(option) {
		this.getElement(this.wrapDataTestId(ltr.radioButton)).then((options) => {
			cy.wrap(options).each((opt) => {
				cy.wrap(opt).parent().invoke('text').then((text) => {
					if (text.includes(option)) {
						cy.wrap(opt).click();
					}
				});
			});
		});
	}

	clickOnEnableReplyCheckbox() {
		this.button.clickButton(this.wrapDataTestId(ltr.checkbox));
	}

	clickOnAddReplyButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.addReplyButton));
	}

	clickOnDeleteButtonGrid() {
		this.getElement(ltr.toolbarContainer).find(this.wrapDataTestId(ltr.deleteButton)).click();
	}

	clickOnDeleteIconButtonRow(index) {
		index = index ? index : 0;
		this.getElement(ltr.gridRow).find(this.wrapDataTestId(ltr.deleteButton)).eq(index).click();
	}

	clickOnDeleteButton() {
		this.getLastElement(this.wrapDataTestId(ltr.deleteButton)).click();
	}

	clickOnGridSelectAll() {
		this.getElement(ltr.columnHeaders).find('input').click();
	}

	validateFourReplyOptionsArePresent() {
		this.clickOnAddReplyButton();
		this.clickOnAddReplyButton();

		this.getElement(ltr.inputField).then((inputs) => {
			assert(inputs.length >= 4);
		});
	}

	validateAddReplyButtonIsDisabled() {
		this.button.checkButtonIsDisabled(this.wrapDataTestId(ltr.addReplyButton));
	}

	validateNewMessageIsPresentOnGrid(name) {
		// cy.wait('@getMessages');
		this.grid.searchEntryInGrid(this.wrapDataTestId(ltr.searchIcon), name);

		this.getElement(this.wrapDataTestId(ltr.grid))
			.contains(name)
			.should('be.visible')
			.click();
	}

	validateMessageIsNotPresentOnGrid(name) {
		this.getElement(this.wrapDataTestId(ltr.grid)).should('not.contain.text', name);
	}

	validateHoverButtonAndAssertTooltipText = () => {
		this.button
			.hoverButtonAndAssertTooltipText(
				this.wrapDataTestId(ltr.deleteButton),
				'[role="tooltip"]',
				txt.delete
			);
	};

	validateCommunicatorToastMessage(message) {
		this.toast.validateToastMessage(ltr.toast, this.wrapDataTestId(ltr.successIcon), message);
		this.getLastElement(this.wrapDataTestId(ltr.closeIcon)).click();
	}

	validateCardHasValue(field, value) {
		const singleDigitFormatter = (number) => number[0] === '0' ? number.slice(-1) : number;

		if (field === 'Expiration') {
			const date = value.split(' ');
			value = `${date[0]} ${singleDigitFormatter(date[1])}, ${date[2]} ${singleDigitFormatter(date[3])}:${date[4]} ${date[5]}`;
		}
		this.getElement(this.wrapDataTestId(ltr.card)).should('contain.text', value);
	}

	validateErrorMessage(message) {
		this.getLastElement(ltr.error).should('contain.text', message);
	}

	selectRowOnGrid(index) {
		index = index ? index : 0;
		this.grid.selectRowByIndexWithCheckbox(ltr.gridRow, index);
	}

	addBasicMessage(testData) {
		this.clickOnAddNewMessageButton();
		this.selectFirst5Resources();
		this.typeMessage(testData.message);
		this.clickOnSendButton();
		this.validateCommunicatorToastMessage(testData.successMessage);
		this.validateNewMessageIsPresentOnGrid(testData.message);
	}

	checkIfDateSentFieldHasDefaultSortingEnabled() {
		this.grid.checkIfSortingArrowIsVisibleOnGivenField('Date Sent', fieldIndex, 'descending');
	}

}

export default CommunicatorHelper;