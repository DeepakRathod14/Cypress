import { CommonHelper } from '../../../fixtures';
import { txt } from './constants';

class CommunicatorDataHelper {

	constructor() {
		this.commonHelper = new CommonHelper();
	}

	generateBaseData() {
		this.testData = {
			message:  this.commonHelper.getFakeMessage(5),
			successMessage: txt.successMessage,
		};
		return this;
	}

	getTestData() {
		return this.testData;
	}

	setTestData(testData) {
		this.testData = {
			...this.testData,
			...testData
		};
        
		return this;
	}

}

export default CommunicatorDataHelper;