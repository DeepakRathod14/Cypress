import CommunicatorHelper from '../helper/CommunicatorHelper';
import { txt } from '../helper/constants';

describe('GIVEN Communicators Page', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var communicatorHelper = new CommunicatorHelper();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		/** 
         * base hooks defined for pre and post conditions
         * before, beforeEach, after, afterEach
         * NOTE: Add custom conditions to specific test cases only
         */
		communicatorHelper.setupHooks();
		communicatorHelper.cleanupHooks();

		it( 'THEN Verify whether Date Sent has default DESCENDING sorting order', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			communicatorHelper.checkIfDateSentFieldHasDefaultSortingEnabled('Date Sent', 'descending');
		});

		it( 'THEN Verify whether Delete Tooltip is present on delete icon', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			const testData = communicatorHelper.createCommunicatorTestData({
				message: communicatorHelper.getFakeMessage(2),
				deleteMessage: txt.deleteSuccessMessage,
			}).getData();

			communicatorHelper.addBasicMessage(testData);
			communicatorHelper.validateHoverButtonAndAssertTooltipText();
		});

		it( 'THEN Verify whether user is able to Delete a Message using Grid Delete Button', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			const testData = communicatorHelper.createCommunicatorTestData({
				message: communicatorHelper.getFakeMessage(2),
				deleteMessage: txt.deleteSuccessMessage,
			}).getData();

			communicatorHelper.addBasicMessage(testData);
			communicatorHelper.selectRowOnGrid();
			communicatorHelper.clickOnDeleteButtonGrid();
			communicatorHelper.clickOnDeleteButton();
			communicatorHelper.validateCommunicatorToastMessage(testData.deleteMessage);
			communicatorHelper.validateMessageIsNotPresentOnGrid(testData.message);
		});

		it( 'THEN Verify whether user is able to Delete a Message using Grid Row Delete Button', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			const testData = communicatorHelper.createCommunicatorTestData({
				message: communicatorHelper.getFakeMessage(2),
				deleteMessage: txt.deleteSuccessMessage,
			}).getData();

			communicatorHelper.addBasicMessage(testData);
			communicatorHelper.clickOnDeleteIconButtonRow();
			communicatorHelper.clickOnDeleteButton();
			communicatorHelper.validateCommunicatorToastMessage(testData.deleteMessage);
			communicatorHelper.validateMessageIsNotPresentOnGrid(testData.message);
		});

		it( 'THEN Verify whether add reply button is disabled when 4 reply fields are present', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			communicatorHelper.clickOnAddNewMessageButton();
			communicatorHelper.clickOnEnableReplyCheckbox();
			communicatorHelper.clickOnRadioButton(txt.staticOptionsReply);
			communicatorHelper.validateFourReplyOptionsArePresent();
			communicatorHelper.validateAddReplyButtonIsDisabled();
		});

		it( 'THEN Verify whether error is thrown for message length more than 200', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');
			
			const testData = communicatorHelper.createCommunicatorTestData({
				message: communicatorHelper.getFakeValue(201),
				errorMessage: txt.errorMaxMessageLength200,
			}).getData();
            
			communicatorHelper.clickOnAddNewMessageButton();
			communicatorHelper.typeMessage(testData.message);
			communicatorHelper.validateErrorMessage(testData.errorMessage);
		});
	});

});
