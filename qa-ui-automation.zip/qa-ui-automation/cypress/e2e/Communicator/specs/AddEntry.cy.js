import CommunicatorHelper from '../helper/CommunicatorHelper';
import { txt } from '../helper/constants';

describe('GIVEN Communicators Page', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var communicatorHelper = new CommunicatorHelper();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		/** 
         * base hooks defined for pre and post conditions
         * before, beforeEach, after, afterEach
         * NOTE: Add custom conditions to specific test cases only
         */
		communicatorHelper.setupHooks();
		communicatorHelper.cleanupHooks();

		it('THEN Verify whether user is able to Add New Message', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			const testData = communicatorHelper.createCommunicatorTestData().getData();

			communicatorHelper.clickOnAddNewMessageButton();
			communicatorHelper.selectFirst5Resources();
			communicatorHelper.typeMessage(testData.message);
			communicatorHelper.clickOnSendButton();
			communicatorHelper.validateCommunicatorToastMessage(testData.successMessage);
			communicatorHelper.validateNewMessageIsPresentOnGrid(testData.message);
		});

		it( 'THEN Verify whether user is able to Add New Message with send NOW and specific expiry date', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			const testData = communicatorHelper.createCommunicatorTestData({
				expirationTime: communicatorHelper.getFormattedFakeDate(), 
			}).getData();

			communicatorHelper.clickOnAddNewMessageButton();
			communicatorHelper.selectFirst5Resources();
			communicatorHelper.typeExpirationDateTime(testData.expirationTime);
			communicatorHelper.typeMessage(testData.message);
			communicatorHelper.clickOnSendButton();
			communicatorHelper.validateCommunicatorToastMessage(testData.successMessage);
			communicatorHelper.validateNewMessageIsPresentOnGrid(testData.message);
			communicatorHelper.validateCardHasValue('Expiration', testData.expirationTime);
		});

		it( 'THEN Verify whether user is able to Add New Message with send LATER', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			const testData = communicatorHelper.createCommunicatorTestData({
				sendOption: txt.later,
			}).getData();

			communicatorHelper.clickOnAddNewMessageButton();
			communicatorHelper.selectFirst5Resources();
			communicatorHelper.clickOnRadioButton(testData.sendOption);
			communicatorHelper.typeMessage(testData.message);
			communicatorHelper.clickOnSendButton();
			communicatorHelper.validateCommunicatorToastMessage(testData.successMessage);
			communicatorHelper.validateNewMessageIsPresentOnGrid(testData.message);
		});

		it( 'THEN Verify whether user is able to Add New Message with send LATER and specific expiry date', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			const testData = communicatorHelper.createCommunicatorTestData({
				sendOption: txt.later,
				expirationTime: communicatorHelper.getFormattedFakeDate(),
			}).getData();

			communicatorHelper.clickOnAddNewMessageButton();
			communicatorHelper.selectFirst5Resources();
			communicatorHelper.clickOnRadioButton(testData.sendOption);
			communicatorHelper.typeExpirationDateTime(testData.expirationTime);
			communicatorHelper.typeMessage(testData.message);
			communicatorHelper.clickOnSendButton();
			communicatorHelper.validateCommunicatorToastMessage(testData.successMessage);
			communicatorHelper.validateNewMessageIsPresentOnGrid(testData.message);
		});

		it( 'THEN Verify whether user is able to Add New Message with send LATER and specific later date', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			const testData = communicatorHelper.createCommunicatorTestData({
				sendOption: txt.later,
				laterTime: communicatorHelper.getFormattedFakeDate(),
			}).getData();

			communicatorHelper.clickOnAddNewMessageButton();
			communicatorHelper.selectFirst5Resources();
			communicatorHelper.clickOnRadioButton(testData.sendOption);
			communicatorHelper.typeLaterDateTime(testData.laterTime);
			communicatorHelper.typeMessage(testData.message);
			communicatorHelper.clickOnSendButton();
			communicatorHelper.validateCommunicatorToastMessage(testData.successMessage);
			communicatorHelper.validateNewMessageIsPresentOnGrid(testData.message);
		});

		it( 'THEN Verify whether user is able to Add New Message with send NOW and Free-flow text reply', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');
			
			const testData = communicatorHelper.createCommunicatorTestData({
				sendOption: txt.now,
				enableReplyOption: txt.freeFlowTextReply,
				expirationTime: communicatorHelper.getFormattedFakeDate(),
			}).getData();

			communicatorHelper.clickOnAddNewMessageButton();
			communicatorHelper.selectFirst5Resources();
			communicatorHelper.clickOnRadioButton(testData.sendOption);
			communicatorHelper.clickOnEnableReplyCheckbox();
			communicatorHelper.clickOnRadioButton(testData.enableReplyOption);
			communicatorHelper.typeExpirationDateTime(testData.expirationTime);
			communicatorHelper.typeMessage(testData.message);
			communicatorHelper.clickOnSendButton();
			communicatorHelper.validateCommunicatorToastMessage(testData.successMessage);
			communicatorHelper.validateNewMessageIsPresentOnGrid(testData.message);
			communicatorHelper.validateCardHasValue('Is Reply Enabled', 'True');
		});
        
	});

});
