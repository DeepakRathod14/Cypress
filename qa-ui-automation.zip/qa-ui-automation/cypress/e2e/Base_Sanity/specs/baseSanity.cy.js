
describe('GIVEN Portal', { tags: ['@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	context('WHERE user is migrated/SSO', { tags: ['@sanity', '@Migrated'] }, () => {

		it('THEN Verify Portal is loading', { tags: ['@sanity', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('');

			cy.contains('Workstations & Servers').should('be.visible');
		});

	});

});