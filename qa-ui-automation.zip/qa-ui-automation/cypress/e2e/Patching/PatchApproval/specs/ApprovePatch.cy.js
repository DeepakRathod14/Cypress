import PatchApprovalHelper from '../helper/PatchApprovalHelper';
import { moduleMetaData, lct, indices, texts, nocStatus } from '../helper/constants';

describe(
	'Should Approve Patches',
	{ tags: ['@Patch Approvals', '@MUI'] },
	() => {
		var patchApprovalHelper = new PatchApprovalHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {
			patchApprovalHelper.setupApiHooks();
			before(() => {
				patchApprovalHelper.setup(moduleMetaData);
			});

			beforeEach(() => {
				patchApprovalHelper.navigateToPageOnCheck(moduleMetaData.name);
			});

			afterEach(() => {
				patchApprovalHelper.pageReload();
				// retryAttempt += 1;
			});

			after(() => {
				// Cy.clearAllCookies()
			});

			it.skip('Should Cancel Modal Single Patch', function () {
				patchApprovalHelper.getRowCheckbox(`${lct.gridRow} input`).first().check();
				cy.wait(1000);
				patchApprovalHelper.getApproveButton(lct.approveButton).click();
				patchApprovalHelper.getApprovalModal(lct.approvalModal).should('exist');
				patchApprovalHelper.getCancelButton(lct.cancel).click();
				patchApprovalHelper.getApprovalModal(lct.approvalModal).should('not.exist');
			});

			it.skip('Should Cancel Modal All Selected Patch', function () {
				patchApprovalHelper.getGridRoot(lct.gridRoot, 'exist');
				patchApprovalHelper.validateFirstRowExists(lct.gridRow);
				patchApprovalHelper.getColumnHeaders(`${lct.gridColumnHeaders} input`).check();
				cy.wait(1000);
				patchApprovalHelper.getApproveButton(lct.approveButton).click();
				patchApprovalHelper.getApprovalModal(lct.approvalModal).should('exist');
				patchApprovalHelper.getCancelButton(lct.cancel).click();
				patchApprovalHelper.getApprovalModal(lct.approvalModal).should('not.exist');
			});

			it.skip('Should Remove Predefined Date filter', function () {
				patchApprovalHelper.getRowCountElement(lct.rowCount)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						patchApprovalHelper.validateFirstRowExists(lct.gridRow);
						patchApprovalHelper.validateLastRowExists(
							lct.gridVirtualScroller,
							lct.gridRow
						);
						patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
						patchApprovalHelper.getRowCountElement(lct.rowCount)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it.skip('Should Approve Single Patch', function () {
				patchApprovalHelper.scrollGridToTop(lct.gridVirtualScroller);
				patchApprovalHelper.validateFirstRowExists(lct.gridRow);
				patchApprovalHelper.sortColumn(lct.selectColumn, indices.resultColumn);
				patchApprovalHelper.checkRowCheckBox(lct.gridRow, indices.firstRow);
				patchApprovalHelper.getApproveButton(lct.approveButton).click();
				patchApprovalHelper.getApprovalModal(lct.approvalModal).should('exist');
				patchApprovalHelper.getSubmitButton(lct.submit).click();
				patchApprovalHelper.getApprovalModal(lct.approvalModal).should('not.exist');
			});

			it.skip('Should Hide Column', function () {
				patchApprovalHelper.getRowByIndex(lct.gridRow, indices.firstRow)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						patchApprovalHelper.validateFirstRowExists(lct.gridRow);
						patchApprovalHelper.selectHideColumnButton(lct.hideColumnButton);
						patchApprovalHelper.hideColumn(lct.hideColumnInput, indices.resultColumn);
						patchApprovalHelper.getRowByIndex(lct.gridRow, indices.firstRow)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('PCH-T1685: Change group status from NEW to REVIEWED using "Approve" header button', function () {
				patchApprovalHelper.getRowCheckbox(`${lct.gridRow} input`).first().check();
				patchApprovalHelper.getApproveButton(lct.approveButton).click();
				patchApprovalHelper.getElement(lct.modalWindow).should('contain', texts.approvalModalMessage);
				patchApprovalHelper.getApproveButton(lct.submit).click();
			});

			it('PCH-T1686: Change group status from NEW to REVIEWED using "Block" header button', function () {
				patchApprovalHelper.getRowCheckbox(`${lct.gridRow} input`).first().check();
				patchApprovalHelper.getElementBydatatestid(lct.blockButton).click();
				patchApprovalHelper.getElement(lct.modalWindow).should('contain', texts.blockModalMessage);
				patchApprovalHelper.getElementBydatatestid(lct.blockPatches).click();
			});

			it('PCH-T1705: Verify Partner Approvals Page provides ability to search for patches based on Update Name', function () {
				const patchId = patchApprovalHelper.createPatches(false);
				patchApprovalHelper.pageReload();
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).invoke('text').should('not.contain', patchId);
			});

			it('PCH-T1706: Verify that no results are found on Partner Approvals Page when searching for OS patches using non-existing Update Name', function () {
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, 'non-existing Update');
				patchApprovalHelper.checkElementNotExist(lct.gridRow);
			});

			it('PCH-T2095: Verify default sorting of the grid page load is by "Status" column (ASC-DSC)', function () {
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, 'Security');
				patchApprovalHelper.getElement(lct.classificationColumn).should('contain', 'Security');
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0)
					.invoke('text')
					.as('initialText').should('contain', 'New')
					.then((initialText) => {
						patchApprovalHelper.validateFirstRowExists(lct.gridRow);
						patchApprovalHelper.sortColumn(lct.selectColumn, indices.statusColumn);
						patchApprovalHelper.getRowByIndex(lct.gridRow, indices.firstRow)
							.invoke('text')
							.as('newText')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('PCH-T2096:  Verify ability to sort the information by "Classification" including reverse order', function () {
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						patchApprovalHelper.validateFirstRowExists(lct.gridRow);
						patchApprovalHelper.sortColumn(lct.selectColumn, indices.classificationColumn);
						patchApprovalHelper.getRowByIndex(lct.gridRow, indices.firstRow)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('PCH-T2097:  Verify ability to sort the information by "Result" including reverse order', function () {
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						patchApprovalHelper.validateFirstRowExists(lct.gridRow);
						patchApprovalHelper.sortColumn(lct.selectColumn, indices.resultColumn);
						patchApprovalHelper.sortColumn(lct.selectColumn, indices.resultColumn);
						patchApprovalHelper.getRowByIndex(lct.gridRow, indices.firstRow)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('PCH-T2187: Verify Partner Approvals Page provides ability to search for patches based Reviewed Status', function () {
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, 'Reviewed');
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnStatus, 'Reviewed');
			});

			it('PCH-T1687: Change group status from NEW to REVIEWED using "Approve All" Details Card button', function () {
				const patchId = patchApprovalHelper.createPatches(true);
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.approveAll).click();
				patchApprovalHelper.getElementBydatatestid(lct.approveAll).should('be.disabled');
				patchApprovalHelper.pageReload();
				patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, patchId);
				patchApprovalHelper.checkElementIsVisibleWithText('[aria-label]', patchId);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnStatus, 'Reviewed');
			});

			it('PCH-T1688: Change group status from NEW to REVIEWED using "Block All" Details Card button', function () {
				const patchId = patchApprovalHelper.createPatches(true);
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.blockAll).click();
				patchApprovalHelper.getElementBydatatestid(lct.blockAll).should('be.disabled');
				patchApprovalHelper.pageReload();
				patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, patchId);
				patchApprovalHelper.checkElementIsVisibleWithText('[aria-label]', patchId);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnStatus, 'Reviewed');
			});

			it('PCH-T1691: Change group status from NEW to IN PROGRESS using "Block" Details Card patch button', function () {
				const patchId = patchApprovalHelper.createPatches(true);
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getFirstBlockButtonFromCard(lct.cardBlock);
				patchApprovalHelper.pageReload();
				cy.wait(1000);
				patchApprovalHelper.pageReload(); //temp fix as page loaind issue
				patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, patchId);
				patchApprovalHelper.checkElementIsVisibleWithText('[aria-label]', patchId);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnStatus, 'In Progress');
			});

			it('PCH-T2098: Verify combination filtering + sorting', function () {
				patchApprovalHelper.getRowCountElement(lct.rowCount)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						patchApprovalHelper.selectFilterButton(lct.filterButton);
						patchApprovalHelper.selectDropdownValue(
							lct.nativeSelect,
							indices.dropdownName,
							'status'
						);
						patchApprovalHelper.selectDropdownValue(
							lct.nativeSelect,
							indices.dropdownFilter,
							'is'
						);
						patchApprovalHelper.selectDropdownValue(
							lct.nativeSelect,
							indices.dropdownValue,
							'New'
						);
						patchApprovalHelper.getRowCountElement(lct.rowCount)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
				patchApprovalHelper.closeFilter(lct.removeFilterButton);
				patchApprovalHelper.pageReload();

				patchApprovalHelper.getRowByIndex(lct.gridRow, 0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						patchApprovalHelper.validateFirstRowExists(lct.gridRow);
						patchApprovalHelper.sortColumn(lct.selectColumn, indices.resultColumn);
						patchApprovalHelper.sortColumn(lct.selectColumn, indices.resultColumn);
						patchApprovalHelper.getRowByIndex(lct.gridRow, indices.firstRow)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it.skip('PCH-T1689: Change group status from APPROVED to DISAPPROVED using "Disapprove all" Details Card button', function () {
				//Approve All Patches
				const patchId = patchApprovalHelper.createPatches(true);
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.approveAll).click();
				patchApprovalHelper.getElementBydatatestid(lct.approveAll).should('be.disabled');
				patchApprovalHelper.pageReload();
				patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, patchId);
				patchApprovalHelper.checkElementIsVisibleWithText('[aria-label]', patchId);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnResult, 'Approved');

				//Approved to partially Approved
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getFirstBlockButtonFromCard(lct.cardBlock);
				patchApprovalHelper.pageReload();
				patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, patchId);
				patchApprovalHelper.checkElementIsVisibleWithText('[aria-label]', patchId);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnResult, 'Partially Approved');

				//Partially Approved to BlockALl
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.blockAll).click();
				patchApprovalHelper.getElementBydatatestid(lct.blockAll).should('be.disabled');
				patchApprovalHelper.pageReload();
				patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, patchId);
				patchApprovalHelper.checkElementIsVisibleWithText('[aria-label]', patchId);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnResult, 'Blocked');

				//BlockAll to ApproveAll
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.approveAll).click();
				patchApprovalHelper.getElementBydatatestid(lct.approveAll).should('be.disabled');
				patchApprovalHelper.pageReload();
				patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, patchId);
				patchApprovalHelper.checkElementIsVisibleWithText('[aria-label]', patchId);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnResult, 'Approved');

				//ApproveAll to BlockAll
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.blockAll).click();
				patchApprovalHelper.getElementBydatatestid(lct.blockAll).should('be.disabled');
				patchApprovalHelper.pageReload();
				patchApprovalHelper.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, patchId);
				patchApprovalHelper.checkElementIsVisibleWithText('[aria-label]', patchId);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnResult, 'Blocked');				
			});

			it.skip('PCH-T2375: Verify "Manually Deploy Patches" "Confirm" modal window third step with schedule', function() {
				patchApprovalHelper.manualSchedulePatchDeploy();
			});

			it('PCH-T2374: Verify "Manually Deploy Patches" "Confirm" modal window third step without schedule', function() {
				patchApprovalHelper.manualPatchDeployNow();
			});
	
			it('PCH-T2067: Verify that "no results found" label shown on Partner Approvals Page when filtering by incompatible values', function() {
				patchApprovalHelper.selectFilterButton(lct.filterButton);
				patchApprovalHelper.selectDropdownValue(lct.nativeSelect,indices.dropdownName,'Update Name');
				patchApprovalHelper.selectDropdownValue(lct.nativeSelect,indices.dropdownFilter,'equals');
				patchApprovalHelper.getElementWithIndex(lct.filterValue,indices.filterValue).type('non-existing Update');
				cy.wait(3000);
				patchApprovalHelper.selectFilterButton(lct.filterButton);
				patchApprovalHelper.checkElementIsVisibleWithText(lct.noResultFound, 'No results found');
				patchApprovalHelper.pageReload();
				patchApprovalHelper.checkElementIsVisible(lct.gridRow);
			});

			it('PCH-T2065: Verify Partner Approvals Page filter by default value', function () {
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, 'Reviewed');
				patchApprovalHelper.checkElementIsVisibleWithText(lct.columnStatus, 'Reviewed');
			});

			it('PCH-T2407: Verify Partner Approvals Page has default released in last 90 days enabled', function() {
				const today = patchApprovalHelper.getCurrentDate();
				const priorDate = new Date(today);
				priorDate.setDate(priorDate.getDate() - 90);
				// Format the prior date as YYYY-MM-DD
				const priorDateString = priorDate.toISOString().split('T')[0];
				patchApprovalHelper.selectFilterButton(lct.filterButton);
				patchApprovalHelper.getElement(lct.filterCalender)
					.invoke('prop', 'value')
					.as('UIDate')
					.then((UIDate) => {
						expect(UIDate).equal(priorDateString);
					});
			});

			it('PCH-T2064: Verify Partner Approvals Page provides ability to filter based on multiple values of different categories', function() {
				patchApprovalHelper.selectFilterButton(lct.filterButton);
				patchApprovalHelper.selectDropdownValue(
					lct.nativeSelect,
					indices.dropdownName,
					'status'
				);
				patchApprovalHelper.selectDropdownValue(
					lct.nativeSelect,
					indices.dropdownFilter,
					'is'
				);
				patchApprovalHelper.selectDropdownValue(
					lct.nativeSelect,
					indices.dropdownValue,
					'New'
				);
				cy.wait(3000);
				patchApprovalHelper.getRowCountElement(lct.rowCount)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						patchApprovalHelper.addFilter(lct.addFilter);
						patchApprovalHelper.selectDropdownValue(
							lct.nativeSelect,
							indices.secondRowdropdownName,
							'Classification'
						);
						patchApprovalHelper.selectDropdownValue(
							lct.nativeSelect,
							indices.secondRowdropdownFilter,
							'is'
						);
						patchApprovalHelper.selectDropdownValue(
							lct.nativeSelect,
							indices.secondRowdropdownValue,
							'Security Updates'
						);
						patchApprovalHelper.getRowCountElement(lct.rowCount)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});	
					});
			});
		
			it.skip('PCH-T1834: Patching OS: Check conditionally approved message is present if NOC testing status "Conditionally Blacklisted"', function() {
				// const patchId = patchApprovalHelper.createPatches(true);	
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, 'KB697620');
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.patchDescriptionCard).should('contain', 'This update has been Conditionally Approved by NOC');
				// patchApprovalHelper.getElementBydatatestid(lct.patchDescriptionCard).should('contain', 'This patch was blocked by NOC');
			});

			it.skip('PCH-T1921: Make sure when partner overrides NOC decision when patch APPROVED the right info is shown', function() {
				// const patchId = patchApprovalHelper.createPatches(true);	
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, 'KB697620');
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.patchDescriptionCard).should('contain', 'This update has been Conditionally Approved by NOC');
				// patchApprovalHelper.getElementBydatatestid(lct.patchDescriptionCard).should('contain', 'This patch was blocked by NOC');
			}); 

			it.skip('PCH-2042: Make sure when partner overrides NOC decision, when patch status BLOCKED, the right info is shown', function() {
				// const patchId = patchApprovalHelper.createPatches(true);	
				patchApprovalHelper.selectSearchButton(lct.searchButton);
				patchApprovalHelper.searchInGrid(lct.formInput, 'KB697620');
				patchApprovalHelper.getRowByIndex(lct.gridRow, 0).click();
				patchApprovalHelper.getElementBydatatestid(lct.patchDescriptionCard).should('contain', 'This update has been Conditionally Approved by NOC');
				// patchApprovalHelper.getElementBydatatestid(lct.patchDescriptionCard).should('contain', 'This patch was blocked by NOC');
			});

			it('Should approve noc patch patch ', function () {
				const patchId = patchApprovalHelper.createPatches(false);
				cy.log('Patch ID: ' + patchId);
				const body = { 'nocStatus': nocStatus.conditionalBlacklisted };
				patchApprovalHelper.approveNocPatches(body, patchId.substring(2));
			});

		});
	}
);
