import { CommonHelper } from '../../../../fixtures';
import { createPatchBody, installedPatches1, installedPatches2, missingPatches } from './constants';

class PatchDataHelper {

	constructor() {
		this.commonHelper = new CommonHelper();
	}

	generatePatchCreationData() {
		this.testDataApi = {
			...createPatchBody
		};

		return this;
	}

	setDataForApi(kbArticleID, updateID, updateID2 = '', missingUpdateID = '') {
		this.testDataApi = {
			installedPatches: this.testDataApi.installedPatches,
			executionContext: {
				...this.testDataApi.executionContext
			},
			missingPatches: this.testDataApi.missingPatches,
			assessmentDate: this.testDataApi.assessmentDate
		};

		if(missingUpdateID != '') {
			this.testDataApi.missingPatches[0] = {
				...missingPatches,
				kbArticleID: kbArticleID.toString(),
				updateID: missingUpdateID
			};
		}

		this.testDataApi.installedPatches[0] = {
			...installedPatches1,
			kbArticleID: kbArticleID.toString(),
			updateID: updateID
		};

		if(updateID2 != '') {
			this.testDataApi.installedPatches[1] = {
				...installedPatches2,
				kbArticleID: kbArticleID.toString(),
				updateID: updateID2
			};
		}

		return this;
	}

	getDataForApi() {
		return this.testDataApi;
	}

}

export default PatchDataHelper;