export const moduleMetaData = {
	name: 'Patch Approvals',
	// customUser: 'user_ospatching',
	customUser: 'user_ospatchingui'
};

export const lct = {
	'approveButton': 'osp-approve-btn',
	'blockButton': 'osp-disapprove-btn',
	'button': '.MuiButtonBase-root',
	'rowCount': '.MuiDataGrid-rowCount',
	'cancel': 'approve-multiple-modal-close-button',
	'submit': 'approve-multiple-modal-submit-button',
	'approvalModal': '.MuiDialog-container',
	'gridRoot': '.MuiDataGrid-root',
	'gridRow': '.MuiDataGrid-row',
	'gridColumnHeaders': '.MuiDataGrid-columnHeaders',
	'gridVirtualScroller': '.MuiDataGrid-virtualScroller',
	'gridCell': '.MuiDataGrid-cell',
	'gridCellRenderer': '.MuiDataGrid-cell--withRenderer',
	'selectColumn': '.MuiDataGrid-columnHeaderTitleContainer',
	'nativeSelect': '.MuiNativeSelect-select',
	'formInput': '.MuiFormControl-root input',
	'list': '.MuiList-root',
	'filterButton': 'FilterAltOutlinedIcon',
	'removeFilterButton': 'CloseIcon',
	'removeAllFilterButton': 'DeleteIcon',
	'rowCheckox': 'CheckBoxOutlineBlankIcon',
	'searchButton': 'SearchOutlinedIcon',
	'hideColumnButton': 'ViewColumnOutlinedIcon',
	'hideColumnInput': '.MuiDataGrid-columnsPanelRow input',
	'toggleViewButton': 'ViewStreamIcon',
	'removeAll':'Remove all',
	'blockPatches':'block-multiple-modal-submit-button',
	'columnStatus': '[data-field="status"]',
	'columnResult': '[data-field="result"]',
	'approveAll':'osp-details-approve-all',
	'blockAll':'osp-details-disapprove-all',
	'cardBlock': '.MuiButtonGroup-groupedOutlinedPrimary.MuiButtonGroup-lastButton',
	'modalWindow' : '.MuiDialogContent-root',
	'classificationColumn': '[data-field="classification"]',
	'deploy': '[datatestid="patch-deployment-modal--deploy-button"]',
	'scheduleDeployment' : '.PrivateSwitchBase-input',
	'calenderDateEntry': '[placeholder="MM/DD/YYYY"]',
	'calenderTimeEntry': '[placeholder="hh:mm aa"]',
	'manualDeploySelectEndpointBtn': '[datatestid="patch-deployment-modal--select-endpoints-button"]',
	'manualDeployConfirmBtn': '[datatestid="patch-deployment-modal--confirm-deployment-button"]',
	'manualDeployConfirmation': 'patch-deployment-modal--content',
	'filterValue' : '.MuiInputBase-input',
	'noResultFound' : '.MuiDataGrid-overlay',
	'filterCalender' : '[placeholder="Filter value"]',
	'addFilter' : 'AddIcon',
	'viewInScheduledTask' : 'SettingsIcon',
	'deployMissingOSPatch' : '.tasks-sequences-module-breadcrumbWrapper',
	'addNewTaskName' : '#addNewTaskName',
	'timezoneasio' : '#timezone-asio',
	'deployPatch' : '[datatestid="patch-deployment-modal--deploy-patch-button"]',
	'rebootEndpoint' : '.PrivateSwitchBase-input',
	'patchDescriptionCard' : 'patch-approvals-description-muiCard',
};

export const texts = {
	'approve': 'Approve',
	'block': 'Block',
	'removeFilter': 'Remove',
	'searchText': 'Updates',
	'approvalModalMessage': '1 OS patch(es) will be approved for deployment.',
	'blockModalMessage' : '1 OS patch(es) will be blocked for deployment.',
};

export const nocStatus = {
	'underReview': 'UNDER_REVIEW',
	'whitelisted': 'WHITELISTED',
	'blacklisted': 'BLACKLISTED',
	'globallyBlacklistedSecurity': 'GLOBALLY_BLACKLISTED_SECURITY',
	'globallyBlacklistedUpdates': 'GLOBALLY_BLACKLISTED_UPDATES',
	'conditionalBlacklisted': 'CONDITIONAL_BLACKLISTED'
};

export const indices = {
	'resultColumn': 6,
	'statusColumn':5,
	'dateReviewedColumn':4,
	'dateReleasedColumn':3,
	'classificationColumn':2,
	'patchNameColumn':1,
	'firstRow':0,
	'dropdownName':1,
	'dropdownFilter':2,
	'dropdownValue':3,
	'index1':1,
	'index2':2,
	'filterValue' : 3,
	'secondRowdropdownName':5,
	'secondRowdropdownFilter':6,
	'secondRowdropdownValue':7,
};

export const installedPatches1 = {
	'lastModifiedDate': new Date(),
	'classification': {
		'ID': '0fa1201d-4330-4fa8-8ae9-b877473b6441',
		'Name': 'Security Updates'
	},
	'rebootBehavior': {
		'ID': 0,
		'Name': 'Always Requires Reboot'
	},
	'title': 'Automated generated Title oLnZPDFkIP',
	'msrcSeverity': 'Moderate',
	'msrcNumber': Math.random().toFixed(7).split('.')[1],
	'pendingReboot': true,
	'browseOnly': false,
	'version': '6.6.7462',
	'label': 'Automated generated Label sNdIRyEaVr',
	'size': '',
	'recommended': '',
	'action': '',
	'patchInstallationDate': '0001-01-01T00:00:00Z'
};

export const installedPatches2 = {
	'lastModifiedDate': new Date(),
	'classification': {
		'ID': '0fa1201d-4330-4fa8-8ae9-b877473b6441',
		'Name': 'Security Updates'
	},
	'rebootBehavior': {
		'ID': 2,
		'Name': 'Never Reboots'
	},
	'title': 'Automated generated Title lpjjfHMQtS',
	'msrcSeverity': 'Moderate',
	'msrcNumber': Math.random().toFixed(7).split('.')[1],
	'pendingReboot': false,
	'browseOnly': false,
	'version': '4.1.6747',
	'label': 'Automated generated Label qQkfbpwnuq',
	'size': '',
	'recommended': '',
	'action': '',
	'patchInstallationDate': '0001-01-01T00:00:00Z'
};

export const missingPatches = {
	'lastModifiedDate': new Date(),
	'classification': {
		'ID': '0fa1201d-4330-4fa8-8ae9-b877473b6441',
		'Name': 'Security Updates'
	},
	'rebootBehavior': {
		'ID': 2,
		'Name': 'Never Reboots'
	},
	'title': 'Automated generated Title DSuPkJUQXI',
	'msrcSeverity': 'Moderate',
	'msrcNumber': Math.random().toFixed(7).split('.')[1],
	'pendingReboot': false,
	'browseOnly': false,
	'version': '6.1.6962',
	'label': 'Automated generated Label WoQWvLVQVG',
	'size': '',
	'recommended': '',
	'action': '',
	'patchInstallationDate': '0001-01-01T00:00:00Z'
};

export const createPatchBody = {
	'executionContext': {
		'executionError': '',
		'execDurationMillis': 2472,
		'timedOut': false
	},
	'installedPatches': [],
	'missingPatches': [],
	'assessmentDate': new Date()
};
