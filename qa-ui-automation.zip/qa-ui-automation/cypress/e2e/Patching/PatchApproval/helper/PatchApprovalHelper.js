import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper } from '../../../../fixtures';
import PatchingApi from '../../api/PatchingApi';
import PatchDataHelper from './PatchDataHelper';
import { lct } from './constants';
import {v4 as uuidv4} from 'uuid';
class PatchApprovalHelper extends CommonHelper{

	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.apiHelper = new PatchingApi();
		this.dataHelper = new PatchDataHelper();
	}

	getApprovalModal = (approvalModalLocator) => {
		return this.getElement(approvalModalLocator);
	}

	getApproveButton = (approveBtnLocator) => {
		const datatestid = this.wrapDataTestId(approveBtnLocator);
		return this.getElement(datatestid);
	}

	getBlockButton = (blockBtnLocator) => {
		return this.getElement(this.wrapDataTestId(blockBtnLocator));
	}

	getFirstBlockButtonFromCard = (cardBlockBtnLocator) => {
		return this.buttonHelper.clickButtonWithIndex(cardBlockBtnLocator, 1);
	}	

	checkCardBlockIsDisabled = (cardBlockBtnLocator) => {
		return this.buttonHelper.checkButtonIsDisabled(cardBlockBtnLocator);
	}

	getCancelButton = (cancelBtnLocator) => {
		return this.getElement(this.wrapDataTestId(cancelBtnLocator));
	}

	getSubmitButton = (submitBtnLocator) => {
		return this.getElement(this.wrapDataTestId(submitBtnLocator));
	}

	getGridRoot = (gridRootLocator, assertion) => {
		return this.getElementWithAssertion(gridRootLocator, assertion);
	}

	getColumnHeaders = (gridColumnHeadersLocator) => {
		return this.getElement(gridColumnHeadersLocator);
	}

	searchInGrid = (searchAreaLocator, searchString) => {
		return this.gridHelper.searchEntryInGrid(searchAreaLocator, searchString);
	}

	getGridCellRenderer = (gridCellRendererLocator) => {
		return this.getElement(gridCellRendererLocator);
	}

	removePredefinedFilter = (buttonLocator, removeFilter) => {
		this.buttonHelper.clickButton(this.wrapDataTestId(buttonLocator));
		return this.buttonHelper.clickButton(this.wrapDataTestId(removeFilter));
	}

	addFilter = (addFilter) => {
		return this.buttonHelper.clickButton(this.wrapDataTestId(addFilter));
	}

	closeFilter = (buttonLocator) => {
		return this.buttonHelper.clickButton(this.wrapDataTestId(buttonLocator));
	}

	selectFilterButton = (buttonLocator) => {
		return this.buttonHelper.clickButton(this.wrapDataTestId(buttonLocator));
	}

	selectSearchButton = (buttonLocator) => {
		return this.buttonHelper.clickButton(this.wrapDataTestId(buttonLocator));
	}

	selectHideColumnButton = (buttonLocator) => {
		return this.buttonHelper.clickButton(this.wrapDataTestId(buttonLocator));
	}

	selectToggleViewButton = (buttonLocator) => {
		// added api call for testing purpose
		let kbArticleID = Math.floor(100000 + Math.random() * 900000);
		let updateID = uuidv4();
		let updateID2 = uuidv4();
		const body = this.dataHelper.generatePatchCreationData().setDataForApi(kbArticleID, updateID, updateID2).getDataForApi();
		this.apiHelper.createNewPatch({ body: body }).then((response) => {
			if (response.status === 200) {
				cy.log('Monitor created successfully');
			}
		});
		
		return this.buttonHelper.clickButton(this.wrapDataTestId(buttonLocator));
	}

	// api call to create patches
	createPatches = (multiplePatch = false) => {
		let kbArticleID = Math.floor(100000 + Math.random() * 900000);
		let updateID = uuidv4();
		let missingUpdateID = uuidv4();
		let updateID2 = multiplePatch ? uuidv4() : '';
		const body = this.dataHelper.generatePatchCreationData().setDataForApi(kbArticleID, updateID, updateID2, missingUpdateID).getDataForApi();
		this.apiHelper.createNewPatch({ body: body }).then((response) => {
			if (response.status === 200) {
				this.pageReload();
				cy.wait(3000); // Temp fix for the latency issue. Will imlement recurring function to ckech condition true or false. 
				this.pageReload(); // Temp fix for the latency issue
				cy.wait(3000); // Temp fix for the latency issue
				this.removePredefinedFilter(lct.filterButton, lct.removeFilterButton);
				this.selectSearchButton(lct.searchButton);
				this.searchInGrid(lct.formInput, 'KB' + kbArticleID);
				this.checkElementIsVisibleWithText('[aria-label]', 'KB' + kbArticleID);
				cy.log('Patch created successfully');
			} else {
				cy.log('Patch not created or not visible on page');
				cy.log(response.body);
				throw new Error('Patch creation failed');
			}
		});
		return 'KB' + kbArticleID; 
	}

	// api call to approve noc patches
	approveNocPatches = (body, kbID ) => {
		this.apiHelper.approveNOCPatch({ body: body, kbID: kbID }).then((response) => {
			if (response.status === 204) {
				cy.log('Patch approved successfully');
			} else {
				cy.log('Patch was not approved');
				cy.log(response.body);
				throw new Error('Patch approval by noc failed');
			}
		});
	}

	validateFirstRowExists = (gridRowLocator) => {
		return this.gridHelper.validateFirstRowExists(gridRowLocator);
	}

	validateLastRowExists = (gridVirtualScrollerLocator, gridRowLocator) => {
		return this.gridHelper.validateLastRowExists(gridVirtualScrollerLocator, gridRowLocator);
	}

	getRowCount = (rowCountLocator) => {
		return this.gridHelper.getRowCount(rowCountLocator);
	}

	getRowCountElement = (rowCountLocator) => {
		return this.gridHelper.getRowCountElement(rowCountLocator);
	}

	getRowCheckbox = (rowInputLocator) => {
		return this.gridHelper.getRowCheckbox(rowInputLocator);
	}

	checkRowCheckBox = (rowLocator, index) => {
		return this.gridHelper.selectRowByIndexWithCheckbox(rowLocator,index);
	}

	selectRowByIndex = (gridRowLocator, index) => {
		return this.gridHelper.selectRowByIndex(gridRowLocator, index);
	}

	getRowByIndex = (gridRowLocator, index) => {
		return this.gridHelper.getRowByIndex(gridRowLocator, index);
	}

	getList = (listLocator) => {
		return this.getElement(listLocator);
	}

	filterColumn = (buttonLocator, nativeSelectLocator, columnName, operator, value) => {
		return this.gridHelper.filterColumn(buttonLocator, nativeSelectLocator, columnName, operator, value);
	}

	sortColumn = (columnHeaderLocator, columnIndex) => {
		return this.gridHelper.sortColumn(columnHeaderLocator, columnIndex);
	}

	hideColumn = (panelSelector, columnIndex) => {
		return this.gridHelper.hideColumn(panelSelector, columnIndex);
	}

	changeView = (rowSelector, view) => {
		return this.gridHelper.changeGridView(rowSelector, view);
	}

	selectDropdownValue = (dropdownSelector, index, value) => {
		return this.dropdownHelper.selectDropdownValue(dropdownSelector, index, value);
	}

	scrollGridToTop = (gridLocator) => {
		return this.gridHelper.scrollGridToTop(gridLocator);
	}

	setupApiHooks() {
		beforeEach(() => {
			this.apiHelper.setup();
		});
	}

	scheduleDeployment = (scheduleDeploymentLocator) => {
		this.getElementBydatatestid(lct.deploy).click();
		this.getElement(lct.scheduleDeployment).first().click();
		return this.buttonHelper.clickButton(this.wrapDataTestId(scheduleDeploymentLocator));
	}

	manualSchedulePatchDeploy = () => {
		const patchId = this.createPatches(false);
		cy.log('Patch ID: ' + patchId);
		this.getRowByIndex(lct.gridRow, 0).click();
		this.getElement(lct.deploy).click();
		//Step1 verifications
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', patchId);
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Summary');
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Deploy patch now');
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Schedule deployment');
		this.getElement(lct.scheduleDeployment).last().click();
		const dateTime = this.getFormattedDate();
		const dateTimeSplit = dateTime.split('-');
		this.getElement(lct.calenderDateEntry).type(dateTimeSplit[0]);
		this.getElement(lct.calenderTimeEntry).type(dateTimeSplit[1]);
		this.getElement(lct.manualDeploySelectEndpointBtn).click();
		
		// //Step2 verifications
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Reboot endpoints after deployment');
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Resources');
		this.getElement(lct.rebootEndpoint).eq(2).check();
		this.getRowCheckbox(`${lct.gridRow} input`).last().check();
		this.getElement(lct.manualDeployConfirmBtn).click();

		// //Step3 verifications
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', patchId);
		const date = dateTimeSplit[0].split('/');
		const dateFormat = date[0]+'/'+date[1]+'/'+date[2].slice(-2);
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Deploy on '+dateFormat+' '+dateTimeSplit[1]+' '+'Local Machine Time');
		// this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', '1 Device(s)');
		// Below assertion is in case "Reboot Endpoint checkbox" not selected. 
		//this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Device(s) will not be forced to reboot after update');
		// Below assertion is in case "Reboot Endpoint checkbox" selected. 
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Device(s) will be forced to reboot after update in case at least one patch pending reboot');
		this.getElement(lct.deployPatch).click();

		//Step 4 verifications
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', patchId);
		//const date1 = date[1]+' '+this.getMonthName(date[0])+' '+date[2];
		// Below assertion is in case "Reboot Endpoint checkbox" not selected.
		// this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Device(s) will not be forced to reboot after update.');
		// Below assertion is in case "Reboot Endpoint checkbox" selected. 
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Device(s) will be forced to reboot after update in case at least one patch pending reboot');
		this.getElementBydatatestid(lct.viewInScheduledTask).click();

		//Schedule Task Page
		// this.getElement(lct.deployMissingOSPatch).should(exists);
		this.inputFieldHelper.getInputFieldValue(lct.addNewTaskName).should('contain', 'Deploy Missing OS Patch');
		this.inputFieldHelper.getInputFieldValue(lct.timezoneasio).should('contain', 'Local Machine Time');
		this.inputFieldHelper.getInputFieldValue(lct.calenderDateEntry).should('contain', date[0]+'/'+date[1]+'/'+date[2]);
	}

	manualPatchDeployNow = () => {
		const patchId = this.createPatches(false);
		cy.log('Patch ID: ' + patchId);
		this.getRowByIndex(lct.gridRow, 0).click();
		this.getElement(lct.deploy).click();
		//Step1 verifications
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', patchId);
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Summary');
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Deploy patch now');
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Schedule deployment');
		this.getElement(lct.manualDeploySelectEndpointBtn).click();
		
		//Step2 verifications
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Reboot endpoints after deployment');
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Resources');
		this.getElement(lct.rebootEndpoint).eq(2).check();
		this.getRowCheckbox(`${lct.gridRow} input`).last().check();
		this.getElement(lct.manualDeployConfirmBtn).click();

		// //Step3 verifications
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', patchId);
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Deploy patch now');
		// this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', '1 Device(s)');
		// Below assertion is in case "Reboot Endpoint checkbox" not selected. 
		// this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Device(s) will not be forced to reboot after update');
		// Below assertion is in case "Reboot Endpoint checkbox" selected. 
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Device(s) will be forced to reboot after update in case at least one patch pending reboot');
		this.getElement(lct.deployPatch).click();

		//Step 4 verifications
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', patchId);
		//this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'This update has been scheduled to be deployed  immediately to 1 endpoint(s).');
		// Below assertion is in case "Reboot Endpoint checkbox" not selected. 
		// this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Device(s) will not be forced to reboot after update.');
		// Below assertion is in case "Reboot Endpoint checkbox" selected.
		this.getElementBydatatestid(lct.manualDeployConfirmation).should('contain', 'Device(s) will be forced to reboot after update in case at least one patch pending reboot.');
		this.getElementBydatatestid(lct.viewInScheduledTask).click();

		//Schedule Task Page
		// this.getElement(lct.deployMissingOSPatch).should(exists);
		this.inputFieldHelper.getInputFieldValue(lct.addNewTaskName).should('contain', 'Deploy Missing OS Patch');

	}

}

export default PatchApprovalHelper;
