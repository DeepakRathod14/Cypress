import {CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper } from '../../../../fixtures';

class PatchExclusionHelper extends CommonHelper{

	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
	}

	navigateToPatchExclusionOnCheck = () => {
		cy.get('@url').then((links) => {
			const PATCH_EXCLUSION_URL = links.PatchExclusion;

			const stripQueryParams = this.stripQueryParams;

			cy.url().then((currentURL) => {
				if (!stripQueryParams(currentURL).endsWith(stripQueryParams(PATCH_EXCLUSION_URL))) {
					cy.visit(PATCH_EXCLUSION_URL);
				}
			});
		});
	}

}

export default PatchExclusionHelper;
