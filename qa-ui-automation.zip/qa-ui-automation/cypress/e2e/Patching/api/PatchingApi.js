import { ApiHelper } from '../../../fixtures';
import { api, endpointID, uuid } from './constants';

class PatchingApi {
	constructor() {

		// Define Helper Classes here
		this.api = new ApiHelper();
	}

	setup() {

		cy.get('@currUserData').then((user) => {
			Cypress.env('patchingPartnerId', user.partnerId);
		});

		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseAgentUrl = apiList['Agent'];
			const basePatchUrl = apiList['Patching'];

			cy.wrap({
				//Define common urls here
				assessmentResultUrl: baseAgentUrl + endpointID + api.assessmentResult,
				patchNOCApprovalUrl: basePatchUrl + api.patch
			}).as('urlConfig');
		});

		cy.get('@urlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'application/json'
				}
			};
		}).as('setupConfig');
	}

	/**
	 * Function to create a new patch.
	 * @param {object} body - Body for the request.
	 */
	createNewPatch = ({ body }) => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.postUrl({
				apiUrl: config.assessmentResultUrl,
				headers: {
					'Content-Type': 'application/json'
				},
				body: body,
			});
		});
	};

	/**
	 * Function to approve NOC a new patch.
	 * @param {object} body - Body for the request.
	 *  @param {string} kbID - kbID for URL..
	 */
	approveNOCPatch = ({ body, kbID }) => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.patchUrl({
				apiUrl: config.patchNOCApprovalUrl + kbID + api.status,
				headers: {
					'Content-Type': 'text/plain',
					'uid': uuid
				},
				body: JSON.stringify(body),
			});
		});
	};


}

export default PatchingApi;