export const api = {assessmentResult: '/os_patching_assessment_result', patch: '/patch/', status: '/status'};

export const endpointID = '/5a0957a0-d714-47ae-9ea5-88d6b9ab2d9c';

export const uuid = 'ospatching.automation@connectwise.com';
