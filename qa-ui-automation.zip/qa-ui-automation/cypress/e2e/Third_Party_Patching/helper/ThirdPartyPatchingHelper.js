import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper } from '../../../fixtures';

class ThirdPartyPatchingHelper extends CommonHelper {

	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
	}

}

export default ThirdPartyPatchingHelper;
