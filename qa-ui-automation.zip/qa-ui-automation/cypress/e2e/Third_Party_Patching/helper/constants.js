export const moduleMetaData = {
	name: 'Third Party Patching',
	customUser: 'user_2',
};