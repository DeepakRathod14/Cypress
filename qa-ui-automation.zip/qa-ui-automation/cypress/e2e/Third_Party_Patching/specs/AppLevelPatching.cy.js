import ThirdPartyPatchingHelper from '../helper/ThirdPartyPatchingHelper';

import { moduleMetaData } from '../helper/constants';


describe('GIVEN ', { tags: ['@AppLevelPatching', '@MUI'] }, () => {

	var thirdPartyPatchingHelper = new ThirdPartyPatchingHelper();
	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {

		// define hooks for pre and post conditions
		before(() => { });

		beforeEach(() => {
			thirdPartyPatchingHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { });

		// test cases start here

		it('Should Cancel Modal Single Patch', function () {
			//navigate to Applications tab from device summary
		});

	});

});