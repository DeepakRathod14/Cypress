import { CommonHelper } from '../../../../fixtures';
import { txt } from './constants';

class PoliciesDataHelper {

	constructor() {
		this.commonHelper = new CommonHelper();
	}

	generateBaseData() {
		this.testData = {
			name: txt.newPolicyName,
			category: txt.devices,
			subCategory: txt.communicator,
			lastModified: this.commonHelper.getFakeDateAndTime(),
			updatedBy: this.commonHelper.getFakeValue()
		};

		return this;
	}

	getData() {
		return this.testData;
	}

	getTestData() {
		return this.testData;
	}

	setTestData(testData) {
		this.testData = {
			...this.testData,
			...testData
		};
        
		return this;
	}

	setData(testData) {
		this.testData = testData;
	}
}

export default PoliciesDataHelper;
