import PoliciesDataHelper from './PoliciesDataHelper';
import { ltr, moduleMetaData, txt } from './constants';
import {
	ButtonHelper, CommonHelper, DropDownHelper, GridHelper, InputButtonHelper,
	InputFieldHelper, ToastHelper
} from '../../../../fixtures';


/**
 * Helper class for Policies module/
 * @class
 * @extends CommonHelper
 */
class PoliciesHelper extends CommonHelper {
	constructor() {

		// Define Helper Classes here
		super();
		this.button = new ButtonHelper();
		this.inputButton = new InputButtonHelper();
		this.inputField = new InputFieldHelper();
		this.toast = new ToastHelper();
		this.dropDown = new DropDownHelper();
		this.grid = new GridHelper();

		this.dataHelper = new PoliciesDataHelper();
	}

	/**
	 * All SETUP methods
	 */

	setupApiIntercepts() {
		before(() => {
			this.interceptApi();
		});
	}

	setupHooks() {
		before(() => {
			this.setup(moduleMetaData);
		});
		beforeEach(() => {
			this.initialLandingSetup();
		});
	}

	cleanupHooks() {
	}

	setupApiHooks() {
	}

	interceptApi() {
	}

	initialLandingSetup() {
		this.navigateToPageOnCheck(moduleMetaData.name);
	}

	getData() {
		return this.testData;
	}

	setData(testData) {
		this.testData = testData;
	}

	createPolicyTestData(fields) {
		let testData = fields
			? this.dataHelper.generateBaseData().setTestData(fields).getTestData()
			: this.dataHelper.generateBaseData().getTestData();

		this.setData(testData);
		return this;
	}


	clickOnAddNewPolicyButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.addButton));
	}

	clickOnEditPolicyButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.editButton));
	}

	clickOnDuplicatePolicyButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.duplicateButton));
	}

	clickOnSavePolicyButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.saveButton));
	}

	clickOnDeleteButton() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.deleteButton));
	}

	clickOnDeleteButtonOnModal() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.deleteButtonModal));
	}

	selectCategory(category) {
		this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(ltr.policyCategoryField),
				ltr.paperRoot,
				category
			);
	}

	selectSubCategory(subCategory) {
		this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(ltr.policySubCategoryField),
				ltr.paperRoot,
				subCategory
			);
	}

	selectTicketHelpDesk(sendTo) {
		this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(ltr.settingsCreateTicketHelpdeskSelect),
				ltr.paperRoot,
				sendTo
			);
	}

	typePolicyName(name) {
		this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.policyNameField), name);
	}

	clickSettingButtonOrSwitch(dataTestId) {
		this.button
			.clickButton(this.wrapDataTestId(dataTestId));
	}

	selectTasksGridRow(index) {
		this.grid
			.selectRowByIndexWithCheckbox(ltr.gridRow, index);
	}

	typeValueInTextField(dataTestId, value) {
		this.inputField.typeIntoInputField(this.wrapDataTestId(dataTestId), value);
	}

	addNewPolicy(testData) {
		this.clickOnAddNewPolicyButton();
		this.typePolicyName(testData.name);
		this.selectCategory(testData.category);
		this.selectSubCategory(testData.subCategory);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorEnabledSwitch);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorSysInfoSwitch);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorWindowsTasksSwitch);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorClearHistorySwitch);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorDeleteTempSwitch);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorTasksLink);
		this.selectTasksGridRow(0);
		this.clickSettingButtonOrSwitch(ltr.selectTasksSubmitButton);
		this.typeValueInTextField(ltr.settingsCommunicatorTasksFriendlyName1Field, txt.task1);
		this.clickOnSavePolicyButton();
		this.validatePoliciesToastMessage(txt.addPolicySuccessMessage);
	}

	editPolicy(testData) {
		this.addBasicPolicy(testData);
		cy.wait(5000);
		this.clickOnEditPolicyButton();
		this.typePolicyName(txt.editPolicyName);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorEnabledSwitch);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorCreateTicketSwitch);
		this.selectTicketHelpDesk(txt.partner);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorTicketKewordSwitch);
		this.typeValueInTextField(ltr.settingsCommunicatorTicketKewordText, txt.ticketPrefix);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorTasksLink);
		this.selectTasksGridRow(0);
		this.clickSettingButtonOrSwitch(ltr.selectTasksSubmitButton);
		this.typeValueInTextField(ltr.settingsCommunicatorTasksFriendlyName1Field, txt.task1);
		this.clickOnSavePolicyButton();
		this.validatePoliciesToastMessage(txt.editPolicySuccessMessage);
	}

	duplicatePolicy() {
		this.clickOnDuplicatePolicyButton();
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorCustomUrl1Switch);
		this.typeValueInTextField(ltr.settingsCommunicatorCustomUrl1MenuName, txt.qaPortalName);
		this.typeValueInTextField(ltr.settingsCommunicatorCustomUrl1Url, txt.qaPortalUrl);
		this.clickSettingButtonOrSwitch(ltr.settingsCommunicatorTasksLink);
		this.selectTasksGridRow(1);
		this.clickSettingButtonOrSwitch(ltr.selectTasksSubmitButton);
		this.typeValueInTextField(ltr.settingsCommunicatorTasksFriendlyName2Field, txt.task2);
		this.clickOnSavePolicyButton();
		this.validatePoliciesToastMessage(txt.addPolicySuccessMessage);
	}

	addBasicPolicy(testData) {
		this.clickOnAddNewPolicyButton();
		this.typePolicyName(testData.name);
		this.clickOnSavePolicyButton();
		this.validatePoliciesToastMessage(txt.addPolicySuccessMessage);
	}
	checkAccordionDevicesGridIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(ltr.deviceGrid));
	}

	checkAccordionSettingPackagesGridIsVisible() {
		this.getElement(this.wrapDataTestId(ltr.policiesViewSettingsCard))
			.contains('Package Inclusions')
			.should('be.visible')
			.click();
		this.checkElementIsVisible(this.wrapDataTestId(ltr.settingPackagesGrid));
	}

	checkAccordionSettingPolicyGroupIsVisible() {
		this.getElement(this.wrapDataTestId(ltr.policiesViewSettingsCard))
			.contains('Policy Group Assignments')
			.should('be.visible')
			.click();
		this.checkElementIsVisible(this.wrapDataTestId(ltr.settingPolicyGroup));
	}

	selectDevicesGridRow(index) {
		this.grid
			.getRowByIndex(ltr.gridRow, index).click();
	}

	validatePoliciesToastMessage(message) {
		this.toast.validateToastMessage(ltr.toast, this.wrapDataTestId(ltr.successIcon), message);
		this.getLastElement(this.wrapDataTestId(ltr.closeIcon)).click();
	}
}

export default PoliciesHelper;
