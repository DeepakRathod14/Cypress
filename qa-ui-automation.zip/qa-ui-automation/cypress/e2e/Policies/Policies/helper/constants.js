export const moduleMetaData = {
	name: 'Policies',
	customUser: 'user_4'
};

export const ltr = {
	'deviceGrid': 'policies-device-data-grid',
	'siteGrid': 'policies-site-data-grid',
	'packagesGrid': 'packages-data-grid',
	'packagesSitesGrid': 'sites-data-grid',
	'settingPackagesGrid': 'policies-settings-packages-data-grid',
	'settingPolicyGroup': 'policies-settings-policy-group-data-grid',
	'addButton': 'policies-add-button',
	'editButton': 'policies-edit-button',
	'duplicateButton': 'policies-duplicate-button',
	'deleteButton': 'policies-delete-button',
	'deleteButtonModal': 'policies-delete-modal-submit-button',
	'cancelButtonModal': 'policies-delete-modal-close-button',
	'saveButton': 'policies-save-policy-button',
	'cancelButton': 'policies-cancel-policy-button',

	'policyNameField': 'policies-edit-policy-name-text-input',
	'policyCategoryField': 'policies-edit-category-select',
	'policySubCategoryField': 'policies-edit-subcategory-select',
	'settingTaskSelectionGrid': 'policies-settings-task-data-grid',
	'policiesViewSettingsCard': 'policies-detail-card',
	'infoIcon': 'policies-settings-info-icon',

	//Communicator Policy
	'settingsCommunicatorEnabledSwitch': 'settings.communicator#enabled-switch',
	'settingsCommunicatorSysInfoSwitch': 'settings.communicator#system_information-switch',
	'settingsCommunicatorWindowsTasksSwitch': 'settings.communicator#windows_tasks-switch',
	'settingsCommunicatorClearHistorySwitch': 'settings.communicator#cleariehistory-switch',
	'settingsCommunicatorDeleteTempSwitch': 'settings.communicator#deletetemp-switch',
	'settingsCommunicatorTasksLink': 'policies-settings-tasks-link',
	'settingsTasksDataGrid': 'policies-settings-task-data-grid',
	'settingsCommunicatorTasksFriendlyName1Field': 'settings.communicator#custom_scripts-friendlyName-0-input',
	'settingsCommunicatorTasksFriendlyName2Field': 'settings.communicator#custom_scripts-friendlyName-1-input',
	'selectTasksSubmitButton': 'select-tasks-submit-button',
	'settingsCommunicatorCreateTicketSwitch': 'settings.communicator#create_ticket-switch',
	'settingsCreateTicketHelpdeskSelect': 'policies-settings-static-communicator#create_ticket_helpdesk-select',
	'settingsCommunicatorTicketKewordSwitch': 'settings.communicator#ticket_keyword-switch',
	'settingsCommunicatorTicketKewordText': 'settings.communicator#ticket_keyword_text',
	'settingsCommunicatorCustomUrl1Switch': 'settings.communicator#custom_url_1-switch',
	'settingsCommunicatorCustomUrl1MenuName': 'settings.communicator#custom_url_1_menu_name',
	'settingsCommunicatorCustomUrl1Url': 'settings.communicator#custom_url_1_url',

	//Tbd
	'gridRow': '.MuiDataGrid-row',
	'toast': '.MuiAlert-message',
	'paperRoot': '.MuiPaper-root',

	//Svgs
	'checkBox': 'CheckBoxOutlineBlankIcon',
	'expandMore': 'ExpandMoreIcon',
	'closeIcon': 'CloseIcon',
	'successIcon': 'SuccessOutlinedIcon',
};

export const txt = {
	'emptyData': 'No rows',
	'cancel': 'Cancel',
	'newPolicyName': 'Dummy_Policy',
	'editPolicyName': '_Edit',
	'duplicatePolicyName': 'Copy_Dummy_Policy',
	'devices': 'Devices',
	'communicator': 'Communicator',
	'partner': 'Partner',
	'task1': 'Task1',
	'task2': 'Task2',
	'ticketPrefix': 'Com-',
	'qaPortalName': 'QA Portal',
	'qaPortalUrl': 'https://control.qa.itsupport247.net/',
	'addPolicySuccessMessage': 'Policy was added successfully',
	'editPolicySuccessMessage': 'Policy was updated successfully',
	'deletePolicySuccessMessage': 'Policy was deleted successfully'
};

export const atr = {

};

export const fieldIndex = {
	'Policy name': '0',
	'Type': '1',
	'Last modified': '2',
	'Modified by': '3'
};
