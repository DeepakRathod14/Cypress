import PoliciesHelper from '../helper/PoliciesHelper';
import { txt } from '../helper/constants';

describe('GIVEN Policies Landing Page', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var policiesHelper = new PoliciesHelper();

	// Define global hook for describe block
	policiesHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {
		// Define hooks for pre and post conditions
		policiesHelper.setupHooks();
		policiesHelper.cleanupHooks();

		it( 'THEN Verify user is able to delete a policy', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('FGP-T939');

			const testData = policiesHelper.createPolicyTestData().getData();

			policiesHelper.addBasicPolicy(testData);
			policiesHelper.selectDevicesGridRow(0);
			policiesHelper.clickOnDeleteButton();
			policiesHelper.clickOnDeleteButtonOnModal();
			policiesHelper.validatePoliciesToastMessage(txt.deletePolicySuccessMessage);
		});
		
		// Test cases start here
		it('THEN Verify Accordion Devices Grid is visible', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('FGP-T940');

			policiesHelper.checkAccordionDevicesGridIsVisible();
		});

		it('THEN Verify user is able to select grid row', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('FGP-T941');

			policiesHelper.selectDevicesGridRow(0);
		});

		it('THEN Verify settings view cards Package Inclusions Grid visible', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('FGP-T942');

			policiesHelper.checkAccordionSettingPackagesGridIsVisible();
		});

		it('THEN Verify settings view cards Policy Group Assignments Grid visible', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('FGP-T943');

			policiesHelper.checkAccordionSettingPolicyGroupIsVisible();
		});
	});
});
