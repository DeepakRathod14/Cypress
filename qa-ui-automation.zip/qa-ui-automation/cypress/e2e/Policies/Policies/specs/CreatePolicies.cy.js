import PoliciesHelper from '../helper/PoliciesHelper';

describe('GIVEN Policies', { tags: ['@Policies', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var policiesHelper = new PoliciesHelper();

	// Define global hook for describe block
	policiesHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		/** 
		 * Base hooks defined for pre and post conditions
		 * before, beforeEach, after, afterEach
		 * NOTE: Add custom conditions to specific test cases only
		 */
		policiesHelper.setupHooks();
		policiesHelper.cleanupHooks();

		it( 'THEN Verify user is able to create a policy', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('FGP-T937');

			const testData = policiesHelper.createPolicyTestData().getData();

			policiesHelper.addNewPolicy(testData);
		});
	});
});
