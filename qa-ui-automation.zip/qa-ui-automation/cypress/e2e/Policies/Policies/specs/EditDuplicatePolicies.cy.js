import PoliciesHelper from '../helper/PoliciesHelper';

describe('GIVEN Policies', { tags: ['@Policies', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var policiesHelper = new PoliciesHelper();

	// Define global hook for describe block
	policiesHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {
		// Define hooks for pre and post conditions
		policiesHelper.setupHooks();
		policiesHelper.cleanupHooks();
		const testData = policiesHelper.createPolicyTestData().getData();


		it( 'THEN Verify user is able to edit/duplicate a policy', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('FGP-T938');

			policiesHelper.editPolicy(testData);
			cy.wait(5000);
			policiesHelper.duplicatePolicy();
		});
	});
});
