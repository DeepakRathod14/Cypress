export const moduleMetaData = {
	sidekickPages: [
		'Dashboard',
		'Company List',
		'Contact Management',
		'End User Portals',
		'Available Integrations',
		'Workstations & Servers',
		'Device Groups',
		'Network Devices',
		// 'Server Password',
		// 'Desktop Password',
		'Communicator',
		'Patch Approvals',
		'Patch Exclusion',
		'Intelligent Alerts',
		'Monitors',
		'Suspensions', 
		'Packages',
		'Policies',
		'Backup360',
		'SaaS Backup',
		'Disaster Recovery Runbooks',
		'Vulnerability Management Not Subscribed',
		'SaaS Security Not Subscribed',
		'SOC Hero Dashboard Not Subscribed',
		'Risk Assessment',
		'Microsoft Defender for Business Not Subscribed',
		'Activation',
		'Tasks',
		'Scheduled Tasks',
		'Workflows',
		'Form Templates',
		'Unified Billing Intake',
		'API Access',
		'Corporate Structure',
		'Automate Migration',
		'Webroot Endpoint License Management',
		'Deployment Package',
		'Managed Accounts',
		'Notification Templates',
		'Data Mapping',
		'Custom Fields',
		'IP Restriction Management',
		'Agent Report',
		'Agent Uninstall Report', 
		'Disk Space Report',
		'Remote Access Report',
		'Automation Execution Detail Report',
		'Automation Execution Summary Report', 
		'System Information Report', 
		'Patch Compliance Report', 		 
		'Endpoint Protection Report', 
		'Network Devices Report',
		'Patch Deployment Report'
	],

	sidekickLegacyPages: [
		// 'Tickets (Legacy)',
		'Continuty Backup',
		'Asio Reports',
		'Security Reports',
		'Account Administration',
		'RMM Setup'
	],
	
	ltrPrefix: 'monitors',
	namePerSite: 'Company List',
	deviceDetails: 'Workstations & Servers',
};

export const ltr = {	
	'sidekickIcon': 'sidekick-fab-button-image',
};

export const txt = {	
	'cpu': 'CPU',	
};

export const atr = {

};

export const fieldIndex = {
	'Name': '0',
	'Type': '1',
	'Family': '2',
	'Status': '3',
	'Severity': '4',
};