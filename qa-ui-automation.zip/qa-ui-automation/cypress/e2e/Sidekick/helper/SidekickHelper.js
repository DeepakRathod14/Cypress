import { ltr } from './constants';
import {
	ButtonHelper, CommonHelper, DropDownHelper, GridHelper, InputButtonHelper,
	InputFieldHelper, ResourceSelectorHelper, ToastHelper
} from '../../../fixtures';


/**
 * Helper class for Custom Monitor module/
 * @class
 * @extends CommonHelper
 */
class SidekickHelper extends CommonHelper {
	constructor() {

		// Define Helper Classes here
		super();
		this.button = new ButtonHelper();
		this.inputButton = new InputButtonHelper();
		this.inputField = new InputFieldHelper();
		this.toast = new ToastHelper();
		this.dropDown = new DropDownHelper();
		this.grid = new GridHelper();
		this.resourceSelector = new ResourceSelectorHelper();		
		this.commonHelper = new CommonHelper();
		this.getMonitorsResponse = null;
	}

	/**
	 * All SETUP methods
	 */

	verifySidekickIconExist(isPresent){
		const dataTestId = this.wrapDataTestId(ltr.sidekickIcon);			
		const result = isPresent ? 'be.visible' : 'not.be.visible';
		cy.get(dataTestId).should(result);
	}

}

export default SidekickHelper;