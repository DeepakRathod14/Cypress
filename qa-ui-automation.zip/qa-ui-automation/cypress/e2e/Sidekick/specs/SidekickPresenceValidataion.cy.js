import SidekickHelper from '../helper/SidekickHelper';
import { moduleMetaData } from '../helper/constants';
import { envTag } from '../../../constants';

describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var sidekickHelper = new SidekickHelper();	

	context('WHERE user is migrated/SSO', { tags: [envTag.Regression, envTag.Migrated] }, () => {			

		it('Navigate to 2.0 pages and verify if sidekick is shown at the bottom right corner', { tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7368');
			moduleMetaData.sidekickPages.forEach((page) => {
				sidekickHelper.navigateToPageOnCheck(page);
				sidekickHelper.verifySidekickIconExist(true);			
			});			

		});	

		it('Navigate to 1.0 pages and verify if sidekick is NOT shown at the bottom right corner', { tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7369');			

			moduleMetaData.sidekickLegacyPages.forEach((page) => {
				sidekickHelper.navigateToPage(page);
				sidekickHelper.verifySidekickIconExist(false);			
			});

		});	
	});
});