//import { ApiHelper, CommonHelper } from '../../../fixtures';
import { lct, text, moduleMetaData } from '../helper/constants';
import TaskingHelper from '../helper/TaskingHelper';

describe ('Tasking - End to End Test', { tags: ['@TaskingUI', '@MUI'] }, () => {
		
	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var TaskingHelper1 = new TaskingHelper();

	context('User schedules different types of tasks and verify them', { tags: ['@Regression'] }, () => {
		before(() => {});
		TaskingHelper1.setupHook();

		after(() => {
		});

		it('THEN Verify Next Agent Check-In task & check the revoke functionality', { tags: ['@Sanity'] }, function () {
			cy.allure().tms('TASK-T4354');
			TaskingHelper1.searchTemplateAndClickOnFirstRow(text.templateName);
			TaskingHelper1.clickOnButtons(lct.scheduleTaskButton);
			TaskingHelper1.getElement(lct.nacRadioButton).click();
			TaskingHelper1.validateHoverText(lct.afterLabel, 'Task fails if device doesn\'t come online within entered hours/days');
			cy.wait(50000);
			TaskingHelper1.clickOnButtons(lct.selectTargets);
			TaskingHelper1.getElement(lct.devicesRadioButton).click();
			TaskingHelper1.searchWithMachineNameFake();
			TaskingHelper1.getElement(lct.saveSelection).click();
			var taskName = TaskingHelper1.generateTaskName();
			TaskingHelper1.inputTaskName(lct.taskNameInput, taskName);
			TaskingHelper1.getElement(lct.highlightedButton).click();
			cy.wait(10000);
			cy.reload();
			cy.wait(30000);
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			TaskingHelper1.validateWebElementVisibility(lct.scheduleTaskRunningStatusLabel);
			TaskingHelper1.validateText(lct.scheduleTaskRunningStatusLabel, 'Running');
			TaskingHelper1.clickOnTaskByName(taskName);
			cy.wait(45000);
			TaskingHelper1.clickOnTab(lct.scheduledTaskHistoryTab);
			TaskingHelper1.validateMultiTextWithAnOrCondition(lct.outcome, 'Running', 'Success');
			TaskingHelper1.getElement(lct.cancelButton).click();
			cy.wait(30000);
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			TaskingHelper1.getElement(lct.RevokeButton).click();
			TaskingHelper1.getElement(lct.deactivateButton).click();
			TaskingHelper1.validateTaskingToastMessage('The task was deactivated successfully.');
			cy.reload();
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			TaskingHelper1.validateWebElementVisibility(lct.scheduledTaskSuspendedStatusLabel);
			TaskingHelper1.validateText(lct.scheduledTaskSuspendedStatusLabel, 'Suspended');
			TaskingHelper1.clickOnTaskByName(taskName);
			cy.wait(45000);
			TaskingHelper1.clickOnTab(lct.scheduledTaskHistoryTab);
			TaskingHelper1.validateMultiTextWithAnOrCondition(lct.outcome, 'Suspended');
			TaskingHelper1.getElement(lct.deploymentDateValue).should('not.have.text', 'Not Available');
		});

		it('THEN Schedule a RunNow task & verify it', function () {				
			TaskingHelper1.searchTemplateAndClickOnFirstRow(text.templateName);
			cy.wait(5000);
			TaskingHelper1.clickOnButtons(lct.scheduleTaskButton);
			cy.wait(10000);
			TaskingHelper1.getElement(lct.runNowRadioButton).click();
			cy.wait(50000);
			TaskingHelper1.clickOnButtons(lct.selectTargets);
			cy.wait(5000);
			TaskingHelper1.getElement(lct.devicesRadioButton).click();
			cy.wait(5000);
			TaskingHelper1.searchWithMachineName();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.saveSelection).click();
			cy.wait(5000);
			var taskName = TaskingHelper1.generateTaskName();
			TaskingHelper1.inputTaskName(lct.taskNameInput, taskName);
			TaskingHelper1.getElement(lct.highlightedButton).click();
			cy.wait(30000);
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			cy.wait(5000);
			TaskingHelper1.validateWebElementVisibility(lct.scheduleTaskRunningStatusLabel);
			TaskingHelper1.validateText(lct.scheduleTaskRunningStatusLabel, 'Running');
			TaskingHelper1.clickOnTaskByName(taskName);
			cy.wait(45000);
			TaskingHelper1.clickOnTab(lct.scheduledTaskHistoryTab);
			cy.wait(30000);
			TaskingHelper1.validateMultiTextWithAnOrCondition(lct.outcome, 'Running', 'Success');

		});

		it('THEN Schedule a Next Agent Check In task & verify it', function () {				
			TaskingHelper1.searchTemplateAndClickOnFirstRow(text.templateName);
			cy.wait(10000);
			TaskingHelper1.clickOnButtons(lct.scheduleTaskButton);
			cy.wait(50000);
			TaskingHelper1.clickOnButtons(lct.selectTargets);
			cy.wait(5000);
			TaskingHelper1.getElement(lct.devicesRadioButton).click();
			cy.wait(5000);
			TaskingHelper1.searchWithMachineName();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.saveSelection).click();
			cy.wait(5000);
			var taskName = TaskingHelper1.generateTaskName();
			TaskingHelper1.inputTaskName(lct.taskNameInput, taskName);
			TaskingHelper1.getElement(lct.highlightedButton).click();
			cy.wait(3000);
			cy.reload();
			cy.wait(30000);
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			cy.wait(5000);
			TaskingHelper1.validateWebElementVisibility(lct.scheduleTaskRunningStatusLabel);
			TaskingHelper1.validateMultiTextWithAnOrCondition(lct.scheduleTaskRunningStatusLabel, 'Running', 'Success');
			TaskingHelper1.clickOnTaskByName(taskName);
			cy.wait(20000);
			TaskingHelper1.clickOnTab(lct.scheduledTaskHistoryTab);
			cy.wait(10000);
			TaskingHelper1.validateMultiTextWithAnOrCondition(lct.outcome, 'Running', 'Success');

		});

		it('THEN Schedule a recurring monthly task & verify it', function () {			
			TaskingHelper1.searchTemplateAndClickOnFirstRow(text.templateName);
			cy.wait(5000);
			TaskingHelper1.clickOnButtons(lct.scheduleTaskButton);
			cy.wait(50000);
			TaskingHelper1.getElement(lct.scheduleRadioButton).click();
			cy.wait(5000);
			TaskingHelper1.clickOnButtons(lct.recurrentIcon);
			cy.wait(5000);
			TaskingHelper1.getElement(lct.selectDropDown).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.monthlyOption).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.monthlyOnDatesDropdown).click();
			cy.wait(2000);
			TaskingHelper1.getElement(lct.firstOption).click();
			cy.wait(5000);
			TaskingHelper1.clickOnButtons(lct.recurrentBoxOkbutton);
			cy.wait(5000);
			TaskingHelper1.clickOnButtons(lct.selectTargets);
			cy.wait(5000);
			TaskingHelper1.getElement(lct.devicesRadioButton).click();
			cy.wait(5000);
			TaskingHelper1.searchWithMachineName();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.saveSelection).click();
			cy.wait(5000);
			var taskName = TaskingHelper1.generateTaskName();
			TaskingHelper1.inputTaskName(lct.taskNameInput, taskName);
			TaskingHelper1.getElement(lct.highlightedButton).click();
			cy.wait(2000);
			TaskingHelper1.validateTaskingToastMessage(text.taskSuccessMessage);
			cy.wait(2000);
			//cy.reload();
			TaskingHelper1.getElement(lct.menuIcon).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.scheduledTasks).click();
			cy.wait(30000);
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			cy.wait(5000);
			TaskingHelper1.validateWebElementVisibility(lct.scheduleTaskNewStatusLabel);
			TaskingHelper1.validateText(lct.scheduleTaskNewStatusLabel, 'New');
			TaskingHelper1.clickOnTaskByName(taskName);
			cy.wait(40000);
			TaskingHelper1.clickOnTab(lct.scheduledTaskHistoryTab);
			cy.wait(30000);
			TaskingHelper1.validateMultiTextWithAnOrCondition(lct.outcome, 'Scheduled');

			cy.wait(5000);
			TaskingHelper1.getElement(lct.cancelButton).click();
			cy.wait(30000);
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			cy.wait(5000);
			TaskingHelper1.getElement(lct.pauseIcon).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.suspendButton).click();
			cy.wait(5000);
			TaskingHelper1.validateTaskingToastMessage('The task was suspended successfully.');
			cy.reload();
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			cy.wait(2000);
			TaskingHelper1.validateWebElementVisibility(lct.scheduledTaskSuspendedStatusLabel);
			TaskingHelper1.validateText(lct.scheduledTaskSuspendedStatusLabel, 'Suspended');
			cy.wait(2000);
			TaskingHelper1.clickOnTaskByName(taskName);
			cy.wait(40000);
			TaskingHelper1.clickOnTab(lct.scheduledTaskHistoryTab);
			cy.wait(30000);
			TaskingHelper1.validateMultiTextWithAnOrCondition(lct.outcome, 'Suspended');
			cy.wait(5000);
			TaskingHelper1.getElement(lct.cancelButton).click();
			cy.wait(30000);
			TaskingHelper1.searchTemplateAndClickOnFirstRow(taskName);
			cy.wait(5000);
			TaskingHelper1.getElement(lct.deactivateIcon).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.deactivateButton).click();
			cy.wait(3000);
			TaskingHelper1.validateTaskingToastMessage('The task was deactivated successfully.');
		});

		it('THEN Schedule a recurring monthly task with different weeks options & verify it', function () {		
			var optionArr = ['[data-value="2"]','[data-value="3"]','[data-value="4"]'];
			optionArr.forEach (option => {
				TaskingHelper1.searchTemplateAndClickOnFirstRow(text.templateName);
				cy.wait(2000);
				TaskingHelper1.clickOnButtons(lct.scheduleTaskButton);
				cy.wait(50000);
				TaskingHelper1.getElement(lct.scheduleRadioButton).click();
				cy.wait(2000);
				TaskingHelper1.clickOnButtons(lct.recurrentIcon);
				cy.wait(2000);
				TaskingHelper1.getElement(lct.selectDropDown).click();
				cy.wait(2000);
				TaskingHelper1.getElement(lct.monthlyOption).click();
				cy.wait(2000);
				TaskingHelper1.getElement(lct.monthlyOnDatesDropdown).click();
				cy.wait(2000);
				TaskingHelper1.getElement(option).click();
				cy.wait(2000);
				TaskingHelper1.clickOnButtons(lct.recurrentBoxOkbutton);
				cy.wait(2000);
				TaskingHelper1.clickOnButtons(lct.selectTargets);
				cy.wait(2000);
				TaskingHelper1.getElement(lct.devicesRadioButton).click();
				cy.wait(2000);
				TaskingHelper1.searchWithMachineName();
				cy.wait(2000);
				TaskingHelper1.getElement(lct.saveSelection).click();
				cy.wait(2000);
				var taskName = TaskingHelper1.generateTaskName();
				TaskingHelper1.inputTaskName(lct.taskNameInput, taskName);
				TaskingHelper1.getElement(lct.highlightedButton).click();
				cy.wait(2000);
				TaskingHelper1.validateTaskingToastMessage(text.taskSuccessMessage);
				cy.wait(5000);
				TaskingHelper1.navigateToPageOnCheck(moduleMetaData.name);
				cy.wait(30000);
			});
		});

		it('THEN Verify Tasks & Schedule Tasks page from Left navigation menu', function () {				
			TaskingHelper1.getElement(lct.menuIcon).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.scheduledTasks).click();
			cy.wait(30000);
			TaskingHelper1.validateWebElementVisibility(lct.taskingPagesHeaderLabel);
			TaskingHelper1.validateText(lct.taskingPagesHeaderLabel, 'Scheduled Tasks');
			TaskingHelper1.getElement(lct.Tasks).click();
			cy.wait(30000);
			TaskingHelper1.validateWebElementVisibility(lct.taskingPagesHeaderLabel);
			TaskingHelper1.validateText(lct.taskingPagesHeaderLabel, 'Tasks');
			TaskingHelper1.validateWebElementVisibility(lct.addTasksDropDown);
		});

		it('THEN Schedule a Run Now Task from Tasking 2.0 page and verify it\'s result', function () {	
			TaskingHelper1.getElement(lct.menuIcon).click();
			cy.wait(5000);			
			TaskingHelper1.getElement(lct.endpointsLabel).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.devicesLabel).click();
			cy.wait(5000);
			TaskingHelper1.validateWebElementVisibility(lct.runDropDown);
			TaskingHelper1.getElement(lct.runDropDown).click();
			cy.wait(30000);
			TaskingHelper1.getElement(lct.searchRunDropdown).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.searchRunDropdown).type('PowerShell script');
			cy.wait(5000);
			TaskingHelper1.selectFirstElement(lct.taskSelectorDropdown, 'PowerShell script');
			cy.wait(50000);
			TaskingHelper1.selectFirstElement(lct.deviceRadioBtnDevicePage, 'Devices');
			cy.wait(5000);
			TaskingHelper1.getElement(lct.searchDeviceDevicePage).click();
			TaskingHelper1.getElement(lct.searchDeviceDevicePage).type('TASKING-WIN-SER2016');
			cy.wait(5000);
			TaskingHelper1.getElement(lct.deviceCheckboxDevicePage).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.conutinueBtnDevicePage).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.scriptParamTextAreaDevicePage).type('hostname');
			cy.wait(5000);
			TaskingHelper1.getElement(lct.conutinueToScheduleBtnDevicePage).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.runTaskBtnDevicePage).click();
			//cy.wait(3000);
			//TaskingHelper1.validateTaskingToastMessageOnDevicePage('The task has been successfully submitted.');
			cy.wait(5000);
			TaskingHelper1.getElement(lct.recentTaskPanel).click();
			cy.wait(5000);
			TaskingHelper1.getElement(lct.recentPanelSearchBar).type('PowerShell script');
			cy.wait(5000);
			TaskingHelper1.getElement(lct.recentPanelSearchBar).type('{enter}');
			cy.wait(50000);
			TaskingHelper1.getStatusOfFirstElementInList(lct.recentPanelTaskStatus, '1 Success');
			cy.wait(5000);
			TaskingHelper1.selectFirstElementInList(lct.recentTaskListElements);
			cy.wait(50000);
			TaskingHelper1.validateWebElementVisibility(lct.recentPanelSearchedTaskStatus);
			TaskingHelper1.validateText(lct.recentPanelSearchedTaskStatus, 'Success');
			
		});

		it('THEN verify the Devices Services Tab', function () {
			TaskingHelper1.navigateToPageOnCheck(moduleMetaData.deviceDetails);
			cy.wait(30000);
			TaskingHelper1.searchOnDevice(lct.searchMachineName);
			TaskingHelper1.getElement(lct.serviceTab).click();
			TaskingHelper1.getElement(lct.summaryChart);
			TaskingHelper1.getElement(lct.startupTypeChart);
			TaskingHelper1.getElement(lct.editButton).click();
			TaskingHelper1.getElement(lct.thumbnailPanel).should('exist');
			TaskingHelper1.getElement(lct.serviceTabSaveBtn).click();
			TaskingHelper1.getElement(lct.serviceTabSearch).should('exist');
			TaskingHelper1.getElement(lct.serviceTabFilter).should('exist');
			TaskingHelper1.getElement(lct.serviceTabViewColumn).should('exist');
			TaskingHelper1.getElement(lct.serviceTabViewStream).should('exist');
			TaskingHelper1.getElement(lct.serviceTabSaveAlt).should('exist');
			TaskingHelper1.getElement(lct.serviceTabServiceMode).should('exist');
			TaskingHelper1.getElement(lct.serviceTabActionDropDown).should('exist');
			TaskingHelper1.getFirstElement(lct.serviceTabCheckbox).click();
			TaskingHelper1.verifyAction();
			TaskingHelper1.getFirstElement(lct.serviceTabCreateMonitor).click();
		});

		it('THEN Verify the Script Preview option for Action task templates', () => {
			TaskingHelper1.searchTemplateAndClickOnFirstRow(text.templateName2);
			TaskingHelper1.clickOnButtons(lct.duplicateTaskButton);
			TaskingHelper1.verifyScriptPreviewDuplicateTasksPage();
			cy.wait(10000);		
			TaskingHelper1.searchTemplateAndClickOnFirstRow(text.templateName1);
			TaskingHelper1.verifyScriptPreviewTasksPage();
			TaskingHelper1.clickOnButtons(lct.scheduleTaskButton);
			TaskingHelper1.verifyScriptPreviewBetaPage();
		});

		it('THEN Verify the Toolbar section on Tasks and Scheduled Tasks page', () => {
			TaskingHelper1.verifyFilterTasks();
			cy.get('body').type('{esc}');
			TaskingHelper1.getElement(lct.menuIcon).click();
			TaskingHelper1.getElement(lct.scheduledTasks).click();
			cy.wait(30000);
			TaskingHelper1.verifyFilterScheduledTasks();
			cy.get('body').type('{esc}');
		});
	});
});
