import {CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, ApiHelper, ToastHelper } from '../../../fixtures';
import { moduleMetaData, lct, text } from '../helper/constants';

class TaskingHelper extends CommonHelper{

	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.apiHelper = new ApiHelper();
		this.toastHelper = new ToastHelper();
		this.getTaskResponse = null; 
		//this.dropdownHelper = new DropDownHelper();
	}

	setupHook() {
		before(() => {
			this.setup(moduleMetaData);
		});
		beforeEach(() => {
			this.navigateToPageOnCheck(moduleMetaData.name);
			cy.reload();
			this.apiHelper.setAliasForGraphQL('GraphQL/', 'TasksAndSequencesSelector', 'getTasks');
			cy.wait(60000);
		});
	}

	selectSearchButton = (buttonLocator) => {
		return this.buttonHelper.clickButtonWithIndex(buttonLocator, 0);
	}

	searchInGrid = (searchAreaLocator, searchString) => {
		return this.getElement(searchAreaLocator).type(searchString);
	}

	searchEndpoint(name) {
		cy.get('.MuiDataGrid-row').should('be.visible');
		this.gridHelper.searchEntryInGrid(this.wrapDataTestId(lct.searchIcon), name);
	}

	searchTaskTemplate(name) {
		cy.get('.MuiDataGrid-row').should('be.visible');
		cy.get(lct.searchIconTaskAndScheduleTask).click().type(name);
	}

	searchOnDevice(searchMachineNameLocator) {
		cy.fixture(`data/${this.env}/testdata/${moduleMetaData.testDataFile}`).as('tasking-data');
		cy.get('@tasking-data').then((data) => {
			var machineName = data['Tasking.MachineName'];
			cy.get(searchMachineNameLocator).type(data['Tasking.MachineName']).type('{enter}');
			cy.wait(5000);
			cy.get('a[title='+ machineName +']').click();
			cy.reload();
		});	
	}

	searchTemplateAndClickOnFirstRow(name) {
		this.searchTaskTemplate(name);
		this.getFirstElement(lct.gridRow).click();
	}

	selectFirstElement(locator, name) {
		cy.get(locator).first().should('contain.text', name).click();
	}

	selectLastElement(locator, name) {
		cy.get();
		cy.get(locator).last().should('contain.text', name).click();
	}

	searchWithMachineName() {
		cy.fixture(`data/${this.env}/testdata/${moduleMetaData.testDataFile}`).as('tasking-data');
		cy.get('@tasking-data').then((data) => {
			this.searchEndpoint(data['Tasking.MachineName']);
			// cy.wait(5000);
			this.gridHelper.selectRowByIndexWithCheckbox(lct.gridRow, 0);
		});		

	}

	searchWithMachineNameFake() {
		cy.fixture(`data/${this.env}/testdata/${moduleMetaData.testDataFile}`).as('tasking-data');
		cy.get('@tasking-data').then((data) => {
			this.searchEndpoint(data['Tasking.MachineNameFake']);
			// cy.wait(5000);
			this.gridHelper.selectRowByIndexWithCheckbox(lct.gridRow, 0);
		});		

	}

	clickOnButtons(locator) {
		this.buttonHelper.clickButton(this.wrapDataTestId(locator));
	}
	
	clickOnRadio(locator) {
		this.buttonHelper.clickButton(this.wrapData(locator));
	}

	validateHoverText(locator, text) {
		cy.get(lct.afterLabel).invoke('show').click({ force: true }).should('be.visible');
		cy.get(lct.toolTipStopAfter).should('be.visible').and('contain.text', text);
	}

	inputTaskName(locator, text) {
		cy.get(this.wrapDataTestId(locator)).clear();
		cy.get(this.wrapDataTestId(locator)).type(text);
	}

	clickOnTaskByName(name) {
		cy.get('a[title="'+ name +'"]').click();
	}

	generateTaskName() {
		// const now = new Date(Date.UTC(2017, 2, 14)).getTime()
		// cy.clock(now)
		var now = this.getFakeName();
		var taskName = 'TASK - ' + now;
		cy.log(taskName);
		return taskName;
	}

	validateWebElementVisibility(locator) {
		cy.get(locator).should('be.visible');
	}

	validateText(locator, text) {
		cy.get(locator).should('be.visible').and('contain.text', text);
	}

	clickOnTab(locator) {
		this.getElement(locator).click({ force: true });
	}

	validateMultiTextWithAnOrCondition(locator, text1, text2) {
		cy.get(locator).invoke('text').should('be.oneOf', [text1, text2]);

	}

	validateTaskingToastMessage(message) {
		this.toastHelper.validateToastMessage(lct.toast, this.wrapDataTestId(lct.successIcon), message);
		this.getLastElement(this.wrapDataTestId(lct.closeIcon)).click();
	}

	validateTaskingToastMessageOnDevicePage(message) {
		this.toastHelper.validateToastMessage(lct.notificationMessageDevicePage, lct.notificationMessageCloseDevicePage, message);
		this.getLastElement(lct.notificationMessageCloseDevicePage).click();
	}

	selectFirstElementInList(locator) {
		cy.get(locator).eq(0).click();
	}

	getStatusOfFirstElementInList(locator, text) {
		cy.get(locator).eq(0).should('be.visible').and('contain.text', text);
	}

	verifyAction() {
		this.getElement(lct.serviceTabActionDropDown).click();
		cy.wait(2000);
		cy.get('#split-button-menu').contains('Start').click();
		cy.wait(2000);
		this.getElement(lct.serviceTabPopupStartBtn).click();
		cy.wait(5000);
		cy.get('div').contains(text.serviceTabSuccessMessage);
	}

	verifyScriptPreviewTasksPage() {
		cy.get(lct.tasksPageScriptTypeLabel).should('have.text','Script Type');
		cy.get(lct.tasksPageScriptTypeValue).should('contain','Action');
		this.verifyPreviewPanel();
	}

	verifyScriptPreviewBetaPage() {
		cy.get(lct.betaPageScriptTypeLabel).should('have.text','Script Type');
		cy.get(lct.betaPageScriptTypeValue).should('contain','Action');
		this.verifyPreviewPanel();
	}

	verifyScriptPreviewDuplicateTasksPage() {
		cy.get(lct.duplicateTaskPageScriptTypeLabel).should('have.text','Script Type');
		cy.get(lct.duplicateTaskPageScriptTypeValue).should('contain','Action');
		cy.get(lct.scriptPreviewLink).click();
		cy.get(lct.scriptPreviewWindows);
		cy.get(lct.scriptPreviewClose).click();
		cy.get(lct.duplicateTaskPageCancelButton).click();
	}

	verifyPreviewPanel() {
		cy.get(lct.scriptPreviewLink).click();
		cy.get(lct.scriptPreviewWindows).click();
		cy.get(lct.scriptPreviewMacOs).click();
		cy.get(lct.scriptPreviewLinux).click();
		cy.get(lct.scriptPreviewClose).click();
	}

	verifyFilterTasks() {
		cy.get(lct.filterButton).click();
		cy.get(lct.addFilterButton).click();
		cy.get(lct.andOrDropdown).eq(3).select('or').invoke('val').should('eq','or');
		cy.get(lct.andOrDropdown).eq(3).select('and').invoke('val').should('eq','and');
	}

	verifyFilterScheduledTasks() {
		cy.get(lct.filterButton).click();
		cy.get(lct.addFilterButton).click();
		cy.get(lct.andOrDropdown).eq(4).select('or').invoke('val').should('eq','or');
		cy.get(lct.andOrDropdown).eq(4).select('and').invoke('val').should('eq','and');
	}
}

export default TaskingHelper;
