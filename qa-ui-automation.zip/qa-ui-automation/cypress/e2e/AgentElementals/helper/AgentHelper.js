import { ltr, moduleMetaData } from '../helper/constants';
import {
	ButtonHelper, CommonHelper, DropDownHelper, GridHelper, InputButtonHelper,
	InputFieldHelper, ResourceSelectorHelper, ToastHelper
} from '../../../fixtures';
import { recurse } from 'cypress-recurse';


/**
 * Helper class for Custom Monitor module/
 * @class
 * @extends CommonHelper
 */
class AgentHelper extends CommonHelper {
	constructor() {
		// Define Helper Classes here
		super();
		this.button = new ButtonHelper();
		this.inputButton = new InputButtonHelper();
		this.inputField = new InputFieldHelper();
		this.toast = new ToastHelper();
		this.dropDown = new DropDownHelper();
		this.grid = new GridHelper();
		this.resourceSelector = new ResourceSelectorHelper();
		this.commonHelper = new CommonHelper();
		this.getMonitorsResponse = null;
	}

	setupHooks() {
		beforeEach(() => {
			this.navigateToPageOnCheck(moduleMetaData.deviceDetails);
			cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		});
	}

	getRemoteEnabledSite() {
		var siteName;
		cy.get('@alert-data').then((data) => {
			siteName = data['Agent.RemoteEnabledSiteName'];			
			cy.get(ltr.remoteEnabledSiteSearch).should(() => { }).each((btn) => { btn.trigger('click'); });
			this.getElementWithWait(ltr.searchDevice, 10000).type(siteName).type('{enter}');			
		});
	}

	getRemoteDisabledSite() {
		var siteName;
		cy.get('@alert-data').then((data) => {
			siteName = data['Agent.RemoteDisabledSiteName'];			
			cy.get(ltr.remoteEnabledSiteSearch).should(() => { }).each((btn) => { btn.trigger('click'); });
			this.getElementWithWait(ltr.searchDevice, 10000).type(siteName).type('{enter}');			
		});
	}

	clickDevice = (name) => {		
		this.getElementWithText(this.wrapDataTestId(ltr.deviceName), name).as('btn').click({ force: true });
	}

	navigateToDeviceDetailsPage = () => {
		this.navigateToPage(moduleMetaData.testDataPage);
		this.navigateToPage(moduleMetaData.deviceDetails);

	}

	clickMachineOnlineToggleButton = () => {		
		this.getElementWithWait(ltr.machineOnlineToggleButton, 10000).click();		
		this.getElementWithWait(ltr.machineOnlineToggleButton, 10000).click();		
	}

	clickScreenConnectRemoteAccess = () => {
		cy.wait(5000);
		this.getElementWithWait(ltr.remoteAccessParentComponent, 10000).first().click();
		this.getElement(ltr.remoteAccessContainerDialog).contains('ScreenConnect Remote Access').click({ force: true });
	}

	checkScreenConnectRemoteAccessDialogExist = (assertionQuery) => {
		this.getElementWithTextAndAssertion(this.wrapDataTestId(ltr.screenconnectReasonDialog), 'Join Session', assertionQuery);
	}

	checkScreenConnectRemoteAccessDialogNotExist = (assertionQuery) => {
		this.getElementWithAssertion(this.wrapDataTestId(ltr.screenconnectReasonDialog), assertionQuery);
	}

	checkContinueButtonIsDisabled() {
		this.inputButton.isInputButtonDisabled(this.wrapDataTestId(ltr.continueButton));
	}

	checkContinueButtonIsEnabled() {
		this.inputButton.isInputButtonEnabled(this.wrapDataTestId(ltr.continueButton));
	}

	enterReasonTextMessage() {
		this.getElement(this.wrapDataTestId(ltr.reasonForConnectingTextArea)).clear().type('Test Message');
	}

	checkCancelButton() {		
		this.getElementWithWait(this.wrapDataTestId(ltr.cncelButton), 10000).click();
	}

	clickOnFirstIntelligentMonitorForEdit() {
		cy.wait(10000);
		this.getElementWithWait(this.wrapDataTestId(ltr.machineName), 10000).first().click();		
	}

	clickOnSettingsTab() {
		this.getElementWithWait(this.wrapDataTestId(ltr.settingsTab), 60000).click();
	}

	clickOnExpandDevices() {
		cy.wait(15000);
		this.getElementWithIndexAndWait(ltr.expandDevices, 0, 60000).click();		
	}

	clickOnRemoteAccess() {
		cy.get('@alert-data').then((data) => {
			const deviceTypeSettings = data['Agent.DeviceTypeSettings'];
			let scrollPerc = 0;
			this.getElement(this.wrapDataTestId(ltr.firstElementInDevice)).click();
			recurse(
				() => cy.contains(ltr.remoteAccessLink, deviceTypeSettings).should(() => { }),
				($quote) => $quote.length > 0,
				{
					log: false,
					delay: 500,
					timeout: 50000,
					post() {
						scrollPerc = scrollPerc + 2;
						cy.get(ltr.viewPort).first().scrollTo('0%', scrollPerc + '%');
					}
				}
			);
			cy.get(ltr.remoteAccessLink).each((device) => {
				if (device.text() === deviceTypeSettings) {
					device.trigger('click');
				}
			});
		});

	}

	clickOtherDeivesButton() {		
		this.getElementWithWait(this.wrapDataTestId(ltr.otherDevicesButton), 10000).click();
	}

	selectAddDevicesType() {
		cy.wait(5000);
		cy.get('@alert-data').then((data) => {
			const addDevicesName = data['Agent.AddDevices'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.addDevicesDropDown),
					ltr.paperRoot,
					addDevicesName
				);
		});
	}

	selectCompanyForVMWareHost() {
		cy.get('@alert-data').then((data) => {
			const companyName = data['Agent.CompanyName'];
			this.typeName(this.wrapDataTestId(ltr.selectCompanyDropDown), companyName);
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.selectCompanyDropDown),
					ltr.paperRoot,
					companyName
				);
		});
	}

	selectSiteForVMWareHost() {
		cy.get('@alert-data').then((data) => {
			const siteName = data['Agent.SiteName'];
			this.typeName(this.wrapDataTestId(ltr.selectSiteDropDown), siteName);
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.selectSiteDropDown),
					ltr.paperRoot,
					siteName
				);
		});
	}

	selectMonitoringDevicesForVMWareHost() {
		cy.get('@alert-data').then((data) => {
			const monitoringDevices = data['Agent.MonitoringDevices'];
			this.typeName(this.wrapDataTestId(ltr.selectMonitoringDevicesDropDown), monitoringDevices);
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.selectMonitoringDevicesDropDown),
					ltr.paperRoot,
					monitoringDevices
				);
		});
	}

	typeName(fieldName, name) {
		this.inputField.typeIntoInputField(fieldName, name);
	}

	enterIPAddress() {
		cy.get('@alert-data').then((data) => {
			const ipAddress = data['Agent.IPAddressForVMWareHost'];			
			this.typeName(this.wrapDataTestId(ltr.ipAddress), ipAddress);
		});
	}

	enterUserName() {
		cy.get('@alert-data').then((data) => {
			const userName = data['Agent.UserNameForVMWareHost'];			
			this.typeName(this.wrapDataTestId(ltr.userName), userName);
		});
	}

	enterPassword() {
		cy.get('@alert-data').then((data) => {
			const password = data['Agent.PasswordForVMWareHost'];
			this.typeName(this.wrapDataTestId(ltr.password), password);
		});
	}

	clickTestButton() {
		this.getElementWithWait(ltr.testButton, 30000).click();
	}

	checkAlertMessageShouldVisible() {
		this.getElementWithWait(this.wrapDataTestId(ltr.muiSuccessAlertMessage), 60000).should('be.visible');
		cy.get('@alert-data').then((data) => {
			const connectionMessage = data['Agent.ConnectionMessage'];			
			this.getTextOfElement(this.wrapDataTestId(ltr.muiSuccessAlertMessage)).then((text) => {
				expect(text.trim()).to.be.equal(connectionMessage);
			});
		});
	}

	clickSaveButton() {
		this.getElement(this.wrapDataTestId(ltr.saveButton)).click();		
	}

	checkAddingDevicesAlertMessageShouldVisible() {
		cy.wait(10000);
		this.getElementWithWait(this.wrapDataTestId(ltr.muiSuccessAlertMessage), 60000).should('be.visible');
		cy.get('@alert-data').then((data) => {
			const addingDevicesMessage = data['Agent.AddingDevicesMessage'];			
			this.getTextOfElement(this.wrapDataTestId(ltr.muiSuccessAlertMessage)).then((text) => {
				expect(text.trim()).to.be.equal(addingDevicesMessage);
			});
		});
	}

	checkAddingDevicesErrorAlertMessageShouldVisible() {
		this.getElementWithWait(this.wrapDataTestId(ltr.AlertErrorMessage), 60000).should('be.visible');
		cy.get('@alert-data').then((data) => {
			const addingDevicesFailMessage = data['Agent.DevicesAddFailMessage'];			
			this.getTextOfElement(this.wrapDataTestId(ltr.AlertErrorMessage)).then((text) => {
				expect(text.trim()).to.be.equal(addingDevicesFailMessage);
			});
		});
	}

	clickOtherDevicesLink() {
		this.getElement(this.wrapDataTestId(ltr.otherDevicesLink)).click();		
	}

	SearchCreatedDevice() {
		cy.get('@alert-data').then((data) => {
			const monitoringDevices = data['Agent.MonitoringDevices'];			
			this.grid.searchEntryInGridNew(ltr.searchIconNew, monitoringDevices);	
			cy.wait(5000);		
			this.getFirstElement(ltr.gridRow).find('input').check({ force: true });			
		});

	}

	clickRemoveDeviceButton() {		
		this.getElementWithWait(this.wrapDataTestId(ltr.removeButton), 10000).click();
		this.getElementWithWait(ltr.removeButtonForConfirmation, 10000).click();	
	}

	verifyReasonForRemoteAccess(status) {
		this.getElementWithWait(this.wrapDataTestId(ltr.reasonForRemoteAccess), 10000).contains(status).should('be.visible');
	}

	clickOnCloseIconButton() {
		cy.get(ltr.controlOverlayDialog).its(ltr.controlOverlayBody).as('iFrame');		
		cy.get(ltr.controlOverlayFrame).find(ltr.closeIconButtonOnJoinDialog).click();
	}

	clickOnSummaryTab() {
		this.getElementWithWait(this.wrapDataTestId(ltr.summaryTab), 10000).click();
	}

	checkMachineSpec(keyName){
		 cy.contains(keyName);
	 }

}

export default AgentHelper;