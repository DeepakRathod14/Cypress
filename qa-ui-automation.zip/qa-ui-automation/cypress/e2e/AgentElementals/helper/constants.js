export const moduleMetaData = {	
	deviceDetails: 'Workstations & Servers'	
};

export const ltr = {
	
	'machineOnlineToggleButton': 'div[title=\'Machine online/offline\'] > div',	
	'searchDeviceCleanup': 'div[class=\'page-level-search-components-inputWrapper--1apRV6OS\'] > div > div > input',
	'searchDevice': 'div[class=\'page-level-search-components-inputWrapper--1apRV6OS\']',
	'remoteAccessParentComponent': 'div[class=\'remote-access-components-parent--14iMjagw\']',
	'remoteAccessContainerDialog': 'div[class=\'remote-access-components-container--2HMUzefG\'] > div',
	'screenconnectReasonDialog': 'lmi-screenconnect-reason-dialog',
	'continueButton': 'primary-reason-btn',
	'reasonForConnectingTextArea': 'lmi-screenconnect-reason-field',
	'cncelButton': 'cancel-reason-btn',
	'machineName': 'devices-machine-name-cell',		
	'settingsTab': 'policy-settings',
	'expandDevices': 'div[title=\'Toggle Row Expanded\']',
	'remoteAccess': 'remote_access',
	'firstElementInDevice': 'acronis-acronis_cyber_protect',
	'tableCount': '*[class^=\'Row-avdwv GridRowStyled\']',
	'otherDevicesButton': 'virtualization-monitoring-button',
	'paperRoot': '.MuiPaper-root',
	'addDevicesDropDown': 'add-vmware-monitoring-button',
	'selectCompanyDropDown': 'company',
	'selectMonitoringDevicesDropDown': 'monitoring-devices',
	'portNumber': 'port-number',
	'password': 'password',
	'selectSiteDropDown': 'site',
	'ipAddress': 'host-ip',
	'userName': 'username',
	'addDevicesDropDownExpanded': 'sentinelStart',
	'testButton':'button[datatestid=\'ESXi-test-connection\']',
	'muiSuccessAlertMessage': 'SUCCESS-alert-bar',
	'saveButton': 'ESXi-save',
	'otherDevicesLink': 'other.devices',
	'searchIcon': 'SearchOutlinedIcon',
	'searchIconNew': '.MuiInputBase-inputAdornedEnd',
	'gridRow': '.MuiDataGrid-row',	
	'removeButton': 'remove-button',
	'removeButtonForConfirmation': 'button[datatestid=\'remove-submit-btn\']',
	'reasonForRemoteAccess': 'control#SC_JOIN_REASON_SERVER:value-view',
	'remoteAccessSettingsReason':'button[datatestid=\'ESXi-test-connection\']',
	'remoteAccessSettingsRemoteAccess': 'div[class=\'remote-access-components-container\'] > div',
	'closeIconButtonOnJoinDialog': 'div[class=\'TitlePanel\'] > a',
	'remoteEnabledSiteSearch': 'i[class*=\'page-level-search-components-root\'][role=\'button\']',
	'remoteAccessLink': 'div[id$=\'-col-label\'] > div',
	'viewPort': '.os-viewport',
	'controlOverlayDialog': 'iframe[title=\'control-overlay\']',
	'controlOverlayBody': '0.contentDocument.body',
	'controlOverlayFrame': '@iFrame',
	'AlertErrorMessage': 'ERROR-alert-bar',
	'summaryTab': 'summary'
};

export const txt = {
	
};

export const atr = {

};

export const fieldIndex = {
	
};