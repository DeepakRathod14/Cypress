import { envTag } from '../../../constants';
import AgentHelper from '../helper/AgentHelper';

describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var AgentsHelper = new AgentHelper();

	context('WHERE user is migrated/SSO', { tags: [envTag.Regression, envTag.Migrated] }, () => {

		AgentsHelper.setupHooks();

		it('Verify user navigates to Join Session Reason when user clicks on the ScreenConnect Remote Access when reason for remote access is enabled',
			{ tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('AGENT-T9905');
				AgentsHelper.getRemoteEnabledSite();
				AgentsHelper.clickMachineOnlineToggleButton();
				AgentsHelper.clickScreenConnectRemoteAccess();
				AgentsHelper.checkScreenConnectRemoteAccessDialogExist('exist');
				AgentsHelper.checkContinueButtonIsDisabled();
				AgentsHelper.enterReasonTextMessage();
				AgentsHelper.checkContinueButtonIsEnabled();
				AgentsHelper.checkCancelButton();
			});

		it('Verify user navigates to Join Session Reason when user clicks on the ScreenConnect Remote Access when reason for remote access is disabled',
			{ tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('AGENT-T9906');
				AgentsHelper.getRemoteDisabledSite();
				AgentsHelper.clickMachineOnlineToggleButton();
				AgentsHelper.clickScreenConnectRemoteAccess();
				AgentsHelper.checkScreenConnectRemoteAccessDialogNotExist('not.exist');
				AgentsHelper.clickOnCloseIconButton();
			});

		it('Verify for remote enabled sites Screen Connect Remote Access is Enabled in Remote Access Settings', { tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('AGENT-T9896');
			cy.allure().tms('AGENT-T9897');
			AgentsHelper.getRemoteEnabledSite();
			AgentsHelper.clickMachineOnlineToggleButton();
			AgentsHelper.clickOnFirstIntelligentMonitorForEdit();
			AgentsHelper.clickOnSettingsTab();
			AgentsHelper.clickOnExpandDevices();
			AgentsHelper.clickOnRemoteAccess();
			AgentsHelper.verifyReasonForRemoteAccess('Enabled');			
			AgentsHelper.clickScreenConnectRemoteAccess();
			AgentsHelper.checkScreenConnectRemoteAccessDialogExist('exist');
			AgentsHelper.checkContinueButtonIsDisabled();
			AgentsHelper.enterReasonTextMessage();
			AgentsHelper.checkContinueButtonIsEnabled();
			AgentsHelper.checkCancelButton();
		});

		it('Verify for remote disabled sites Screen Connect Remote Access is Disabled in Remote Access Settings', { tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('AGENT-T9898');
			cy.allure().tms('AGENT-T9899');
			AgentsHelper.getRemoteDisabledSite();
			AgentsHelper.clickMachineOnlineToggleButton();
			AgentsHelper.clickOnFirstIntelligentMonitorForEdit();
			AgentsHelper.clickOnSettingsTab();
			AgentsHelper.clickOnExpandDevices();
			AgentsHelper.clickOnRemoteAccess();
			AgentsHelper.verifyReasonForRemoteAccess('Disabled');			
			AgentsHelper.clickScreenConnectRemoteAccess();
			AgentsHelper.checkScreenConnectRemoteAccessDialogNotExist('not.exist');
			AgentsHelper.clickOnCloseIconButton();
		});
	});
});