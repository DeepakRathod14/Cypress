import { envTag } from '../../../constants';
import AgentHelper from '../helper/AgentHelper';

describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var AgentsHelper = new AgentHelper();	

	context('WHERE user is migrated/SSO', { tags: [envTag.Regression, envTag.Migrated] }, () => {

		AgentsHelper.setupHooks();

		it('Verify user is able to add VMware Host from other devices', { tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('AGENT-T9907');
			cy.allure().tms('AGENT-T9908');
			cy.allure().tms('AGENT-T9909');
			cy.allure().tms('AGENT-T9910');
			cy.allure().tms('AGENT-T9911');
			cy.allure().tms('AGENT-T9912');
			AgentsHelper.clickOtherDeivesButton();
			AgentsHelper.selectAddDevicesType();
			AgentsHelper.selectCompanyForVMWareHost();
			AgentsHelper.selectSiteForVMWareHost();
			AgentsHelper.selectMonitoringDevicesForVMWareHost();
			AgentsHelper.enterIPAddress();
			AgentsHelper.enterUserName();
			AgentsHelper.enterPassword();
			AgentsHelper.clickTestButton();
			AgentsHelper.checkAlertMessageShouldVisible();
			AgentsHelper.clickSaveButton();
			AgentsHelper.checkAddingDevicesAlertMessageShouldVisible();			
		});

		it('Verify when user click on save button message shows Device already exists', { tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('AGENT-T9907');
			cy.allure().tms('AGENT-T9908');
			cy.allure().tms('AGENT-T9909');
			cy.allure().tms('AGENT-T9910');
			cy.allure().tms('AGENT-T9911');
			cy.allure().tms('AGENT-T9912');
			AgentsHelper.clickOtherDeivesButton();
			AgentsHelper.selectAddDevicesType();
			AgentsHelper.selectCompanyForVMWareHost();
			AgentsHelper.selectSiteForVMWareHost();
			AgentsHelper.selectMonitoringDevicesForVMWareHost();
			AgentsHelper.enterIPAddress();
			AgentsHelper.enterUserName();
			AgentsHelper.enterPassword();
			AgentsHelper.clickTestButton();
			AgentsHelper.checkAlertMessageShouldVisible();
			AgentsHelper.clickSaveButton();
			AgentsHelper.checkAddingDevicesErrorAlertMessageShouldVisible();
			AgentsHelper.clickOtherDevicesLink();			
			AgentsHelper.SearchCreatedDevice();
			AgentsHelper.clickRemoveDeviceButton();
		});

	});

});