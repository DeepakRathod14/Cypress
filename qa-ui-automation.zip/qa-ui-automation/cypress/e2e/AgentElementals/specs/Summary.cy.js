import { envTag } from '../../../constants';
import AgentHelper from '../helper/AgentHelper';

describe('GIVEN DeviceSummary', { tags: ['@Agent', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var AgentsHelper = new AgentHelper();

	context('WHERE user is migrated/SSO', { tags: [envTag.Regression, envTag.Migrated] }, () => {

		AgentsHelper.setupHooks();

		it('Verify User is able to navigate to Device Summary page and validate SystemType is listed',
			{ tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('AGENT-T9934');
				cy.allure().tms('AGENT-T9933');
				cy.allure().tms('AGENT-T9932');
				AgentsHelper.getRemoteEnabledSite();
			    AgentsHelper.clickMachineOnlineToggleButton();
				AgentsHelper.clickOnFirstIntelligentMonitorForEdit();
				AgentsHelper.clickOnSummaryTab();
				AgentsHelper.checkMachineSpec('System Type');
			});
            
	});
});