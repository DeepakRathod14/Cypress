import MappingSchemaPageHelper from '../helper/MappingSchemaPageHelper';
//import { locator} from '../helper/constants';

describe('GIVEN ', { tags: ['@Regression', '@MappingSchamePage', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var mappingSchemaPageHelper = new MappingSchemaPageHelper();

	context('WHEN user on mapping schemas page', { tags: ['@Schema'] }, () => {

		mappingSchemaPageHelper.setupHook();

		// it('To validate mapping service page', {tags: ['@Sanity']}, ()=>{
		// 	cy.allure().tms('CWMS-T15');
		// 	mappingSchemaPageHelper.validateSchemaTitle(locator.schemaBreadcrumb, 'Schemas');
		// });

	});

});