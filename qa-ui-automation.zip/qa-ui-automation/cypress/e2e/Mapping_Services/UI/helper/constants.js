export const moduleMetaData = {
	name: 'Mapping', // for redirecting mapping home page
	//customUser: 'user_mapping' //for login custome credentials
	customUser: 'user_default'
};

export const locator = {
	'schemaBreadcrumb' : 'breadcrumb-last-item'
};