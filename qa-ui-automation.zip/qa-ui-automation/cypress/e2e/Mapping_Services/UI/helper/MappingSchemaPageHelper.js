import { CommonHelper } from '../../../../fixtures';
import { moduleMetaData } from '../helper/constants';

class MappingSchemaPageHelper extends CommonHelper{

	constructor() {
		super();
	}

	setupHook() {
		before(() => {
			this.setup(moduleMetaData);
		});
		beforeEach(() => {
			this.navigateToPageOnCheck(moduleMetaData.name);
			cy.reload();
		});
	}

	validateSchemaTitle(locator, text) {
		cy.get(locator).should('be.visible').and('contain.text', text);
	}
}
export default MappingSchemaPageHelper;