/* eslint-disable no-mixed-spaces-and-tabs */
import { ApiHelper } from '../../../../fixtures';
import { api } from './constants';

class SchemaApi{

	constructor(){
		// Define Helper Classes here
		this.api = new ApiHelper();
	}

	schemaApiSetup(){
		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseMappingUrl = apiList['MappingService'];

			// Define constants here
			const baseSchemaUrl = baseMappingUrl + api.v1Schemas;
			const basePartnerSchemaUrl = baseMappingUrl + api.v1Partners;
			const baseV2SchemaUrl = baseMappingUrl + api.v2Schemas;
			const invalidSchemaUrl = baseMappingUrl + api.inavlidV1Schemas;
			const jwtKey = 'jwt';

			// Check and Generate JWT token
			const jwtToken = Cypress.env(jwtKey);
			if (!jwtToken) {
				this.api.generateJWTToken();
			}

			cy.wrap({
				//Define common urls here
				customSchemasUrl: baseSchemaUrl,
				customeV2SchemaUrl: baseV2SchemaUrl,
				customeInvalidSchemasUrl: invalidSchemaUrl,
				customePartnerLevelSchemaUrl: basePartnerSchemaUrl
			}).as('urlConfig');

		});     

		cy.get('@urlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'application/json',
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				}
			};
		}).as('setupConfig');
	}


    createNewSchema = ({ body }) => {
    	return cy.get('@setupConfig').then((config) => {
    		return this.api.postUrl({
    			apiUrl: config.customSchemasUrl,
    			headers: config.headers,
    			body: body,
    		});
    	});
    };

	createNewSchemaUsingV2 = ({ body }) => {
    	return cy.get('@setupConfig').then((config) => {
    		return this.api.postUrl({
    			apiUrl: config.customeV2SchemaUrl,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	invalidUrlCreateSchema = ({ body }) => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.invalidPost({
				apiUrl: config.customeInvalidSchemasUrl,
				headers: config.headers,
				body: body,
			});
		});
	};

	invalidBodyCreateSchema = ({ body }) => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.invalidPost({
				apiUrl: config.customSchemasUrl,
				headers: config.headers,
				body: body,
			});
		});
	};

	emptyBodyCreateSchema = ({ body }) => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.invalidPost({
				apiUrl: config.customSchemasUrl,
				headers: config.headers,
				body: body,
			});
		});
	};	

	getSchemas = () => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customSchemasUrl,
				headers: config.headers,
			});
		});
	};

	getSchemasUsingV2 = () => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeV2SchemaUrl,
				headers: config.headers,
			});
		});
	};

	getExpandedSchemas = ({schemaId}) => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customePartnerLevelSchemaUrl + schemaId + api.expanded,
				headers: config.headers,
			});
		});
	};

	invalidUrlGetSchema = () =>{
		return cy.get('@setupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeInvalidSchemasUrl
			});
		});
	};

	deleteSchema = ({schemaId}) =>{
		return cy.get('@setupConfig').then((config) => {
			return this.api.deleteUrl({
				apiUrl: config.customSchemasUrl + schemaId,
				headers: config.headers,
			});
		});
	};

	deleteSchemaUsingV2 = ({schemaId}) =>{
		return cy.get('@setupConfig').then((config) => {
			return this.api.deleteUrl({
				apiUrl: config.customeV2SchemaUrl + schemaId,
				headers: config.headers,
			});
		});
	};

	invalidUrlDeleteSchema = ({schemaId}) =>{
		return cy.get('@setupConfig').then((config) => {
			return this.api.invalidDelete({
				apiUrl: config.customeInvalidSchemasUrl + schemaId,
				headers: config.headers,
			});
		});
	};

	emptySchemaIDToDeleteSchema = ({schemaId}) =>{
		return cy.get('@setupConfig').then((config) => {
			return this.api.invalidDelete({
				apiUrl: config.customSchemasUrl + schemaId,
				headers: config.headers,
			});
		});
	};

	schemaIDNotExistToDeleteSchema = ({schemaId}) =>{
		return cy.get('@setupConfig').then((config) => {
			return this.api.invalidDelete({
				apiUrl: config.customSchemasUrl + schemaId,
				headers: config.headers,
			});
		});
	};

	invalidSchemaIDToDeleteSchema = ({schemaId}) =>{
		return cy.get('@setupConfig').then((config) => {
			return this.api.invalidDelete({
				apiUrl: config.customSchemasUrl + schemaId,
				headers: config.headers,
			});
		});
	};

}

export default SchemaApi;