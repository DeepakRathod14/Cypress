/* eslint-disable no-mixed-spaces-and-tabs */
import { ApiHelper } from '../../../../fixtures';
import { api } from './constants';

class DatasetUploadCSVApi {

	constructor(){
		// Define Helper Classes here
		this.api = new ApiHelper();
	}

	datasetUploadCSVApiSetup(){
		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseMappingUrl = apiList['MappingService'];

			// Define constants here
			const uploadSchemaPartnerUrl = baseMappingUrl + api.v1Partners;
			const jwtKey = 'jwt';

			// Check and Generate JWT token
			const jwtToken = Cypress.env(jwtKey);
			if (!jwtToken) {
				this.api.generateJWTToken();
			}

			cy.wrap({
				//Define common urls here
				customeUploadSchemaUrl: uploadSchemaPartnerUrl,
			}).as('datasetUrlConfig');

		}); 
        
		cy.get('@datasetUrlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'multipart/form-data',
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				}
			};
		}).as('datasetCSVSetupConfig');
	}
	
	prepareCSVFile = ({fileName}) =>{
		const updatedFileName = `data/${this.api.env}/mapping/`+fileName;
		const formData = new FormData();
		cy.fixture(updatedFileName, 'binary').then((file) => { 
			const blob = Cypress.Blob.binaryStringToBlob(file, 'text/csv');			
			formData.append('file', blob, fileName);
		});
		return formData;
	}

    uploadSchemaDatasetWithCSV = ({schemaId, fileName}) =>{
    	var updatedCsvFile = this.prepareCSVFile({fileName});
    	return cy.get('@datasetCSVSetupConfig').then((config) => {
    		return this.api.putUrl({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: updatedCsvFile,
    		});
    	});
    };

	uploadSchemaDatasetWithInvalidHeaderCSV = ({schemaId, fileName}) =>{
		var updatedCsvFile = this.prepareCSVFile({fileName});
    	return cy.get('@datasetCSVSetupConfig').then((config) => {
    		return this.api.invalidPut({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: updatedCsvFile,
    		});			
    	});
	};

	uploadSchemaDatasetWithBlankCSV = ({schemaId, fileName}) =>{
		var updatedCsvFile = this.prepareCSVFile({fileName});
    	return cy.get('@datasetCSVSetupConfig').then((config) => {
    		return this.api.invalidPut({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: updatedCsvFile,
    		});
    	});
	};

	uploadSchemaDatasetWithInvalidFormatFile = ({schemaId, fileName}) =>{
		var updatedCsvFile = this.prepareCSVFile({fileName});
    	return cy.get('@datasetCSVSetupConfig').then((config) => {
    		return this.api.invalidPut({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: updatedCsvFile,
    		});
    	});
	};

}
export default DatasetUploadCSVApi;