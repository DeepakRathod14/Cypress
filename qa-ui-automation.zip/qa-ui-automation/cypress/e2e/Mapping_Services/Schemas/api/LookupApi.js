/* eslint-disable no-mixed-spaces-and-tabs */
import { ApiHelper } from '../../../../fixtures';
import { api } from './constants';

class LookupApi{

	constructor(){
		// Define Helper Classes here
		this.api = new ApiHelper();
	}

	lookupApiSetup(){
		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseMappingUrl = apiList['MappingService'];

			// Define constants here
			const lookupPartnerApiUrl = baseMappingUrl + api.v1LookupWithPartner;
			const lookupAuthApiUrl = baseMappingUrl + api.v1LookupWithAuth;
			const invalidLookupApiUrl = baseMappingUrl + api.invalidv1Lookup;
			const jwtKey = 'jwt';

			// Check and Generate JWT token
			const jwtToken = Cypress.env(jwtKey);
			if (!jwtToken) {
				this.api.generateJWTToken();
			}

			cy.wrap({
				//Define common urls here
				customeLookupPartnerUrl: lookupPartnerApiUrl,
				customeLookupAuthUrl: lookupAuthApiUrl,
				customeInvalidLookupUrl: invalidLookupApiUrl
			}).as('lookupUrlConfig');

		});     

		// lookup api configuration with authorization token
		cy.get('@lookupUrlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'application/json',
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				}
			};
		}).as('lookupAuthConfig');

		// lookup api configuration without authorization token
		cy.get('@lookupUrlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'application/json',
				}
			};
		}).as('lookupPartnerConfig');
	}

    lookupWithPartner = ({ lookupBody }) => {
    	return cy.get('@lookupPartnerConfig').then((config) => {
    		return this.api.postUrl({
    			apiUrl: config.customeLookupPartnerUrl,
    			headers: config.headers,
    			body: lookupBody,
    		});
    	});
    };

    lookupWithAuth = ({ lookupBody }) => {
    	return cy.get('@lookupAuthConfig').then((config) => {
    		return this.api.postUrl({
    			apiUrl: config.customeLookupAuthUrl,
    			headers: config.headers,
    			body: lookupBody,
    		});
    	});
    };

    invalidLookupUrl = ({ lookupBody }) => {
    	return cy.get('@lookupAuthConfig').then((config) => {
    		return this.api.invalidPost({
    			apiUrl: config.customeInvalidLookupUrl,
    			headers: config.headers,
    			body: lookupBody,
    		});
    	});
    };

    invalidLookupBody = ({ body }) => {
    	return cy.get('@lookupAuthConfig').then((config) => {
    		return this.api.invalidPost({
    			apiUrl: config.customeLookupAuthUrl,
    			headers: config.headers,
    			body: body,
    		});
    	});
    };

}

export default LookupApi;