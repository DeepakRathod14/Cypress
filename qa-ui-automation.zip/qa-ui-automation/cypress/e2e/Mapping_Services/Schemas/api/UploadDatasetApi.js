/* eslint-disable no-mixed-spaces-and-tabs */
import { ApiHelper } from '../../../../fixtures';
import { api } from './constants';

class UploadDatasetApi {

	constructor(){
		// Define Helper Classes here
		this.api = new ApiHelper();
	}

	datasetApiCSVSetup(){
		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseMappingUrl = apiList['MappingService'];

			// Define constants here
			const uploadSchemaPartnerUrl = baseMappingUrl + api.v1Partners;
			const jwtKey = 'jwt';

			// Check and Generate JWT token
			const jwtToken = Cypress.env(jwtKey);
			if (!jwtToken) {
				this.api.generateJWTToken();
			}

			cy.wrap({
				//Define common urls here
				customeUploadSchemaUrl: uploadSchemaPartnerUrl,
			}).as('datasetUrlConfig');

		}); 

		cy.fixture(`data/${this.api.env}/mapping/dataset.csv`, 'binary').then((file) => { 
			//Cypress.Blob.binaryStringToBlob(file)).then((blob) => {
			const blob = Cypress.Blob.binaryStringToBlob(file, 'text/csv');
			const formData = new FormData();
			formData.append('file', blob, 'dataset.csv');
            
			cy.wrap({
				datasetFile: formData 
			}).as('datasetcsv');
		});
        
		cy.get('@datasetUrlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'multipart/form-data',
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				}
			};
		}).as('datasetCSVSetupConfig');
	}	

    uploadSchemaDatasetWithCSV = ({schemaId}) =>{
    	return cy.get('@datasetCSVSetupConfig').then((config) => {
    		return cy.get('@datasetcsv').then((fileConfig) =>{
    			return this.api.putUrl({
    				apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    				headers: config.headers,
    				body: fileConfig.datasetFile,
    			});
    		});
    		
    	});
    };

}
export default UploadDatasetApi;