/* eslint-disable no-mixed-spaces-and-tabs */
import { ApiHelper } from '../../../../fixtures';
import { api } from './constants';

class MappingApplicationApi {

	constructor(){
		this.api = new ApiHelper();
	}

	applicationApiSetup(){
		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseApplicationMappingUrl = apiList['MappingApplicationService'];

			// Define constants here
			const baseApplicationMappingSchemaUrl = baseApplicationMappingUrl + api.v1Partners;
			const jwtKey = 'jwt';

			// Check and Generate JWT token
			const jwtToken = Cypress.env(jwtKey);
			if (!jwtToken) {
				this.api.generateJWTToken();
			}

			cy.wrap({
				//Define common urls here
				customApplicationMappingSchemasUrl: baseApplicationMappingSchemaUrl
			}).as('applicationServiceUrlConfig');

		});     

		cy.get('@applicationServiceUrlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'application/json',
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				}
			};
		}).as('applicationServiceSetupConfig');
	}

    getSchemaDataset = ({schemaId}) =>{
    	return cy.get('@applicationServiceSetupConfig').then((config) => {
    		return this.api.invalidGet({
    			apiUrl: config.customApplicationMappingSchemasUrl + schemaId + api.dataset,
    			headers: config.headers,
    		});
    	});
    };

    uploadSchemaDataset = ({schemaId, body}) =>{
    	return cy.get('@applicationServiceSetupConfig').then((config) => {
    		return this.api.postUrl({
    			apiUrl: config.customApplicationMappingSchemasUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: body,
    		});
    	});
    };
}
export default MappingApplicationApi;