const { CommonHelper } = require('../../../../../fixtures');
import SchemaApi from '../SchemaApi';
import DatasetApi from '../DatasetApi';
import UploadDatasetApi from '../DatasetUploadCSVApi';
import MappingSchemaDataHelper from './MappingSchemaDataHelper';
import { errorsData, uploadCsvFileNames } from './constants';

class MappingDatasetUploadCSVHelper extends CommonHelper{

	constructor(){
		super();
		this.schemaApiHelper = new SchemaApi();
		this.uploadDatasetApiHelper = new UploadDatasetApi();
		this.datasetApiHelper = new DatasetApi();
		this.dataHelper = new MappingSchemaDataHelper();
	}

	setupApiHooks() {
		beforeEach(() => {
			this.schemaApiHelper.schemaApiSetup();
			this.uploadDatasetApiHelper.datasetUploadCSVApiSetup();
			this.datasetApiHelper.datasetApiSetup();
		});
	}

	validateUploadDatasetUsingCSV(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			//this.uploadDatasetApiHelper.prepareCSVFile({fileName: uploadCsvFileNames.validFile});			
			this.uploadDatasetApiHelper.uploadSchemaDatasetWithCSV({schemaId:schemaId, fileName: uploadCsvFileNames.validFile}).then((response) =>{
				expect(response.status).to.eq(200);
				this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(200);
					//expect(response.body.length).to.eq(10);
				});
			});
			//Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateUploadDatasetUsingInvalidCSV(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;

			//1. To validate dataset should not be uploaded if user will send invalid data or format of .csv file
			this.uploadDatasetApiHelper.uploadSchemaDatasetWithInvalidHeaderCSV({schemaId:schemaId, fileName: uploadCsvFileNames.invalidHeaderFile}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.statusText).to.equals(errorsData.errorTextMessage);
			});

			//2. To validate partner can't upload blank csv
			this.uploadDatasetApiHelper.uploadSchemaDatasetWithBlankCSV({schemaId:schemaId, fileName: uploadCsvFileNames.emptyFile}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.statusText).to.equals(errorsData.errorTextMessage);
			});

			//4. To validate partner can't be upload invalid file format (.xls/.xlsx)
			this.uploadDatasetApiHelper.uploadSchemaDatasetWithInvalidFormatFile({schemaId:schemaId, fileName: uploadCsvFileNames.invalidFileFormat}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.statusText).to.equals(errorsData.errorTextMessage);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}
}

export default MappingDatasetUploadCSVHelper;