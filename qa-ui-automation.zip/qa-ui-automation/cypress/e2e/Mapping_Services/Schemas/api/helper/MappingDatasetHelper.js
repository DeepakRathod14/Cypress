const { CommonHelper } = require('../../../../../fixtures');
import SchemaApi from '../SchemaApi';
import DatasetApi from '../DatasetApi';
import UploadDatasetApi from '../UploadDatasetApi';
import MappingSchemaDataHelper from './MappingSchemaDataHelper';
import { errorsData, testData, updatedData } from './constants';

class MappingDatasetHelper extends CommonHelper{

	constructor(){
		super();
		this.schemaApiHelper = new SchemaApi();
		this.datasetApiHelper = new DatasetApi();
		this.uploadDatasetApiHelper = new UploadDatasetApi();
		this.dataHelper = new MappingSchemaDataHelper();
	}

	setupApiHooks() {
		beforeEach(() => {
			this.schemaApiHelper.schemaApiSetup();
			this.datasetApiHelper.datasetApiSetup();
			this.uploadDatasetApiHelper.datasetApiCSVSetup();
		});
	}

	uploadSchemaDatasetApiWithPUT(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});
			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	uploadSchemaDatasetApiWithPOST(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.uploadSchemaDataSetForPOST().getUploadSchemaDataSetForPOST();
			this.datasetApiHelper.uploadSchemaDatasetWithPOST({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});
			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	uploadSchemaDataSetWithCondition(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			
			//To validate dataset should be replace if user will set overwrite flag as TRUE
			this.datasetApiHelper.uploadSchemaDatasetWithTrueCondition({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});

			//To validate dataset should be append with existing dataset if user will set overwrite flag as FALSE
			this.datasetApiHelper.uploadSchemaDatasetWithFalseCondition({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	getSchemaDatasetApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);

				// To validate GET Dataset api response with all details - CWMS-T3
				// To validate GET Dataset api response without applying any condition - CWMS-T17
				// To validate GET Dataset api response with dataset-id - CWMS-T22
				// To validate existing schemas dataset should have an updated_at field in response - CWMS-T96
				this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(200);
					expect(response.body[0]).to.have.property(testData.datasetId);
					expect(response.body[0]).to.have.property(testData.priority);
					expect(response.body[0]).to.have.property(testData.serviceId);
					expect(response.body[0]).to.have.property(testData.serviceIsActive);
					expect(response.body[0]).to.have.property(testData.serviceName);
					expect(response.body[0]).to.have.property(testData.service);
					expect(response.body[0]).to.have.property(testData.severity);
					expect(response.body[0]).to.have.property(testData.updated_at);
				});

				// Delete dataset
				this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});

				// Delete schema
				this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});
			});
		});
	}

	getDatasetWithCondition(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);

				// To validate GET Dataset api response with valid condition applied
				this.datasetApiHelper.getSchemaDatasetWithCondition({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(200);
					expect(response.body[0].serviceboard).to.eq(testData.serviceBoard);
				});

				// Delete dataset
				this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});

				// Delete schema
				this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});
			});
		});
	}

	validateGetDatasetWithInvalidConditions(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);

				//To validate get dataset with missing space in condition
				this.datasetApiHelper.getDatasetWithMissingConditionSpace({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(500);
					expect(response.body.errors[0].code).to.equals(errorsData.datasetErrorCode);
					expect(response.body.errors[0].message).to.contains(errorsData.datasetErrorMessage);
				});

				//To validate get dataset with invalid value in condition
				this.datasetApiHelper.getDatasetWithInvalidConditionValue({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(500);
					expect(response.body.errors[0].code).to.equals(errorsData.datasetErrorCode);
					expect(response.body.errors[0].message).to.contains(errorsData.invalidConditionValue);
				});

				// Delete dataset
				this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});

				// Delete schema
				this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});
			});
		});
	}

	validateUpdateDatasetDetails(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.uploadSchemaDataSet().getSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);				
			});
			this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
				const datasetId = response.body[0].id;
				const updateDatasetBody = this.dataHelper.updateDataset().getUpdateDataset();

				// To validate update dataset api response with updated fields
				// To validate update_at in response once partner will update existing dataset - CWMS-T97
				this.datasetApiHelper.updateSchemaDataset({schemaId:schemaId, datasetId: datasetId, body:updateDatasetBody}).then((response) =>{
					expect(response.status).to.eq(200);
					expect(response.body.service_id).to.eq(updatedData.serviceID);
					expect(response.body.serviceboard).to.eq(updatedData.serviceBoard);
					expect(response.body).to.have.property(testData.updated_at);
				
					const serviceName = response.body.service_name;
					// To validate updated dataset should be TOP in the list if will execute sort by updated_at as query parameter
					this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
						expect(response.status).to.eq(200);
						expect(response.body[0].service_id).to.eq(updatedData.serviceID);
						expect(response.body[0].service_name).to.eq(serviceName);
						expect(response.body[0].serviceboard).to.eq(updatedData.serviceBoard);
					});

				});
			});
			
			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateInvalidUpdateDatasetDetails(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);				
			});
			this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
				const datasetId = response.body[0].id;
				const updateDatasetBody = this.dataHelper.updateDataset().getUpdateDataset();

				// To validate invalid URL to update dataset api
				this.datasetApiHelper.invalidUrlToUpdateSchemaDataset({schemaId:schemaId, datasetId: datasetId, body:updateDatasetBody}).then((response) =>{
					expect(response.status).to.eq(404);
				});

				// To validate empty schemaID to update dataset api
				this.datasetApiHelper.invalidSchemaOrDatasetIDToUpdateSchemaDataset({schemaId:null, datasetId: datasetId, body:updateDatasetBody}).then((response) =>{
					expect(response.status).to.eq(404);
				});

				// To validate empty datasetID to update dataset api
				this.datasetApiHelper.invalidSchemaOrDatasetIDToUpdateSchemaDataset({schemaId:schemaId, datasetId: null, body:updateDatasetBody}).then((response) =>{
					expect(response.status).to.eq(404);
				});

				// To validate empty request body to update dataset api
				this.datasetApiHelper.invalidSchemaOrDatasetIDToUpdateSchemaDataset({schemaId:schemaId, datasetId: datasetId, body:null}).then((response) =>{
					expect(response.status).to.eq(400);
				});

				// Delete dataset based for entire schema
				this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});

				// To validate if dataset is not longer available to update dataset api
				this.datasetApiHelper.invalidSchemaOrDatasetIDToUpdateSchemaDataset({schemaId:schemaId, datasetId: datasetId, body:updateDatasetBody}).then((response) =>{
					expect(response.status).to.eq(404);
					expect(response.body.errors[0].code).to.equals(errorsData.datasetNotExistErrorCode);
					expect(response.body.errors[0].message).to.contains(errorsData.datasetNotExistErrorMessage);
				});
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	deleteSchemaDatasetApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
				this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(200);					
				});
			});

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

		});

	}

	deleteSchemaDatasetApiWithID(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
				this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(200);
					const datasetId = response.body[0].id;	
						
					// Delete dataset with datasetID
					this.datasetApiHelper.deleteSchemaDatasetWithID({schemaId: schemaId, datasetId: datasetId}).then((response) =>{
						expect(response.status).to.eq(204);
					});
				});
			});
	
			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
	
		});

	}

	validateInvalidCreateDatasetPUTApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
        
			this.datasetApiHelper.invalidUrlToUploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(404);
			});

			const emptySchemaBody = this.dataHelper.emptyUploadSchemaDataSet().getEmptyUploadSchemaDataSet();
			this.datasetApiHelper.emptyBodyToUploadSchemaDataset({schemaId:schemaId, body:emptySchemaBody}).then((response) =>{
				expect(response.status).to.eq(400);
			});

			//To validate unsupported media type error with status code once user will enter invalid content type
			this.datasetApiHelper.invalidContentTypeToUploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(400);
			});

			this.datasetApiHelper.emptySchemaIDToUploadSchemaDataset({schemaId:null, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(404);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	// eslint-disable-next-line no-dupe-class-members
	validateInvalidUploadDatasetPOSTApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.uploadSchemaDataSetForPOST().getUploadSchemaDataSetForPOST();
			const invalidUploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			
			//1. To validate error message for invalid request URL
			this.datasetApiHelper.invalidUrlToUploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(404);
			});

			//2. To validate error message for empty body
			const emptySchemaBody = this.dataHelper.emptyUploadSchemaDataSet().getEmptyUploadSchemaDataSet();
			this.datasetApiHelper.emptyBodyToUploadSchemaDataset({schemaId:schemaId, body:emptySchemaBody}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.body.errors[0].code).to.contains(errorsData.emptyBodyDatasetErrorCode);
			});

			//3. To validate error message while creating dataset if partner will pass array (more than one dataset).
			this.datasetApiHelper.invalidRequestDataForSchemaDataset({schemaId:schemaId, body:invalidUploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.body.errors[0].code).to.contains(errorsData.emptyBodyDatasetErrorCode);
				expect(response.body.errors[0].message).to.contains(errorsData.invalidBodyDatasetErrorMessage);
			});

			//4. To validate error message for 2nd time creating dataset with same data for same schema.
			this.datasetApiHelper.uploadSchemaDatasetWithPOST({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});

			this.datasetApiHelper.invalidUploadSchemaDatasetWithPOST({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.body.errors[0].message).to.contains(errorsData.duplicateDatasetErrorMessage);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			//5. To validate error message if schema does not exist
			this.datasetApiHelper.invalidUploadSchemaDatasetWithPOST({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(404);
				expect(response.body.errors[0].code).to.contains(errorsData.code);
				expect(response.body.errors[0].message).to.contains(errorsData.message);
			});
		});
	}
	
	validateInvalidGetSchemaDatasetApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);

				// To validate invalid URL for GET dataset api 
				this.datasetApiHelper.invalidUrlGetSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(404);
				});

				// To validate empty schema id for GET dataset api
				this.datasetApiHelper.emptySchemaIDToGetSchemaDataset({schemaId: null}).then((response) =>{
					expect(response.status).to.eq(404);
				});
			});

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}


	validateInvalidDeleteSchemaDatasetApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
				this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(200);

					// To validate invalid URL for delete dataset api
					this.datasetApiHelper.invalidUrlDeleteSchemaDataset({schemaId: schemaId}).then((response) =>{
						expect(response.status).to.eq(404);
					});

					// To validate empty schema ID for delete dataset api
					this.datasetApiHelper.emptySchemaIDToDeleteSchemaDataset({schemaId: null}).then((response) =>{
						expect(response.status).to.eq(404);
					});
				});
			});

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateUploadDatasetUsingCSV(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			this.uploadDatasetApiHelper.uploadSchemaDatasetWithCSV({schemaId:schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
				this.datasetApiHelper.getSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(200);
					//expect(response.body.length).to.eq(10);
				});
			});
			//Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateGetDatasetApiWithQueryParameter(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});

			//1. GET dataset using page number query parameter
			this.datasetApiHelper.getSchemaDatasetWithPageNumberCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
			});

			//2. GET dataset using page size query parameter
			this.datasetApiHelper.getSchemaDatasetWithPageSizeCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
			});

			//3. GET dataset using page size and page number query parameter together
			this.datasetApiHelper.getSchemaDatasetWithPageSizeAndNumberCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
			});

			//4.GET dataset using soryBy query parameter
			this.datasetApiHelper.getSchemaDatasetWithSortByCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
			});			

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateGetDatasetApiWithInvalidQueryParameter(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});

			//1. GET dataset using invalid page query parameter
			this.datasetApiHelper.getSchemaDatasetWithInvalidPageNumberCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.body.errors[0].code).to.contains(errorsData.invalidPageQueryParameterCode);
				expect(response.body.errors[0].message).to.contains(errorsData.invalidPageQueryParameterMessage);
			});

			//2. GET dataset using invalid pageSize query parameter
			this.datasetApiHelper.getSchemaDatasetWithInvalidPageSizeCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.body.errors[0].code).to.contains(errorsData.invalidPageSizeQueryParameterCode);
				expect(response.body.errors[0].message).to.contains(errorsData.invalidPageSizeQueryParameterMessage);
			});

			//3. GET dataset using invalid page number & valid page size in query parameter
			this.datasetApiHelper.getSchemaDatasetWithPageSizeAndInvalidPageNumberCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(400);
			});

			//4.GET dataset using invalid sortBy query parameter
			this.datasetApiHelper.getSchemaDatasetWithInvalidSortByCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.body.errors[0].code).to.contains(errorsData.invalidPageSortByQueryParameterCode);
				expect(response.body.errors[0].message).to.contains(errorsData.invalidPageSortByQueryParameterMessage);
			});			

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateUploadDatasetWithDiffData(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.UploadSchemaDatasetWithDiffData().getSchemaDatasetWithDiffData();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});

			// GET dataset
			this.datasetApiHelper.getSchemaDatasetWithPageNumberCondition({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
			});

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}
}
export default MappingDatasetHelper;