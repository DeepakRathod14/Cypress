const { CommonHelper } = require('../../../../../fixtures');
import MappingApplicationDataHelper from './MappingApplicationDataHelper';
import MappingEntityDataHelper from './MappingEntityDataHelper';
import SchemaApi from '../SchemaApi';
import DatasetApi from '../DatasetApi';
import EntityApi from '../EntityApi';
import MappingApplicationApi from '../MappingApplicationApi';
import { mappingApplicationTestData, testData, errorsData, entityData } from './constants';
class MappingApplicationHelper extends CommonHelper{

	constructor(){
		super();
		this.schemaApi = new SchemaApi();
		this.datasetApi = new DatasetApi();
		this.entityApiHelper = new EntityApi();  
		this.mappingApplicationApi = new MappingApplicationApi();
		this.mappingApplicationDataHelper = new MappingApplicationDataHelper();
		this.entityDataHelper = new MappingEntityDataHelper();

	}

	setupApiHooks() {
		beforeEach(() => {
			this.schemaApi.schemaApiSetup();
			this.datasetApi.datasetApiSetup();
			this.entityApiHelper.entityApiSetup();			
			this.mappingApplicationApi.applicationApiSetup();
		});
	}

	validateGETSchemaDataset(){
		const body = this.mappingApplicationDataHelper.generateV2Schema().getV2Schema();
		this.schemaApi.createNewSchemaUsingV2({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.mappingApplicationDataHelper.uploadSchemaDataSet().getUploadSchemaDataSet();
			this.mappingApplicationApi.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
				this.mappingApplicationApi.getSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(200);
					expect(response.body).to.have.property(mappingApplicationTestData.totalCount);
					expect(response.body).to.have.property(mappingApplicationTestData.schemaFields);
					expect(response.body.schemaFields).to.have.property(mappingApplicationTestData.sourceAttributes);
					expect(response.body.schemaFields.sourceAttributes).to.have.property(mappingApplicationTestData.systemName);
					expect(response.body.schemaFields.sourceAttributes).to.have.property(mappingApplicationTestData.schemaAttributes);
					expect(response.body.schemaFields.sourceAttributes.schemaAttributes[0]).to.have.property(mappingApplicationTestData.displayName);
					expect(response.body.schemaFields.sourceAttributes.schemaAttributes[0]).to.have.property(mappingApplicationTestData.isContingentField);
					expect(response.body.schemaFields.sourceAttributes.schemaAttributes[0]).to.have.property(mappingApplicationTestData.isHidden);
					expect(response.body.schemaFields).to.have.property(mappingApplicationTestData.targetAttributes);
					expect(response.body).to.have.property(mappingApplicationTestData.records);
					expect(response.body.records[0]).to.have.property(testData.schemaId);
					expect(response.body.records[0]).to.have.property(mappingApplicationTestData.attributes);
				});

				//Delete dataset
				this.datasetApi.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});

				// Delete schema
				this.schemaApi.deleteSchema({schemaId: schemaId}).then((response) =>{
					expect(response.status).to.eq(204);
				});
			});
		});
	}

	createNewV2Schema(){
		const body = this.mappingApplicationDataHelper.generateV2Schema().getV2Schema();
		return this.schemaApi.createNewSchemaUsingV2({ body: body }).then((response)=>{
			expect(response.status).to.eq(201);
		});
	}

	deleteSchema({schemaId}){
		this.schemaApi.deleteSchema({schemaId: schemaId}).then((response) =>{
			expect(response.status).to.eq(204);
		});
	}

	validateInvalidGETSchemaDataset(){
		const body = this.mappingApplicationDataHelper.generateV2Schema().getV2Schema();
		this.schemaApi.createNewSchemaUsingV2({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			
			// Delete schema
			this.schemaApi.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			//1. To validate error response if user will enter deleted schema id
			this.mappingApplicationApi.getSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(404);
				expect(response.body.errors[0].code).to.equals(errorsData.code);
				expect(response.body.errors[0].message).to.equals(errorsData.message);
			});

		});
	}

	validateSchemaEntities(){
		const body = this.mappingApplicationDataHelper.generateV2Schema().getV2Schema();
		this.schemaApi.createNewSchemaUsingV2({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const entityId = response.body.sourceAttributes[0].entityId;
			const connectionBody = this.entityDataHelper.generateConnectionData().getConnectionData();
			this.entityApiHelper.createEntityConnection({schemaId: schemaId, entityId: entityId, body: connectionBody}).then((response) =>{
				expect(response.status).to.eq(201);
				expect(response.body).to.have.property(entityData.connectionIdField);
			});
			this.entityApiHelper.getSchemaEntities({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
				expect(response.body[0]).to.have.property(entityData.entityIdField);
				expect(response.body[0]).to.have.property(entityData.nameField);
				expect(response.body[0]).to.have.property(entityData.connectionTypeField);
				expect(response.body[0]).to.have.property(entityData.connectionIdField);
				expect(response.body[1]).to.have.property(entityData.entityIdField);
				expect(response.body[1]).to.have.property(entityData.nameField);
				expect(response.body[1]).to.have.property(entityData.connectionTypeField);				
			});

			// To validate error if attempting to delete a entity that is in use by a schema field
			this.entityApiHelper.invalidDeleteEntity({entityId}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.body.errors[0].code).to.equals(errorsData.entityUsedErrorCode);
				expect(response.body.errors[0].message).to.equals(errorsData.entityUsedErrorMessage);
			});
			// Delete schema
			this.schemaApi.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}
}
export default MappingApplicationHelper;