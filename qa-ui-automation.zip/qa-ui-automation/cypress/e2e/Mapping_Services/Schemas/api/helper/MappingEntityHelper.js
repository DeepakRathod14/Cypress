const { CommonHelper } = require('../../../../../fixtures');
import EntityApi from '../EntityApi';
import MappingEntityDataHelper from './MappingEntityDataHelper';
import { entityData, errorsData } from './constants';

class MappingEntityHelper extends CommonHelper{

	constructor(){
		super();
		this.entityApiHelper = new EntityApi();        
		this.entityDataHelper = new MappingEntityDataHelper();
	}

	setupApiHooks() {
		beforeEach(() => {
			this.entityApiHelper.entityApiSetup();
		});
	}

	validateMappingEntity(){
		const uploadEntityBody = this.entityDataHelper.generateEntityData().getEntityData();
		//1. To validate post api should be create new entity
		this.entityApiHelper.createNewEntity({body:uploadEntityBody}).then((response) =>{
			expect(response.status).to.eq(201);
			const entityId = response.body.id;
			expect(response.body).to.have.property(entityData.idField);
			expect(response.body).to.have.property(entityData.nameField);
			expect(response.body).to.have.property(entityData.connectionTypeField);
			expect(response.body).to.have.property(entityData.fieldsField);
			expect(response.body).to.have.property(entityData.actionReferenceField);

			//2. To validate GET entity Api should be return list of entities in response
			this.entityApiHelper.getEntities().then((response) =>{
				expect(response.status).to.eq(200);
			});

			//3.To validate entity should be delete once user will send DELETE entity api
			this.entityApiHelper.deleteEntity({entityId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}


	validateInvalidEntityError(){
		const uploadEntityBody = this.entityDataHelper.generateEntityData().getEntityData();
		// Create new entity
		this.entityApiHelper.createNewEntity({body:uploadEntityBody}).then((response) =>{
			expect(response.status).to.eq(201);
			const entityId = response.body.id;
			
			//1. To validate error message and error code while user will enter already exist entity name
			this.entityApiHelper.invalidCreateEntity({body:uploadEntityBody}).then((response) =>{
				expect(response.status).to.eq(409);
				expect(response.body.errors[0].code).equals(errorsData.entityExistError);
			});

			//2. To validate entity should not be delete if user will send invalid entity_id to DELETE entity api
			const invalidEntityId = entityData.invalidEntityId;
			this.entityApiHelper.invalidDeleteEntity({invalidEntityId}).then((response) =>{
				expect(response.status).to.eq(404);
				expect(response.body.errors[0].code).to.equals(errorsData.invalidSchemaIdCode);
				expect(response.body.errors[0].message).to.equals(errorsData.invalidSchemaIdMessage);
			});

			// Delete Entity
			this.entityApiHelper.deleteEntity({entityId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			//3. To validate entity should not be delete if user will send already deleted entity_id to DELETE entity api
			this.entityApiHelper.invalidDeleteEntity({entityId}).then((response) =>{
				expect(response.status).to.eq(404);
				expect(response.body.errors[0].code).to.equals(errorsData.entityNotExistErrorCode);
				expect(response.body.errors[0].message).to.equals(errorsData.entityNotExistErrorMessage);
			});
		});

	}

	validateInvalidEntityCreationError(){
		const uploadEntityBody = this.entityDataHelper.generateEntityData().getEntityData();
		// Create new entity
		this.entityApiHelper.createNewEntity({body:uploadEntityBody}).then((response) =>{
			expect(response.status).to.eq(201);
			const entityId = response.body.id;
			
			
			//1. To validate POST entity api with invalid request
			this.entityApiHelper.invalidCreateEntity({body:null}).then((response) =>{
				expect(response.status).to.eq(400);
				expect(response.body.errors[0].code).to.equals(errorsData.entityEmptyBodyError);
			});

			// Delete Entity
			this.entityApiHelper.deleteEntity({entityId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}
}
export default MappingEntityHelper;