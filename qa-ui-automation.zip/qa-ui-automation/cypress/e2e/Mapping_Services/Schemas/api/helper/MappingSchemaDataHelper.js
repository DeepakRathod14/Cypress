/* eslint-disable camelcase */
import { CommonHelper } from '../../../../../fixtures';


class MappingSchemaDataHelper{

	constructor(){
		this.commonHelper = new CommonHelper();
	}

	generateCreateSchemaData(){
		this.createSchemaData = {
			name: this.commonHelper.getFakeName(),
			source: {
				systemName: 'Automate',
				attributes: [
					{
						name: 'service_id',
						type: 'integer'
					},
					{
						name: 'service_name',
						type: 'string'
					},
					{
						name: 'service_isActive',
						type: 'boolean'
					}
				]
			},
			target: {
				systemName: 'Asio',
				attributes: [
					{
						name: 'serviceboard',
						type: 'string'
					},
					{
						name: 'priority',
						type: 'string'
					},
					{
						name: 'severity',
						type: 'string'
					}
				]
			},
			dataSourceType: 'db'
		};
		return this;
	}

	getCreateSchemaDataApi() {
		return this.createSchemaData;
	}

	createSchemaDataUsingV2(){
		this.createV2SchemaData = {
			name: this.commonHelper.getFakeName(),
			sourceAttributes: [
				{
					name: 'service_id',
					type: 'integer'
				},
				{
					name: 'service_name',
					type: 'string'
				},
				{
					name: 'service_isActive',
					type: 'boolean'
				}
			],
			targetAttributes: [
				{
					name: 'serviceboard',
					type: 'string'
				},
				{
					name: 'priority',
					type: 'string'
				},
				{
					name: 'severity',
					type: 'string'
				}
			],
			dataSourceType: 'db'
		};
		return this;
	}

	getSchemaDataUsingV2Api() {
		return this.createV2SchemaData;
	}

	createSchemaWithUppercase(){
		this.UpperCaseSchemaData = {
			name: this.commonHelper.getFakeName(),
			source: {
				systemName: 'Automate',
				attributes: [
					{
						name: 'SERVICE_ID',
						type: 'integer'
					},
					{
						name: 'SERVICE_NAME',
						type: 'string'
					},
					{
						name: 'SERVICE_ISACTIVE',
						type: 'boolean'
					}
				]
			},
			target: {
				systemName: 'Asio',
				attributes: [
					{
						name: 'SERVICEBOARD',
						type: 'string'
					},
					{
						name: 'PRIORITY',
						type: 'string'
					},
					{
						name: 'SEVERITY',
						type: 'string'
					}
				]
			},
			dataSourceType: 'db'
		};
		return this;
	}

	getSchemaDataWithUppercase() {
		return this.UpperCaseSchemaData;
	}

	invalidCreateSchemaData(){
		this.invalidSchemaData = {

		};
		return this;
	}

	getInvalidCreateSchemaData(){
		return this.invalidSchemaData;
	}

	generateUploadSchemaDataSet(){
		this.uploadSchemaData = [{
			service_id: 101,
			service_name: 'Auto Test',
			service_isActive: true,
			priority: 'High',
			severity: 'Critical',
			serviceboard: 'Board T'
		},];
		return this;
	}

	getUploadSchemaDataSet(){
		return this.uploadSchemaData;
	}

	uploadSchemaDataSet(){
		this.uploadSchemaData = [{
			service_id: 104,
			service_name: this.commonHelper.getFakeName(),
			service_isActive: true,
			priority: 'High',
			severity: 'Critical',
			serviceboard: 'Board A'
		}];
		return this;
	}

	getSchemaDataSet(){
		return this.uploadSchemaData;
	}

	generateUploadSchemaDataSetWithUpperCase(){
		this.UpperCaseUploadSchemaData = [{
			SERVICE_ID: 101,
			SERVICE_NAME: 'Auto Test',
			SERVICE_ISACTIVE: true,
			PRIORITY: 'High',
			SEVERITY: 'Critical',
			SERVICEBOARD: 'Board T'
		},];
		return this;
	}

	getUploadSchemaDataSetWithUpperCase(){
		return this.UpperCaseUploadSchemaData;
	}

	uploadSchemaDataSetForPOST(){
		this.uploadSchemaData = {
			service_id: 101,
			service_name: this.commonHelper.getFakeName(),
			service_isactive: true,
			priority: 'High',
			severity: 'Critical',
			serviceboard: 'Board T'
		};
		return this;
	}

	// eslint-disable-next-line no-dupe-class-members
	getUploadSchemaDataSetForPOST(){
		return this.uploadSchemaData;
	}

	updateDataset(){
		this.updateData = {
			service_id: 104,
			service_name: this.commonHelper.getFakeName(),
			serviceboard: 'Board H'
		};
		return this;
	}

	getUpdateDataset(){
		return this.updateData;
	}

	emptyUploadSchemaDataSet(){
		this.emptySchemaData = {

		};
		return this;
	}

	getEmptyUploadSchemaDataSet(){
		return this.emptySchemaData;
	}

	UploadSchemaDatasetWithDiffData(){
		this.uploadSchemaData = [
			{
				service_id: 101,
				service_name: this.commonHelper.getFakeName(),
				service_isActive: true,
				priority: 'High',
				severity: 'Critical',
				serviceboard: 'Board A'
			},
			{
				Service_Id: 102,
				Service_Name: this.commonHelper.getFakeName(),
				Service_IsActive: false,
				Priority: 'Low',
				Severity: 'Minor',
				Serviceboard: 'Board B'
			},
			{
				SERVICE_ID: 103,
				SERVICE_NAME: this.commonHelper.getFakeName(),
				SERVICE_ISACTIVE: true,
				PRIORITY: 'Medium',
				SEVERITY: 'Mejor',
				SERVICEBOARD: 'Board C'
			},
		];
		return this;
	}

	getSchemaDatasetWithDiffData(){
		return this.uploadSchemaData;
	}

}

export default MappingSchemaDataHelper;