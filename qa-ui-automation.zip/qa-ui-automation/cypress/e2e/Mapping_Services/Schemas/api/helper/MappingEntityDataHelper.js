/* eslint-disable camelcase */
import { CommonHelper } from '../../../../../fixtures';
import { entityData} from './constants';

class MappingEntityDataHelper{

	constructor(){
		this.commonHelper = new CommonHelper();
	}
    
	generateEntityData(){
		this.entityData = {
			name: this.commonHelper.getFakeName(),
			connectionType: entityData.connectionTypeFieldAttributeValue,
			fields: [
				{
					name: entityData.nameFieldAttributeValue,
					displayName: entityData.displayNameFieldAttributeValue,
					attributesDependsOn: [
						'string'
					],
					actionIdField: 'id',
					actionFriendlyNameField: 'name',
					actionReference: '1'
				},
				{
					name: entityData.nameFieldAttributeValue1,
					displayName: entityData.displayNameFieldAttributeValue1,
					attributesDependsOn: [
						'string'
					],
					actionIdField: 'id',
					actionFriendlyNameField: 'name',
					actionReference: '2'
				}
			],
			actionReference: 'string'
		};
		return this;
	}

	getEntityData(){
		return this.entityData;
	}
	
	generateConnectionData(){
		this.connectionData = {
			connectionId: entityData.connectionId
		};
		return this;
	}

	getConnectionData(){
		return this.connectionData;
	}
}
export default MappingEntityDataHelper;