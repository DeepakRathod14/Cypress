/* eslint-disable camelcase */


export const testData = {
	schemaId: 'id',
	schemaName: 'name',
	description: 'description',
	overrides: 'allowPartnerOverrides',
	tableName: 'dsTableName',
	sourceType: 'dataSourceType',
	createdAt: 'createdAt',
	updatedAt: 'updatedAt',
	source: 'source',
	target: 'target',
	datasetId: 'id',
	priority: 'priority',
	service: 'serviceboard',
	serviceId: 'service_id',
	serviceIsActive: 'service_isactive',
	serviceName: 'service_name',
	severity: 'severity',
	serviceBoard: 'Board T',
	sourceAttributes: 'sourceAttributes',
	targetAttributes: 'targetAttributes',
	dataSourceType: 'dataSourceType',
	updated_at: 'updated_at'
};

export const lookupData = {
	matchedSchema: 'matchedSchemaIds',
	matchedAttribute: 'matchedAttributes',
	upperCaseService: 'SERVICEBOARD',
};

export const uploadCsvFileNames = {
	validFile: 'dataset.csv',
	invalidHeaderFile: 'invalidheader.csv',
	emptyFile: 'emptyfile.csv',
	invalidFileFormat: 'invalidfileformat.xlsx'
};


export const entityData ={
	idField: 'id',
	entityIdField: 'entityId',
	nameField: 'name',
	connectionTypeField: 'connectionType',
	fieldsField: 'fields',
	displayNameField: 'displayName',
	actionReferenceField: 'actionReference',
	entityField: 'entity',	
	invalidEntityId: '52e76155-ff64-421e-ae26-24d40223d5',
	nameFieldAttributeValue: 'serviceboardid',
	displayNameFieldAttributeValue: 'Service Board ID',
	connectionTypeFieldAttributeValue: 'multiple',
	connectionIdField: 'connectionId',
	nameFieldAttributeValue1: 'service_name',
	displayNameFieldAttributeValue1: 'Service Name',
	connectionId: '87eb892c-19a5-4d0e-9276-b91fe6fd630f'
};


export const errorsData = {
	code: 'SchemaDoesNotExistError',
	message: 'Schema does not exist',
	invalidSchemaId: 'c1549879-7f39-492b-a47d-8b3b726f65',
	invalidSchemaIdCode: 'InvalidUUIDInRequestError',
	invalidSchemaIdMessage: 'Invalid UUID in request',
	datasetErrorCode: 'UnhandledError',
	datasetErrorMessage: 'Error in filter query',
	invalidDatasetError: 'No data found for the given schema',
	datasetNotExistErrorCode: 'DatasetEntryDoesNotExistError',
	datasetNotExistErrorMessage: 'The dataset entry does not exist for this schema',
	duplicateDatasetErrorMessage: 'A dataset entry already exists for this schema with these values',
	emptyBodyDatasetErrorCode: 'InvalidRequestFormatError',
	invalidBodyDatasetErrorMessage: 'json: cannot unmarshal array into Go value of type map[string]interface {}',
	invalidPageQueryParameterCode: 'PageNotValidError',
	invalidPageQueryParameterMessage: 'page query paramater is not valid. It must be a valid positive integer',
	invalidPageSizeQueryParameterCode: 'PageSizeNotValidError',
	invalidPageSizeQueryParameterMessage: 'pageSize query paramater is not valid. It must be an integer between 1 and 1000',
	invalidPageSortByQueryParameterCode: 'SortByNotValidError',
	invalidPageSortByQueryParameterMessage: 'sortBy query paramater is not valid. It must be a singular valid field with an optional direction of asc or desc',
	invalidConditionValue: 'Error in filter query | Location: serviceboar )  | Error: cannot create command from queue : [serviceboar]',
	entityExistError: 'EntityAlreadyExistError',
	entityEmptyBodyError: 'InvalidRequestFormatError',
	entityNotExistErrorCode: 'EntityDoesNotExistError',
	entityNotExistErrorMessage: 'The entity does not exist',
	entityUsedErrorCode: 'EntityInUseBySchemaField',
	entityUsedErrorMessage: 'The entity can not be deleted as it is in use by a schema field',
	invalidCSVHeaderErrorCode: 'InvalidCSVHeaderError',
	invalidCSVHeaderErrorMessage: 'csv headers are invalid. They must belong to the schema and a header line is required',
	emptyCSVFileErrorMessage: 'csv file is in an incorrect format',
	invalidFileFormatErrorCode: 'InvalidFileFormat',
	invalidFileFormatErrorMessage: 'Not a valid csv file',
	errorTextMessage: 'Bad Request'

};

export const updatedData = {
	serviceID: 104,
	serviceBoard: 'Board H'
};

export const mappingApplicationTestData = {
	totalCount: 'totalCount',
	schemaFields: 'schemaFields',
	sourceAttributes: 'sourceAttributes',
	systemName: 'systemName',
	schemaAttributes: 'schemaAttributes',
	displayName: 'displayName',
	isContingentField: 'isContingentField',
	isHidden: 'isHidden',
	targetAttributes: 'targetAttributes',
	records: 'records',
	attributes: 'Attributes'
};