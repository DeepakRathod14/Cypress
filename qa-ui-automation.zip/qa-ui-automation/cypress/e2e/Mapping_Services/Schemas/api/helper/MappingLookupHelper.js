const { CommonHelper } = require('../../../../../fixtures');
import SchemaApi from '../SchemaApi';
import LookupApi from '../LookupApi';
import DatasetApi from '../DatasetApi';
import MappingSchemaDataHelper from './MappingSchemaDataHelper';
import MappingLookupDataHelper from './MappingLookupDataHelper';
import { lookupData, testData } from './constants';

class MappingLookupHelper extends CommonHelper{

	constructor(){
		super();
		this.schemaApiHelper = new SchemaApi();
		this.lookupApiHelper = new LookupApi();
		this.datasetApiHelper = new DatasetApi();
		this.dataHelper = new MappingSchemaDataHelper();
		this.lookupDataHelper = new MappingLookupDataHelper();
	}

	setupApiHooks() {
		beforeEach(() => {
			this.schemaApiHelper.schemaApiSetup();
			this.lookupApiHelper.lookupApiSetup();
			this.datasetApiHelper.datasetApiSetup();
		});
	}

	lookupApiWithPartner(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});
			const lookupBody = this.lookupDataHelper.generateLookupData({schemaId: schemaId}).getLookupData();
			this.lookupApiHelper.lookupWithPartner({lookupBody: lookupBody}).then((response)=>{				
				expect(response.status).to.eq(200);
				expect(response.body.completeMatch).to.eq(true);
				expect(response.body).to.have.property(lookupData.matchedSchema);
				expect(response.body).to.have.property(lookupData.matchedAttribute);
				expect(response.body.matchedAttributes).to.have.property(testData.service);
			});

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	lookupApiWithAuth(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});
			const lookupBody = this.lookupDataHelper.generateLookupData({schemaId: schemaId}).getLookupData();
			this.lookupApiHelper.lookupWithAuth({lookupBody: lookupBody}).then((response)=>{				
				expect(response.status).to.eq(200);
				expect(response.body.completeMatch).to.eq(true);
				expect(response.body).to.have.property(lookupData.matchedSchema);
				expect(response.body).to.have.property(lookupData.matchedAttribute);
				expect(response.body.matchedAttributes).to.have.property(testData.service);
			});

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateInvalidLookupApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.schemaApiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});

			// To validate invalid matching attributes 
			const invalidMatchingLookupBody = this.lookupDataHelper.generateInvalidLookupAttributeData({schemaId: schemaId}).getInvalidLookupAttributeData();
			this.lookupApiHelper.lookupWithAuth({lookupBody: invalidMatchingLookupBody}).then((response)=>{				
				expect(response.status).to.eq(200);
				expect(response.body.completeMatch).to.eq(false);
			});
			// To validate invalid lookup api url
			const lookupBody = this.lookupDataHelper.generateLookupData({schemaId: schemaId}).getLookupData();
			this.lookupApiHelper.invalidLookupUrl({lookupBody: lookupBody}).then((response)=>{				
				expect(response.status).to.eq(404);
			});

			// To validate invalid lookup api body
			const invalidBody = this.lookupDataHelper.invalidLookupData({schemaId: schemaId}).getInvalidLookupData();
			this.lookupApiHelper.invalidLookupBody({invalidBody: invalidBody}).then((response)=>{				
				expect(response.status).to.eq(400);
			});

			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// Delete schema
			this.schemaApiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}
	
}

export default MappingLookupHelper;