/* eslint-disable camelcase */
import { CommonHelper } from '../../../../../fixtures';

class MappingApplicationDataHelper{

	constructor(){
		this.commonHelper = new CommonHelper();
	}

	generateV2Schema(){
		this.createV2SchemaData = {
			name: this.commonHelper.getFakeName(),
			description: 'Created v2 schema for automation script',
			sourceAttributes: [
				{
					name: 'service_id',
					displayName: 'Service Id',
					type: 'integer',
					entityId: '31d7945d-2e51-4f03-8976-df2a67d3ee6a'
				  },
				  {
					name: 'service_name',
					displayName: 'Service Name',
					type: 'string',
					entityId: '31d7945d-2e51-4f03-8976-df2a67d3ee6a'
				  },
				  {
					name: 'service_isactive',
					displayName: 'Service IsActive',
					type: 'string',
					entityId: '31d7945d-2e51-4f03-8976-df2a67d3ee6a'
				  }
			],
			targetAttributes: [
				{
					name: 'serviceboard',
					displayName: 'Service Board',
					type: 'string',
					entityId: 'a8060ec5-d5cb-4364-883c-be4af1dbfd39'
				},
				{
					name: 'priority',
					displayName: 'Priority',
					type: 'string',
					entityId: 'a8060ec5-d5cb-4364-883c-be4af1dbfd39'
				},
				{
					name: 'severity',
					displayName: 'Severity',
					type: 'string',
					entityId: 'a8060ec5-d5cb-4364-883c-be4af1dbfd39'
				}
			],
			permissions: {
				'data.read': [
					'intelligentalert.mapper.read',
					'custommonitor.mapper.read'
				],
				'data.update': [
				],
				'data.create': [
					'intelligentalert.mapper.read',
					'custommonitor.mapper.read'
				],
				'data.delete': [
					'intelligentalert.mapper.read',
					'custommonitor.mapper.read'
				],
				'data.csv': []
			},
			dataSourceType: 'db'
		};
		return this;
	}

	getV2Schema() {
		return this.createV2SchemaData;
	}

	uploadSchemaDataSet(){
		this.uploadSchemaData = {
			service_id: 101,
			service_name: 'Auto Test',
			service_isActive: true,
			priority: 'High',
			severity: 'Critical',
			serviceboard: 'Board T'
		};
		return this;
	}

	getUploadSchemaDataSet(){
		return this.uploadSchemaData;
	}

}
export default MappingApplicationDataHelper;