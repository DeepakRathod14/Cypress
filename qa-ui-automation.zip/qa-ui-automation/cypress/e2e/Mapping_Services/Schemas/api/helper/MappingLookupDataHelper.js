/* eslint-disable camelcase */
import { CommonHelper } from '../../../../../fixtures';

class MappingLookupDataHelper{

	constructor(){
		this.commonHelper = new CommonHelper();
	}

	generateLookupData({schemaId}){
		this.lookupData = {
			schemas: [
				{
					id: schemaId
				}
			],
			criteria: {
				sourceAttributes: {
					service_id: 101,
					service_name: 'Auto Test',
					service_isActive: true
				},
				targetAttributesRequest: [
					'serviceboard',
					'priority',
					'severity'
				]
			}
		};
		return this;
	}

	getLookupData(){
		return this.lookupData;
	}

	generateLookupDataWithUpperCase({schemaId}){
		this.UpperCaselookupData = {
			schemas: [
				{
					id: schemaId
				}
			],
			criteria: {
				sourceAttributes: {
					SERVICE_ID: 101,
					SERVICE_NAME: 'Auto Test',
					SERVICE_ISACTIVE: true
				},
				targetAttributesRequest: [
					'SERVICEBOARD',
					'PRIORITY',
					'SEVERITY'
				]
			}
		};
		return this;
	}

	getLookupDataWithUpperCase(){
		return this.UpperCaselookupData;
	}

	generateInvalidLookupAttributeData({schemaId}){
		this.lookupData = {
			schemas: [
				{
					id: schemaId
				}
			],
			criteria: {
				sourceAttributes: {
					service_id: 101,
					service_name: 'Auto Test',
					service_isActive: false
				},
				targetAttributesRequest: [
					'serviceboard',
					'priority',
					'severity'
				]
			}
		};
		return this;
	}

	getInvalidLookupAttributeData(){
		return this.lookupData;
	}

	// eslint-disable-next-line no-unused-vars
	invalidLookupData({schemaId}){
		this.invalidData = {
			
		};
		return this;
	}

	getInvalidLookupData(){
		return this.invalidData;
	}
}

export default MappingLookupDataHelper;