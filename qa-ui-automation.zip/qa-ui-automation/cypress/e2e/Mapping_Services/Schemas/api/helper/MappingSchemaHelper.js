
import { CommonHelper } from '../../../../../fixtures';
import SchemaApi from '../SchemaApi';
import DatasetApi from '../DatasetApi';
import LookupApi from '../LookupApi';
import MappingSchemaDataHelper from './MappingSchemaDataHelper';
import MappingLookupDataHelper from './MappingLookupDataHelper';
import { testData, errorsData, lookupData} from './constants';

class MappingSchemaHelper extends CommonHelper{

	constructor(){
		super();
		this.apiHelper = new SchemaApi();
		this.datasetApiHelper = new DatasetApi();
		this.lookupApiHelper = new LookupApi();
		this.dataHelper = new MappingSchemaDataHelper();
		this.lookupDataHelper = new MappingLookupDataHelper();
	}

	setupApiHooks() {
		beforeEach(() => {
			this.apiHelper.schemaApiSetup();
			this.lookupApiHelper.lookupApiSetup();
			this.datasetApiHelper.datasetApiSetup();
		});
	}

	createSchemaApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.apiHelper.createNewSchema({ body: body }).then((response)=>{
			expect(response.status).to.eq(201);
			expect(response.body).to.have.property(testData.schemaId);
			expect(response.body).to.have.property(testData.schemaName);
			expect(response.body).to.have.property(testData.overrides);
			expect(response.body).to.have.property(testData.tableName);
			expect(response.body).to.have.property(testData.sourceType);
			expect(response.body).to.have.property(testData.createdAt);
			expect(response.body).to.have.property(testData.updatedAt);

			const schemaId = response.body.id;
			this.apiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	createSchemaApiUsingV2(){
		const body = this.dataHelper.createSchemaDataUsingV2().getSchemaDataUsingV2Api();
		this.apiHelper.createNewSchemaUsingV2({ body: body }).then((response)=>{
			expect(response.status).to.eq(201);
			expect(response.body).to.have.property(testData.schemaId);
			expect(response.body).to.have.property(testData.schemaName);
			expect(response.body).to.have.property(testData.overrides);
			expect(response.body).to.have.property(testData.tableName);
			expect(response.body).to.have.property(testData.sourceAttributes);
			expect(response.body).to.have.property(testData.targetAttributes);
			expect(response.body).to.have.property(testData.sourceType);
			expect(response.body).to.have.property(testData.createdAt);
			expect(response.body).to.have.property(testData.updatedAt);

			const schemaId = response.body.id;
			this.apiHelper.deleteSchemaUsingV2({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	getSchemasApi(){
		this.apiHelper.getSchemas().then((response) =>{
			expect(response.status).to.eq(200);
			expect(response.body[0]).to.have.property(testData.schemaId);
			expect(response.body[0]).to.have.property(testData.schemaName);
			expect(response.body[0]).to.have.property(testData.overrides);
			expect(response.body[0]).to.have.property(testData.source);
			expect(response.body[0]).to.have.property(testData.target);
			expect(response.body[0]).to.have.property(testData.sourceType);
			expect(response.body[0]).to.have.property(testData.description);
			expect(response.body[0]).to.have.property(testData.createdAt);
			expect(response.body[0]).to.have.property(testData.updatedAt);
		});
	}

	getSchemasApiUsingV2(){
		this.apiHelper.getSchemasUsingV2().then((response) =>{
			expect(response.status).to.eq(200);
			expect(response.body[0]).to.have.property(testData.schemaId);
			expect(response.body[0]).to.have.property(testData.schemaName);
			expect(response.body[0]).to.have.property(testData.overrides);
			expect(response.body[0]).to.have.property(testData.sourceAttributes);
			expect(response.body[0]).to.have.property(testData.targetAttributes);
			expect(response.body[0]).to.have.property(testData.dataSourceType);
			expect(response.body[0]).to.have.property(testData.description);
			expect(response.body[0]).to.have.property(testData.createdAt);
			expect(response.body[0]).to.have.property(testData.updatedAt);
		});
	}

	getExpandedSchemasApi(){
		const body = this.dataHelper.createSchemaDataUsingV2().getSchemaDataUsingV2Api();
		this.apiHelper.createNewSchemaUsingV2({ body: body }).then((response)=>{
			expect(response.status).to.eq(201);
			const schemaId = response.body.id;
			this.apiHelper.getExpandedSchemas({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(200);
				expect(response.body).to.have.property(testData.schemaId);
				expect(response.body).to.have.property(testData.schemaName);				
				expect(response.body).to.have.property(testData.description);
				expect(response.body).to.have.property(testData.overrides);
				expect(response.body).to.have.property(testData.dataSourceType);
				expect(response.body).to.have.property(testData.sourceAttributes);
				expect(response.body.sourceAttributes[0].name).to.equals(testData.serviceName);
				expect(response.body.sourceAttributes[1].name).to.equals(testData.serviceIsActive);
				expect(response.body.sourceAttributes[2].name).to.equals(testData.serviceId);
				expect(response.body).to.have.property(testData.targetAttributes);
				expect(response.body.targetAttributes[0].name).to.equals(testData.priority);
				expect(response.body.targetAttributes[1].name).to.equals(testData.service);
				expect(response.body.targetAttributes[2].name).to.equals(testData.severity);
			});

			// Delete Schema
			this.apiHelper.deleteSchemaUsingV2({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	deleteSchemaApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.apiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			this.apiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	deleteSchemaApiUsingV2(){
		const body = this.dataHelper.createSchemaDataUsingV2().getSchemaDataUsingV2Api();
		this.apiHelper.createNewSchemaUsingV2({ body: body }).then((response)=>{
			const schemaId = response.body.id;
			this.apiHelper.deleteSchemaUsingV2({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateInvalidCreateSchemaApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.apiHelper.invalidUrlCreateSchema({ body: body }).then((response)=>{
			expect(response.status).to.eq(404);
		});    

		// To validate invalid body for create schema
		const invalidBody = this.dataHelper.invalidCreateSchemaData().getInvalidCreateSchemaData();
		this.apiHelper.invalidBodyCreateSchema({ body: invalidBody}).then((response) =>{
			expect(response.status).to.eq(500);
		});

		// To validate empty body for create schema
		this.apiHelper.emptyBodyCreateSchema({ body: null}).then((response) =>{
			expect(response.status).to.eq(400);
		});
	}

	validateInvalidGetSchemasApi(){
		this.apiHelper.invalidUrlGetSchema().then((response) =>{
			expect(response.status).to.eq(404);
		});
	}

	validateInvalidDeleteSchemaApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		this.apiHelper.createNewSchema({ body: body }).then((response)=>{
			const schemaId = response.body.id;

			// To validate invalid URL for delete schema api
			this.apiHelper.invalidUrlDeleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(404);
			});

			// To validate empty schema ID for delete schema api
			this.apiHelper.emptySchemaIDToDeleteSchema({schemaId: null}).then((response) =>{
				expect(response.status).to.eq(404);
			});

			// To validate invalid schema ID for delete schema api
			this.apiHelper.invalidSchemaIDToDeleteSchema({schemaId: errorsData.invalidSchemaId}).then((response) =>{
				expect(response.status).to.eq(404);
				expect(response.body.errors[0].code).to.equals(errorsData.invalidSchemaIdCode);
				expect(response.body.errors[0].message).to.equals(errorsData.invalidSchemaIdMessage);
			});

			// Delete schema
			this.apiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});

			// To validate if schema is not exist to delete
			this.apiHelper.schemaIDNotExistToDeleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(404);
				expect(response.body.errors[0].code).to.equals(errorsData.code);
				expect(response.body.errors[0].message).to.equals(errorsData.message);
			});
			
		});
	}

	validateUppercaseLowsercaseSchemaApi(){
		const body = this.dataHelper.createSchemaWithUppercase().getSchemaDataWithUppercase();
		//Step 1. Created schema with upper case attributes name
		this.apiHelper.createNewSchema({ body: body }).then((response)=>{
			expect(response.status).to.eq(201);
			const schemaId = response.body.id;
			//Step 2. Upload dataset with lower case attributes name
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSet().getUploadSchemaDataSet();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});
			//Step 3. To validate lookup api with lower case request attributes name
			const lookupBody = this.lookupDataHelper.generateLookupData({schemaId: schemaId}).getLookupData();
			this.lookupApiHelper.lookupWithAuth({lookupBody: lookupBody}).then((response)=>{				
				expect(response.status).to.eq(200);
				expect(response.body.completeMatch).to.eq(true);
				expect(response.body).to.have.property(lookupData.matchedSchema);
				expect(response.body).to.have.property(lookupData.matchedAttribute);
				expect(response.body.matchedAttributes).to.have.property(testData.service);
			});
			
			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
			// Delete schema
			this.apiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

	validateLowsercaseUppercaseSchemaApi(){
		const body = this.dataHelper.generateCreateSchemaData().getCreateSchemaDataApi();
		//Step 1. Created schema with lower case attributes name
		this.apiHelper.createNewSchema({ body: body }).then((response)=>{
			expect(response.status).to.eq(201);
			const schemaId = response.body.id;
			//Step 2. Upload dataset with upper case attributes name
			const uploadSchemaBody = this.dataHelper.generateUploadSchemaDataSetWithUpperCase().getUploadSchemaDataSetWithUpperCase();
			this.datasetApiHelper.uploadSchemaDataset({schemaId:schemaId, body:uploadSchemaBody}).then((response) =>{
				expect(response.status).to.eq(201);
			});

			//Step 3. To validate lookup api with upper case request attributes name
			const lookupBody = this.lookupDataHelper.generateLookupDataWithUpperCase({schemaId: schemaId}).getLookupDataWithUpperCase();
			this.lookupApiHelper.lookupWithAuth({lookupBody: lookupBody}).then((response)=>{				
				expect(response.status).to.eq(200);
				expect(response.body.completeMatch).to.eq(true);
				expect(response.body).to.have.property(lookupData.matchedSchema);
				expect(response.body).to.have.property(lookupData.matchedAttribute);
				expect(response.body.matchedAttributes).to.have.property(lookupData.upperCaseService);
			});
			
			// Delete dataset
			this.datasetApiHelper.deleteSchemaDataset({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
			// Delete schema
			this.apiHelper.deleteSchema({schemaId: schemaId}).then((response) =>{
				expect(response.status).to.eq(204);
			});
		});
	}

}

export default MappingSchemaHelper;