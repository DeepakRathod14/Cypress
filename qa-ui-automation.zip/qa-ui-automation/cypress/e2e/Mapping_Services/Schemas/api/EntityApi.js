/* eslint-disable no-mixed-spaces-and-tabs */

import { ApiHelper } from '../../../../fixtures';
import { api } from './constants';
class EntityApi{

	constructor(){
		// Define Helper Classes here
		this.api = new ApiHelper();
	}

	entityApiSetup(){
		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseMappingUrl = apiList['MappingService'];

			// Define constants here
			const entityApiUrl = baseMappingUrl + api.entityApi;
			const getEntitiesApiUrl = baseMappingUrl + api.v1Partners;
			const jwtKey = 'jwt';

			// Check and Generate JWT token
			const jwtToken = Cypress.env(jwtKey);
			if (!jwtToken) {
				this.api.generateJWTToken();
			}

			cy.wrap({
				//Define common urls here
				customeEntityUrl: entityApiUrl,
				customeGetEntitiesUrl: getEntitiesApiUrl
			}).as('entityUrlConfig');

		});     

		// lookup api configuration with authorization token
		cy.get('@entityUrlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'application/json',
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				}
			};
		}).as('entityConfig');
	}

    createNewEntity = ({ body }) => {
    	return cy.get('@entityConfig').then((config) => {
    		return this.api.postUrl({
    			apiUrl: config.customeEntityUrl,
    			headers: config.headers,
    			body: body,
    		});
    	});
    };

	invalidCreateEntity = ({ body }) => {
    	return cy.get('@entityConfig').then((config) => {
    		return this.api.invalidPost({
    			apiUrl: config.customeEntityUrl,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	getEntities = () => {
		return cy.get('@entityConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeEntityUrl,
				headers: config.headers,
			});
		});
	};

	getSchemaEntities = ({schemaId}) => {
		return cy.get('@entityConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeGetEntitiesUrl + schemaId + api.entities,
				headers: config.headers,
			});
		});
	};

	createEntityConnection = ({schemaId, entityId, body}) =>{
		return cy.get('@entityConfig').then((config) => {
    		return this.api.postUrl({
    			apiUrl: config.customeGetEntitiesUrl + schemaId + api.entities + entityId + api.connection,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	deleteEntity = ({entityId}) =>{
		return cy.get('@entityConfig').then((config) => {
			return this.api.deleteUrl({
				apiUrl: config.customeEntityUrl + entityId,
				headers: config.headers,
			});
		});
	};

	invalidDeleteEntity = ({entityId}) =>{
		return cy.get('@entityConfig').then((config) => {
			return this.api.invalidDelete({
				apiUrl: config.customeEntityUrl + entityId,
				headers: config.headers,
			});
		});
	};

}
export default EntityApi;