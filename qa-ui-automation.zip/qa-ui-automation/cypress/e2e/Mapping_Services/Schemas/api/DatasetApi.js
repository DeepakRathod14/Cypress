/* eslint-disable no-mixed-spaces-and-tabs */
import { ApiHelper } from '../../../../fixtures';
import { api } from './constants';

class DatasetApi {

	constructor(){
		// Define Helper Classes here
		this.api = new ApiHelper();
	}

	datasetApiSetup(){
		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseMappingUrl = apiList['MappingService'];

			// Define constants here
			const baseMappingPartnerUrl = baseMappingUrl + api.v1Schemas;
			const uploadSchemaPartnerUrl = baseMappingUrl + api.v1Partners;
			const invalidSchemaUrl = baseMappingUrl + api.inavlidV1Schemas;
			const invalidUploadSchemaPartnerUrl = baseMappingUrl + api.invalidv1Partners;
			const jwtKey = 'jwt';

			// Check and Generate JWT token
			const jwtToken = Cypress.env(jwtKey);
			if (!jwtToken) {
				this.api.generateJWTToken();
			}

			cy.wrap({
				//Define common urls here
				customMappingUrl: baseMappingPartnerUrl,
				customeUploadSchemaUrl: uploadSchemaPartnerUrl,
				customeInvalidSchemasUrl: invalidSchemaUrl,
				customeInvalidUploadSchemaUrl: invalidUploadSchemaPartnerUrl
			}).as('datasetUrlConfig');

		});     

		cy.get('@datasetUrlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'application/json',
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				},
				wrongContentTypeHeaders: {
					'Content-Type': 'text/csv',
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				}
			};
		}).as('datasetSetupConfig');
	}

    uploadSchemaDataset = ({schemaId, body}) =>{
    	return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.putUrl({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: body,
    		});
    	});
    };

	uploadSchemaDatasetWithPOST = ({schemaId, body}) =>{
    	return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.postUrl({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	invalidUploadSchemaDatasetWithPOST = ({schemaId, body}) =>{
    	return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.invalidPost({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	uploadSchemaDatasetWithTrueCondition = ({schemaId, body}) =>{
    	return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.putUrl({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.uploadDatasetTrueCondition,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	uploadSchemaDatasetWithFalseCondition = ({schemaId, body}) =>{
    	return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.putUrl({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.uploadDatasetFalseCondition,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	updateSchemaDataset = ({schemaId, datasetId, body}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.putUrl({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset + datasetId,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	invalidUrlToUpdateSchemaDataset = ({schemaId, datasetId, body}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.invalidPut({
    			apiUrl: config.customeInvalidUploadSchemaUrl + schemaId + api.dataset + datasetId,
    			headers: config.headers,
    			body: body,
    		});
    	});
	}

	invalidSchemaOrDatasetIDToUpdateSchemaDataset = ({schemaId, datasetId, body}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.invalidPut({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset + datasetId,
    			headers: config.headers,
    			body: body,
    		});
    	});
	}

	invalidUrlToUploadSchemaDataset = ({schemaId, body}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidPut({
				apiUrl: config.customeInvalidUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
				body: body,
			});
		});
	};

	invalidContentTypeToUploadSchemaDataset = ({schemaId, body}) =>{
    	return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.invalidPut({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.wrongContentTypeHeaders,
    			body: body,
    		});
    	});
	};

	invalidRequestDataForSchemaDataset = ({schemaId, body}) =>{
    	return cy.get('@datasetSetupConfig').then((config) => {
    		return this.api.invalidPost({
    			apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
    			headers: config.headers,
    			body: body,
    		});
    	});
	};

	emptyBodyToUploadSchemaDataset = ({schemaId, body}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidPut({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
				body: body,
			});
		});
	};

	emptySchemaIDToUploadSchemaDataset = ({schemaId, body}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidPut({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
				body: body,
			});
		});
	};

	getSchemaDataset = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.datasetCondition,
				headers: config.headers,
			});
		});
	};

	getDatasetWithMissingConditionSpace = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.invalidDatasetCondition,
				headers: config.headers,
			});
		});
	};

	getDatasetWithInvalidConditionValue = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.invalidDatasetConditionValue,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithPageNumberCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.pageNumberQueryParm,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithInvalidPageNumberCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.invalidPageNumberQueryParm,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithPageSizeCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.pageSizeQueryParm,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithInvalidPageSizeCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.invalidPageSizeQueryParm,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithPageSizeAndNumberCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.pageSizeAndNumberQueryParm,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithPageSizeAndInvalidPageNumberCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.invalidPageSizeAndNumberQueryParm,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithSortByCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.sortByQueryParm,
				headers: config.headers,
			});
		});
	};

	getSchemaDatasetWithInvalidSortByCondition = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.invalidSortByQueryParm,
				headers: config.headers,
			});
		});
	};

	invalidUrlGetSchemaDataset = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeInvalidUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
			});
		});
	};

	emptySchemaIDToGetSchemaDataset = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidGet({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
			});
		});
	};

	deleteSchemaDataset = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.deleteUrl({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
			});
		});
	};

	deleteSchemaDatasetWithID = ({schemaId, datasetId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.deleteUrl({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset + datasetId,
				headers: config.headers,
			});
		});
	};

	invalidUrlDeleteSchemaDataset = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidDelete({
				apiUrl: config.customeInvalidUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
			});
		});
	};

	emptySchemaIDToDeleteSchemaDataset = ({schemaId}) =>{
		return cy.get('@datasetSetupConfig').then((config) => {
			return this.api.invalidDelete({
				apiUrl: config.customeUploadSchemaUrl + schemaId + api.dataset,
				headers: config.headers,
			});
		});
	};
}
export default DatasetApi;