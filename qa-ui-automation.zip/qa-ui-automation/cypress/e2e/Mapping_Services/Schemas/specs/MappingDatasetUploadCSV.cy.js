import MappingDatasetUploadCSVHelper from '../api/helper/MappingDatasetUploadCSVHelper';

describe('GIVEN ', { tags: ['@Regression', '@MappingDataset', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var mappingDatasetUploadCSVHelper = new MappingDatasetUploadCSVHelper();

	context('WHEN Schema Dataset api send', { tags: ['@Dataset'] }, () => {

		mappingDatasetUploadCSVHelper.setupApiHooks();

		it('Upload dataset using csv file', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T39');
			mappingDatasetUploadCSVHelper.validateUploadDatasetUsingCSV();
		});

		it('CSV file should not be uploaded', ()=>{
			cy.allure().tms('CWMS-T40');
			mappingDatasetUploadCSVHelper.validateUploadDatasetUsingInvalidCSV();
		});

	});

});