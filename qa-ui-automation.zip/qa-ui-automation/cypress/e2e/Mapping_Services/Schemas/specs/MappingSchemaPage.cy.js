import MappingApplicationHelper from '../api/helper/MappingApplicationHelper';
import MappingSchemaPageHelper from '../UI/helper/MappingSchemaPageHelper';

describe('GIVEN ', { tags: ['@Regression', '@MappingSchamePage', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var mappingSchemaPageHelper = new MappingSchemaPageHelper();
	var mappingApplicationHelper = new MappingApplicationHelper();

	context('WHEN user on mapping schemas page', { tags: ['@Schema'] }, () => {

		mappingSchemaPageHelper.setupHook();
		mappingApplicationHelper.setupApiHooks();

		it('To validate schema grid which will have the available schema list', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T16');
			mappingSchemaPageHelper.validateSchemaGrid();
		});

		it('To validate breadcrumb for schemas page', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T47');
			mappingSchemaPageHelper.validateSchemaBreadcrumb();
		});

		it('To validate schema page with search, filter and pagination items', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T15');
			mappingSchemaPageHelper.validateSchemaPagination();
		});

		it('To validate schema should be available at schema grid table on UI once user will create new schema from backend API service.', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T21');
			mappingApplicationHelper.createNewV2Schema().then((response) => {
				const schemaName = response.body.name;
				const schemaId = response.body.id;
				mappingSchemaPageHelper.validateSearchAndClickAtSchema({schemaName: schemaName});
				mappingApplicationHelper.deleteSchema({schemaId: schemaId});
			});			
		});

		it('To validate partner should be able to see the dataset grid.', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T28');
			mappingApplicationHelper.createNewV2Schema().then((response) => {
				const schemaName = response.body.name;
				const schemaId = response.body.id;
				mappingSchemaPageHelper.validateSearchAndClickAtSchema({schemaName: schemaName});
				mappingApplicationHelper.deleteSchema({schemaId: schemaId});
			});			
		});

	});

});