import LookupHelper from '../api/helper/MappingLookupHelper';

describe('GIVEN ', { tags: ['@Regression', '@MappingLookup', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var lookupHelper = new LookupHelper();

	context('WHEN Mapping lookup api send', { tags: ['@lookup'] }, () => {

		lookupHelper.setupApiHooks();
	
		it('Lookup api with partner', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T13');
			lookupHelper.lookupApiWithPartner();
		});
		
		it('Lookup api with invalid request details', ()=>{
			cy.allure().tms('CWMS-T14');
			lookupHelper.validateInvalidLookupApi();
		});

		it('Lookup api with authorization', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T61');
			lookupHelper.lookupApiWithAuth();
		});		
    
	});

});