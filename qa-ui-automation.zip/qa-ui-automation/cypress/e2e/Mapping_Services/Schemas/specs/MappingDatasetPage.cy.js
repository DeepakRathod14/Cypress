import MappingApplicationHelper from '../api/helper/MappingApplicationHelper';
import MappingDatasetPageHelper from '../UI/helper/MappingDatasetPageHelper';

describe('GIVEN ', { tags: ['@Regression', '@MappingSchamePage', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var mappingDatasetPageHelper = new MappingDatasetPageHelper();
	var mappingApplicationHelper = new MappingApplicationHelper();

	context('WHEN user on mapping schemas page', { tags: ['@Schema'] }, () => {

		mappingDatasetPageHelper.setupHook();
		mappingApplicationHelper.setupApiHooks();

		it('To validate partner should be able to see the dataset grid.', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T28');
			mappingApplicationHelper.createNewV2Schema().then((response) => {
				const schemaName = response.body.name;
				const schemaId = response.body.id;
				mappingDatasetPageHelper.searchSchemaAndClickOnIt({schemaName: schemaName});
				mappingDatasetPageHelper.validateDatasetGrid();
				mappingApplicationHelper.deleteSchema({schemaId: schemaId});
			});			
		});

		it('To validate breadcrumb for dataset page.', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T48');
			mappingApplicationHelper.createNewV2Schema().then((response) => {
				const schemaName = response.body.name;
				const schemaId = response.body.id;
				mappingDatasetPageHelper.searchSchemaAndClickOnIt({schemaName: schemaName});
				mappingDatasetPageHelper.validateDatasetBreadcrumb();
				mappingApplicationHelper.deleteSchema({schemaId: schemaId});
			});			
		});

		it('To validate pagination on dataset grid page', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T59');
			mappingApplicationHelper.createNewV2Schema().then((response) => {
				const schemaName = response.body.name;
				const schemaId = response.body.id;
				mappingDatasetPageHelper.searchSchemaAndClickOnIt({schemaName: schemaName});
				mappingDatasetPageHelper.validateDatasetPagination();
				mappingApplicationHelper.deleteSchema({schemaId: schemaId});
			});			
		});

		it('To validate added info message as note at top of grid for source and target columns', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T59');
			mappingApplicationHelper.createNewV2Schema().then((response) => {
				const schemaName = response.body.name;
				const schemaId = response.body.id;
				mappingDatasetPageHelper.searchSchemaAndClickOnIt({schemaName: schemaName});
				mappingDatasetPageHelper.validateNoteSection();
				mappingApplicationHelper.deleteSchema({schemaId: schemaId});
			});			
		});

		it('To validate blank template button on dataset grid page', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T92');
			mappingApplicationHelper.createNewV2Schema().then((response) => {
				const schemaName = response.body.name;
				const schemaId = response.body.id;
				mappingDatasetPageHelper.searchSchemaAndClickOnIt({schemaName: schemaName});
				mappingDatasetPageHelper.validateBlankTemplateOption();
				mappingApplicationHelper.deleteSchema({schemaId: schemaId});
			});			
		});

	});

});