import MappingDatasetHelper from '../api/helper/MappingDatasetHelper';

describe('GIVEN ', { tags: ['@Regression', '@MappingDataset', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var mappingDatasetHelper = new MappingDatasetHelper();

	context('WHEN Schema Dataset api send', { tags: ['@Dataset'] }, () => {

		mappingDatasetHelper.setupApiHooks();

		it('Upload schema dataset api by using PUT api', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T2');
			mappingDatasetHelper.uploadSchemaDatasetApiWithPUT();
		});

		it('Upload schema dataset api by using POST api', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T37');
			mappingDatasetHelper.uploadSchemaDatasetApiWithPOST();
		});

		it('Upload dataset with condition', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T34');
			mappingDatasetHelper.uploadSchemaDataSetWithCondition();
		});

		it('Get schema dataset api', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T3');
			cy.allure().tms('CWMS-T17');
			cy.allure().tms('CWMS-T22');
			mappingDatasetHelper.getSchemaDatasetApi();
		});

		it('Get schema dataset with condition', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T18');
			mappingDatasetHelper.getDatasetWithCondition();
		});

		it('Get schema dataset with invalid condition', ()=>{
			cy.allure().tms('CWMS-T19');
			cy.allure().tms('CWMS-T20');
			mappingDatasetHelper.validateGetDatasetWithInvalidConditions();
		});

		it('Update the existing dataset details', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T29');
			cy.allure().tms('CWMS-T98');
			mappingDatasetHelper.validateUpdateDatasetDetails();

		});

		it('Dataset should not be update with invalid request', ()=>{
			cy.allure().tms('CWMS-T30');
			mappingDatasetHelper.validateInvalidUpdateDatasetDetails();
		});

		it('Delete schema dataset api', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T4');
			mappingDatasetHelper.deleteSchemaDatasetApi();
			cy.allure().tms('CWMS-T31');
			mappingDatasetHelper.deleteSchemaDatasetApiWithID();
		});

		it('Upload schema dataset should not be happen with invalid PUT api request', ()=>{
			cy.allure().tms('CWMS-T8');
			cy.allure().tms('CWMS-T36');
			mappingDatasetHelper.validateInvalidCreateDatasetPUTApi();
		});
		
		it('Upload schema dataset should not be happen with invalid POST api request', ()=>{
			cy.allure().tms('CWMS-T38');
			mappingDatasetHelper.validateInvalidUploadDatasetPOSTApi();
		});

		it('Get schema dataset response once user will enter invalid request', ()=>{
			cy.allure().tms('CWMS-T9');
			mappingDatasetHelper.validateInvalidGetSchemaDatasetApi();
		});

		it('Delete schema dataset response once user will enter invalid request', ()=>{
			cy.allure().tms('CWMS-T10');
			cy.allure().tms('CWMS-T32');
			mappingDatasetHelper.validateInvalidDeleteSchemaDatasetApi();
		});	

		it('Dataset API with pagination by using page number, size query parameter', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T46');
			cy.allure().tms('CWMS-T55');
			cy.allure().tms('CWMS-T56');
			cy.allure().tms('CWMS-T57');
			mappingDatasetHelper.validateGetDatasetApiWithQueryParameter();
		});

		it('GET dataset API with invalid query parameter', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T58');
			mappingDatasetHelper.validateGetDatasetApiWithInvalidQueryParameter();
		});

		it('Upload successfully with JSON body data (camel case, upper case, lower case)', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T49');
			mappingDatasetHelper.validateUploadDatasetWithDiffData();
		});
	});    
});