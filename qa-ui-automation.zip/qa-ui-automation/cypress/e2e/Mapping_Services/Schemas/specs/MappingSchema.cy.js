import MappingSchemaHelper from '../api/helper/MappingSchemaHelper';

describe('GIVEN ', { tags: ['@Regression', '@MappingSchema', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var mappingSchemaHelper = new MappingSchemaHelper();

	context('WHEN Mapping schema api send', { tags: ['@Schema'] }, () => {

		mappingSchemaHelper.setupApiHooks();

        
		it('Create new schema api', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T1');
			cy.allure().tms('CWMS-T99');
			mappingSchemaHelper.createSchemaApi();
		});

		it('Get schemas api', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T5');
			cy.allure().tms('CWMS-T24');
			mappingSchemaHelper.getSchemasApi();
		});

		it('Delete schema api', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T6');
			mappingSchemaHelper.deleteSchemaApi();
		});

		it('Schema should not be create with invalid request send to the create schema API', ()=>{
			cy.allure().tms('CWMS-T7');
			mappingSchemaHelper.validateInvalidCreateSchemaApi();
		});	 

		it('Schema should not get with invalid request send', ()=>{
			cy.allure().tms('CWMS-T11');
			mappingSchemaHelper.validateInvalidGetSchemasApi();
		});	

		it('Schema should not delete with invalid request send', ()=>{
			cy.allure().tms('CWMS-T12');
			mappingSchemaHelper.validateInvalidDeleteSchemaApi();
		});		

		it('Create new schema api by using v2', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T72');
			cy.allure().tms('CWMS-T100');
			mappingSchemaHelper.createSchemaApiUsingV2();
		});

		it('Get schemas api by using v2', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T73');
			mappingSchemaHelper.getSchemasApiUsingV2();
		});

		it('Delete schema api by using v2', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T74');
			mappingSchemaHelper.deleteSchemaApiUsingV2();
		});

		it('Schema with uppercase fields, attempt to perform dataset/lookup calls with lower case fields', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T76');
			mappingSchemaHelper.validateUppercaseLowsercaseSchemaApi();
		});

		it('Schema with lowercase fields, attempt to perform dataset/lookup calls with uppercase fields', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T77');
			mappingSchemaHelper.validateLowsercaseUppercaseSchemaApi();
		});

		it('Get expanded schemas api', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T106');
			mappingSchemaHelper.getExpandedSchemasApi();
		});

	});

});