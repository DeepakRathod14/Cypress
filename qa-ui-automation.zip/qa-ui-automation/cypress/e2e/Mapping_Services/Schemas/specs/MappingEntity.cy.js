
import EntityHelper from '../api/helper/MappingEntityHelper';

describe('GIVEN ', { tags: ['@Regression', '@MappingEntity', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var entityHelper = new EntityHelper();

	context('WHEN Mapping entity api send', { tags: ['@Entity'] }, () => {

		entityHelper.setupApiHooks();
	
		it('Post api should be create new entity', { tags: ['@Sanity'] }, ()=>{
			cy.allure().tms('CWMS-T78');
			cy.allure().tms('CWMS-T81');
			cy.allure().tms('CWMS-T84');
			entityHelper.validateMappingEntity();
		});
    
		it('Duplicate entity name error message and error code', ()=>{
			cy.allure().tms('CWMS-T79');
			cy.allure().tms('CWMS-T85');
			cy.allure().tms('CWMS-T86');
			entityHelper.validateInvalidEntityError();
		});

		it('Invalid entity creation error message and error code', ()=>{
			cy.allure().tms('CWMS-T80');
			entityHelper.validateInvalidEntityCreationError();
		});

	});

});