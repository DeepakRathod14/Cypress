import MappingApplicationHelper from '../api/helper/MappingApplicationHelper';

describe('GIVEN ', { tags: ['@Regression', '@MappingDataset', '@Mapping'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add Helpers here
	var mappingApplicationHelper = new MappingApplicationHelper();

	context('WHEN Schema Dataset api send', { tags: ['@Dataset'] }, () => {

		mappingApplicationHelper.setupApiHooks();

		it('Get dataset api from mapping application service', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T91');
			cy.allure().tms('CWMS-T104');
			cy.allure().tms('CWMS-T111');
			mappingApplicationHelper.validateGETSchemaDataset();
		});

		it('Get dataset api from mapping application service with invalid request', ()=>{
			cy.allure().tms('CWMS-T112');
			mappingApplicationHelper.validateInvalidGETSchemaDataset();
		});

		it('GET entities with connection for specific schema', {tags: ['@Sanity']}, ()=>{
			cy.allure().tms('CWMS-T94');
			cy.allure().tms('CWMS-T95');
			mappingApplicationHelper.validateSchemaEntities();
		});

	});

});