
import { CommonHelper } from '../../../../../fixtures';
import { moduleMetaData } from '../constants';
import { locator} from '../constants';
import '@cypress/xpath';


class MappingDatasetPageHelper extends CommonHelper{

	constructor() {
		super();
	}

	setupHook() {
		before(() => {
			this.setup(moduleMetaData);
		});
		beforeEach(() => {
			this.navigateToPageOnCheck(moduleMetaData.name);
			//cy.reload();
		});
	}

	searchSchemaAndClickOnIt({schemaName}){
		cy.reload();
		this.getElement(locator.searchTextbox).type(schemaName);
		cy.xpath(this.schemaXpath({schemaName: schemaName})).click();
	}

	validateDatasetBreadcrumb() {
		cy.xpath(locator.datasetPageTitle).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.datasetBreadCrumb)).should('be.visible');
	}

	validateNoteSection(){
		cy.xpath(locator.noteSection).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.noteInfoIcon)).should('be.visible');
		cy.xpath(locator.noteName).should('be.visible');
		cy.xpath(locator.noteMessage).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.noteCloseIcon)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.noteCloseIcon)).click();
	}

	validateDatasetGrid(){		
		this.getElement(this.wrapDataTestId(locator.datasetGrid)).should('be.visible');
		this.getElement(locator.searchTextbox).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.searchIcon)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.filterIcon)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.columnsIcon)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.densityIcon)).should('be.visible');
		cy.xpath(locator.addDataOption).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.addDataArrow)).should('be.visible');
		cy.xpath(locator.actionsColumn).should('be.visible');
	}

	validateBlankTemplateOption(){
		this.getElement(this.wrapDataTestId(locator.blankTemplateBtn)).should('be.visible');
	}

	validateDatasetPagination(){
		cy.xpath(locator.rowsPerPage).should('be.visible');
		this.getElement(locator.datasetPageRowsSelectionDropdown).should('be.visible');
		this.getElement(locator.rowsDisplayed).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.firstPageArrow)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.previousPageArrow)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.nextPageArrow)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.lastPageArrow)).should('be.visible');
	}

	schemaXpath({schemaName}){
		var nameLoc = '//a[contains(@href, "'+schemaName+'")]';
		return nameLoc;
	}
}
export default MappingDatasetPageHelper;