import { CommonHelper } from '../../../../../fixtures';
import { moduleMetaData } from '../constants';
import { locator} from '../constants';
import '@cypress/xpath';

class MappingSchemaPageHelper extends CommonHelper{

	constructor() {
		super();
	}

	setupHook() {
		before(() => {
			this.setup(moduleMetaData);
		});
		beforeEach(() => {
			this.navigateToPageOnCheck(moduleMetaData.name);
			//cy.reload();
		});
	}

	validateSchemaBreadcrumb() {
		cy.xpath(locator.schemaPageTitle).should('be.visible');
	}

	validateSchemaGrid() {
		this.getElement(this.wrapDataTestId(locator.schemaGrid)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.searchIcon)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.filterIcon)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.columnsIcon)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.densityIcon)).should('be.visible');
		cy.xpath(locator.nameColumn).should('be.visible');
		cy.xpath(locator.descriptionColumn).should('be.visible');
		cy.xpath(locator.createdAtColumn).should('be.visible');
		cy.xpath(locator.typeColumn).should('be.visible');
	}

	validateSchemaPagination(){
		cy.xpath(locator.rowsPerPage).should('be.visible');
		this.getElement(locator.rowsSelectionDropdown).should('be.visible');
		this.getElement(locator.rowsDisplayed).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.firstPageArrow)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.previousPageArrow)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.nextPageArrow)).should('be.visible');
		this.getElement(this.wrapDataTestId(locator.lastPageArrow)).should('be.visible');
	}

	validateSearchAndClickAtSchema({schemaName}){
		cy.reload();
		this.getElement(locator.searchTextbox).type(schemaName);
		cy.xpath(this.schemaXpath({schemaName: schemaName})).click();
	}

	validateDatasetGrid({schemaName}){
		cy.reload();
		this.getElement(locator.searchTextbox).type(schemaName);
		cy.xpath(this.schemaXpath({schemaName: schemaName})).click();
		this.getElement(this.wrapDataTestId(locator.datasetGrid)).should('be.visible');
	}

	schemaXpath({schemaName}){
		var nameLoc = '//a[contains(@href, "'+schemaName+'")]';
		return nameLoc;
	}
}
export default MappingSchemaPageHelper;