export const moduleMetaData = {
	name: 'Mapping', // for redirecting mapping home page
	//customUser: 'user_mapping' //for login custome credentials
	customUser: 'user_default'
};

export const locator = {
	'schemaPageTitle' : '//h4[contains(text(),"Data Mapping")]',
	'schemaGrid' : 'schema-grid',
	'searchIcon': 'SearchIcon',
	'filterIcon': 'FilterAltOutlinedIcon',
	'columnsIcon': 'ViewColumnOutlinedIcon',
	'densityIcon': 'density-selector',
	'searchTextbox': 'input[placeholder="Search input placeholder"]',
	'nameColumn': '//div[@role="columnheader" and @data-field="name"]',
	'descriptionColumn': '//div[@role="columnheader" and @data-field="description"]',
	'createdAtColumn': '//div[@role="columnheader" and @data-field="createdAt"]',
	'typeColumn': '//div[@role="columnheader" and @data-field="type"]',
	//'schemaName': '//a[contains(@href, "CWRMMToCWPSABoardMapping-V24")]',
	//'schemaNameLoc': '//div[@role="cell" and @data-field="name"]',
	'rowsPerPage': '//*[text()="Rows per page:"]',
	'rowsSelectionDropdown': 'div#mui-12',
	'rowsDisplayed': '.MuiTablePagination-displayedRows',
	'firstPageArrow': 'first-page',
	'lastPageArrow': 'last-page',
	'previousPageArrow': 'previous-page',
	'nextPageArrow': 'next-page',

	// Dataset Page
	'datasetPageTitle' : '//*[contains(text(),"Mapped Data")]',
	'datasetBreadCrumb' : 'breadcrumbs',
	'datasetGrid' : 'dataset-grid',
	'datasetPageRowsSelectionDropdown': 'div#mui-51',
	'blankTemplateBtn' : 'blank_template_button',
	'addDataOption' : '//*[contains(text(),"Add Data")]',
	'addDataArrow' : 'upload-data-icon-click',
	'actionsColumn': '//div[@role="columnheader" and @data-field="actions"]',
	'noteSection' : '//*[@role="alert"]',
	'noteInfoIcon' : 'info-icon',
	'noteName' : '//*[contains(text(),"Note")]',
	'noteMessage' : '//*[contains(text(),"The mapping records below have the")]',
	'noteCloseIcon' : 'CloseIcon'

};