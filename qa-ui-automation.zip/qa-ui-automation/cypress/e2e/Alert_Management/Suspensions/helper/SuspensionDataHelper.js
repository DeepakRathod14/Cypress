import { CommonHelper } from '../../../../fixtures';

class SuspensionDataHelper {

	constructor() {
		this.commonHelper = new CommonHelper();
	}

	generateBaseData() {
		this.testData = {
			suspensionName: this.commonHelper.getFakeName(),
			suspensionDescription: this.commonHelper.getFakeDescription(),
		};

		return this;
	}

	getData() {
		return this.testData;
	}

	setData(testData) {
		this.testData = testData;
	}
}

export default SuspensionDataHelper;