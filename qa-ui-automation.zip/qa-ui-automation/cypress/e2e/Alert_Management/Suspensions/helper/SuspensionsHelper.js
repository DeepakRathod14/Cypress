import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper, ResourceSelectorHelper, ToastHelper } from '../../../../fixtures';
// Added the ModuleMetaData here in the below import part.
import { moduleMetaData, lct, txt, atr } from './constants';
import SuspensionDataHelper from './SuspensionDataHelper';

class SuspensionsHelper extends CommonHelper {

	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.resourceSelectorHelper = new ResourceSelectorHelper();
		this.toast = new ToastHelper();
		this.dataHelper = new SuspensionDataHelper();
	}

	getAddRuleButton = () => {
		const dataTestId = this.wrapDataTestId(lct.addRuleButton);
		return this.getElement(dataTestId);
	}

	clickAddRuleButton = () => {
		return this.getAddRuleButton().click();
	}

	getSearchIcon = () => {
		const dataTestId = this.wrapDataTestId(lct.searchIcon);
		return this.getElement(dataTestId);
	}

	clickSearchIcon = () => {
		return this.getSearchIcon().click();
	}

	getFilterIcon = () => {
		const dataTestId = this.wrapDataTestId(lct.filterIcon);
		return this.getElement(dataTestId);
	}

	getToggleColumnIcon = () => {
		const dataTestId = this.wrapDataTestId(lct.toggleColumnIcon);
		return this.getElement(dataTestId);
	}

	clickToggleColumnIcon = () => {
		return this.getToggleColumnIcon().click();
	}

	shouldMetaDataCardExist = () => {
		const dataTestId = this.wrapDataTestId(lct.metaDataCard);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	getChangeViewIcon = () => {
		const dataTestId = this.wrapDataTestId(lct.changeViewIcon);
		return this.getElement(dataTestId);
	}

	clickChangeViewIcon = () => {
		return this.getChangeViewIcon().click();
	}

	getDownloadIcon = () => {
		return this.getElement(lct.downloadIcon);
	}

	clickDownloadIcon = () => {
		return this.getDownloadIcon().click();
	}

	getHeaderCheckboxIcon = () => {
		return this.getElement(lct.headerCheckboxIcon);
	}

	checkHeaderCheckboxIcon = () => {
		return this.getHeaderCheckboxIcon().check();
	}

	getDeleteButton = () => {
		const dataTestId = this.wrapDataTestId(lct.deleteButton);
		return this.getElement(dataTestId);
	}

	getDeleteConfirmButton = () => {		
		return this.getElement(lct.deleteConfirmButton);
	}

	clickDeleteButton = () => {
		return this.getDeleteButton().click();
	}

	clickDeleteConfirmButton = () => {
		return this.getDeleteConfirmButton().click();
	}

	getSelectedRowCount = () => {
		return this.getElement(lct.selectedRowCount);
	}

	getTotalRowCount = () => {
		return this.getElement(lct.totalRowCount);
	}

	getSuspensionBreadcrumb = () => {
		return this.getElement(lct.suspensionBreadcrumb);
	}

	clickSuspensionBreadcrumb = () => {
		return this.getSuspensionBreadcrumb().click();
	}

	getBackButton = () => {
		return this.getElement(lct.backButton);
	}

	clickBackButton = () => {
		return this.getBackButton().click();
	}

	getSaveButton = () => {
		const dataTestId = this.wrapDataTestId(lct.saveButton);
		return this.getElement(dataTestId);
	}

	clickSaveButton = () => {
		return this.getSaveButton().click();
	}

	getDuplicateButton = () => {
		return this.getElement(lct.duplicateButton);
	}

	clickDuplicateButton = () => {
		return this.getDuplicateButton().click();
	}

	checkMetaDataCardExist = () => {		
		return this.getElementWithAssertion(lct.suspensionMetadataCard, 'exist');
	}

	checkMetaDataCardData = (suspensionName) => {
		const dataTestId = this.wrapDataTestId(lct.suspensionMetadataCardTitle);
		return this.getElementWithTextAndAssertion(dataTestId, suspensionName, 'exist');
	}

	getGridRow = () => {
		return this.getElement(lct.gridRow);
	}

	clickGridRow = () => {
		return this.getGridRow().click();
	}

	getList = () => {
		return this.getElement(lct.list);
	}

	searchInGrid = (suspensionName) => {
		return this.getElement(lct.formInput).type(suspensionName);
	}

	getGridCell = () => {
		return this.getElement(lct.gridCell);
	}

	getColumnHeaders = (gridColumnHeadersLocator) => {
		return this.getElement(gridColumnHeadersLocator);
	}

	validateFirstRowExists = () => {
		return this.gridHelper.validateFirstRowExists(lct.gridRow);
	}

	validateLastRowExists = (gridVirtualScrollerLocator, gridRowLocator) => {
		return this.gridHelper.validateLastRowExists(gridVirtualScrollerLocator, gridRowLocator);
	}

	getRowCheckbox = (rowInputLocator) => {
		return this.gridHelper.getRowCheckbox(rowInputLocator);
	}

	selectRowByIndex = (gridRowLocator, index) => {
		return this.gridHelper.selectRowByIndex(gridRowLocator, index);
	}

	getRowByIndex = (index) => {
		return this.gridHelper.getRowByIndex(lct.gridRow, index);
	}

	getColumnHeaders = () => {
		return this.getElement(lct.gridColumnHeaders);
	}

	filterColumn = (buttonLocator, nativeSelectLocator, columnName, operator, value) => {
		return this.gridHelper.filterColumn(buttonLocator, nativeSelectLocator, columnName, operator, value);
	}

	sortColumn = (columnIndex) => {
		return this.gridHelper.sortColumn(lct.selectColumn, columnIndex);
	}

	hideColumn = (columnIndex) => {
		return this.gridHelper.hideColumn(lct.hideColumnSelector, columnIndex);
	}

	changeView = (index) => {
		return this.gridHelper.changeGridView(lct.gridRow, index);
	}

	selectDropdownValue = (dropdownSelector, index, value) => {
		return this.dropdownHelper.selectDropdownValue(dropdownSelector, index, value);
	}

	getMetadataCard = () => {
		const dataTestId = this.wrapDataTestId(lct.metadatacard);
		return this.getElement(dataTestId);
	}

	getNameField = () => {
		return this.getElementWithIndex(lct.formBaseInput, 0);
	}


	nameFieldShouldExist = () => {
		return this.getElementWithIndexAndAssertion(lct.formBaseInput, 0, 'exist');
	}

	getDescriptionField = () => {
		const dataTestId = this.wrapDataTestId(lct.description);
		return this.getElement(dataTestId);
	}

	typeName = (suspensionName) => {
		return this.getNameField().type(suspensionName);
	}

	typeDescription = (suspensionDescription) => {
		return this.getDescriptionField().type(suspensionDescription);
	}

	typeDateField = () => {
		const randomDate = this.getFakeDate();
		const formattedDate = `${(randomDate.getMonth() + 1)
			.toString().padStart(2, '0')}${(randomDate.getDate())
			.toString().padStart(2, '0')}${randomDate.getFullYear()}T${randomDate.getHours().toString().padStart(2, '0')}${randomDate.getMinutes().toString().padStart(2, '0')}`;
		return this.getElement(lct.dateElement).eq(0).type(formattedDate, { force: true });
	}

	selectResource = () => {
		return this.resourceSelectorHelper.selectFirstResource(lct.gridRow);
	}

	selectAlert = () => {
		return this.resourceSelectorHelper.selectFirstResource(lct.gridRow);
	}

	clickSelectTargetsButton = () => {
		const dataTestId = this.wrapDataTestId(lct.selectTarget);
		return this.buttonHelper.clickButton(dataTestId);
	}

	clickSelectAlertButton = () => {
		const dataTestId = this.wrapDataTestId(lct.selectAlert);
		return this.buttonHelper.clickButton(dataTestId);
	}

	getSelectAlertTypography = () => {
		const dataTestId = this.wrapDataTestId(lct.selectAlertTypography);
		return this.getElement(dataTestId);
	}
	
	getResourceSelectorTypography = () => {
		return this.getElement(lct.resourceSelectorTypography);
	}

	clickResourceSelectorButton = (index) => {
		return this.getElement(lct.resourceSelectorActions)
			.find(lct.buttonBaseRoot)
			.eq(index)
			.click();
	}

	clickSelectAlertSaveButton = () => {
		const dataTestId = this.wrapDataTestId(lct.saveSelectedAlertButton);
		return this.buttonHelper.clickButton(dataTestId);
	}

	validateErrorToastMessage = () => {
		this.toast
			.checkToastIsVisibleWithText(
				lct.toast,
				txt.errorMessage
			);
		this.toast
			.checkToastAttributeAndIcon(
				lct.toast,
				this.wrapDataTestId(lct.errorIcon),
				atr.errorColor,
			);
	}

	validateSuccessToastMessage = () => {
		this.toast
			.checkToastIsVisibleWithText(
				lct.toast,
				txt.successMessage
			);
		this.toast
			.checkToastAttributeAndIcon(
				lct.toast,
				this.wrapDataTestId(lct.successIcon),
				atr.successColor,
			);
	}

	selectRuleType = (index) => {
		return this.getElement(lct.ruleTypeSelector).eq(index).click();
	}

	// Here on the Functions for the Suspension per site leves are added.

	setupHooksSuspensionPerCompany() {
		beforeEach(() => {
			cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');			
			this.initialLandingSetupSuspensionPerCompany();
		});
	}

	setupHooksSuspensionPerSite() {
		beforeEach(() => {
			cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
			this.initialLandingSetupSuspensionPerSite();
		});
	}

	setupHooks() {
		beforeEach(() => {
			cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
			this.initialLandingSetupSuspension();
		});
	}

	clickSuspension = (name) => {
		this.buttonHelper.clickButtonWithText(lct.suspensionName, name);
	}

	clickSuspensionforMetadata = () => {
		this.buttonHelper.clickButtonWithIndex(lct.suspensionNameCellforMetadata, 0);
	}

	pageTitleToBeVisible = (pageTitle) => {		
		this.getElementWithTextAndAssertion(lct.pageTitle, pageTitle, 'be.visible');
	}

	initialLandingSetupSuspensionPerSite() {
		this.navigateToPageOnCheck(moduleMetaData.namePerSite);
		var companyName;
		cy.get('@alert-data').then((data) => {			
			companyName = data['Monitor.CompanyName'];
			this.clickCompany(companyName);
			this.clickSite();
		});		
		this.clickMonitoringTab();
	}

	initialLandingSetupSuspension() {
		this.navigateToPageOnCheck(moduleMetaData.name);		
	}

	initialLandingSetupSuspensionPerCompany() {
		this.navigateToPageOnCheck(moduleMetaData.namePerSite);
		var companyName;
		cy.get('@alert-data').then((data) => {
			companyName = data['Monitor.CompanyName'];
			this.clickCompany(companyName);
		});		
		this.clickMonitoringTabForCompany();
	}

	clickCompany = (name) => {
		cy.contains(name).click();
	}

	clickSite = () => {		
		this.getElementWithIndex(lct.siteName, 1).click();
	}

	clickMonitoringTab = () => {
		cy.get(lct.monitorTab).click();
	}

	clickMonitoringTabForCompany = () => {
		cy.get(lct.monitorTabForCompany).click();
	}

	CheckAndNavigateToSuspensionTab() {
		this.checkSuspensionTabIsVisible();
		this.clickSuspensionTab('Suspensions');
	}

	checkSuspensionTabIsVisible = () => {
		this.checkElementIsVisibleWithText(lct.suspensionTab, 'Suspensions');
	}

	clickSuspensionTab = (tabName) => {
		this.buttonHelper.clickButtonWithText(lct.suspensionTab, tabName);
	}

	typeValue = (Value) => {
		return cy.get(lct.txtValue).type(Value);
	}

	CreateSuspensionAtSiteLevel = (suspensionName, suspensionDescription) => {
		this.navigateToPageOnCheck(moduleMetaData.name);
		this.clickAddRuleButton();
		this.ClickOnCustomAlertsButton();
		this.typeName(suspensionName);
		this.typeDescription(suspensionDescription);
		this.clickSelectTargetsButton();
		this.checkInputButtonUsingLabel(lct.radioSelectionType, 'Sites');
		var siteName;
		cy.get('@alert-data').then((data) => {
			siteName = data['Monitor.SiteName'];
			this.searchAndSelectSite(siteName);		
		});		
		this.checkSearchedSite(lct.chkboxSelectTargetEndpoint);
		this.clickSaveSelectionButton();
		this.SelectSchedule();
		this.SelectSuspendedAlerts();
		this.clickSaveButton();
	}

	CreateSuspensionAtCompanyLevel = (suspensionName, suspensionDescription) => {
		this.navigateToPageOnCheck(moduleMetaData.name);
		this.clickAddRuleButton();
		this.ClickOnCustomAlertsButton();
		this.typeName(suspensionName);
		this.typeDescription(suspensionDescription);
		this.clickSelectTargetsButton();
		this.checkInputButtonUsingLabel(lct.radioSelectionType, 'Companies');
		var companyName;
		cy.get('@alert-data').then((data) => {			
			companyName = data['Monitor.CompanyName'];
			this.searchAndSelectCompany(companyName);
		});
		
		this.checkSearchedSite(lct.chkboxSelectTargetEndpoint);
		this.resourceSelectorHelper.saveResources();
		this.SelectSchedule();
		this.SelectSuspendedAlerts();
		this.clickSaveButton();
	}

	ClickOnCustomAlertsButton = () => {
		this.selectRuleType(0);
	}

	ClickOnIntelligentAlertsButton = () => {
		this.selectRuleType(-1);
	}

	checkInputButtonUsingLabel = (labelSelector, label) => {
		return this.getElement(labelSelector).contains(label).click();
	}

	searchAndSelectSite = (siteName) => {
		this.clickSearchIconWithIndex(1);
		this.searchSiteInGrid(siteName);
	}

	searchAndSelectCompany = (companyName) => {
		this.clickSearchIconWithIndex(1);
		this.searchSiteInGrid(companyName);
	}

	clickSearchIconWithIndex = (index) => {
		return this.getSearchIconWithIndex(index).click();
	}

	getSearchIconWithIndex = (searchIndex) => {
		const dataTestId = this.wrapDataTestId(lct.searchIcon);
		return this.getElementWithIndex(dataTestId, searchIndex);
	}

	searchSiteInGrid = (searchString) => {
		return this.getElement(lct.txtSearchSite).type(searchString);
	}

	checkSearchedSite = (siteSelector) => {
		cy.wait(500);
		this.getElement(siteSelector).click({ force: true });
	}

	clickSaveSelectionButton = () => {
		this.resourceSelectorHelper.saveResources();
	}

	SelectSchedule = () => {
		cy.get(lct.ddListTimeZone).type('(UTC-12:00) Etc/GMT+12{downArrow}{enter}');
		cy.wait(5000);
		cy.get(lct.ddListScheduleAt).eq(0).click();
		cy.get(lct.listScheduleAt).contains('Now').click();
		cy.get(lct.ddListScheduleAt).eq(1).click();
		cy.get(lct.listScheduleAt).contains('Never').click();
	}

	SelectSuspendedAlerts = () => {
		this
			.getSelectAlertTypography()
			.invoke('text')
			.as('initialText1')
			.then((initialText1) => {
				cy.log('Initial text is : ', initialText1);				
				this.clickSelectAlertButton();
				this
					.getSelectAlertTypography()
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						this.selectAlert();
						this
							.getSelectAlertTypography()
							.invoke('text')
							.should('not.equal', initialText);
					});
				this.clickSelectAlertSaveButton();
			});
	}

	createSuspensionTestDataBasedOnType(type) {
		let testData;

		switch (type) {
			case txt.suspensionPerSite:
				testData = this.dataHelper
					.generateBaseData()
					.getData();
				break;
			case txt.suspensionPerCompany:
				testData = this.dataHelper
					.generateBaseData()
					.getData();
				break;
			default:
				testData = this.dataHelper
					.generateBaseData()
					.getData();
		}

		this.setData(testData);
	}

	setData(testData) {
		this.testData = testData;
	}

	getData() {
		return this.testData;
	}

	enterSuspensionName(name) {
		this.inputFieldHelper
			.typeIntoInputField(this.wrapDataTestId(lct.formBaseInput), name);
	}

	enterSuspensionDescription(description) {
		this.inputFieldHelper
			.typeIntoInputField(this.wrapDataTestId(lct.description), description);
	}

	selectSuspensionCheckbox() {
		this.selectAlert();
		cy.wait(5000);
	}

	clickFilterIcon = () => {
		return this.getFilterIcon().click();
	}

	clickOnFirstSuspensionForEdit() {
		this.buttonHelper.clickButtonWithIndex(this.wrapDataTestId(lct.SuspensionName), 0);
	}

	checkSuspensionsListingBreadcrumbIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(lct.SuspensionsListingBreadcrumb));
	}

	checkEndpointsTextIsVisibleInBreadcrumbSuspensionsListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(lct.EndpointsTextInBreadcrumb), 'Endpoints');
	}

	checkAlertsTextIsVisibleInBreadcrumbSuspensionsListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(lct.AlertsTextInBreadcrumb), 'Alerts');
	}

	checkSuspensionsTextIsVisibleInBreadcrumbSuspensionsListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(lct.SuspensionsTextInBreadcrumb), 'Suspensions');
	}

	checkEditSuspensionBreadcrumbIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(lct.EditSuspensionBreadcrumb));
	}

	clickSuspensionsLinkInBreadcrumb() {
		this.buttonHelper.clickButtonWithWait(this.wrapDataTestId(lct.SuspensionsBreadcrumbLink), 5);
	}
}

export default SuspensionsHelper;
