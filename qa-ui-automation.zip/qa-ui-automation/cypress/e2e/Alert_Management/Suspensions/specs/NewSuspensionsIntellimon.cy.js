import SuspensionsHelper from '../helper/SuspensionsHelper';
import { envTag } from '../../../../constants';
import { txt } from '../helper/constants';


describe(
	'GIVEN Add Suspensions Page for Intellimon Alert',
	{ tags: ['@Suspensions', '@MUI'] },
	() => {
		var suspensionsHelper = new SuspensionsHelper();
		suspensionsHelper.createSuspensionTestDataBasedOnType(txt.suspensionPerCompany);
		const { suspensionName, suspensionDescription } = suspensionsHelper.getData();
		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {
			suspensionsHelper.setupHooks();

			it('Should Open New Suspension Page for Add Rule Button', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7423');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.pageTitleToBeVisible('New Suspension');
			});

			it('Should Have Suspension Metadata Card', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7424');
				suspensionsHelper.clickSuspensionforMetadata();
				suspensionsHelper.checkMetaDataCardExist();
			});

			it('Should Add Suspension Name Field', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7425');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.typeName(suspensionName);
			});

			it('Should Add Description Field', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7426');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.typeName(suspensionName);
				suspensionsHelper.getDescriptionField().should('exist');
				suspensionsHelper.typeDescription(suspensionDescription);
			});

			it('Should Delete Selected Resource on Cancel', function () {
				cy.allure().tms('ALERT-T7427');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.typeName(suspensionName);
				suspensionsHelper.getDescriptionField().should('exist');
				suspensionsHelper.typeDescription(suspensionDescription);
				suspensionsHelper
					.getResourceSelectorTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						suspensionsHelper.clickSelectTargetsButton();
						suspensionsHelper
							.getResourceSelectorTypography()
							.invoke('text')
							.as('initialText')
							.then((initialText) => {
								suspensionsHelper.selectResource();
								suspensionsHelper
									.getResourceSelectorTypography()
									.invoke('text')
									.should('not.equal', initialText);
							});
						suspensionsHelper.clickResourceSelectorButton(0);

						suspensionsHelper
							.getResourceSelectorTypography()
							.invoke('text')
							.should('equal', initialText1);
					});
			});

			it('Should Save Selected Resource on Save', function () {
				cy.allure().tms('ALERT-T7428');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.typeName(suspensionName);
				suspensionsHelper.getDescriptionField().should('exist');
				suspensionsHelper.typeDescription(suspensionDescription);
				suspensionsHelper.getResourceSelectorTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						suspensionsHelper.clickSelectTargetsButton();
						suspensionsHelper.getResourceSelectorTypography()
							.invoke('text')
							.as('initialText')
							.then((initialText) => {
								suspensionsHelper.selectResource();
								suspensionsHelper.getResourceSelectorTypography()
									.invoke('text')
									.should('not.equal', initialText);
							});
						suspensionsHelper.clickResourceSelectorButton(1);
						suspensionsHelper.getResourceSelectorTypography()
							.invoke('text')
							.should('not.equal', initialText1);
					});
			});

			//   It.skip("Should Add Schedule Field", function () {
			//     Cy.get('.MuiPaper-root.css-bqb0mx').should("exist");
			//     Cy.get('.MuiFormControl-root.css-8vgkqp').click().type('(UTC-12:00) Etc/GMT+12{enter}');
			//     Cy.get('.MuiButtonBase-root.css-1ibrj8s').click();
			//     Cy.wait(1000);
			//     Cy.get('.MuiSelect-select.css-1eqswf6').eq(0).click()
			//     Cy.get('.MuiList-root.css-1ce435n').children('.MuiButtonBase-root.css-1scnr0o').eq(0).click();
			// });

			it('Should select Alerts', function () {
				cy.allure().tms('ALERT-T7429');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.typeName(suspensionName);
				suspensionsHelper.getDescriptionField().should('exist');
				suspensionsHelper.typeDescription(suspensionDescription);
				suspensionsHelper
					.getSelectAlertTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						suspensionsHelper.clickSelectAlertButton();
						suspensionsHelper
							.getSelectAlertTypography()
							.invoke('text')
							.as('initialText')
							.then((initialText) => {
								suspensionsHelper.selectAlert();
								suspensionsHelper
									.getSelectAlertTypography()
									.invoke('text')
									.should('not.equal', initialText);
							});
						suspensionsHelper.clickSelectAlertSaveButton();
						suspensionsHelper
							.getSelectAlertTypography()
							.invoke('text')
							.should('not.equal', initialText1);
					});
			});

			it('Should Save Suspension', function () {
				cy.allure().tms('ALERT-T7430');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.typeName(suspensionName);
				suspensionsHelper.getDescriptionField().should('exist');
				suspensionsHelper.typeDescription(suspensionDescription);
				suspensionsHelper.getResourceSelectorTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						suspensionsHelper.clickSelectTargetsButton();
						suspensionsHelper.getResourceSelectorTypography()
							.invoke('text')
							.as('initialText')
							.then((initialText) => {
								suspensionsHelper.selectResource();
								suspensionsHelper.getResourceSelectorTypography()
									.invoke('text')
									.should('not.equal', initialText);
							});
						suspensionsHelper.clickResourceSelectorButton(1);
						suspensionsHelper.getResourceSelectorTypography()
							.invoke('text')
							.should('not.equal', initialText1);
					});

				suspensionsHelper
					.getSelectAlertTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						suspensionsHelper.clickSelectAlertButton();
						suspensionsHelper
							.getSelectAlertTypography()
							.invoke('text')
							.as('initialText')
							.then((initialText) => {
								suspensionsHelper.selectAlert();
								suspensionsHelper
									.getSelectAlertTypography()
									.invoke('text')
									.should('not.equal', initialText);
							});
						suspensionsHelper.clickSelectAlertSaveButton();
						suspensionsHelper
							.getSelectAlertTypography()
							.invoke('text')
							.should('not.equal', initialText1);
					});
				suspensionsHelper.SelectSchedule();
				suspensionsHelper.clickSaveButton();				
			});
		});
	}
);
