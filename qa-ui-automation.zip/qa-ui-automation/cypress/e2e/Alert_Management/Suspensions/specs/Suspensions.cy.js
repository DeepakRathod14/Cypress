import SuspensionsHelper from '../helper/SuspensionsHelper';
import { envTag } from '../../../../constants';
import { lct } from '../helper/constants';

describe(
	'GIVEN Suspensions Landing Page',
	{ tags: ['@Suspensions', '@MUI'] },
	() => {
		var suspensionsHelper = new SuspensionsHelper();


		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {
			suspensionsHelper.setupHooks();

			it('Should Click Add Rule Button', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7403');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.pageTitleToBeVisible('New Suspension');
			});

			it('Should Filter value', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {				
				cy.allure().tms('ALERT-T7404');
				// Added Comment for filter values
				suspensionsHelper.clickFilterIcon();
				suspensionsHelper.selectDropdownValue(
					lct.selectListContains,
					0,
					'Status'
				);
				suspensionsHelper.selectDropdownValue(
					lct.selectListOperator,
					0,
					'equals'
				);
				suspensionsHelper.typeValue('Active');				
				suspensionsHelper.getGridCell()
					.should('exist') // Ensure that at least one cell exists
					.each((cell) => {
						cy.wrap(cell)
							.invoke('text')
							.then((cellText) => {
								expect(cellText).to.include('Active');
							}
							);
					});
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.pageTitleToBeVisible('New Suspension');
			});

			it('Should Search in grid', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () { 
				cy.allure().tms('ALERT-T7405');
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid('Active');
				suspensionsHelper.getGridCell()
					.should('exist') // Ensure that at least one cell exists
					.each((cell) => {
						cy.wrap(cell)
							.invoke('text')
							.then((cellText) => {
								expect(cellText).to.include('Active');
							}
							);
					});
			});

			it('Should Sort Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7406');
				suspensionsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						suspensionsHelper.validateFirstRowExists();
						suspensionsHelper.sortColumn(5);
						suspensionsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Should Hide Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7407');
				suspensionsHelper.getColumnHeaders()
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						suspensionsHelper.clickToggleColumnIcon();
						suspensionsHelper.hideColumn(3);
						suspensionsHelper.getColumnHeaders()
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Should Change View ', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7408');
				suspensionsHelper.clickChangeViewIcon();
				suspensionsHelper.getList().children().eq(1).click();
				suspensionsHelper.changeView(1);
			});

			it('Verify breadcrumbs is displayed on Suspensions listing page', { tags: [envTag.Regression] }, function () {
				cy.allure().tms('ALERT-T7490');
				suspensionsHelper.checkSuspensionsListingBreadcrumbIsVisible();
			});

			it('Verify text of breadcrumbs displayed is correct on Suspensions listing page', { tags: [envTag.Regression] }, function () {
				cy.allure().tms('ALERT-T7492');
				suspensionsHelper.checkEndpointsTextIsVisibleInBreadcrumbSuspensionsListing();
				suspensionsHelper.checkAlertsTextIsVisibleInBreadcrumbSuspensionsListing();
				suspensionsHelper.checkSuspensionsTextIsVisibleInBreadcrumbSuspensionsListing();
			});

			it('Verify clicking suspensions breadcrumbs link navigates to listing page.', { tags: [envTag.Regression] }, function () {
				cy.allure().tms('ALERT-T7494');
				suspensionsHelper.clickOnFirstSuspensionForEdit();
				suspensionsHelper.checkEditSuspensionBreadcrumbIsVisible();
				suspensionsHelper.clickSuspensionsLinkInBreadcrumb();
				suspensionsHelper.checkSuspensionsListingBreadcrumbIsVisible();
			});
		});
	}
);
