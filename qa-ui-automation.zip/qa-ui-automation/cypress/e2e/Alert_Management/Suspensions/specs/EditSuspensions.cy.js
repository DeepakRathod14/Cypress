import SuspensionsHelper from '../helper/SuspensionsHelper';
import { envTag } from '../../../../constants';
import { txt } from '../helper/constants';

describe(
	'GIVEN Edit Suspensions Page',
	{ tags: ['@Suspensions', '@MUI'] },
	() => {
		var suspensionsHelper = new SuspensionsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {			
			suspensionsHelper.setupHooks();
			suspensionsHelper.createSuspensionTestDataBasedOnType(txt.suspensionPerCompany);
			const { suspensionName, suspensionDescription } = suspensionsHelper.getData();

			it('Should Save Suspension', function () {
				cy.allure().tms('ALERT-T7409');
				suspensionsHelper.clickAddRuleButton();
				suspensionsHelper.selectRuleType(1);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.typeName(suspensionName);
				suspensionsHelper.getDescriptionField().should('exist');
				suspensionsHelper.typeDescription(suspensionDescription);
				suspensionsHelper.getResourceSelectorTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						suspensionsHelper.clickSelectTargetsButton();
						suspensionsHelper.getResourceSelectorTypography()
							.invoke('text')
							.as('initialText')
							.then((initialText) => {
								suspensionsHelper.selectResource();
								suspensionsHelper.getResourceSelectorTypography()
									.invoke('text')
									.should('not.equal', initialText);
							});
						suspensionsHelper.clickResourceSelectorButton(1);
						suspensionsHelper.getResourceSelectorTypography()
							.invoke('text')
							.should('not.equal', initialText1);
					});

				suspensionsHelper
					.getSelectAlertTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						suspensionsHelper.clickSelectAlertButton();
						suspensionsHelper
							.getSelectAlertTypography()
							.invoke('text')
							.as('initialText')
							.then((initialText) => {
								suspensionsHelper.selectAlert();
								suspensionsHelper
									.getSelectAlertTypography()
									.invoke('text')
									.should('not.equal', initialText);
							});
						suspensionsHelper.clickSelectAlertSaveButton();
						suspensionsHelper
							.getSelectAlertTypography()
							.invoke('text')
							.should('not.equal', initialText1);
					});
				suspensionsHelper.SelectSchedule();
				suspensionsHelper.clickSaveButton();				
			});

			it('Should Open Edit Suspension Page for a suspension', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {				
				cy.allure().tms('ALERT-T7410');
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper.pageTitleToBeVisible('Edit Suspension');
			});

			it('Should Have Suspension Metadata Card', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7411');
				suspensionsHelper.clickSuspensionforMetadata();
				suspensionsHelper.checkMetaDataCardExist();
			});

			it('Should Have Suspension Name Field as Not Empty', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7412');
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.getNameField().should('not.have.value', '');
			});

			it('Should Have Resource Selected', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7413');
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);

				suspensionsHelper
					.getResourceSelectorTypography()
					.should('not.have.text', '00');
			});

			it('Should Have Alert Selected', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7414');
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper
					.getSelectAlertTypography()
					.should('not.have.text', 'No Selection');
			});
		});
	}
);
