export const moduleMetaData = {
	// eslint-disable-next-line camelcase
	company_management: 'Company List',
};

export const ltr = {
	//company-mgmt
	'companyLink': '.MuiDataGrid-virtualScrollerContent .MuiDataGrid-cell .MuiLink-root',
	'companyLevelMonitoringTab': '.MuiTabs-flexContainer > button[option=\'primary\']:nth-child(3)',
	'customMonitorsSubTab': '.MuiButtonBase-root.MuiTab-root.MuiTab-textColorPrimary.Mui-selected',
	'siteLink': '.MuiDataGrid-row .MuiDataGrid-cell .MuiLink-root',
	'siteLevelMonitoringTab': 'button:nth-child(3)',
	'monitorsGrid': '.MuiBox-root > .MuiGrid-root',
	'monitorsGridContent': '.MuiDataGrid-virtualScroller',
	'searchIcon': 'SearchOutlinedIcon',

	//custom monitors tab
	'customMonitorsFirstRowName': '.MuiDataGrid-virtualScrollerRenderZone > div:nth-child(1) .MuiDataGrid-cell--textLeft > a > span',
	'editMonitorLabel': '.MuiTypography-root.MuiTypography-h4',
	'newSuspensionLabel': '.MuiTypography-root.MuiTypography-h4',

	//grid header
	'status': '.MuiDataGrid-columnHeadersInner :nth-child(5)',

	// grid
	'gridRowName': '.MuiDataGrid-row > .MuiDataGrid-cell--textLeft > a > span',
	'gridRow': '.MuiDataGrid-row',

	// buttons
	'suspensionRuleButton': '.MuiButtonBase-root.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeMedium.MuiButton-containedSizeMedium' +
		'.MuiButton-root.MuiButton-contained.MuiButton-containedPrimary.MuiButton-sizeMedium.MuiButton-containedSizeMedium',
};

export const txt = {
	'emptyData': 'No rows',
	'emptySearch': 'No results found',
	'saveSelection': 'Save Selection',
	'cancel': 'Cancel',
	'cpu': 'CPU',
	'service': 'Service',
	'customField': 'Custom field',
	'dropdown': 'Dropdown',
	'criticalImpactAlerts': 'Critical Impact Alerts',
	'activeDirectory': 'Active Directory',
	'successMessage': 'saved',
	'enableStatus': 'Enabled',
	'disableStatus': 'Disabled',
	'singleDeleteSuccessMessage': 'Monitor has been deleted',
	'mutipleDeleteSuccessMessage': 'Monitors has been deleted',
	'enabledSuccessMessage': 'Monitor has been enabled',
	'disabledSuccessMessage': 'Monitor has been disabled',
	'suspensionText': 'Included in 1 Suspension Rule'
};