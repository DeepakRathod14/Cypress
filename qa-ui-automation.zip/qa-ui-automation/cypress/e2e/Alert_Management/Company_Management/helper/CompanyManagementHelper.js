import { ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper, 
	ResourceSelectorHelper, ToastHelper } from '../../../../fixtures';

import { ltr, txt, moduleMetaData } from './constants';
import { rqt } from '../../../../constants';
import AlertingApi from '../../api/AlertingApi';
import MonitorsHelper from '../../Monitors/helper/MonitorsHelper';

/**
 * Helper class for Company Management module/
 * @class
 * @extends MonitorsHelper
 */
class CompanyManagementHelper extends MonitorsHelper {

	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.resourceSelectorHelper = new ResourceSelectorHelper();
		this.apiHelper = new AlertingApi();
		this.toast = new ToastHelper();

		this.monitorsGQLRequest = null;
		this.getMonitorsResponse = null;
	}

	/**
	 * All SETUP methods
	 */
	setupHooks() {
		beforeEach(() => {
			this.initialLandingSetup();
		});
	}

	setupApiIntercepts() {
		before(() => {
			this.interceptApi();
		});
	}

	interceptApi() {
		this.apiHelper.api.setAliasForGraphQL('Alerting/GraphQL/', 'MonitorsBasedOnDevicesQuery', 'monitorsQuery').then(() => {
			this.isGetMonitorLoaded = false;
		});
		this.apiHelper.api.setAliasForApi(rqt.Put, '**/monitors', 'updateMonitor');
	}

	/**
	 * All CHECK methods
	 */
	checkCompanyLevelMonitoringTabIsVisible = () => {
		this.checkElementIsVisible(ltr.companyLevelMonitoringTab).should('contains.text', 'Monitoring');
	};

	checkCustomMonitorsSubTabIsVisible = () => {
		this.checkElementIsVisible(ltr.customMonitorsSubTab).should('contains.text', 'Custom Monitors');
	};

	checkMonitorsGridIsVisibleAndHasData = () => {
		this.checkElementIsVisible(ltr.monitorsGrid)
			.find(ltr.monitorsGridContent)
			.should('not.contain.text', txt.emptyData);
	};

	checkEditMonitorPageIsVisible = () => {
		this.checkElementIsVisible(ltr.editMonitorLabel);
	};

	checkSuspensionRuleButtonIsVisibleAndEnabled() {
		this.getElement(ltr.suspensionRuleButton).should('be.enabled');
	}

	checkNewSuspensionPageIsVisible = () => {
		this.checkElementIsVisible(ltr.newSuspensionLabel);
	};

	checkSiteLevelMonitoringTabIsVisible = () => {
		this.checkElementIsVisible(ltr.siteLevelMonitoringTab).should('contains.text', 'Monitoring');
	};

	/**
	 * All click Methods
	 */
	clickCompanyName = (index) => {
		this.getElement(ltr.companyLink).eq(index).click();
	}

	clickCompanyLevelMonitoringTab = () => {
		this.getElement(ltr.companyLevelMonitoringTab).click();
		cy.wait(5000);
	}

	clickMonitorsNameInGrid = () => {
		this.getElement(ltr.customMonitorsFirstRowName).click();
	};

	clickSuspensionRuleButton() {
		this.getElement(ltr.suspensionRuleButton).click();
	}

	clickSiteName = () => {
		this.getElement(ltr.siteLink).click();
	}

	clickSiteLevelMonitoringTab = () => {
		this.getElement(ltr.siteLevelMonitoringTab).click();
	}

	/** 
	 * All SEARCH methods
	 */
	searchMonitorAndSelectFirstRow(name) {
		this.searchMonitor(name);
		this.getFirstElement(ltr.gridRow).find('input').check({ force: true });
	}

	/**
	 * All OTHER Methods
	 */

	initialLandingSetup() {
		this.navigateToPageOnCheck(moduleMetaData.company_management);

		this.clickCompanyName(1);
		this.checkCompanyLevelMonitoringTabIsVisible();
		this.clickCompanyLevelMonitoringTab();

		this.checkOnGridApiAndSaveResponse('@monitorsQuery', this.isGetMonitorLoaded, this.getMonitorsResponse);

		cy.get('@checkOnGridApiAndSaveResponse').then((result) => {
			this.isGetMonitorLoaded = result.classInstFlag;
			this.getMonitorsResponse = result.classInstResponse;
		});
	}

	sortApiDataBasedOnGivenField(field, order) {
		let combinedMonitors;
		let responseField = '';

		cy.wrap(this.getMonitorsResponse).as('getMonitorResponse').then((monitors) => {
			const mainResponse = monitors.response.body.data.MonitorsBasedOnDevicesQuery.outdata;
			const customMonitors = mainResponse.customMonitors;
			combinedMonitors = customMonitors.concat(mainResponse.complexMonitors);

			if (field === 'Name') {
				responseField = 'displayName';
			}

			if (order === 'ascending') {
				combinedMonitors.sort(function (a, b) {
					return a[responseField].localeCompare(b[responseField]);
				});
			} else {
				combinedMonitors.sort(function (a, b) {
					return b[responseField].localeCompare(a[responseField]);
				});
			}

			cy.wrap(combinedMonitors).as('sortedCombinedMonitors');
		});

	}
}

export default CompanyManagementHelper;