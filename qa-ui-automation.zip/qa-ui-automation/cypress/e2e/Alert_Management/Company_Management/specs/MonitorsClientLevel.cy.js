import CompanyManagementHelper from '../helper/CompanyManagementHelper';
import { txt } from '../helper/constants';

describe('GIVEN Monitoring Landing Page', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var companyManagementHelper = new CompanyManagementHelper();

	// Define global hook for describe block 
	companyManagementHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {

		/** 
		 * Base hooks defined for pre and post conditions
		 * before, beforeEach, after, afterEach
		 * NOTE: Add custom conditions to specific test cases only 
		 */
		companyManagementHelper.setupHooks();

		// test cases start here
		it('THEN Verify user is able to see Monitors data displayed in grid at client level', { tags: ['@Regression', '@ALERT-6847'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1559');

			companyManagementHelper.checkCustomMonitorsSubTabIsVisible();
			companyManagementHelper.checkMonitorsGridIsVisible();
		});

		it('THEN Verify user is able to redirect to edit monitor details screen on click of name at client level', { tags: ['@Regression', '@ALERT-6848'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1584');
			
			companyManagementHelper.clickMonitorsNameInGrid();
			companyManagementHelper.checkEditMonitorPageIsVisible();
		});

		it('THEN Verify custom monitors grid has default sorting on Name Field at client level', { tags: ['@Regression'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1606');
			
			companyManagementHelper.checkIfNameFieldHasDefaultSortingEnabled('ascending');
			companyManagementHelper.sortApiDataBasedOnGivenField('Name', 'ascending');
			companyManagementHelper.validateFirstNSortedDataOnGrid(10);
		});
	});

	context('WHERE tests require external api call', { tags: ['@Migrated'] }, () => {
		// Define hooks for pre and post conditions
		companyManagementHelper.setupHooks();
		companyManagementHelper.setupApiHooks();

		// companyManagementHelper.cleanupHooks();

		// test cases start here
		it('THEN Verify user is able to search the monitor at client level', { tags: ['@Regression'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1607');

			companyManagementHelper.createMonitorUsingApi();
			const testDataApi = companyManagementHelper.dataHelper.getDataForApi();

			cy.reload();

			companyManagementHelper.clickCompanyLevelMonitoringTab();
			companyManagementHelper.searchMonitorAndClickOnFirstRow(testDataApi.displayName);
		});

		it('THEN Verify user is able to disable and then enable the monitor at client level', { tags: ['@Regression', '@ALERT-6909'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1604');

			companyManagementHelper.createMonitorUsingApi();
			const testDataApi = companyManagementHelper.dataHelper.getDataForApi();

			cy.reload();

			companyManagementHelper.clickCompanyLevelMonitoringTab();
			companyManagementHelper.searchMonitorAndSelectRow(testDataApi.displayName);
			companyManagementHelper.toggleMonitorStatus(false);
			companyManagementHelper.validateMonitorToastMessage(txt.disabledSuccessMessage);
			companyManagementHelper.validateMonitorRowStatus(0, txt.disableStatus);

			companyManagementHelper.toggleMonitorStatus(true);
			companyManagementHelper.validateMonitorToastMessage(txt.enabledSuccessMessage);
			companyManagementHelper.validateMonitorRowStatus(0, txt.enableStatus);

			companyManagementHelper.deselectMonitorGridRow(0);
		});

		it('THEN Verify suspension rule button is enabled and new suspension screen displayed when clicked for a monitor at client level', { tags: ['@Regression', '@ALERT-6909'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1603');

			companyManagementHelper.createMonitorUsingApi();
			const testDataApi = companyManagementHelper.dataHelper.getDataForApi();

			cy.reload();

			companyManagementHelper.clickCompanyLevelMonitoringTab();
			companyManagementHelper.searchMonitorAndSelectRow(testDataApi.displayName);
			companyManagementHelper.checkSuspensionRuleButtonIsVisibleAndEnabled();
			companyManagementHelper.clickSuspensionRuleButton();
			companyManagementHelper.checkNewSuspensionPageIsVisible();
		});

		it( 'THEN Verify Card view has Data for CPU type Monitor with Suspension Rule added and Suspension link is working', { tags: ['@Regression', '@ALERT-6849'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1561');

			companyManagementHelper.createMonitorUsingApi(null, true);
			const testDataApi = companyManagementHelper.dataHelper.getDataForApi();		
			
			cy.reload();

			companyManagementHelper.clickCompanyLevelMonitoringTab();
			companyManagementHelper.searchMonitorAndClickOnFirstRow(testDataApi.displayName);
			companyManagementHelper.validateCardHasValueBasedOnType(txt.cpu, testDataApi);

			cy.get('@suspensionRuleBody').then((body) => {
				console.log(body);
				companyManagementHelper.validateMonitorCardHasSuspensionValue(body.rulename);
				companyManagementHelper.validateSuspensionRedirectionWithMonitorValue(body.rulename, testDataApi.displayName);

				companyManagementHelper.navigateBackToMonitorsPage();
			});
		});

		it( 'THEN Verify user is able to delete a monitor', { tags: ['@Regression', '@ALERT-6909'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1602');

			companyManagementHelper.createMonitorUsingApi();
			const testDataApi = companyManagementHelper.dataHelper.getDataForApi();

			cy.reload();

			companyManagementHelper.clickCompanyLevelMonitoringTab();
			companyManagementHelper.searchMonitorAndSelectRow(testDataApi.displayName);
			companyManagementHelper.clickOnDeleteButton();
			companyManagementHelper.clickOnDeleteButtonOnModal();
			companyManagementHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);
		});
	});
});