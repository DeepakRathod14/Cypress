import SuspensionsHelper from '../../Suspensions/helper/SuspensionsHelper';
import { lct, txt } from '../../Suspensions/helper/constants';
import { envTag } from '../../../../constants';

describe(
	'GIVEN Suspensions Per Site Landing Page',
	{ tags: ['@Suspensions', '@MUI'] },
	() => {
		var suspensionsHelper = new SuspensionsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {

			suspensionsHelper.setupHooksSuspensionPerSite();

			suspensionsHelper.createSuspensionTestDataBasedOnType(txt.suspensionPerSite);
			const { suspensionName, suspensionDescription } = suspensionsHelper.getData();

			it('Should create suspension at site level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1696');
				suspensionsHelper.CreateSuspensionAtSiteLevel(suspensionName, suspensionDescription);
			});

			it('Should verify the suspension tab is shown on site details screen', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1697');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
			});

			it('Should Search in grid', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1698');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.getGridCell()
					.should('exist');
			});

			it('Should Filter value', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1699');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickToggleColumnIcon();
				suspensionsHelper.clickFilterIcon();
				suspensionsHelper.selectDropdownValue(
					lct.selectListContains,
					0,
					'Status'
				);
				suspensionsHelper.selectDropdownValue(
					lct.selectListOperator,
					0,
					'equals'
				);
				suspensionsHelper.typeValue('Active');				
				suspensionsHelper.getGridCell()
					.should('exist') // Ensure that at least one cell exists
					.each((cell) => {
						cy.wrap(cell)
							.invoke('text')
							.then((cellText) => {
								expect(cellText).to.include('Active');
							}
							);
					});
			});

			it('Should Sort Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1700');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						suspensionsHelper.validateFirstRowExists();
						suspensionsHelper.sortColumn(5);
						suspensionsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Should Hide Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1701');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.getColumnHeaders()
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						suspensionsHelper.clickToggleColumnIcon();
						suspensionsHelper.hideColumn(3);
						suspensionsHelper.getColumnHeaders()
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Should Open Edit Suspension Page for a suspension', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1702');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper.pageTitleToBeVisible('Edit Suspension');
			});

			it('Should Have Suspension Metadata Card', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1703');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspensionforMetadata();
				suspensionsHelper.checkMetaDataCardExist();
				suspensionsHelper.checkMetaDataCardData(suspensionName);
			});

			it('Should Have Suspension Name Field as Not Empty', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1704');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.getNameField().should('not.have.value', '');
			});

			it('Should Have Resource Selected', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1705');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper.getResourceSelectorTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						cy.log(initialText1);
						suspensionsHelper.getResourceSelectorTypography().should(
							'not.have.text',
							'00'
						);
					});
			});

			it('Should delete the newly created suspension', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1706');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.selectSuspensionCheckbox();
				suspensionsHelper.clickDeleteButton();
				suspensionsHelper.clickDeleteConfirmButton();
			});

		});

	}
);