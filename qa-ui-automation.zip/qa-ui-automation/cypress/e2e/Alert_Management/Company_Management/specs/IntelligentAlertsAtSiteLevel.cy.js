import IntelligentAlertsHelper from '../../IntelligentAlerts/helper/IntelligentAlertsHelper';
// import { moduleMetaData, lct, txt, atr } from "../helper/constants"
import { envTag } from '../../../../constants';

describe(
	'GIVEN IntelligentAlerts Landing Page',
	{ tags: ['@Intelligent Alerts', '@MUI'] },
	() => {
		var intelligentAlertsHelper = new IntelligentAlertsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {

			intelligentAlertsHelper.setupHooksIntelligentAlertPerSite();

			it('Verify the intelligent alerts tab is shown on site details screen', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6999');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.checkIntelligentAlertsGridIsVisible();
			});

			it('Verify edit intelligent alerts screen is displayed when clicked on intelligent alerts name', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6992');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.checkEditIntelligentAlertsPageIsVisible();
			});
			
			it('Verify Intelligent alerts details are coming when clicking on any intelligent alerts', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6987');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.checkDataCardforIntelligentAlerts();
			});

			it('Verify Add suspension rule is coming when selecting any intelligent alerts', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6991');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.checkSuspensionRuleButtonAtCompanyManagement();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Endpoint Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6995');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Devices');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtSite();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Sites Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6993');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Sites');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtSite();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Companies Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6994');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Companies');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtSite();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at DeviceGroups Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6988');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Device Groups');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtSite();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Partner Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6960');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAletsAtPartnerLevel('All Resources');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtSite();
			});			

			it('Verify user is able to add and delete automation in default threshold', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6990');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnDefaultThreshold();
				intelligentAlertsHelper.deleteAutomationOnDefaultThreshold();
			});

			it('Verify user is able to add and delete automation in custom threshold', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6989');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnCustomThreshold();
				intelligentAlertsHelper.deleteAutomationOnCustomThreshold();
			});

			it('Verify user Should Sort on Name Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6996');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						intelligentAlertsHelper.validateFirstRowExists();
						intelligentAlertsHelper.sortColumn(1);
						intelligentAlertsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Verify user Should Sort on Family Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6997');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						intelligentAlertsHelper.validateFirstRowExists();
						intelligentAlertsHelper.sortColumn(3);
						intelligentAlertsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Verify user Should Sort on Severity Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6998');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						intelligentAlertsHelper.validateFirstRowExists();
						intelligentAlertsHelper.sortColumn(4);
						intelligentAlertsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Verify user should be able to filter with And Condition', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7007');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.filterIntellimonAlertsForFirstName();
				intelligentAlertsHelper.clickAddFilterButton();
				intelligentAlertsHelper.filterSelectLogicalAndOperator();
				intelligentAlertsHelper.filterIntellimonAlertsForSecondName();
				intelligentAlertsHelper.checkAlertName2Exist();
			});

			it('Verify user should be able to filter with Or Condition', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7008');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.filterIntellimonAlertsForFirstName();
				intelligentAlertsHelper.clickAddFilterButton();
				intelligentAlertsHelper.filterSelectLogicalOrOperator();
				intelligentAlertsHelper.filterIntellimonAlertsForSecondName();
				intelligentAlertsHelper.checkAlertName1Exist();
				intelligentAlertsHelper.checkAlertName2Exist();
			});

			it('Verify family dropdown values are sorted in ascending order', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7006');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.filterSelectColumnName('Family');
				intelligentAlertsHelper.validateDropdownValuesAreSorted();							
			});

			it('Verify severity dropdown values are sorted in ascending order', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7006');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.filterSelectColumnName('Severity');
				intelligentAlertsHelper.validateDropdownValuesAreSorted();							
			});
		});
	}
);
