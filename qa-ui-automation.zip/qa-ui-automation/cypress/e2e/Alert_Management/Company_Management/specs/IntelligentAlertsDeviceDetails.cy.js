import IntelligentAlertsHelper from '../../IntelligentAlerts/helper/IntelligentAlertsHelper';
import MonitorsHelper from '../../Monitors/helper/MonitorsHelper';
import { envTag } from '../../../../constants';

describe('GIVEN IntelligentAlerts Landing Page',{ tags: ['@Intelligent Alerts', '@MUI'] }, () => {
	var intelligentAlertsHelper = new IntelligentAlertsHelper();
	var monitorsHelper = new MonitorsHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	context('Migrated/SSO User', {}, () => {

		// intelligentAlertsHelper.setupHooksIntelligentAlertPerSite();
		monitorsHelper.setupHooksMonitorFromDeviceDetails();

		it('Verify family dropdown values are sorted in ascending order', { tags: [envTag.Regression, envTag.CTS] }, function () {        
			cy.allure().tms('ALERT-T6999');
			intelligentAlertsHelper.clickMonitoringTabOnDeviceDetailPage();
			intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
			intelligentAlertsHelper.filterSelectColumnName('Family');
			intelligentAlertsHelper.validateDropdownValuesAreSorted();	
		});

		it('Verify severity dropdown values are sorted in ascending order', { tags: [envTag.Regression, envTag.CTS] }, function () {        
			cy.allure().tms('ALERT-T6999');
			intelligentAlertsHelper.clickMonitoringTabOnDeviceDetailPage();
			intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
			intelligentAlertsHelper.filterSelectColumnName('Severity');
			intelligentAlertsHelper.validateDropdownValuesAreSorted();	
		});

		it('Verify condition description is wrapped on card', { tags: [envTag.Regression, envTag.CTS] }, function () {        
			cy.allure().tms('ALERT-T7206');
			intelligentAlertsHelper.clickMonitoringTabOnDeviceDetailPage();
			intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
			intelligentAlertsHelper.verifyIntelligentMonitorTitle();
		});
	});
});