import IntelligentAlertsHelper from '../../IntelligentAlerts/helper/IntelligentAlertsHelper';
// import { moduleMetaData, lct, txt, atr } from "../helper/constants"
import { envTag } from '../../../../constants';

describe(
	'GIVEN IntelligentAlerts Landing Page',
	{ tags: ['@Intelligent Alerts', '@MUI'] },
	() => {
		var intelligentAlertsHelper = new IntelligentAlertsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {

			intelligentAlertsHelper.setupHooksIntelligentAlertPerCompany();

			it('Verify the intelligent alerts tab is shown on company details screen', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6959');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.checkIntelligentAlertsGridIsVisible();
			});

			it('Verify edit intelligent alerts screen is displayed when clicked on intelligent alerts name', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6983');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.checkEditIntelligentAlertsPageIsVisible();
			});
			
			it('Verify Intelligent alerts details are coming when clicking on any intelligent alerts', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6976');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.checkDataCardforIntelligentAlerts();
			});

			it('Verify Add suspension rule is coming when selecting any intelligent alerts', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6974');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.checkSuspensionRuleButtonAtCompanyManagement();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Endpoint Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6975');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Devices');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtCompany();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Sites Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6979');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Sites');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtCompany();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Companies Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6977');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Companies');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtCompany();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at DeviceGroups Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6978');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Device Groups');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtCompany();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Partner Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6984');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnIntelligentAletsAtPartnerLevel('All Resources');
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsAtCompany();
			});

			it('Verify user is able to add and delete automation in default threshold', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6986');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnDefaultThreshold();
				intelligentAlertsHelper.deleteAutomationOnDefaultThreshold();
			});

			it('Verify user is able to add and delete automation in custom threshold', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6985');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.addAutomationOnCustomThreshold();
				intelligentAlertsHelper.deleteAutomationOnCustomThreshold();
			});

			it('Verify user Should Sort on Name Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6981');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						intelligentAlertsHelper.validateFirstRowExists();
						intelligentAlertsHelper.sortColumn(1);
						intelligentAlertsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Verify user Should Sort on Family Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6982');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						intelligentAlertsHelper.validateFirstRowExists();
						intelligentAlertsHelper.sortColumn(3);
						intelligentAlertsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Verify user Should Sort on Severity Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T6980');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						intelligentAlertsHelper.validateFirstRowExists();
						intelligentAlertsHelper.sortColumn(4);
						intelligentAlertsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Verify user should be able to filter with And Condition', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7005');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();				
				intelligentAlertsHelper.filterIntellimonAlertsForFirstName();
				intelligentAlertsHelper.clickAddFilterButton();
				intelligentAlertsHelper.filterSelectLogicalAndOperator();
				intelligentAlertsHelper.filterIntellimonAlertsForSecondName();								
				intelligentAlertsHelper.checkAlertName2Exist();											
			});

			it('Verify user should be able to filter with Or Condition', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7006');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();				
				intelligentAlertsHelper.filterIntellimonAlertsForFirstName();
				intelligentAlertsHelper.clickAddFilterButton();
				intelligentAlertsHelper.filterSelectLogicalOrOperator();
				intelligentAlertsHelper.filterIntellimonAlertsForSecondName();
				intelligentAlertsHelper.checkAlertName1Exist();
				intelligentAlertsHelper.checkAlertName2Exist();									
			});

			it('Verify family dropdown values are sorted in ascending order', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7006');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.filterSelectColumnName('Family');
				intelligentAlertsHelper.validateDropdownValuesAreSorted();							
			});

			it('Verify severity dropdown values are sorted in ascending order', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7006');
				intelligentAlertsHelper.CheckAndNavigateToIntelligentAlertTab();
				intelligentAlertsHelper.filterSelectColumnName('Severity');
				intelligentAlertsHelper.validateDropdownValuesAreSorted();							
			});
		});
	}
);
