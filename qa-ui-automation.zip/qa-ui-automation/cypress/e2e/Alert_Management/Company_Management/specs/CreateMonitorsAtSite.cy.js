import { envTag } from '../../../../constants';
import MonitorsHelper from '../../Monitors/helper/MonitorsHelper';
import { moduleMetaData, txt } from '../../Monitors/helper/constants';


describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		monitorsHelper.setupHooksMonitorPerSite();
		// monitorsHelper.cleanupHooks();

		monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
		const testData = monitorsHelper.dataHelper.getData();

		it('Verify user is able to create CPU monitors at Sites Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1707');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectSiteLevelResourceSelectorValueAndSave();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Should verify the Custom Monitor tab is shown on site details screen', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
			cy.allure().tms('ALERT-T1708');
			monitorsHelper.CheckAndNavigateToCustomMonitorsTab();
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify Monitors Grid is loading', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1709');
			monitorsHelper.checkMonitorsGridIsVisible();
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify created monitor is displayed at the Custom Monitor per site', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1710');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectSiteLevelResourceSelectorValueAndSave();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify Monitors Grid have default sorting on Name Field', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1711');
			cy.wait(5000);
			monitorsHelper.checkIfNameFieldHasDefaultSortingEnabled('ascending');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to disable and then enable Monitor', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1712');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectSiteLevelResourceSelectorValueAndSave();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.selectMonitorGridRow(0);
			monitorsHelper.toggleMonitorStatus(false);
			monitorsHelper.validateMonitorToastMessage(txt.disabledSuccessMessage);
			monitorsHelper.validateMonitorRowStatus(0, txt.disableStatus);
			monitorsHelper.toggleMonitorStatus(true);
			monitorsHelper.validateMonitorToastMessage(txt.enabledSuccessMessage);
			monitorsHelper.validateMonitorRowStatus(0, txt.enableStatus);
			monitorsHelper.deselectMonitorGridRow(0);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it( 'THEN Verify user is able to select all monitors', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T5138');
			monitorsHelper.checkSelectAllCheckboxOnGrid();
			monitorsHelper.validateCountOfSelectedRows();			
		});

		it( 'THEN Verify Add Download button added on the custom monitor', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// mandatory to link JIRA test case ID		
			cy.allure().tms('ALERT-T5139');		
			monitorsHelper.checkDownloadButtonDisplayed();
			monitorsHelper.clickDownloadButton();					
		});	
		
		it('THEN Verify Display of Automation Task when Editing Monitors', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T5140');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
			const testData = monitorsHelper.getData();
			// creating a monitor
			monitorsHelper.baseStepsForMonitorCreation();
			monitorsHelper.selectFromResourceSelectorAndSave(testData.resourceType);
			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.toggleTicketResolution(testData.enableInverse);
			monitorsHelper.baseValidationForMonitorCreation();
			// editing a monitor
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.validateBaseFieldsHaveValues(testData);
			monitorsHelper.clickOnAutomationButton();
			monitorsHelper.clickFirstAutomation();
			monitorsHelper.clickOnSelectAutomationButton();
			monitorsHelper.validateAutomationIsAdded();
			monitorsHelper.validateAutomationNameAfterEditCancel();
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		context('WHERE test requires external API call', { tags: ['@Migrated'] }, () => {

			// Define hooks for pre and post conditions
			monitorsHelper.setupHooksMonitorPerSite();
			monitorsHelper.setupApiHooks();
			monitorsHelper.cleanupHooks();
			
			it('Verify Card view has Data for CPU type Monitor', { tags: ['@Regression', envTag.CTS] }, () => {
				// mandatory to link JIRA test case ID
				cy.allure().tms('ALERT-T1595');
				monitorsHelper.createMonitorUsingApi();
				const testDataApi = monitorsHelper.dataHelper.getDataForApi();
				cy.reload();
				monitorsHelper.clickMonitoringTab();
				monitorsHelper.searchMonitorAndClickOnFirstRow(testDataApi.displayName);
				monitorsHelper.validateCardHasValueBasedOnType(txt.cpu, testDataApi);
			});

			it('Verify user is able to delete a monitor', { tags: ['@Regression', envTag.CTS] }, () => {
				// mandatory to link JIRA test case ID
				cy.allure().tms('ALERT-T1596');
				monitorsHelper.createMonitorUsingApi();
				const testDataApi = monitorsHelper.dataHelper.getDataForApi();
				cy.reload();
				monitorsHelper.clickMonitoringTab();
				monitorsHelper.searchMonitorAndSelectRow(testDataApi.displayName);
				monitorsHelper.clickOnDeleteButton();
				monitorsHelper.clickOnDeleteButtonOnModal();
				monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);
			});

			it('Verify Card view has Data for CPU type Monitor with Suspension Rule added and Suspension link is working', { tags: ['@Regression', envTag.CTS] }, () => {
				// mandatory to link JIRA test case ID
				cy.allure().tms('ALERT-T1597');				
				monitorsHelper.createMonitorUsingApi(null, true);
				const testDataApi = monitorsHelper.dataHelper.getDataForApi();				
				cy.reload();
				monitorsHelper.clickMonitoringTab();				
				monitorsHelper.searchMonitorAndClickOnFirstRow(testDataApi.displayName);				
				monitorsHelper.validateCardHasValueBasedOnType(txt.cpu, testDataApi);						
				cy.get('@suspensionRuleBody').then((body) => {					
					console.log(body);					
					monitorsHelper.validateMonitorCardHasSuspensionValue(body.rulename);					
					monitorsHelper.validateSuspensionRedirectionWithMonitorValue(body.rulename, testDataApi.displayName);					
					monitorsHelper.navigateBackToMonitorsPage();					
					monitorsHelper.clickMonitoringTab();					
				});				
				monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);						
			});

		});

	});

});