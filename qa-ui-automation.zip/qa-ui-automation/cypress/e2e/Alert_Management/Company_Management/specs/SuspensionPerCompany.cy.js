import SuspensionsHelper from '../../Suspensions/helper/SuspensionsHelper';
import { lct, txt } from '../../Suspensions/helper/constants';
import { envTag } from '../../../../constants';

describe(
	'GIVEN Suspensions Per Company Landing Page',
	{ tags: ['@Suspensions', '@MUI'] },
	() => {
		var suspensionsHelper = new SuspensionsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {

			suspensionsHelper.setupHooksSuspensionPerCompany();

			suspensionsHelper.createSuspensionTestDataBasedOnType(txt.suspensionPerCompany);
			const { suspensionName, suspensionDescription } = suspensionsHelper.getData();

			it('Should create suspension at company level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1685');
				suspensionsHelper.CreateSuspensionAtCompanyLevel(suspensionName, suspensionDescription);
			});

			it('Should verify the suspension tab is shown on company details screen', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1686');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
			});

			it('Should Search in grid', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1687');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.getGridCell()
					.should('exist');
			});

			it('Should Filter value', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1688');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickToggleColumnIcon();
				suspensionsHelper.clickFilterIcon();
				suspensionsHelper.selectDropdownValue(
					lct.selectListContains,
					0,
					'Status'
				);
				suspensionsHelper.selectDropdownValue(
					lct.selectListOperator,
					0,
					'equals'
				);
				suspensionsHelper.typeValue('Active');				
				suspensionsHelper.getGridCell()
					.should('exist') // Ensure that at least one cell exists
					.each((cell) => {
						cy.wrap(cell)
							.invoke('text')
							.then((cellText) => {
								expect(cellText).to.include('Active');
							}
							);
					});
			});

			it('Should Sort Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1689');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.getRowByIndex(0)
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						suspensionsHelper.validateFirstRowExists();
						suspensionsHelper.sortColumn(5);
						suspensionsHelper.getRowByIndex(0)
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Should Hide Column', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1690');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.getColumnHeaders()
					.invoke('text')
					.as('initialText')
					.then((initialText) => {
						suspensionsHelper.clickToggleColumnIcon();
						suspensionsHelper.hideColumn(3);
						suspensionsHelper.getColumnHeaders()
							.invoke('text')
							.then((newText) => {
								expect(newText).to.not.equal(initialText);
							});
					});
			});

			it('Should Open Edit Suspension Page for a suspension', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1691');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper.pageTitleToBeVisible('Edit Suspension');
			});

			it('Should Have Suspension Metadata Card', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1692');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspensionforMetadata();
				suspensionsHelper.checkMetaDataCardExist();
				suspensionsHelper.checkMetaDataCardData(suspensionName);
			});

			it('Should Have Suspension Name Field as Not Empty', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1693');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper.nameFieldShouldExist();
				suspensionsHelper.getNameField().should('not.have.value', '');
			});

			it('Should Have Resource Selected', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1694');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.clickSuspension(suspensionName);
				suspensionsHelper.getResourceSelectorTypography()
					.invoke('text')
					.as('initialText1')
					.then((initialText1) => {
						cy.log(initialText1);
						suspensionsHelper.getResourceSelectorTypography().should(
							'not.have.text',
							'00'
						);
					});
			});

			it('Should delete the newly created suspension', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T1695');
				suspensionsHelper.CheckAndNavigateToSuspensionTab();
				suspensionsHelper.clickSearchIcon();
				suspensionsHelper.searchInGrid(suspensionName);
				suspensionsHelper.selectSuspensionCheckbox();
				suspensionsHelper.clickDeleteButton();
				suspensionsHelper.clickDeleteConfirmButton();
			});

		});

	}
);