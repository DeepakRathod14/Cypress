import IntelligentAlertsHelper from '../helper/IntelligentAlertsHelper';
import { moduleMetaData } from '../helper/constants';
import { envTag } from '../../../../constants';
import MonitorsHelper from '../../Monitors/helper/MonitorsHelper';

describe(
	'GIVEN IntelligentAlerts Landing Page',
	{ tags: ['@Intelligent Alerts', '@MUI'] },
	() => {
		var intelligentAlertsHelper = new IntelligentAlertsHelper();
		var monitorsHelper = new MonitorsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/CSM User', {}, () => {
			before(() => {
				intelligentAlertsHelper.setup(moduleMetaData);
			});

			intelligentAlertsHelper.setupHooks();

			it('Verify automation sction is not diaplayed on intelligent alerts page for csm user', { tags: ['@Regression', envTag.CTS] }, function () {
				cy.allure().tms('ALERT-T7207');
				intelligentAlertsHelper.editIntelligentAlert();		
				intelligentAlertsHelper.automationCardNotDisplayed();
				monitorsHelper.checkMapperToggleButtonNotExist();
			});
		});
	}
);
