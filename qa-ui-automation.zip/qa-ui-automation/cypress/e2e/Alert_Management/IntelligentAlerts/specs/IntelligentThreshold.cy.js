import IntelligentAlertsHelper from '../helper/IntelligentAlertsHelper';
import { envTag } from '../../../../constants';
import MonitorsHelper from '../../Monitors/helper/MonitorsHelper';

describe(
	'GIVEN IntelligentAlerts Landing Page',
	{ tags: ['@Intelligent Alerts', '@MUI'] },
	() => {
		var intelligentAlertsHelper = new IntelligentAlertsHelper();
		var monitorsHelper = new MonitorsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {

			intelligentAlertsHelper.setupHooks();			

			it('Verify mapper toggle button and fields added on intelligent threshold page', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7214');
				intelligentAlertsHelper.editIntelligentThreshold();
				//Check Mapper Data Fields exist
				monitorsHelper.checkMapperToggleButtonExist();
				monitorsHelper.clickOnTheMapperToggleButton();			
				monitorsHelper.checkMapperServiceBoardExist();
				//Check Service Board is shwon with asteric mark
				monitorsHelper.checkMapperServiceBoardExistWithAstericMark();
				monitorsHelper.checkMapperTypeExist();
				monitorsHelper.checkMapperSubTypeExist();
				monitorsHelper.checkMapperItemExist();			
			});

			it('Verify when user edit intellimon threshold with mapper toggle on and without selecting values', { tags: ['@Regression'] }, () => {
				cy.allure().tms('ALERT-T7168');
				intelligentAlertsHelper.editIntelligentThreshold();							
				monitorsHelper.checkMapperToggleButtonExist();			 
				monitorsHelper.clickOnTheMapperToggleButton();			
				monitorsHelper.checkMapperServiceBoardExist();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
				monitorsHelper.checkMapperServiceBoardExistAsMandatoryField();
			});

			it('Verify if user can create mapping without automation for default threshold', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7263');
				intelligentAlertsHelper.editIntelligentThreshold();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();				
				//Verify the added Mapper Data 
				intelligentAlertsHelper.editIntelligentThreshold();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();					
			});

			it('Verify when user - select values from dropdown and disable mapper toggle before save', { tags: ['@Regression'] }, () => {
				cy.allure().tms('ALERT-T7266');
				intelligentAlertsHelper.editIntelligentThreshold();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Toggle Mapper Button
				monitorsHelper.clickOnTheMapperToggleButton();
				// Save Monitor and verify
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
				//Verify the Mapper Data should be blank after toggle
				intelligentAlertsHelper.editIntelligentThreshold();
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.verifyBlankSelectedMapperServiceBoard();
				monitorsHelper.verifyBlankSelectedMapperType();
				monitorsHelper.verifyBlankSelectedMapperSubType();
				monitorsHelper.verifyBlankSelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();	
			});

			it('Verify when user edit intellimon threshold by selecting only board name', { tags: ['@Regression'] }, () => {
				cy.allure().tms('ALERT-T7169');
				intelligentAlertsHelper.editIntelligentThreshold();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();			
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				//Verify the added Mapper Data 
				intelligentAlertsHelper.editIntelligentThreshold();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				intelligentAlertsHelper.editIntelligentThreshold();
				cy.reload();	
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifyBlankSelectedMapperType();
				monitorsHelper.verifyBlankSelectedMapperSubType();
				monitorsHelper.verifyBlankSelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();	
			});

			it('Verify when user update intellimon threshold by clearing one of the selected values', { tags: ['@Regression'] }, () => {
				cy.allure().tms('ALERT-T7268');
				intelligentAlertsHelper.editIntelligentThreshold();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				//Edit Mapper Data
				intelligentAlertsHelper.editIntelligentThreshold();
				monitorsHelper.selectMapperTypeNewValue();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				//Delete or Remove Mapper Data
				intelligentAlertsHelper.editIntelligentThreshold();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
			});

			it('Verify when user edit intellimon threshold with mapper toggle off', { tags: ['@Regression', envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7167');
				intelligentAlertsHelper.editIntelligentThreshold();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();		
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
				//Delete or Remove Mapper Data
				intelligentAlertsHelper.editIntelligentThreshold();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();	
			});			
		});
	}
);
