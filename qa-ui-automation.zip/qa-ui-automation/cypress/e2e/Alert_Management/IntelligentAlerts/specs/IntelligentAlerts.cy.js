import IntelligentAlertsHelper from '../helper/IntelligentAlertsHelper';
// import { moduleMetaData, lct, txt, atr } from "../helper/constants"
import { envTag } from '../../../../constants';

describe(
	'GIVEN IntelligentAlerts Landing Page',
	{ tags: ['@Intelligent Alerts', '@MUI'] },
	() => {
		var intelligentAlertsHelper = new IntelligentAlertsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {

			intelligentAlertsHelper.setupHooks();

			it('Verify Intelligent alerts are loaded properly', { tags: [envTag.Regression, envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2375');
				intelligentAlertsHelper.checkIntelligentAlertsGridIsVisible();
			});

			it('Verify Intelligent alerts details are coming when clicking on any intelligent alerts', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2376');
				intelligentAlertsHelper.checkDataCardforIntelligentAlerts();
			});

			it('Verify Add suspension rule is coming when selecting any intelligent alerts', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2377');
				intelligentAlertsHelper.checkSuspensionRuleButtonForIntelligentAlerts();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Endpoint Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2378');
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Devices');
				intelligentAlertsHelper.editIntelligentAlert();
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlerts();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Sites Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2379');
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Sites');
				intelligentAlertsHelper.editIntelligentAlert();
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlerts();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Companies Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2380');
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Companies');
				intelligentAlertsHelper.editIntelligentAlert();
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlerts();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at DeviceGroups Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2381');
				intelligentAlertsHelper.addAutomationOnIntelligentAlets('Device Groups');
				intelligentAlertsHelper.editIntelligentAlert();
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlerts();
			});

			it('Verify user is able to add and delete automation in intelligent alerts page at Partner Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2382');
				intelligentAlertsHelper.addAutomationOnIntelligentAletsAtPartnerLevel('All Resources');
				intelligentAlertsHelper.editIntelligentAlert();
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlerts();
			});

			it('Verify user is able to navigate to suspension page aftre clicking on suspension from card view', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T2383');
				intelligentAlertsHelper.navigateToSuspensionPage();
			});

			it('Verify breadcrumbs is displayed on Intelligent alerts listing page', { tags: [envTag.Regression] }, function () {
				cy.allure().tms('ALERT-T7486');
				intelligentAlertsHelper.checkIntelligentAlertsListingBreadcrumbIsVisible();
			});

			it('Verify text of breadcrumbs displayed is correct on Intelligent alerts listing page.', { tags: [envTag.Regression] }, function () {
				cy.allure().tms('ALERT-T7487');
				intelligentAlertsHelper.checkEndpointsTextIsVisibleInBreadcrumbIntelligentAlertListing();
				intelligentAlertsHelper.checkAlertsTextIsVisibleInBreadcrumbIntelligentAlertListing();
				intelligentAlertsHelper.checkIntelligentAlertsTextIsVisibleInBreadcrumbIntelligentAlertListing();
			});

			it('Verify clicking on intelligent alerrts breadcrumbs link navigates to listing page.', { tags: [envTag.Regression] }, function () {
				cy.allure().tms('ALERT-T7488');
				intelligentAlertsHelper.clickOnFirstIntelligentMonitorForEdit();
				intelligentAlertsHelper.checkEditIntelligentAlertsBreadcrumbIsVisible();
				intelligentAlertsHelper.clickIntelligentAlertsLinkInBreadcrumb();
				intelligentAlertsHelper.checkIntelligentAlertsListingBreadcrumbIsVisible();
			});

			// it('Verify user is able to add and delete automation in default threshold', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
			// 	cy.allure().tms('ALERT-T2384');
			// 	intelligentAlertsHelper.addAutomationOnDefaultThreshold();				
			// 	intelligentAlertsHelper.deleteAutomationOnDefaultThreshold();
			// });

			// it('Verify user is able to add and delete automation in custom threshold', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
			// 	cy.allure().tms('ALERT-T2385');
			// 	intelligentAlertsHelper.addAutomationOnCustomThreshold();
			// 	intelligentAlertsHelper.deleteAutomationOnCustomThreshold();
			// });

		});
	}
);
