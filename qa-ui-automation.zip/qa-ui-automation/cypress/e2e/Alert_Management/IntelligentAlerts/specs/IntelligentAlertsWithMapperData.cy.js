import IntelligentAlertsHelper from '../helper/IntelligentAlertsHelper';
import { envTag } from '../../../../constants';
import MonitorsHelper from '../../Monitors/helper/MonitorsHelper';

describe(
	'GIVEN IntelligentAlerts Landing Page',
	{ tags: ['@Intelligent Alerts', '@MUI'] },
	() => {
		var intelligentAlertsHelper = new IntelligentAlertsHelper();
		var monitorsHelper = new MonitorsHelper();

		Cypress.on('uncaught:exception', () => {
			return false;
		});

		context('Migrated/SSO User', {}, () => {

			intelligentAlertsHelper.setupHooks();			

			it('Verify mapper toggle button and fields added on intelligent alerts page', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7214');
				intelligentAlertsHelper.editIntelligentAlert();
				//Check Mapper Data Fields exist
				monitorsHelper.checkMapperToggleButtonExist();
				monitorsHelper.clickOnTheMapperToggleButton();			
				monitorsHelper.checkMapperServiceBoardExist();
				//Check Service Board is shwon with asteric mark
				monitorsHelper.checkMapperServiceBoardExistWithAstericMark();
				monitorsHelper.checkMapperTypeExist();
				monitorsHelper.checkMapperSubTypeExist();
				monitorsHelper.checkMapperItemExist();			
			});

			it('Verify when user edit intellimon alert with mapper toggle on and without selecting values of dropdown', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7168');
				intelligentAlertsHelper.editIntelligentAlert();							
				monitorsHelper.checkMapperToggleButtonExist();			 
				monitorsHelper.clickOnTheMapperToggleButton();			
				monitorsHelper.checkMapperServiceBoardExist();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
				monitorsHelper.checkMapperServiceBoardExistAsMandatoryField();
			});

			it('Verify if user can create mapping without automation policy', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7189');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();				
				//Verify the added Mapper Data 
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();					
			});

			it('Verify if user can create automation policy without mappiing values', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7190');
				intelligentAlertsHelper.editIntelligentAlert();
				//Do Not Enter Mapper Data				
				// Add Automation
				intelligentAlertsHelper.addAutomationOnIntelligentAletsWithMapperData('Sites');
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				// Verify no mapper data because we have not added it
				intelligentAlertsHelper.editIntelligentAlert();				
				// Delete added Automation
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsWithMapperData();				
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
			});

			it('Verify user is able to add and delete the automation policy', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7191');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Add Automation
				intelligentAlertsHelper.addAutomationOnIntelligentAletsWithMapperData('Sites');
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				// Verify added mapper data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				// Delete added Automation
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsWithMapperData();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
			});

			it('Verify user is able to update the automation policy', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7192');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Add Automation
				intelligentAlertsHelper.addAutomationOnIntelligentAletsWithMapperData('Devices');
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				// Verify added mapper data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				// Delete added Automation
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsWithMapperData();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
			});

			it('Verify when user - select values from dropdown and disable mapper toggle before save', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7170');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Toggle Mapper Button
				monitorsHelper.clickOnTheMapperToggleButton();
				// Save Monitor and verify
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
				//Verify the Mapper Data should be blank after toggle
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.verifyBlankSelectedMapperServiceBoard();
				monitorsHelper.verifyBlankSelectedMapperType();
				monitorsHelper.verifyBlankSelectedMapperSubType();
				monitorsHelper.verifyBlankSelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();	
			});

			it('Verify when user edit intellimon alert by selecting only board name', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7169');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();			
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();				
				//Verify the added Mapper Data 
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifyBlankSelectedMapperType();
				monitorsHelper.verifyBlankSelectedMapperSubType();
				monitorsHelper.verifyBlankSelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();	
			});

			it('Verify when user update intellimon alert by clearing one of the selected values', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7163');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				//Verify the added Mapper Data 
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				//Edit Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperTypeNewValue();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				//Verify Edited Mapper Data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperTypeWithNewValue();
				monitorsHelper.verifyBlankSelectedMapperSubType();
				monitorsHelper.verifyBlankSelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
			});

			it('Update existing intellimon alert having values selected in mapper dropdown with toggle off', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7162');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				//Verify the added Mapper Data 
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				//Edit Mapper Data
				monitorsHelper.selectMapperTypeNewValue();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				//Verify Edited Mapper Data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperTypeWithNewValue();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
			});

			it('Verify when user edit intellimon alert with mapper toggle off', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7167');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();		
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();			
				//Verify the added Mapper Data 
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				//Verify the added Mapper Data 			
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				//Verify the Mapper Data should be blank after toggle
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.verifyBlankSelectedMapperServiceBoard();
				monitorsHelper.verifyBlankSelectedMapperType();
				monitorsHelper.verifyBlankSelectedMapperSubType();
				monitorsHelper.verifyBlankSelectedMapperItem();
				//Delete or Remove Mapper Data
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();	
			});			

			it('Add and delete automation in intelligent alerts page at Sites Level with Mapper Data', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7221');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Add Automation
				intelligentAlertsHelper.addAutomationOnIntelligentAletsWithMapperData('Sites');
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				// Verify added mapper data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				// Delete added Automation
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsWithMapperData();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
			});

			it('Add and delete automation in intelligent alerts page at Endpoint Level with Mapper Data', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7222');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Add Automation
				intelligentAlertsHelper.addAutomationOnIntelligentAletsWithMapperData('Devices');
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				// Verify added mapper data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				// Delete added Automation
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsWithMapperData();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
			});

			it('Add and delete automation in intelligent alerts page at Company Level with Mapper Data', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7223');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Add Automation
				intelligentAlertsHelper.addAutomationOnIntelligentAletsWithMapperData('Companies');
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				// Verify added mapper data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				// Delete added Automation
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsWithMapperData();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
			});

			it('Add and delete automation in intelligent alerts page at DG Level with Mapper Data', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7224');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Add Automation
				intelligentAlertsHelper.addAutomationOnIntelligentAletsWithMapperData('Device Groups');
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				// Verify added mapper data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				// Delete added Automation
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsWithMapperData();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
			});

			it('Add and delete automation in intelligent alerts page at Partner Level with Mapper Data', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
				cy.allure().tms('ALERT-T7225');
				intelligentAlertsHelper.editIntelligentAlert();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				// Add Automation
				intelligentAlertsHelper.addAutomationOnIntelligentAletsAtPartnerLevelWithMapperData('All Resources');
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
				// Verify added mapper data
				intelligentAlertsHelper.editIntelligentAlert();
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				// Delete added Automation
				intelligentAlertsHelper.deleteAutomationFromIntelligentAlertsWithMapperData();
				monitorsHelper.clickOnTheMapperToggleButton();
				intelligentAlertsHelper.clickSaveButtonOnIntelligentAlerts();
			});

		});
	}
);
