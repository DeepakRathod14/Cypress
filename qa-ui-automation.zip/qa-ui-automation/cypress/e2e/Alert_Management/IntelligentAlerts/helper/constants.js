export const moduleMetaData = {
	name: 'Intelligent Alerts',
	customUser: 'user_csm',
	// customUser: 'user_technician',
	namePerSite: 'Company List',
};

export const lct = {
	'IntelligentAlertGrid': 'intelligent-alert-data-grid',
	'gridRow': '.MuiDataGrid-row',
	'totalRowCount': '.MuiDataGrid-rowCount',
	'selectColumn': '.MuiDataGrid-columnHeaderTitleContainer',
	'intelligentMonitorTitle': 'suspensions-label-typography',	
	'intelligentMonitorFamilyName': '.MuiDataGrid-cell > div',
	'intelligentMonitorDataCardCloseIcon': 'intelligent-alert-card-close-icon',
	'intelligentAlertCardViewDetails': 'intelligent-alert-details-card',
	'intelligentAlertTitleOnCardView': 'intelligent-alert-card-title-typography',
	'intelligentAlertSuspensionRuleButton': 'intelligent-alert-add-suspension-rule-button',
	'suspensionRuleButtonAtCompanyAndSiteLevel': 'add-suspension-rule-button',	
	'intelligentAlertDescriptionOnCardView': 'intelligent-alert-card-description-typography',
	'intelligentAlertFamilyOnCardView': 'intelligent-alert-card-family-typography',
	'intelligentAlertFamilyNameOnCardView': '.MuiTypography-root.MuiTypography-body2.css-tzb27g',
	'AlertsTab': 'tab-ialert',
	'PreviewAlertsTab': 'tab-i-preview-alert',
	'suspensionRuleButton': 'intelligent-alert-add-suspension-rule-button',
	'searchIcon': 'SearchOutlinedIcon',
	'filterIcon': 'FilterAltOutlinedIcon',
	'toggleColumnIcon': 'ViewColumnOutlinedIcon',
	'changeViewIcon': 'ViewStreamIcon',
	'downloadIcon': 'SaveAltIcon',
	'addAutomationButton': 'intelligent-alert-preview-add-automation-button',
	'editAutomationButton': 'EditOutlinedIcon',
	'deleteAutomationButton': 'DeleteOutlinedIcon',
	'automationSelectButton': 'task-list-modal-primary-button',
	'selectTargetButton': 'suspensions-select-target-button',
	'radioSelectionType': '.MuiFormControlLabel-root.MuiFormControlLabel-labelPlacementEnd.css-jnmj2f',
	'chkboxSelectTargetEndpoint': '.MuiDataGrid-cellCheckbox.MuiDataGrid-cell--withRenderer.MuiDataGrid-cell.MuiDataGrid-cell--textCenter.MuiDataGrid-withBorderColor > span > input',
	'btnSaveSelection': '.MuiButtonBase-root.MuiButton-root.MuiButton-contained',
	'btnSaveOnIntelligentAlerts': 'intelligent-alert-preview-save-button',
	'confirmDeleteAutomationButton': 'delete-modal-primary-button',
	'suspensionRuleOnDataCard': '.MuiListItem-root.MuiListItem-padding > a',
	'suspensionBackButton': 'suspensions-back-button',

	//Filter
	'selectListContains': '.MuiDataGrid-filterFormColumnInput select',
	'selectListOperator': '.MuiDataGrid-filterFormOperatorInput select',
	'selectValue': '.MuiDataGrid-filterFormValueInput select',	
	'selectLogicOperator': '.MuiDataGrid-filterFormLogicOperatorInput select',	
	'addFilterButton': '.MuiDataGrid-panelFooter button',
	'enterValue': '.MuiDataGrid-filterFormValueInput input',	
	'valuesDropdown': '.MuiDataGrid-filterFormValueInput div div div',

	'btnAddThresholdException': 'add-threshold-exception',
	'txtThresholdName': '.MuiFormControl-root.textInputFormControl > div >input',
	'monitorTab': '.MuiTabs-flexContainer > button[option=\'primary\']:nth-child(3)',
	'monitorTabDeviceDetailsPage': 'span[data-testid=\'monitoring\']',
	'monitorTabForCompany': '.MuiTabs-flexContainer > button[option=\'primary\']:nth-child(3)',
	'intelligentAlertsTab': '.MuiButtonBase-root.MuiTab-root',
	'siteName': '.MuiTypography-root.css-dzvr0m',
	'editIntelligentAlertsLabel': '.MuiTypography-root.MuiTypography-h4',

	//breadcrumb
	'IntelligentAlertListingBreadcrumb': 'alert-list-breadcrumb',
	'EndpointsTextInBreadcrumb': 'endpoints-label-typography',
	'AlertsTextInBreadcrumb': 'alerts-label-typography',
	'IntelligentAlertsTextInBreadcrumb': 'intellimon-list-label-typography',
	'IntelligentAlertsEditBreadcrumb': 'intelligent-alert-preview-breadcrumb',
	'IntelligentAlertsBreadcrumbLink': 'intelligent-alert-list-link',
};

export const txt = {

};

export const atr = {
	'successColor': 'rgb(0, 128, 0)',
	'errorColor': 'rgb(255, 0, 0)',
};