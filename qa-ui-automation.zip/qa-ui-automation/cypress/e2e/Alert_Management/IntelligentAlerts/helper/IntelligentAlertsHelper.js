import { ButtonHelper, ResourceSelectorHelper, CommonHelper, GridHelper, InputButtonHelper, DropDownHelper, InputFieldHelper, ToastHelper } from '../../../../fixtures';
import { lct, moduleMetaData } from './constants';


/**
 * Helper class for Intelligent Alerts module/
 * @class
 * @extends CommonHelper
 */
class IntelligentAlertsHelper extends CommonHelper {
	constructor() {

		// Define Helper Classes here
		super();
		this.button = new ButtonHelper();
		this.inputButton = new InputButtonHelper();
		this.inputField = new InputFieldHelper();
		this.toast = new ToastHelper();
		this.grid = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.resourceSelector = new ResourceSelectorHelper();
		this.commonHelper = new CommonHelper();
	}

	setupHooks() {
		beforeEach(() => {
			this.initialLandingSetup();
		});
	}

	setupHooksIntelligentAlertPerCompany() {		
		beforeEach(() => {
			cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');			
			cy.get('@alert-data').then((data) => {				
				companyName = data['Monitor.IntelligentAlertsCompanyName'];				
				siteName = data['Monitor.IntelligentAlertsSiteName'];
			});
			this.initialLandingSetupIntelligentAlertPerCompany();
		});
	}

	setupHooksIntelligentAlertPerSite() {
		beforeEach(() => {	
			cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');		
			this.initialLandingSetupIntelligentAlertPerSite();
		});
	}

	/**
	 * Sets up the test module metadata.
	 * @param {object} setupObject - The setup object to be set.
	 * @returns {void}
	 */
	setup = (setupObject) => {
		Cypress.env('module-metadata', setupObject);
	}

	initialLandingSetup() {
		this.navigateToPageOnCheck(moduleMetaData.name);
	}

	initialLandingSetupIntelligentAlertPerSite() {
		this.navigateToPageOnCheck(moduleMetaData.namePerSite);
		var companyName;
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		cy.get('@alert-data').then((data) => {			
			companyName = data['Monitor.IntelligentAlertsCompanyName'];
			this.grid.searchEntryInGrid(this.wrapDataTestId(lct.searchIcon), companyName);
			this.clickCompany(companyName);
			this.clickSite();
		});		
		this.clickMonitoringTab();
	}

	initialLandingSetupIntelligentAlertPerCompany() {
		this.navigateToPageOnCheck(moduleMetaData.namePerSite);		
		cy.wait(10000);
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var companyName;
		cy.get('@alert-data').then((data) => {				
			companyName = data['Monitor.IntelligentAlertsCompanyName'];			
			this.grid.searchEntryInGrid(this.wrapDataTestId(lct.searchIcon), companyName);
			this.clickCompany(companyName);
		});		
		this.clickMonitoringTabForCompany();
	}

	clickCompany = (name) => {		
		cy.contains(name).click();
	}

	checkEditIntelligentAlertsPageIsVisible = () => {
		this.clickOnFirstIntelligentMonitorForEdit();
		this.checkElementIsVisible(lct.editIntelligentAlertsLabel);
	};

	clickSite = () => {			
		this.getElementWithIndex(lct.siteName, 1).click();
	}

	clickMonitoringTabForCompany = () => {
		cy.get(lct.monitorTabForCompany).click();
	}

	clickMonitoringTab = () => {
		cy.get(lct.monitorTab).click();
	}

	clickMonitoringTabOnDeviceDetailPage = () => {
		cy.get(lct.monitorTabDeviceDetailsPage).click();
	}

	CheckAndNavigateToIntelligentAlertTab() {
		this.checkIntelligentAlertTabIsVisible();
		this.clickIntelligentAlertTab('Intelligent Alerts');
	}

	checkIntelligentAlertTabIsVisible = () => {
		this.checkElementIsVisibleWithText(lct.intelligentAlertsTab, 'Intelligent Alerts');
	}

	clickIntelligentAlertTab = (tabName) => {
		this.button.clickButtonWithText(lct.intelligentAlertsTab, tabName);
	}

	checkIntelligentAlertsGridIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(lct.IntelligentAlertGrid));
	}

	checkIntelligentAlertsListingBreadcrumbIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(lct.IntelligentAlertListingBreadcrumb));
	}

	checkEditIntelligentAlertsBreadcrumbIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(lct.IntelligentAlertsEditBreadcrumb));
	}

	clickIntelligentAlertsLinkInBreadcrumb() {
		this.button.clickButtonWithWait(this.wrapDataTestId(lct.IntelligentAlertsBreadcrumbLink), 5);
	}

	checkEndpointsTextIsVisibleInBreadcrumbIntelligentAlertListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(lct.EndpointsTextInBreadcrumb), 'Endpoints');
	}

	checkAlertsTextIsVisibleInBreadcrumbIntelligentAlertListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(lct.AlertsTextInBreadcrumb), 'Alerts');
	}

	checkIntelligentAlertsTextIsVisibleInBreadcrumbIntelligentAlertListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(lct.IntelligentAlertsTextInBreadcrumb), 'Intelligent Alerts');
	}

	checkDataCardforIntelligentAlerts() {
		this.clickOnFirstIntelligentMonitor();
		this.checkMetaDataCardExist();
		this.checkOnMetaDataCardDescriptionExistAndNotNull();
		this.verifyIntelligentMonitorTitle();
		this.verifyIntelligentMonitorFamilyName();
	}

	clickOnFirstIntelligentMonitor() {
		this.getFirstElement(lct.gridRow).click();
	}

	verifyIntelligentMonitorTitle() {
		cy.wait(5000);
		const dataTestId = this.wrapDataTestId(lct.intelligentMonitorTitle);
		cy.get(dataTestId).first().then(($value) => {
			this.getFirstElement(lct.gridRow).click();
			this.checkOnMetaDataCardTitleExistAndNotNull();
			cy.wait(5000);
			const dataTestId = this.wrapDataTestId(lct.intelligentAlertTitleOnCardView);
			cy.get(dataTestId).invoke('text').should('equal', $value.text());
			cy.get(dataTestId).invoke('css', 'white-space').should('eq', 'normal');
			const dataTestIdButton = this.wrapDataTestId(lct.intelligentMonitorDataCardCloseIcon);
			this.getElement(dataTestIdButton).click({ force: true });
		});
	}

	verifyIntelligentMonitorFamilyName() {
		cy.wait(5000);
		cy.get(lct.intelligentMonitorFamilyName).first().then(($value) => {			
			this.getFirstElement(lct.gridRow).click();
			this.checkOnMetaDataCardFamilyExistAndNotNull();
			cy.get(lct.intelligentAlertFamilyNameOnCardView).first().invoke('text').should('equal', $value.text());
			const dataTestIdButton = this.wrapDataTestId(lct.intelligentMonitorDataCardCloseIcon);
			this.getElement(dataTestIdButton).click({ force: true });
		});

	}

	checkMetaDataCardExist = () => {
		const dataTestId = this.wrapDataTestId(lct.intelligentAlertCardViewDetails);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	checkOnMetaDataCardTitleExistAndNotNull = () => {
		const dataTestId = this.wrapDataTestId(lct.intelligentAlertTitleOnCardView);
		this.getElementWithAssertion(dataTestId, 'exist');
		return this.getFieldValue(dataTestId).should('not.have.text', '');
	}

	checkOnMetaDataCardDescriptionExistAndNotNull = () => {
		const dataTestId = this.wrapDataTestId(lct.intelligentAlertDescriptionOnCardView);
		this.getFieldValue(dataTestId).should('not.have.text', '');
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	checkOnMetaDataCardFamilyExistAndNotNull = () => {
		const dataTestId = this.wrapDataTestId(lct.intelligentAlertFamilyOnCardView);
		this.getFieldValue(dataTestId).should('not.have.text', '');
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	getFieldValue = (element) => {
		return this.getElementWithIndex(element, 0);
	}

	checkSuspensionRuleButtonForIntelligentAlerts() {		
		this.SelectFirstRowOnIntelligentMonGrid();
		this.checkSuspensionRuleButtonExist();
	}

	checkSuspensionRuleButtonAtCompanyManagement() {		
		this.SelectFirstRowOnIntelligentMonGrid();
		this.checkSuspensionRuleButtonAtCompanyAndSiteLevel();

	}

	SelectFirstRowOnIntelligentMonGrid() {
		cy.wait(500);
		this.grid.selectRowByIndexWithCheckbox(lct.gridRow, 0);
	}

	checkSuspensionRuleButtonExist = () => {
		const dataTestId = this.wrapDataTestId(lct.intelligentAlertSuspensionRuleButton);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	checkSuspensionRuleButtonAtCompanyAndSiteLevel = () => {
		const dataTestId = this.wrapDataTestId(lct.suspensionRuleButtonAtCompanyAndSiteLevel);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}	

	addAutomationOnIntelligentAlets = (targetName) => {		
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var intelligentAlertName;
		cy.get('@alert-data').then((data) => {			
			intelligentAlertName = data['IntelligentAlerts.IntelligentAlertsName'];
			this.resourceSelector.searchResourceByName(lct.searchIcon, intelligentAlertName);
			cy.wait(5000);
		});		
		this.clickOnFirstIntelligentMonitorForEdit();
		this.clickOnAutomationButton();
		this.clickFirstAutomation();
		this.clickOnSelectAutomationButton();
		this.clickOnSelectTargetButton();
		this.checkInputButtonUsingLabel(lct.radioSelectionType, targetName);
		this.checkSearchedSite(lct.chkboxSelectTargetEndpoint);
		this.clickSaveSelectionButton();
		this.clickSaveButtonOnIntelligentAlerts();
	}

	addAutomationOnIntelligentAletsWithMapperData = (targetName) => {		
		this.clickOnAutomationButton();
		this.clickFirstAutomation();
		this.clickOnSelectAutomationButton();
		this.clickOnSelectTargetButton();
		this.checkInputButtonUsingLabel(lct.radioSelectionType, targetName);
		this.checkSearchedSite(lct.chkboxSelectTargetEndpoint);
		this.clickSaveSelectionButton();
		
	}

	addAutomationOnDefaultThreshold = () => {
		this.clickOnAutomationButton();
		this.clickFirstAutomation();
		this.clickOnSelectAutomationButton();
		this.clickSaveSelectionButton();
	}


	automationCardNotDisplayed = () => {
		this.commonHelper.checkElementNotExist(lct.addAutomationButton);
	}

	editIntelligentAlert = () => {		
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var intelligentAlertName;
		cy.get('@alert-data').then((data) => {			
			intelligentAlertName = data['IntelligentAlerts.IntelligentAlertsName'];
			this.resourceSelector.searchResourceByName(lct.searchIcon, intelligentAlertName);
			cy.wait(5000);
		});		
		this.clickOnFirstIntelligentMonitorForEdit();		
	}

	editIntelligentThreshold = () => {		
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var intelligentThresholdName;
		cy.get('@alert-data').then((data) => {			
			intelligentThresholdName = data['IntelligentAlerts.IntelligentThreshold'];
			this.resourceSelector.searchResourceByName(lct.searchIcon, intelligentThresholdName);
			cy.wait(5000);
		});		
		this.clickOnFirstIntelligentMonitorForEdit();		
	}

	addAutomationOnIntelligentAletsAtPartnerLevel = (targetName) => {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var intelligentAlertName;
		cy.get('@alert-data').then((data) => {			
			intelligentAlertName = data['IntelligentAlerts.IntelligentAlertsName'];
			this.resourceSelector.searchResourceByName(lct.searchIcon, intelligentAlertName);
			cy.wait(5000);
		});		
		this.clickOnFirstIntelligentMonitorForEdit();
		this.clickOnAutomationButton();
		this.clickFirstAutomation();
		this.clickOnSelectAutomationButton();
		this.clickOnSelectTargetButton();
		this.checkInputButtonUsingLabel(lct.radioSelectionType, targetName);		
		this.clickSaveSelectionButton();
		this.clickSaveButtonOnIntelligentAlerts();
	}

	addAutomationOnIntelligentAletsAtPartnerLevelWithMapperData = (targetName) => {		
		this.clickOnAutomationButton();
		this.clickFirstAutomation();
		this.clickOnSelectAutomationButton();
		this.clickOnSelectTargetButton();
		this.checkInputButtonUsingLabel(lct.radioSelectionType, targetName);		
		this.clickSaveSelectionButton();		
	}

	deleteAutomationFromIntelligentAlerts = () => {
		cy.wait(5000);
		this.clickOnDeleteAutomationButton();
		this.clickDeleteConfirmButton();
		this.clickSaveButtonOnIntelligentAlerts();
	}

	deleteAutomationFromIntelligentAlertsWithMapperData = () => {
		cy.wait(5000);		
		this.clickOnDeleteAutomationButton();
		this.clickDeleteConfirmButton();		
	}

	deleteAutomationFromIntelligentAlertsAtCompany = () => {
		cy.wait(5000);
		this.initialLandingSetupIntelligentAlertPerCompany();
		this.CheckAndNavigateToIntelligentAlertTab();
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var intelligentAlertName;
		cy.get('@alert-data').then((data) => {			
			intelligentAlertName = data['IntelligentAlerts.IntelligentAlertsName'];
			this.resourceSelector.searchResourceByName(lct.searchIcon, intelligentAlertName);
			cy.wait(5000);
		});	
		this.clickOnFirstIntelligentMonitorForEdit();
		cy.wait(10000);
		this.clickOnDeleteAutomationButton();
		this.clickDeleteConfirmButton();
		this.clickSaveButtonOnIntelligentAlerts();
	}

	deleteAutomationFromIntelligentAlertsAtSite = () => {
		cy.wait(5000);		
		this.initialLandingSetupIntelligentAlertPerSite();
		this.CheckAndNavigateToIntelligentAlertTab();
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var intelligentAlertName;
		cy.get('@alert-data').then((data) => {			
			intelligentAlertName = data['IntelligentAlerts.IntelligentAlertsName'];
			this.resourceSelector.searchResourceByName(lct.searchIcon, intelligentAlertName);
			cy.wait(5000);
		});
		this.clickOnFirstIntelligentMonitorForEdit();
		cy.wait(10000);
		this.clickOnDeleteAutomationButton();
		this.clickDeleteConfirmButton();
		this.clickSaveButtonOnIntelligentAlerts();
	}

	clickOnAutomationButton() {
		cy.wait(20000);
		this.button
			.clickButton(this.wrapDataTestId(lct.addAutomationButton));
	}

	checkAutomationButtonIsDisabled() {
		this.inputButton.isInputButtonDisabled(this.wrapDataTestId(lct.addAutomationButton));
	}

	clickOnAutomationButtonForDefaultThreshold() {
		this.button
			.clickButton(this.wrapDataTestId(lct.addAutomationButton));
	}

	clickOnAutomationButtonForCustomThreshold() {
		this.button
			.clickButtonWithIndex(this.wrapDataTestId(lct.addAutomationButton), 0);
	}

	clickOnAddThresholdButton() {
		this.button
			.clickButton(this.wrapDataTestId(lct.btnAddThresholdException));
	}

	clickOnEditAutomationButton() {
		this.button
			.clickButton(this.wrapDataTestId(lct.editAutomationButton));
	}

	clickOnDeleteAutomationButton() {
		cy.wait(5000);
		this.button
			.clickButton(this.wrapDataTestId(lct.deleteAutomationButton));
	}

	clickOnDeleteAutomationButtonForDefaultThreshold() {
		this.button
			.clickButtonWithIndex(this.wrapDataTestId(lct.deleteAutomationButton), 0);
	}

	clickOnDeleteAutomationButtonForCustomThreshold() {
		this.button
			.clickButtonWithIndex(this.wrapDataTestId(lct.deleteAutomationButton), 1);
	}

	clickDeleteConfirmButton = () => {
		return this.getDeleteConfirmButton().click();
	}

	getDeleteConfirmButton = () => {
		return this.getElement(this.wrapDataTestId(lct.confirmDeleteAutomationButton));
	}

	clickFirstAutomation() {
		this.getFirstElement(lct.gridRow).click();
	}

	clickOnSelectAutomationButton() {
		this.button
			.clickButton(this.wrapDataTestId(lct.automationSelectButton));
	}

	clickOnSelectTargetButton() {
		cy.wait(5000);
		this.button
			.clickButton(this.wrapDataTestId(lct.selectTargetButton));
	}

	clickOnFirstIntelligentMonitorForEdit() {
		this.button
			.clickButtonWithIndex(this.wrapDataTestId(lct.intelligentMonitorTitle), 0);
	}

	checkInputButtonUsingLabel = (label) => {
		return this.getElement(lct.radioSelectionType).contains(label).click();
	}

	checkSearchedSite = (siteSelector) => {
		cy.wait(500);
		this.getElementWithIndex(siteSelector, 0).click({ force: true });
	}

	clickSaveSelectionButton = () => {
		this.button
			.clickButtonWithText(lct.btnSaveSelection, 'Save Selection');
	}

	clickSaveButtonOnIntelligentAlerts = () => {
		cy.wait(5000);
		this.button
			.clickButton(this.wrapDataTestId(lct.btnSaveOnIntelligentAlerts));
	}

	checkSaveButtonIsEnabled = () => {
		this.inputButton.isInputButtonEnabled(this.wrapDataTestId(lct.btnSaveOnIntelligentAlerts));
	}

	navigateToSuspensionPage = () => {
		this.clickOnFirstIntelligentMonitor();
		this.checkMetaDataCardExist();
		cy.wait(7000);
		this.validateSuspensionRedirection();
		this.navigateBackToIntelligentAlertsPage();
	}

	validateSuspensionRedirection() {
		this.button
			.clickButtonWithIndex(lct.suspensionRuleOnDataCard, 1);
		cy.contains('Edit Suspension').should('be.visible');
	}

	navigateBackToIntelligentAlertsPage() {
		this.button.clickButton(this.wrapDataTestId(lct.suspensionBackButton));
	}

	addAutomationOnDefaultThreshold = () => {
		this.filterIntellimonAlertsForCustomThreshold();
		this.clickOnFirstIntelligentMonitorForEdit();
		cy.wait(10000);
		this.clickOnAutomationButtonForDefaultThreshold();
		this.clickFirstAutomation();
		this.clickOnSelectAutomationButton();
		cy.wait(5000);
		this.clickSaveButtonOnIntelligentAlerts();
	}

	addAutomationOnCustomThreshold = () => {
		this.filterIntellimonAlertsForCustomThreshold();
		this.clickOnFirstIntelligentMonitorForEdit();
		cy.wait(10000);
		this.clickOnAddThresholdButton();
		this.typeName();
		this.clickOnSelectTargetButton();
		this.checkInputButtonUsingLabel(lct.radioSelectionType, 'Companies');
		this.checkResource();
		this.clickSaveSelectionButton();
		this.clickOnAutomationButtonForCustomThreshold();
		this.clickFirstAutomation();
		this.clickOnSelectAutomationButton();
		cy.wait(5000);
		this.clickSaveButtonOnIntelligentAlerts();
	}

	deleteAutomationOnDefaultThreshold = () => {
		this.filterIntellimonAlertsForCustomThreshold();
		cy.wait(5000);
		this.clickOnFirstIntelligentMonitorForEdit();
		this.clickOnDeleteAutomationButtonForDefaultThreshold();
		this.clickDeleteConfirmButton();
		this.clickSaveButtonOnIntelligentAlerts();
	}

	deleteAutomationOnCustomThreshold = () => {
		this.filterIntellimonAlertsForCustomThreshold();
		cy.wait(5000);
		this.clickOnFirstIntelligentMonitorForEdit();		
		this.clickOnDeleteAutomationButtonForCustomThreshold();
		this.clickDeleteConfirmButton();
		this.clickOnDeleteAutomationButtonForDefaultThreshold();
		this.clickDeleteConfirmButton();
		this.clickSaveButtonOnIntelligentAlerts();
	}

	filterIntellimonAlertsForCustomThreshold = () => {
		this.clickFilterIcon();
		cy.wait(5000);
		this.selectDropdownValue(
			lct.selectListContains,
			0,
			'Configurable'
		);
		this.selectDropdownValue(
			lct.selectListOperator,
			0,
			'is'
		);
		this.selectDropdownValue(
			lct.selectValue,
			0,
			'true'
		);

	}

	filterIntellimonAlertsForFirstName = () => {
		this.clickFilterIcon();
		cy.wait(5000);
		this.selectDropdownValue(
			lct.selectListContains,
			0,
			'Name'
		);
		this.selectDropdownValue(
			lct.selectListOperator,
			0,
			'contains'
		);
		cy.wait(2000);
		this.getElement(lct.enterValue).type('system');
		
	}

	filterIntellimonAlertsForSecondName = () => {		
		cy.wait(2000);
		this.selectDropdownValue(
			lct.selectListContains,
			1,
			'Name'
		);
		this.selectDropdownValue(
			lct.selectListOperator,
			1,
			'contains'
		);
		cy.wait(2000);
		this.getElementWithIndex(lct.enterValue, 1).type('Error');		
	}

	filterSelectLogicalAndOperator = () => {		
		cy.wait(2000);
		this.selectDropdownValue(
			lct.selectLogicOperator,
			1,
			'And'
		);
	}

	filterSelectLogicalOrOperator = () => {		
		cy.wait(2000);
		this.selectDropdownValue(
			lct.selectLogicOperator,
			1,
			'Or'
		);
	}

	filterSelectColumnName = (columnName) => {
		this.clickFilterIcon();
		cy.wait(2000);
		this.selectDropdownValue(
			lct.selectListContains,
			0,
			columnName
		);
	}

	validateDropdownValuesAreSorted = () => {
		cy.wait(2000);
		cy.get(lct.selectValue).find('option').then(($options) => {
			const dropdownValues = $options.toArray().map((o) => o.text);
			const sortedDropdownValues = [...dropdownValues].sort();			
			expect(dropdownValues).to.deep.equal(sortedDropdownValues);
		});
		
	}

	filterClickValuesDropdown = () => {
		cy.get(lct.valuesDropdown).click();
		cy.wait(2000);
	}

	clickAddFilterButton = () => {
		this.button.clickButtonWithText(lct.addFilterButton, 'Add filter');
		cy.wait(2000);
	}

	checkAlertNameExist = (alertName) => {		
		return this.getElementWithTextAndAssertion(lct.gridRow, alertName, 'exist');
	}
	
	checkAlertName1Exist = () => {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var alertName;
		cy.get('@alert-data').then((data) => {			
			alertName = data['IntelligentAlerts.IntelligentThreshold'];
			this.getElementWithTextAndAssertion(lct.gridRow, alertName, 'exist');			
		});		
	}

	checkAlertName2Exist = () => {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var alertName;
		cy.get('@alert-data').then((data) => {			
			alertName = data['IntelligentAlerts.IntelligentAlertsName2'];
			this.getElementWithTextAndAssertion(lct.gridRow, alertName, 'exist');			
		});			
	}

	clickFilterIcon = () => {
		return this.getFilterIcon().click();
	}

	getFilterIcon = () => {
		const dataTestId = this.wrapDataTestId(lct.filterIcon);
		return this.getElement(dataTestId);
	}

	selectDropdownValue = (dropdownSelector, index, value) => {
		return this.dropdownHelper.selectDropdownValue(dropdownSelector, index, value);
	}

	typeName = () => {
		const thresholdName = this.getFakeName();
		return this.getNameField().type(thresholdName);
	}

	getNameField = () => {
		return this.getElementWithIndex(lct.txtThresholdName, 0);
	}

	checkInputButtonUsingLabel = (labelSelector, label) => {
		return this.getElement(labelSelector).contains(label).click();
	}

	checkResource = () => {
		cy.wait(500);
		this.getElementWithIndex(lct.chkboxSelectTargetEndpoint, 1).click({ force: true });
	}

	getRowByIndex = (index) => {
		return this.grid.getRowByIndex(lct.gridRow, index);
	}

	validateFirstRowExists = () => {
		return this.grid.validateFirstRowExists(lct.gridRow);
	}

	sortColumn = (columnIndex) => {
		return this.grid.sortColumn(lct.selectColumn, columnIndex);
	}

}

export default IntelligentAlertsHelper;