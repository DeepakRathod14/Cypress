import { ApiHelper } from '../../../fixtures';
import { api } from './constants';

class AlertingApi {
	constructor() {

		// Define Helper Classes here
		this.api = new ApiHelper();
	}

	setup() {

		cy.get('@currUserData').then((user) => {
			Cypress.env('alertingPartnerId', user.partnerId);
			Cypress.env('alertingUid', user.email);
		});

		cy.fixture(`data/${this.api.env}/api.json`).then((apiList) => {
			const baseAlertingUrl = apiList['Alerting'];
			const baseCEUrl = apiList['CorrelationEngine'];

			// Define constants here
			const partnerId = Cypress.env('alertingPartnerId');
			const baseCEPartnerUrl = baseCEUrl + api.v2Partner + `/${partnerId}`;
			const baseAlertingPartnerUrl = baseAlertingUrl + api.v2Partner + `/${partnerId}`;
			const jwtKey = 'jwt';

			// Check and Generate JWT token
			const jwtToken = Cypress.env(jwtKey);
			if (!jwtToken) {
				this.api.generateJWTToken();
			}

			cy.wrap({
				//Define common urls here
				customMonitorUrl: baseCEPartnerUrl + api.customMonitors,
				complexMonitorUrl: baseCEPartnerUrl + api.complexMontiors,
				suspensionUrl: baseAlertingPartnerUrl + api.suspension,
			}).as('urlConfig');
		});

		cy.get('@urlConfig').then((config) => {
			return {
				...config,
				headers: {
					'Content-Type': 'application/json',
					'uid': Cypress.env('alertingUid'),
					'Authorization': 'Bearer ' + Cypress.env('jwt'),
				}
			};
		}).as('setupConfig');
	}

	/**
	 * Function to get partner custom monitors.
	 */
	listPartnerCustomMonitors = () => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.getUrl({
				apiUrl: config.customMonitorUrl,
				headers: config.headers,
			});
		});
	};

	/**
	 * Function to create a new custom monitor.
	 * @param {object} body - Body for the request.
	 */
	createNewCustomMonitor = ({ body }) => {
		return cy.get('@setupConfig').then((config) => {
			return this.api.postUrl({
				apiUrl: config.customMonitorUrl,
				headers: config.headers,
				body: body,
			});
		});
	};

	/**
	 * Function to enable/disable custom monitor using monitor ids.
	 * @param {string} monitorIds - Monitor ids to enable/disable.
	 */
	enableDisableCustomMonitorUsingMonitorIds = ({ monitorIds, body }) => {
		return this.api.putUrl({
			apiUrl: this.customMonitorUrl + `?monitorIDs=${monitorIds}`,
			headers: this.customMonitorHeaders,
			body: body,
		});
	};

	/**
	 * Function to delete custom monitor using monitor ids.
	 * @param {string} monitorIds - Monitor ids to delete.
	 */
	deleteCustomMonitorUsingIds = ({ monitorIds }) => {
		return this.api.deleteUrl({
			apiUrl: this.customMonitorUrl + `?monitorIDs=${monitorIds}`,
			headers: this.customMonitorHeaders,
		});
	};

	/**
	 * Function to get custom monitor using monitor id.
	 * @param {string} monitorId - Monitor id to get.
	 */
	getCustomMonitor = ({ monitorId }) => {
		return this.api.getUrl({
			apiUrl: this.customMonitorUrl + `/${monitorId}`,
			headers: this.customMonitorHeaders,
		});
	};

	/**
	 * Function to update custom monitor using monitor id.
	 * @param {string} monitorId - Monitor id to update.
	 * @param {object} body - Body for the request.
	 */
	updateCustomMonitor = ({ monitorId, body }) => {
		return this.api.putUrl({
			apiUrl: this.customMonitorUrl + `/${monitorId}`,
			headers: this.customMonitorHeaders,
			body: body,
		});
	};

	/**
	 * Function to delete custom monitor using monitor id.
	 * @param {string} monitorId - Monitor id to delete.
	 */
	deleteCustomMonitor = ({ monitorId }) => {
		return this.api.deleteUrl({
			apiUrl: this.customMonitorUrl + `/${monitorId}`,
			headers: this.customMonitorHeaders,
		});
	};

	/**
	 * Function to get partner complex monitors.
	 */
	listPartnerComplexMoniors = () => {
		return this.api.getUrl({
			apiUrl: this.complexMonitorUrl,
			headers: this.complexMonitorHeaders,
		});
	};

	/**
	 * Function to create a new complex monitor.
	 * @param {object} body - Body for the request.
	 */
	createNewComplexMonitor = ({ body }) => {
		return this.api.postUrl({
			apiUrl: this.complexMonitorUrl,
			headers: this.complexMonitorHeaders,
			body: body,
		});
	};

	/**
	 * Function to get complex monitor using monitor id.
	 * @param {string} monitorId - Monitor id to get.
	 */
	getComplexMonitor = ({ monitorId }) => {
		return this.api.getUrl({
			apiUrl: this.complexMonitorUrl + `/${monitorId}`,
			headers: this.complexMonitorHeaders,
		});
	}

	/**
	 * Function to update complex monitor using monitor id.
	 * @param {string} monitorId - Monitor id to update.
	 * @param {object} body - Body for the request.
	 */
	updateComplexMonitor = ({ monitorId, body }) => {
		return this.api.putUrl({
			apiUrl: this.complexMonitorUrl + `/${monitorId}`,
			headers: this.complexMonitorHeaders,
			body: body,
		});
	};

	/**
	 * Function to delete complex monitor using monitor id.
	 * @param {string} monitorId - Monitor id to delete.
	 */
	deleteComplexMonitor = ({ monitorId }) => {
		return this.api.deleteUrl({
			apiUrl: this.complexMonitorUrl + `/${monitorId}`,
			headers: this.complexMonitorHeaders,
		});
	};

	/**
	 * Function to create a new suspension.
	 * @param {object} body - Body for the request.
	 */
	createSuspension = ({ body }) => {
		return cy.get('@setupConfig').then((config) => {
			console.log('here');
			return this.api.postUrl({
				apiUrl: config.suspensionUrl,
				headers: {
					'Content-Type': 'application/json'
				},
				body: body,
			});
		});
	};

	/**
	 * Function to get all suspension rules.
	 */
	listPartnerSuspenionRules = () => {
		return this.api.getUrl({
			apiUrl: this.suspensionUrl,
			headers: this.suspensionHeaders,
		});
	};

	/**
	 * Function to get suspension rule using rule id.
	 * @param {string} ruleId - Rule id to get.
	 */
	getSuspensionRule = ({ ruleId }) => {
		return this.api.getUrl({
			apiUrl: this.suspensionUrl + `/${ruleId}`,
			headers: this.suspensionHeaders,
		});
	};

	/**
	 * Function to update suspension rule using rule id.
	 * @param {string} ruleId - Rule id to update.
	 */
	updateSuspensionRule = ({ ruleId, body }) => {
		return this.api.putUrl({
			apiUrl: this.suspensionUrl + `/${ruleId}`,
			headers: this.suspensionHeaders,
			body: body,
		});
	};

	/**
	 * Function to delete suspension rule using rule id.
	 * @param {string} ruleId - Rule id to delete.
	 */
	deleteSuspensionRule = ({ ruleId }) => {
		return this.api.deleteUrl({
			apiUrl: this.suspensionUrl + `/${ruleId}`,
			headers: this.suspensionHeaders,
		});
	};
}

export default AlertingApi;