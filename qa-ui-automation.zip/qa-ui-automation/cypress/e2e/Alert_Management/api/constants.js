export const api = {
	v1Partner: '/v1/partners',
	v2Partner: '/v2/partners',
	customMonitors: '/custom-monitors',
	complexMontiors: '/complex-monitors',
	suspension: '/rules',
	dynamicGroups: '/dynamic-groups',
};