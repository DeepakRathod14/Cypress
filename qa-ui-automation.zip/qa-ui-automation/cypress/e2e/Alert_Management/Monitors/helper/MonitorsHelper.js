import MonitorDataHelper from './MonitorDataHelper';
import { fieldIndex, ltr, moduleMetaData, txt } from './constants';
import { lct } from '../helper/constants';
import {
	ButtonHelper, CommonHelper, DropDownHelper, GridHelper, InputButtonHelper,
	InputFieldHelper, ResourceSelectorHelper, ToastHelper
} from '../../../../fixtures';

import { rqt } from '../../../../constants';
import AlertingApi from '../../api/AlertingApi';

/**
 * Helper class for Custom Monitor module/
 * @class
 * @extends CommonHelper
 */
class MonitorsHelper extends CommonHelper {
	constructor() {

		// Define Helper Classes here
		super();
		this.button = new ButtonHelper();
		this.inputButton = new InputButtonHelper();
		this.inputField = new InputFieldHelper();
		this.toast = new ToastHelper();
		this.dropDown = new DropDownHelper();
		this.grid = new GridHelper();
		this.resourceSelector = new ResourceSelectorHelper();
		this.apiHelper = new AlertingApi();
		this.commonHelper = new CommonHelper();
		this.dataHelper = new MonitorDataHelper();

		this.getMonitorsResponse = null;
	}

	/**
	 * All SETUP methods
	 */

	setupApiIntercepts() {
		before(() => {
			this.interceptApi();
		});
	}

	setupHooks() {
		beforeEach(() => {
			this.initialLandingSetup();
		});
	}

	setupHooksMonitorFromDeviceDetails() {
		beforeEach(() => {
			// this.setup(moduleMetaData.name);
			// loading user data using cy.fixture
			this.navigateToPageOnCheck(moduleMetaData.deviceDetails);
			cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
			this.initialLandingSetupMonitorsFromDeviceDetails();
		});
	}

	initialLandingSetupMonitorsFromDeviceDetails() {
		var deviceName;
		cy.get('@alert-data').then((data) => {
			deviceName = data['Monitor.DeviceName'];
			this.getElement(ltr.searchDevice).type(deviceName).type('{enter}');
			this.clickDevice(deviceName);
		});
	}

	setupHooksMonitorPerSite() {
		beforeEach(() => {
			cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
			this.initialLandingSetupSuspensionPerSite();
		});
	}

	initialLandingSetupSuspensionPerSite() {
		this.navigateToPageOnCheck(moduleMetaData.namePerSite);
		var companyName;
		cy.get('@alert-data').then((data) => {			
			companyName = data['Monitor.CompanyName'];
			this.grid.searchEntryInGrid(this.wrapDataTestId(ltr.searchIcon), companyName);
			this.clickCompany(companyName);
			this.clickSite();
		});
		this.clickMonitoringTab();
	}

	checkSearchedSite = (siteSelector) => {
		this.getElementWithIndex(siteSelector, 0).click({ force: true });
	}

	clickSelectTargetButton() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.selectTargetButton));
	}

	selectTargetResourceAndSave(target) {
		this.clickSelectTargetButton();
		this.checkInputButtonUsingLabel(ltr.radioSelectionType, target);
		this.checkSearchedSite(ltr.chkboxSelectTargetEndpoint);
		this.resourceSelector.saveResources();
	}

	selectTargetResourceAtCompanyLevel(target) {
		this.clickSelectTargetButton();
		this.checkInputButtonUsingLabel(ltr.radioSelectionType, target);
		this.resourceSelector.saveResources();
	}

	selectComplexMonitorCondition(condition) {
		this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(ltr.complexMonitorCondition),
				ltr.paperRoot,
				condition
			);
	}

	selectComplexMonitorConditionReversal(conditionReversal) {
		this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(ltr.complexMonitorConditionInverse),
				ltr.paperRoot,
				conditionReversal
			);
	}

	clickCompany = (name) => {
		cy.contains(name).click();
	}

	clickSite = () => {
		this.getElementWithIndex(ltr.siteName, 1).click();
	}

	clickDevice = (name) => {
		this.getElementWithText(this.wrapDataTestId(ltr.deviceName), name).as('btn').click({ force: true });
	}

	clickMonitoringTab = () => {
		cy.get(ltr.monitorTabForCompany).click();
	}

	cleanupHooks() {
		after(() => {
			this.grid
				.getElementWithIndex(ltr.gridRow, 0)
				.should('be.visible');
			this.grid.searchEntryInGrid(this.wrapDataTestId(ltr.searchIcon), 'FAKE_');
			this.getElement(this.wrapDataTestId(ltr.grid)).then(($grid) => {
				if ($grid.find(ltr.gridRow).length > 0) {
					this.checkSelectAllCheckboxOnGrid();
					this.clickOnDeleteButton();
					this.clickOnDeleteButtonOnModal();
				}
			});
			this.closeOpenElements(this.wrapDataTestId(ltr.closeIcon));
		});
		afterEach(() => {
			this.closeOpenElements(this.wrapDataTestId(ltr.closeIcon));
			this.closeOpenElements(this.wrapDataTestId(ltr.cancelButton));
		});
	}

	setupApiHooks() {
		beforeEach(() => {
			this.apiHelper.setup();
		});
	}

	interceptApi() {
		this.apiHelper.api.setAliasForApi(rqt.Get, '**/monitors?noCache=*', 'getMonitors').then(() => {
			this.isGetMonitorLoaded = false;
		});
		this.apiHelper.api.setAliasForApi(rqt.Put, '**/monitors', 'updateMonitor');
	}

	/**
	 * All CREATE methods
	 */

	createMonitorUsingApiWithType(type, fields) {
		switch (type) {
			case txt.cpu:
				this.createMonitorUsingApi(fields);
				break;
			default:
				break;
		}
	}

	createMonitorTestDataBasedOnType(type) {
		let testData;

		switch (type) {
			case txt.cpu:
				testData = this.dataHelper
					.generateBaseData()
					.setCpuTypeData('less', '25', '5')
					.getData();
				break;
			case txt.service:
				testData = this.dataHelper
					.generateBaseData()
					.setServiceTypeData('Sentinel Agent', 'stopped', 'true')
					.getData();
				break;
			case txt.customField:
				testData = this.dataHelper
					.generateBaseData()
					.setCustomFieldTypeData()
					.getData();
				break;
			default:
				testData = this.dataHelper
					.generateBaseData()
					.createMonitorTestData(type)
					.getData();
		}

		this.setData(testData);
	}

	setData(testData) {
		this.testData = testData;
	}

	getData() {
		return this.testData;
	}

	createMonitorUsingApi(fields, shouldAddSuspension) {
		const body = this.dataHelper.generateCpuTypeCustomMonitorDataForApiCall().setDataForApi(fields).getDataForApi();

		this.apiHelper.createNewCustomMonitor({ body: body }).then((response) => {
			if (response.status === 201) {
				// check if suspension needs to be added
				if (shouldAddSuspension) {
					const monitorId = response.body.id;
					const suspensionRuleBody = this.dataHelper.generateSuspensionRuleDataForApiCall().setSuspensionMetadata({
						customrules: [monitorId],
						partnerid: Cypress.env('alertingPartnerId'),
					}).getSuspensionData();
					cy.wrap(suspensionRuleBody).as('suspensionRuleBody');
					this.apiHelper.createSuspension({ body: suspensionRuleBody }).then((response) => {
						if (response.status === 201) {
							cy.log('Suspension created successfully');
						}
					});
				}
			}
		});
	}

	/**
	 * All SETVALUES methods
	 */

	setValuesForCpuTypeMonitor(cpuUtilization, cpuUsage, cpuMinute) {
		this.getDropDownAndSelectValue(ltr.cpuUtilization, cpuUtilization);
		this.getDropDownAndSelectValue(ltr.cpuUsage, cpuUsage);
		this.getDropDownAndSelectValue(ltr.cpuMinute, cpuMinute);
	}

	setValuesForServiceTypeMonitor(serviceName, serviceStatus, automaticallyStartServiceWhenStopped) {
		this.getDropDownAndSelectValue(ltr.serviceName, serviceName);
		this.getDropDownAndSelectValue(ltr.serviceStatus, serviceStatus);
		automaticallyStartServiceWhenStopped
			? null
			: this.button
				.clickButton(this.wrapDataTestId(ltr.serviceToggle));
	}

	setValueForCustomFieldTypeMonitor(customFieldType, fields) {
		this.getDropDownAndSelectValue(ltr.customFieldType, customFieldType);
		this.dropDown
			.getDropDownAndSelectFirstValue(this.wrapDataTestId(ltr.customFieldName), ltr.paperRoot);

		if (customFieldType === txt.dropdown) {
			this.getDropDownAndSelectValue(ltr.customFieldDropdownFilter, fields.filter);
			if (fields.condition === 'Contains' || fields.condition === 'Does not contain') {
				this.getDropDownAndSelectValue(ltr.customFieldDropdownCondition, fields.condition);
			}
			this.inputField
				.typeIntoInputField('input[placeholder="Enter Value"]', this.getFakeValue(5));
		}
	}

	/**
	 * All CHECK methods
	 */

	checkMonitorsGridIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(ltr.grid));
	}

	checkSelectAllCheckboxOnGrid() {
		this.grid
			.getElementWithIndex(ltr.gridRow, 0)
			.should('be.visible');
		this.getElement(ltr.columnHeaders).find('input').click({ force: true });
	}

	checkDownloadButtonDisplayed() {
		this.checkElementIsVisible(this.wrapDataTestId(ltr.downloadButton));
	}

	clickDownloadButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.downloadButton));
	}

	verifyFileDownloaded() {
		cy.verifyDownload('.csv', { contains: true });
	}


	checkIfNameFieldHasDefaultSortingEnabled(order) {
		this.grid.checkIfSortingArrowIsVisibleOnGivenField('Name', fieldIndex, order);
	}

	/**
	 * All click Methods
	 */

	clickOnCreateMonitorButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.createButton));
	}

	clickOnTheMapperToggleButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.mapperToggleButton));
	}

	clickOnTheComplexMonitorsTicketResolutionToggle() {
		this.button.clickButton(this.wrapDataTestId(ltr.complexMonitorsTicketResolutionToggle));
	}

	clickOnApplicationTab() {
		this.button.clickButton(this.wrapDataTestId(ltr.tabNameApplications));
	}

	clickOnCreateMonitorActionForApplication() {
		this.getElementWithIndex(ltr.createMonitorActionApplication, 1).as('btn').click({ force: true });

	}

	clickOnCreateMonitorActionForService() {
		this.getElementWithIndex(this.wrapDataTestId(ltr.createMonitorAction), 3).as('btn').click({ force: true });
	}

	clickOnServiceTab() {
		this.button.clickButton(this.wrapDataTestId(ltr.tabNameServices));
	}

	clickOnSelectTargetButton() {
		cy.contains('Select Targets').scrollIntoView();
		this.button
			.clickButtonWithAssertion(this.wrapDataTestId(ltr.selectTargetButton), 'be.visible');
	}

	clickOnSaveChanges() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.saveButton));
	}

	clickOnDeleteButton() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.deleteButton));
	}

	clickOnDeleteButtonOnModal() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.deleteButtonModal));
	}

	clickOnAutomationButton() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.addAutomationButton));
	}

	clickOnEditAutomationButton() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.editAutomationButton));
	}

	clickFirstAutomation() {
		this.getFirstElement(ltr.gridRow).click();
	}

	clickOnSelectAutomationButton() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.automationSelectButton));
	}

	clickOnCancelAutomationButton() {
		this.button
			.clickButton(this.wrapDataTestId(ltr.automationCancelButton));
	}

	clickOnMonitorName(name) {
		this.getElement(this.wrapDataTestId(ltr.grid))
			.contains(name)
			.should('be.visible')
			.click();
	}

	/**
	 * All TYPE & TOGGLE Methods
	 */

	typeMonitorName(name) {
		this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.nameField), name);
	}

	typeMonitorDescription(description) {
		this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.descriptionField), description);
	}

	toggleMonitorStatus(toggle) {
		this.button
			.clickButton(this.wrapDataTestId(toggle ? ltr.enableButton : ltr.disableButton));
	}

	toggleTicketResolution(enable) {
		enable ? null : this.button
			.clickButton(this.wrapDataTestId(ltr.ticektResolutionToggle));
	}

	/**
	 * All select Methods
	 */

	selectMonitorType(type) {
		this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(ltr.typeDropdown),
				ltr.paperRoot,
				type
			);
	}

	verifySelectedMonitorType(type) {
		this.dropDown
			.getDropDownAndVerifySelectedValue(
				this.wrapDataTestId(ltr.typeDropdown),
				ltr.paperRoot,
				type
			);
	}

	verifySelectedApplicationStatus() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ApplicationStatusForDDP'];
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.appStatus),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifySelectedApplicationNameFilter() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AppNameFilter'];
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.applicationName),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifySelectedServiceState() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.serviceStatus'];
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.serviceStatus),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifySelectedServiceConditionName() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.serviceConditionName'];
			this.inputField.getInputFieldValue(ltr.serviceNameDeviceDetails).should('contain', testdata);
		});
	}

	verifyAppNameField() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AppNameValue'];
			this.inputField.getInputFieldValue(ltr.appNameDeviceDetails).should('contain', testdata);
		});
	}

	verifyServiceNameField() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ServiceMonitorName'];
			this.inputField.getInputFieldValue(ltr.nameFieldDeviceDetails).should('contain', testdata);
		});
	}

	selectApplicationStatus() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ApplicationStatus'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.applicationStatus),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectApplicationStatusReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ApplicationStatusReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.applicationStatusReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectApplicationName() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ApplicationName'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.applicationName),
					ltr.paperRoot,
					testdata
				);
		});

	}

	selectApplicationNameReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ApplicationNameReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.applicationNameReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectIntegrationVendorName() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.IntegrationVendorName'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.integrationVendorName),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectIntegrationVendorNameReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.IntegrationVendorNameReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.integrationVendorNameReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectIntegrationFieldName() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.IntegrationFieldName'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.integrationFieldName),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectIntegrationFieldNameReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.IntegrationFieldNameReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.integrationFieldNameReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectEventLevelSeverity() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.EventLevelSeverity'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.eventLevelSeverity),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectEventLevelSeverityReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.EventLevelSeverityReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.eventLevelSeverityReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPerformanceCounterType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PerformanceCounterType'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.performanceCounterType),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPerformanceCounterObject() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PerformanceCounterObject'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.performanceCounterObject),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPerformanceCounter() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PerformanceCounter'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.performanceCounter),
					ltr.paperRoot,
					testdata
				);
		});
	}

	typePerformanceCounterValue() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PerformanceCounterValue'];
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.performanceCounterValue), testdata);
		});
	}

	selectPerformanceCounterTypeReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PerformanceCounterTypeReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.performanceCounterTypeReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPerformanceCounterObjectReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PerformanceCounterObjectReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.performanceCounterObjectReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPerformanceCounterReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PerformanceCounterReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.performanceCounterReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPortType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortType'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.portType),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPortState() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortState'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.portState),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPortVerifyPeriod() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortVerifyPeriod'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.portVerifyPeriod),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPortTrigger() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortTrigger'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.portTrigger),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPortTypeReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortTypeReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.portTypeReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectPortStateReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortStateReverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.portStateReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectMapperServiceBoard() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperServiceBoard'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.mapperServiceBoard),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectMapperType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperType'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.mapperType),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectMapperTypeNewValue() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperTypeNewValue'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.mapperType),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectMapperSubType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperSubType'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.mapperSubType),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectMapperItem() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperItem'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.mapperItem),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectComplexConditionType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ConditionType'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.complexConditionType),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectComplexConditionInverseType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ConditionType'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.complexConditionTypeInverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectComplexConditionServiceName() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ServiceName'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.complexMonitorServiceName),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectComplexConditionServiceNameInverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ServiceName'];
			this.dropDown
				.getDropDownAndSelectValue(
					ltr.complexMonitorServiceNameInverse,
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectComplexConditionServiceState() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ServiceState'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.complexMonitorServiceState),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectComplexConditionServiceStateInverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ServiceStateInverse'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.complexMonitorServiceStateInverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	verifySelectedMapperServiceBoard() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperServiceBoard'];
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperServiceBoard),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifyBlankSelectedMapperServiceBoard() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then(() => {
			testdata = 'None';			
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperServiceBoard),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifySelectedMapperType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperType'];			
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperType),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifyBlankSelectedMapperType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then(() => {
			testdata = 'None';			
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperType),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifySelectedMapperTypeWithNewValue() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperTypeNewValue'];			
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperType),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifySelectedMapperSubType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperSubType'];			
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperSubType),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifyBlankSelectedMapperSubType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then(() => {
			testdata = 'None';			
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperSubType),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifySelectedMapperItem() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MapperItem'];			
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperItem),
					ltr.paperRoot,
					testdata
				);
		});

	}

	verifyBlankSelectedMapperItem() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then(() => {
			testdata = 'None';			
			this.dropDown
				.getDropDownAndVerifySelectedValue(
					this.wrapDataTestId(ltr.mapperItem),
					ltr.paperRoot,
					testdata
				);
		});

	}

	checkMapperToggleButtonExist = () => {
		const dataTestId = this.wrapDataTestId(ltr.mapperToggleButton);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	checkMapperToggleButtonNotExist = () => {
		this.commonHelper.checkElementNotExist(ltr.mapperToggleButton);
	}

	checkMapperServiceBoardExist = () => {
		const dataTestId = this.wrapDataTestId(ltr.mapperServiceBoard);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	checkMapperTypeExist = () => {
		const dataTestId = this.wrapDataTestId(ltr.mapperType);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	checkMapperToggleButtonUncheckedByDefault = () => {
		const dataTestId = this.wrapDataTestId(ltr.mapperToggleButton);
		return this.getElement(ltr.mapperToggleButtonStatus).parents(dataTestId).should('not.exist');
		// return this.getElement(ltr.mapperToggleButton).should('not.be.checked');
	}

	checkMapperServiceBoardExistAsMandatoryField = () => {
		const dataTestId = this.wrapDataTestId(ltr.mapperServiceBoard);
		return this.getElement(ltr.mapperServiceBoardMandatoryField).parent(dataTestId).should('exist');
	}

	checkMapperServiceBoardExistWithAstericMark = () => {
		const dataTestId = this.wrapDataTestId(ltr.mapperServiceBoard);
		return this.getElement(ltr.mapperServiceBoardAstericMark).siblings(dataTestId).should('exist');
	}

	checkMapperSubTypeExist = () => {
		const dataTestId = this.wrapDataTestId(ltr.mapperSubType);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	checkMapperItemExist = () => {
		const dataTestId = this.wrapDataTestId(ltr.mapperItem);
		return this.getElementWithAssertion(dataTestId, 'exist');
	}

	selectProcessState() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ProcessState'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.processState),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectProcessDuration() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ProcessDuration'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.processDuration),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectRegistry() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.Registry'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.registry),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectRegistryOperator() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RegistryOperator'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.registryOperator),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectRegistryOperatorReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RegistryOperatorReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.registryOperatorReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectRegistryReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RegistryReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.registryReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectSnmpMetricType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.SnmpMetricType'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.snmpMetricType),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectSnmpDeviceAvailability() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.SnmpDeviceAvailability'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.snmpDeviceAvailability),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectSnmpUnit() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.SnmpUnit'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.snmpUnit),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectSnmpTimeWindowMinutes() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.SnmpTimeWindowMinutes'];
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.snmpTimeWindowMinutes),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectSnmpMetricTypeReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.SnmpMetricTypeReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.snmpMetricTypeReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectSnmpDeviceAvailabilityReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.SnmpDeviceAvailabilityReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.snmpDeviceAvailabilityReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectSnmpUnitReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.SnmpUnitReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.snmpUnitReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectSnmpTimeWindowMinutesReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.SnmpTimeWindowMinutesReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.snmpTimeWindowMinutesReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectVmMachineType() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.VmMachineType'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.vmMachineType),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectVmMachineFilter() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.VmMachineFilter'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.vmMachineFilter),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectVmMachineState() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.VmMachineState'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.vmMachineState),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectVmMachineTypeReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.VmMachineTypeReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.vmMachineTypeReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectVmMachineFilterReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.VmMachineFilterReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.vmMachineFilterReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectVmMachineStateReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.VmMachineStateReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.vmMachineStateReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectDeviceStatus() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.DeviceStatus'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.deviceStatus),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectDeviceStatusTime() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.DeviceStatusTime'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.deviceStatusTime),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectDeviceStatusReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.DeviceStatusReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.deviceStatusReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectDeviceStatusTimeReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.DeviceStatusTimeReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.deviceStatusTimeReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptRunOn() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptRunOn'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptRunOn),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptRepeatPeriod() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptRepeatPeriod'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptRepeatPeriod),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptLanguage() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptLanguage'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptLanguage),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptCriteria() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptCriteria'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptCriteria),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptDescriptionOperator() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptDescriptionOperator'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptDescriptionOperator),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptTriggerReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptTriggerReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptTriggerReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptRunOnReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptRunOnReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptRunOnReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptRepeatPeriodReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptRepeatPeriodReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptRepeatPeriodReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptLanguageReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptLanguageReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptLanguageReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptCriteriaReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptCriteriaReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptCriteriaReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectScriptDescriptionOperatorReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptDescriptionOperatorReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.scriptDescriptionOperatorReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectAssetCategory() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AssetCategory'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.assetCategory),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectAssetParameter() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AssetParameter'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.assetParameter),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectAssetDpCondition() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AssetDpCondition'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.assetDpCondition),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectAssetCategoryReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AssetCategoryReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.assetCategoryReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectAssetParameterReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AssetParameterReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.assetParameterReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	selectAssetDpConditionReverse() {
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AssetDpConditionReverse'];			
			this.dropDown
				.getDropDownAndSelectValue(
					this.wrapDataTestId(ltr.assetDpConditionReverse),
					ltr.paperRoot,
					testdata
				);
		});
	}

	typeAssetValue() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AssetValue'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.assetCustomMonitorValue), testdata);
		});
	}

	typeAssetValueReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AssetValueReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.assetCustomMonitorValueReverse), testdata);
		});
	}

	typePerformanceCounterValueReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PerformanceCounterValueReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.performanceCounterValueReverse), testdata);
		});
	}

	typeConditionValue() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ConditionValue'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.applicationValue), testdata);
		});
	}

	typeConditionValueReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ConditionValueReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.applicationValueReverse), testdata);
		});
	}

	typeAvailableSpaceBelow() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AvailableSpaceBelow'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.availableSpaceBelow), testdata);
		});
	}

	typeAvailableSpaceAboveReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.AvailableSpaceAboveReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.availableSpaceBelowReverse), testdata);
		});
	}

	typeEventIds() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.EventIds'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.eventIds), testdata);
		});
	}

	typeEventIdsReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.EventIdsReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.eventIdsReverse), testdata);
		});
	}

	typeEventProviderName() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.EventProviderName'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.eventProviderName), testdata);
		});
	}

	typeEventProviderNameReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.EventProviderNameReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.eventProviderNameReverse), testdata);
		});
	}

	typeEventKeywords() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.EventKeywords'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.eventKeywords), testdata);
		});
	}

	typeEventKeywordsReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.EventKeywordsReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.eventKeywordsReverse), testdata);
		});
	}

	typeFileSystemTargetPath() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.FileSystemTargetPath'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.fileSystemTargetPath), testdata);
		});
	}

	typeFileSystemTargetPathReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.FileSystemTargetPathReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.fileSystemTargetPathReverse), testdata);
		});
	}

	typeRemoteHostField() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RemoteHostField'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.remoteHostField), testdata);
		});
	}

	typeRemoteHostFieldReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RemoteHostFieldReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.remoteHostFieldReverse), testdata);
		});
	}

	typeVerifyEveryCondition() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.VerifyEveryCondition'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.verifyEveryCondition), testdata);
		});
	}

	typeMemoryPercent() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MemoryPercent'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.memoryPercent), testdata);
		});
	}

	typeMemoryPercentReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.MemoryPercentReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.memoryPercentReverse), testdata);
		});
	}

	typePortNumber() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortNumber'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.portNumber), testdata);
		});
	}

	typePortTryCount() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortTryCount'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.portTryCount));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.portTryCount), testdata);
		});
	}

	typePortVerifyEvery() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortVerifyEvery'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.portVerifyEvery), testdata);
		});
	}

	typePortNumberReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortNumberReverse'];			
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.portNumberReverse), testdata);
		});
	}

	typePortTryCountReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.PortTryCountReverse'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.portTryCountReverse));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.portTryCountReverse), testdata);
		});
	}

	typeProcessName() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ProcessName'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.processName));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.processName), testdata);
		});
	}

	typeRegistryKey() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RegistryKey'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.registryKey));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.registryKey), testdata);
		});
	}

	typeRegistryValue() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RegistryValue'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.registryValue));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.registryValue), testdata);
		});
	}

	typeRegistryKeyReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RegistryKeyReverse'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.registryKeyReverse));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.registryKeyReverse), testdata);
		});
	}

	typeRegistryValueReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.RegistryValueReverse'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.registryValueReverse));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.registryValueReverse), testdata);
		});
	}

	typescriptRepeatEvery() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptRepeatEvery'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.scriptRepeatEvery));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.scriptRepeatEvery), testdata);
		});
	}

	typeScriptBody() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptBody'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.scriptBody));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.scriptBody), testdata);
		});
	}

	typeScriptOutput() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptOutput'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.scriptOutput));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.scriptOutput), testdata);
		});
	}

	typeScriptRepeatEveryReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptRepeatEveryReverse'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.scriptRepeatEveryReverse));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.scriptRepeatEveryReverse), testdata);
		});
	}

	typeScriptBodyReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptBodyReverse'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.scriptBodyReverse));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.scriptBodyReverse), testdata);
		});
	}

	typeScriptOutputReverse() {
		var testdata;
		cy.get('@alert-data').then((data) => {
			testdata = data['Monitor.ScriptOutputReverse'];			
			this.inputField.clearInputField(this.wrapDataTestId(ltr.scriptOutputReverse));
			this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.scriptOutputReverse), testdata);
		});
	}

	selectMonitorSeverity(severity) {
		this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(ltr.severityDropdown),
				ltr.paperRoot,
				severity
			);
	}

	selectMonitorFamily(family) {
		this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(ltr.familyDropdown),
				ltr.paperRoot,
				family
			);
	}

	selectResources() {
		this.resourceSelector.selectMultipleResourceByText(ltr.gridRow, ['123123', '1234Site']);

		cy.contains(txt.saveSelection).click();
	}

	selectMonitorGridRow(index) {
		this.grid
			.selectRowByIndexWithCheckbox(ltr.gridRow, index);
	}

	deselectMonitorGridRow(index) {
		this.grid
			.deselectRowByIndexWithCheckbox(ltr.gridRow, index);

	}

	selectFromResourceSelectorAndSave(resourceType) {
		this.resourceSelector.selectResourceType({ resourceType });
		if (resourceType !== 'alldevices') {
			this.resourceSelector.selectFirstResource(ltr.gridRow);
		}
		this.resourceSelector.saveResources();
	}

	selectSiteLevelResourceSelectorValueAndSave() {
		this.resourceSelector.selectSitesResourceType();
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var siteName;
		cy.get('@alert-data').then((data) => {			
			siteName = data['Monitor.SiteName'];			
			this.resourceSelector.searchResourceByName(ltr.searchIcon, siteName);
		});
		this.resourceSelector.selectFirstResource(ltr.gridRow);
		this.resourceSelector.saveResources();
	}

	selectCompanyLevelResourceSelectorValueAndSave() {
		this.resourceSelector.selectCompanyResourceType();
		cy.fixture(`data/${this.env}/testdata/alert-test-data.json`).as('alert-data');
		var companyName;
		cy.get('@alert-data').then((data) => {
			companyName = data['Monitor.CompanyName'];						
			this.resourceSelector.searchResourceByName(ltr.searchIcon, companyName);
		});
		this.resourceSelector.selectFirstResource(ltr.gridRow);
		this.resourceSelector.saveResources();
	}

	selectAllRsourcesSelectorValueAndSave() {
		this.resourceSelector.selectAllResourcesResourceType();
		this.resourceSelector.saveResources();
	}

	/**
	 * All validation Methods
	 */

	validateCountOfSelectedRows() {
		this.getElement(ltr.selectRowCount).then((elem) => {
			const selectedCount = elem.text().split(' ')[0];

			this.getElement(ltr.rowCount).then((elem) => {
				const totalCount = elem.text().split(' ')[2];
				expect(selectedCount).to.equal(totalCount);
			});
		});

		this.checkSelectAllCheckboxOnGrid();
	}

	validateMonitorToastMessage(message) {
		this.toast.validateToastMessage(ltr.toast, this.wrapDataTestId(ltr.successIcon), message);
		this.getLastElement(this.wrapDataTestId(ltr.closeIcon)).click();
	}

	validateNewMonitorIsPresentOnGrid(name) {
		this.searchMonitor(name);

		this.getElement(this.wrapDataTestId(ltr.grid))
			.contains(name)
			.should('be.visible');
	}

	clickMonitorforMetadata() {
		this.getFirstElement(ltr.gridRow).click();
	}

	checkMetaDataCardExist() {
		const dataTestId = this.wrapDataTestId(ltr.monitorTitleOnCardView);
		this.getElementWithAssertion(dataTestId, 'exist');
		return this.getFieldValue(dataTestId).should('not.have.text', '');
	}

	getFieldValue = (element) => {
		return this.getElementWithIndex(element, 0);
	}

	checkMetaDataCardData(name) {
		const dataTestId = this.wrapDataTestId(ltr.monitorTitleOnCardView);
		this.getElementWithAssertion(dataTestId, 'exist');
		return this.getFieldValue(dataTestId).should('have.text', name);

	}

	validateMonitorRowStatus(index, status) {
		this.grid
			.validateRowIndexHasText(ltr.gridRow, index, status);
	}

	validateFirstNSortedDataOnGrid(number) {
		cy.get('@sortedCombinedMonitors').then((sortedCombinedMonitors) => {
			const length = sortedCombinedMonitors.length;
			for (let i = 0; i < (number > length ? length : number); i++) {
				const currMonitor = sortedCombinedMonitors[i];
				this.grid.validateRowIndexHasText(ltr.gridRow, i, currMonitor.displayName);
			}
		});
	}

	validateMonitorCardHasSuspensionValue(suspensionRuleName) {
		this.getElement(this.wrapDataTestId(ltr.card)).then(($div) => {
			const wrappedElem = cy.wrap($div);
			wrappedElem.should('contain.text', suspensionRuleName)
				.and('contain.text', txt.suspensionText);
		});
	}

	validateCardHasValueBasedOnType(type, data) {
		switch (type) {
			case txt.cpu:
				this.validateCpuTypeCard(data);
				break;
			case txt.service:
				this.validateServiceTypeCard(data);
				break;
			case txt.customField:
				this.validateCustomFieldTypeCard(data);
				break;
			default:
				break;
		}
	}

	validateCpuTypeCard(data) {
		this.getElement(this.wrapDataTestId(ltr.card)).then(($div) => {
			const wrappedElem = cy.wrap($div);
			wrappedElem.should('contain.text', data.displayName)
				.and('contain.text', data.description);

			if (data.variables.cpuState) {
				wrappedElem.should('contain.text', `CPU utilization is ${data.variables.cpuState} than ${data.variables.cpuUsage}% for ${data.variables.timeWindow} minutes`);
			}

			if (data.variablesInverse.cpuState) {
				wrappedElem.should('contain.text', `CPU utilization is ${data.variablesInverse.cpuState} than ${data.variablesInverse.cpuUsage}% for ${data.variablesInverse.timeWindow} minutes`);
			}
		});
	}

	validateAutomationIsAdded() {
		this.getElement(this.wrapDataTestId(ltr.automationIcon)).should('be.visible');
		this.getElement('body').should('contain.text', 'Run Automated Task');
	}

	validateAutomationNameAfterEditCancel() {

		cy.get(ltr.automatedTaskName).then(($value) => {

			// Here we are performing following tasks
			// 1. Take the First Value added in the "Add Automation" 
			// 2. Now edit the "Add Automation"
			// 3. Select another value & click on the Cancel Button
			// 4. Compare the value from step 1 with new value. Both should be equal. 

			this.clickOnEditAutomationButton();
			this.clickSecondAutomation();
			this.clickOnCancelAutomationButton();
			cy.get(ltr.automatedTaskName).invoke('text').should('equal', $value.text());

		});
	}

	clickSecondAutomation() {
		this.getSecondElement(ltr.gridRow).click();
	}

	getSecondElement = (locator) => {
		return this.getElementWithIndex(locator, 2);
	};

	validateSuspensionRedirectionWithMonitorValue(ruleName, monitorName) {
		this.getElement(this.wrapDataTestId(ltr.card)).contains(ruleName).click();
		cy.contains('Edit Suspension').should('be.visible');
		this.grid.validateRowIndexHasText(ltr.gridRow, 0, monitorName);
	}

	validateBaseFieldsHaveValues(data) {
		this.getElement(this.wrapDataTestId(ltr.nameField)).find('input').invoke('val').should('eq', data.name);
		this.getElement(this.wrapDataTestId(ltr.descriptionField)).should('contain.text', data.description);
		this.getElement(this.wrapDataTestId(ltr.severityDropdown)).should('contain.text', data.severity);
		this.getElement(this.wrapDataTestId(ltr.familyDropdown)).should('contain.text', data.family);

		this.validateResourceSelectorIsVisible();
	}

	validateResourceSelectorIsVisible() {
		this.getElement('body').should('contain.text', 'Targeted Resources');
	}

	/** 
	 * All SEARCH methods
	 */
	searchMonitor(name) {
		this.grid.searchEntryInGrid(this.wrapDataTestId(ltr.searchIcon), name);
	}

	searchMonitorAndClickOnName(name) {
		this.searchMonitor(name);

		this.getElement(this.wrapDataTestId(ltr.grid))
			.contains(name)
			.should('be.visible')
			.click();
	}

	searchMonitorAndSelectRow(name) {
		this.searchMonitor(name);
		this.grid.selectRowByIndexWithCheckbox(ltr.gridRow, 0);
	}

	searchMonitorAndClickOnFirstRow(name) {
		this.searchMonitor(name);
		this.getFirstElement(ltr.gridRow).click();
	}

	/**
	 * All OTHER Methods
	 */

	initialLandingSetup() {
		this.navigateToPageOnCheck(moduleMetaData.name);
		this.checkOnGridApiAndSaveResponse('@getMonitors', this.isGetMonitorLoaded, this.getMonitorsResponse);
		cy.get('@checkOnGridApiAndSaveResponse').then((result) => {
			this.isGetMonitorLoaded = result.classInstFlag;
			this.getMonitorsResponse = result.classInstResponse;
		});
	}

	baseStepsForMonitorCreation() {
		this.clickOnCreateMonitorButton();
		this.typeMonitorName(this.testData.name);
		this.typeMonitorDescription(this.testData.description);
		this.selectMonitorSeverity(this.testData.severity);
		this.selectMonitorFamily(this.testData.family);
		this.clickOnSelectTargetButton();
	}

	baseValidationForMonitorCreation() {
		this.clickOnSaveChanges();
		this.validateMonitorToastMessage(this.testData.message);
		this.validateNewMonitorIsPresentOnGrid(this.testData.name);
	}

	getDropDownAndSelectValue(dropDownFieldSelector, value) {
		return value ? this.dropDown
			.getDropDownAndSelectValue(
				this.wrapDataTestId(dropDownFieldSelector),
				ltr.paperRoot,
				value
			) : null;
	}

	sortApiDataBasedOnGivenField(field, order) {
		let combinedMonitors;
		let responseField = '';

		cy.wrap(this.getMonitorsResponse).as('getMonitorResponse').then((monitors) => {
			const customMonitors = monitors.response.body.customMonitors;
			combinedMonitors = customMonitors.concat(monitors.response.body.complexMonitors);

			if (field === 'Name') {
				responseField = 'displayName';
			}

			if (order === 'ascending') {
				combinedMonitors.sort(function (a, b) {
					return a[responseField].localeCompare(b[responseField]);
				});
			} else {
				combinedMonitors.sort(function (a, b) {
					return b[responseField].localeCompare(a[responseField]);
				});
			}

			cy.wrap(combinedMonitors).as('sortedCombinedMonitors');
		});

	}

	navigateBackToMonitorsPage() {
		this.button.clickButton(this.wrapDataTestId('suspensions-back-button'));
	}

	checkInputButtonUsingLabel = (labelSelector, label) => {
		return this.getElement(labelSelector).contains(label).click();
	}

	searchAndSelectSite = (siteName) => {
		this.clickSearchIconWithIndex(1);
		this.searchSiteInGrid(siteName);
	}

	getSearchIconWithIndex = (searchIndex) => {
		const dataTestId = this.wrapDataTestId(lct.searchIcon);
		return this.getElementWithIndex(dataTestId, searchIndex);
	}

	searchSiteInGrid = (searchString) => {
		return this.getElement(lct.txtSearchSite).type(searchString);
	}

	CheckAndNavigateToCustomMonitorsTab() {
		this.checkElementIsVisibleWithText(ltr.customMonitorTab, 'Custom Monitors');
		this.button.clickButtonWithText(ltr.customMonitorTab, 'Custom Monitors');
	}

	//Generative AI Methods for Script Monitor
	checkToggleButtonDisplayedForCondition = () => {
		const dataTestId = this.wrapDataTestId(ltr.useGenerativeAIToggle);
		this.checkElementIsVisible(dataTestId);
	}

	checkToggleButtonDisplayedForInverseCondition = () => {
		const dataTestId = this.wrapDataTestId(ltr.useGenerativeAIToggleInverse);
		this.getElement(dataTestId).last().should('be.visible');	
	}

	checkToggleButtonLableDisplayedForCondition = (label) => {
		this.checkElementIsVisibleWithText(ltr.generativeAIToggleLabel, label);
	}

	checkToggleButtonLableDisplayedForInverseCondition = (label) => {
		this.getElement(ltr.generativeAIToggleLabel).last().contains(label).should('be.visible');
	}

	clickOnConditionsGenerativeAIToggleButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.useGenerativeAIToggle));
	}

	clickOnInverseConditionsGenerativeAIToggleButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.useGenerativeAIToggleInverse));
	}

	checkInoutPromptTextBoxDisplayed = () => {
		const dataTestId = this.wrapDataTestId(ltr.generateScriptInputPrompt);		
		this.checkElementIsVisible(dataTestId);
	}

	checkInoutPromptTextBoxDisplayedInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.generateScriptInputPromptInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGenerateScriptButtonDisplayed = () => {
		const dataTestId = this.wrapDataTestId(ltr.generateScriptButton);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGenerateScriptButtonDisplayedInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.generateScriptButtonInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGenerateScriptOutputBoxDisplayed = () => {
		const dataTestId = this.wrapDataTestId(ltr.generateScriptOutputTextbox);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGenerateScriptOutputBoxDisplayedInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.generateScriptOutputTextboxInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkDownloadButtonDisplayed = () => {
		const dataTestId = this.wrapDataTestId(ltr.scriptDownloadButton);		
		this.checkElementIsVisible(dataTestId);
	}

	checkDownloadButtonDisplayedInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.scriptDownloadButtonInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkCopyToEditorButtonDisplayed = () => {
		const dataTestId = this.wrapDataTestId(ltr.copyScriptButton);		
		this.checkElementIsVisible(dataTestId);
	}

	checkCopyToEditorButtonDisplayedInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.copyScriptButtonInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGeneratedScriptAcceptanceCheckboxDisplayed = () => {
		const dataTestId = this.wrapDataTestId(ltr.checkScriptAcceptanceCheckBox);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGeneratedScriptAcceptanceCheckboxDisplayedInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.checkScriptAcceptanceCheckBoxInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGeneratedScriptAcceptanceLabelDisplayed = (label) => {
		this.checkElementIsVisibleWithText(ltr.generatedScriptAcceptanceLabel, label);
	}

	verifyAllFieldsDisplayedForGenerativeAI(label) {
		this.checkInoutPromptTextBoxDisplayed();
		this.checkGenerateScriptButtonDisplayed();
		this.checkGenerateScriptOutputBoxDisplayed();
		this.checkDownloadButtonDisplayed();
		this.checkCopyToEditorButtonDisplayed();
		this.checkGeneratedScriptAcceptanceCheckboxDisplayed();
		this.checkGeneratedScriptAcceptanceLabelDisplayed(label);
	}

	verifyAllFieldsDisplayedForGenerativeAIInverse(label) {
		this.checkInoutPromptTextBoxDisplayedInverse();
		this.checkGenerateScriptButtonDisplayedInverse();
		this.checkGenerateScriptOutputBoxDisplayedInverse();
		this.checkDownloadButtonDisplayedInverse();
		this.checkCopyToEditorButtonDisplayedInverse();
		this.checkGeneratedScriptAcceptanceCheckboxDisplayedInverse();
		this.checkGeneratedScriptAcceptanceLabelDisplayed(label);
	}

	typeCommandInPromptBox(description) {
		this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.generateScriptInputPrompt), description);
	}

	typeCommandInPromptBoxInverse(description) {
		this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.generateScriptInputPromptInverse), description);
	}

	clickOnGenerateScriptButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.generateScriptButton));
	}

	clickOnGenerateScriptButtonInverse() {
		this.button.clickButton(this.wrapDataTestId(ltr.generateScriptButtonInverse));
	}

	checkScriptOutputBoxContainsText() {
		cy.wait(5000);
		this.getElement(this.wrapDataTestId(ltr.generateScriptOutputTextbox)).should('be.visible').invoke('val').should('not.be.empty');
	}

	checkScriptOutputBoxContainsTextInverse() {
		cy.wait(5000);
		this.getElement(this.wrapDataTestId(ltr.generateScriptOutputTextboxInverse)).should('be.visible').invoke('val').should('not.be.empty');
	}

	clickCopyToScriptEditorButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.copyScriptButton));
	}

	clickCopyToScriptEditorButtonInverse() {
		this.button.clickButton(this.wrapDataTestId(ltr.copyScriptButtonInverse));
	}

	clickIAgreeCheckboxButton() {
		this.button.clickButton(this.wrapDataTestId(ltr.generatedScriptAcceptanceCheckBox));
	}

	clickIAgreeCheckboxButtonInverse() {
		this.button.clickButton(this.wrapDataTestId(ltr.generatedScriptAcceptanceCheckBoxInverse));
	}

	//Generative AI Methods for Event Monitor
	checkToggleButtonDisplayedEventMonitor = () => {
		const dataTestId = this.wrapDataTestId(ltr.useGenerativeAIToggleEvent);
		this.checkElementIsVisible(dataTestId);
	}

	checkToggleButtonDisplayedEventMonitorInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.useGenerativeAIToggleEventInverse);
		this.getElement(dataTestId).last().should('be.visible');	
	}

	checkToggleButtonLableDisplayedEventMonitor = (label) => {
		this.checkElementIsVisibleWithText(ltr.generativeAIToggleLabelEvent, label);
	}

	checkToggleButtonLableDisplayedEventMonitorInverse = (label) => {
		this.getElement(ltr.generativeAIToggleLabelEvent).last().contains(label).should('be.visible');
	}

	clickGenerativeAIToggleButtonEventMonitor() {
		this.button.clickButton(this.wrapDataTestId(ltr.useGenerativeAIToggleEvent));
	}

	clickGenerativeAIToggleButtonEventMonitorInverse() {
		this.button.clickButton(this.wrapDataTestId(ltr.useGenerativeAIToggleEventInverse));
	}

	checkInoutPromptTextBoxDisplayedEventMonitor = () => {
		const dataTestId = this.wrapDataTestId(ltr.generativeAIInputPromptEvent);		
		this.checkElementIsVisible(dataTestId);
	}

	checkInoutPromptTextBoxDisplayedEventMonitorInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.generativeAIInputPromptEventInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGenerateButtonDisplayedEventMonitor = () => {
		const dataTestId = this.wrapDataTestId(ltr.generateAndApplyButtonEvent);		
		this.checkElementIsVisible(dataTestId);
	}

	checkGenerateButtonDisplayedEventMonitorInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.generateAndApplyButtonEventInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkAIAcceptanceCheckboxDisplayedEventMonitor = () => {
		const dataTestId = this.wrapDataTestId(ltr.checkScriptAcceptanceCheckBox);		
		this.checkElementIsVisible(dataTestId);
	}

	checkAIAcceptanceCheckboxDisplayedEventMonitorInverse = () => {
		const dataTestId = this.wrapDataTestId(ltr.checkScriptAcceptanceCheckBoxInverse);		
		this.checkElementIsVisible(dataTestId);
	}

	checkAIAcceptanceLabelDisplayedEventMonitor = (label) => {
		this.checkElementIsVisibleWithText(ltr.generativeAIAcceptanceLabelEvent, label);
	}

	checkAIAcceptanceLabelDisplayedEventMonitorInverse = (label) => {
		this.getElement(ltr.generativeAIAcceptanceLabelEvent).last().contains(label).should('be.visible');
	}

	checkAIAcceptanceValidationMessageEventMonitor = (label) => {
		this.getElement(ltr.eventValidationErrorForCheckbox).scrollIntoView().contains(label).should('be.visible');
	}

	checkAIAcceptanceValidationMessageEventMonitorInverse = (label) => {
		this.getElement(ltr.eventValidationErrorForCheckbox).last().contains(label).should('be.visible');
	}

	verifyGenerativeAIFieldsDisplayedEventMonitor(label) {
		this.checkInoutPromptTextBoxDisplayedEventMonitor();
		this.checkGenerateButtonDisplayedEventMonitor();
		this.checkAIAcceptanceCheckboxDisplayedEventMonitor();
		this.checkAIAcceptanceLabelDisplayedEventMonitor(label);
	}

	verifyGenerativeAIFieldsDisplayedEventMonitorInverse(label) {
		this.checkInoutPromptTextBoxDisplayedEventMonitorInverse();
		this.checkGenerateButtonDisplayedEventMonitorInverse();
		this.checkAIAcceptanceCheckboxDisplayedEventMonitorInverse();
		this.checkAIAcceptanceLabelDisplayedEventMonitorInverse(label);
	}

	typeCommandInPromptBoxEventMonitor(description) {
		this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.generativeAIInputPromptEvent), description);
	}

	typeCommandInPromptBoxEventMonitorInverse(description) {
		this.inputField.typeIntoInputField(this.wrapDataTestId(ltr.generativeAIInputPromptEventInverse), description);
	}

	clickOnGenerateAndApplyButtonEventMonitor() {
		this.button.clickButton(this.wrapDataTestId(ltr.generateAndApplyButtonEvent));
		cy.wait(5000);
	}

	clickOnGenerateAndApplyButtonEventMonitorInverse() {
		this.button.clickButton(this.wrapDataTestId(ltr.generateAndApplyButtonEventInverse));
		cy.wait(5000);
	}

	clickIAgreeCheckboxButtonEventMonitor() {
		this.button.clickButton(this.wrapDataTestId(ltr.generativeAIAcceptanceCheckBoxEvent));
	}

	clickIAgreeCheckboxButtonEventMonitorInverse() {
		this.button.clickButton(this.wrapDataTestId(ltr.generativeAIAcceptanceCheckBoxEventInverse));
	}

	verifyEventLogValueDisplayedEventMonitor = (value) => {
		this.checkElementIsVisibleWithText(ltr.eventLogDropdownValue, value);
	}

	verifyEventLogValueDisplayedEventMonitorInverse = (value) => {
		this.checkElementIsVisibleWithText(ltr.eventLogDropdownValueInverse, value);
	}

	verifyEventIdValueDisplayedEventMonitor = (eventId) => {
		this.checkElementIsVisibleWithText(ltr.eventIdValue, eventId);
	}

	verifyEventIdValueDisplayedEventMonitorInverse = (eventId) => {
		this.checkElementIsVisibleWithText(ltr.eventIdValueInverse, eventId);
	}

	verifyEventSeverityValueDisplayedEventMonitor = (severity) => {
		this.checkElementIsVisibleWithText(ltr.eventSeverityValue, severity);
	}

	verifyEventSeverityValueDisplayedEventMonitorInverse = (severity) => {
		this.checkElementIsVisibleWithText(ltr.eventSeverityValueInverse, severity);
	}

	verifyEventSourceValueDisplayedEventMonitor = (source) => {
		this.getElement(ltr.eventSourceValue)
			.should('be.visible')
			.invoke('val')
			.then((text) => {
				expect(text).to.equal(source);
			}
			);
	}

	verifyEventSourceValueDisplayedEventMonitorInverse = (source) => {
		this.getElement(ltr.eventSourceValueInverse)
			.should('be.visible')
			.invoke('val')
			.then((text) => {
				expect(text).to.equal(source);
			}
			);
	}

	clickOnFirstMonitorForEdit() {
		this.button
			.clickButtonWithIndex(ltr.monitorName, 0);
	}

	checkMonitorsListingBreadcrumbIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(ltr.MonitorsListingBreadcrumb));
	}

	checkEndpointsTextIsVisibleInBreadcrumbMonitorsListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(ltr.EndpointsTextInBreadcrumb), 'Endpoints');
	}

	checkAlertsTextIsVisibleInBreadcrumbMonitorsListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(ltr.AlertsTextInBreadcrumb), 'Alerts');
	}

	checkMonitorsTextIsVisibleInBreadcrumbMonitorsListing = () => {
		this.checkElementIsVisibleWithText(this.wrapDataTestId(ltr.MonitorsTextInBreadcrumb), 'Monitors');
	}

	checkEditMonitorsBreadcrumbIsVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(ltr.MonitorsEditBreadcrumb));
	}

	clickMonitorsLinkInBreadcrumb() {
		this.button.clickButtonWithWait(this.wrapDataTestId(ltr.MonitorsBreadcrumbLink), 5);
	}
}

export default MonitorsHelper;