import { CommonHelper } from '../../../../fixtures';
import { txt } from './constants';

class MonitorDataHelper {

	constructor() {
		this.commonHelper = new CommonHelper();
	}

	generateBaseData() {
		this.testData = {
			name: this.commonHelper.getFakeName(),
			description: this.commonHelper.getFakeDescription(),
			severity: txt.criticalImpactAlerts,
			family: txt.activeDirectory,
			resourceType: 'sites',
			message: txt.successMessage,
		};

		return this;
	}

	generateCpuTypeCustomMonitorDataForApiCall() {
		this.testDataApi = {
			displayName: this.commonHelper.getFakeName(),
			enabled: true,
			description: this.commonHelper.getFakeDescription(),
			definitionID: 'e3f41596-fd6a-41d8-b400-7d3750250ba0',
			alertSeverity: txt.criticalImpactAlerts,
			alertFamily: txt.activeDirectory,
			targets: {
				isPartnerLevel: true
			},
			automation: {
				customTaskId: '',
				useCustomRemediation: false,
				taskType: '',
				taskName: '',
				useAutoRemediation: false,
				originID: ''
			},
			inverseConditionEnabled: false,
			variables: {
				cpuState: 'more',
				cpuUsage: 80,
				timeWindow: 15,
				ticketUpdateSnoozePeriod: 'h',
				ticketUpdateSnoozeInHour: 8
			},
			variablesInverse: {}
		};

		return this;
	}

	getData() {
		return this.testData;
	}

	getDataForApi() {
		return this.testDataApi;
	}

	setDataForApi(fields) {
		if (fields) {
			this.testDataApi = {
				...this.testDataApi,
				...fields,
			};
		}

		return this;
	}

	setData(testData) {
		this.testData = testData;
	}

	setCpuTypeData(
		cpuUtilization,
		cpuUsage,
		cpuMinute,
		cpuSnoozeHour,
		cpuSnoozeMinute,
		cpuSnoozePeriod,
		enableInverse
	) {
		this.testData = {
			...this.testData,
			type: txt.cpu,
			monitorType: txt.complex,
			typeApplication: txt.application,
			typeDisk: txt.disk,
			typeEvent: txt.event,
			typeFileSystem: txt.fileSystem,
			typeHyperV: txt.hyperV,
			typeICMP: txt.ICMP,
			typeIntegrationField: txt.integrationField,
			typeMemory: txt.memory,
			typePerformanceCounter: txt.performanceCounter,
			typePort: txt.port,
			typeProcess: txt.process,
			typeRegistry: txt.registry,
			typeScript: txt.script,
			typeSNMP: txt.SNMP,
			typeVMware: txt.VMware,
			typeAsset: txt.asset,
			typeService: txt.service,
			typeDeviceAvailability: txt.deviceAvailability,
			typeComplex: txt.complex,
			cpuUtilization: cpuUtilization,
			cpuUsage: cpuUsage,
			cpuMinute: cpuMinute,
			cpuSnoozeHour: cpuSnoozeHour,
			cpuSnoozeMinute: cpuSnoozeMinute,
			cpuSnoozePeriod: cpuSnoozePeriod,
			enableInverse: enableInverse,
		};

		return this;
	}

	setServiceTypeData(serviceName, serviceStatus, automaticallyStartServiceWhenStopped) {
		this.testData = {
			...this.testData,
			type: txt.service,
			serviceName: serviceName,
			serviceStatus: serviceStatus,
			automaticallyStartServiceWhenStopped: automaticallyStartServiceWhenStopped,
		};
		return this;
	}

	setCustomFieldTypeData() {
		this.testData = {
			...this.testData,
			type: txt.customField,
		};
		return this;
	}

	setScriptMonitorData() {
		this.testData = {
			...this.testData,
			toggleLabel: txt.GenerateScriptToggleLabel,
			acceptChecboxLabel: txt.AcceptAIScriptLabel,
			inputCommand: txt.InputCommand,
			generateScriptCommand: txt.GenerateScriptCommand,	
		};
		return this;
	}

	createMonitorTestData(type) {
		switch (type) {
			default:
				this.testData = {
					...this.testData,
					type: txt.cpu,
				};
				break;
		}

		return this;

	}

	generateSuspensionRuleDataForApiCall() {
		this.testSuspensionRuleData = {
			schedule: {
				endDate: '0001-01-01T00:00:00Z',
				timeZone: 'Asia/Kolkata',
				regularity: 'OneTime',
				startDate: this.commonHelper.getFutureFakeDateTimeIso(),
				repeat: null
			},
			metadata: {
				granularvalue: [],
				groupType: [],
				clientid: [],
				conditionid: [],
				endpointid: [],
				siteid: [],
				partnerid: Cypress.env('alertingPartnerId'),
				conditionfamily: [],
				customrules: []
			},
			configuredfrom: 'custom_monitor',
			isPartnerLevel: true,
			createdby: Cypress.env('alertingUid'),
			description: this.commonHelper.getFakeDescription(),
			rulename: this.commonHelper.getFakeName(),
			modifiedBy: Cypress.env('alertingUid'),
		};

		return this;
	}

	getSuspensionData() {
		return this.testSuspensionRuleData;
	}

	setSuspensionMetadata(fields) {
		if (fields) {
			this.testSuspensionRuleData.metadata = {
				...this.testSuspensionRuleData.metadata,
				...fields,
			};
		}
		return this;
	}

	setSuspensionData(fields) {
		if (fields) {
			this.testSuspensionRuleData = {
				...this.testSuspensionRuleData,
				...fields,
			};
		}
		return this;
	}


}

export default MonitorDataHelper;