import MonitorsHelper from '../helper/MonitorsHelper';
import { txt } from '../helper/constants';

describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();

	// Define global hook for describe block
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		/** 
		 * Base hooks defined for pre and post conditions
		 * before, beforeEach, after, afterEach
		 * NOTE: Add custom conditions to specific test cases only
		 */
		monitorsHelper.setupHooks();
		monitorsHelper.cleanupHooks();

		/** 
		 * SUB-TEST SCENARIO: Check if user is able to create monitors at different levels 
		 */
		monitorsHelper.resourceSelector.resourceTypeOptionsArray().forEach((resourceType) => {
			it(`THEN Verify user is able to create CPU monitors at ${resourceType} Level`, { tags: ['@Regression', '@CTS'] }, () => {
				// mandatory to link JIRA test case ID
				cy.allure().tms('ALERT-T1585');

				monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
				const testData = monitorsHelper.dataHelper.getData();

				monitorsHelper.clickOnCreateMonitorButton();
				monitorsHelper.typeMonitorName(testData.name);
				monitorsHelper.typeMonitorDescription(testData.description);
				monitorsHelper.selectMonitorType(testData.type);
				monitorsHelper.selectMonitorSeverity(testData.severity);
				monitorsHelper.selectMonitorFamily(testData.family);
				monitorsHelper.clickOnSelectTargetButton();
				monitorsHelper.selectFromResourceSelectorAndSave(resourceType);
				monitorsHelper.clickOnSaveChanges();
				monitorsHelper.validateMonitorToastMessage(testData.message);
				monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			});
		});

		it('THEN Verify user is able to create Monitor of type: CPU', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1586');

			monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
			const testData = monitorsHelper.getData();

			monitorsHelper.baseStepsForMonitorCreation();
			monitorsHelper.selectFromResourceSelectorAndSave(testData.resourceType);

			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.setValuesForCpuTypeMonitor(
				testData.cpuUtilization,
				testData.cpuUsage,
				testData.cpuMinute
			);
			monitorsHelper.toggleTicketResolution(testData.enableInverse);

			monitorsHelper.baseValidationForMonitorCreation();
		});

		it('THEN Verify user is able to create Monitor of type: Service', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1587');

			monitorsHelper.createMonitorTestDataBasedOnType(txt.service);
			const testData = monitorsHelper.getData();

			monitorsHelper.baseStepsForMonitorCreation();
			monitorsHelper.selectFromResourceSelectorAndSave(testData.resourceType);

			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.setValuesForServiceTypeMonitor(
				testData.serviceName,
				testData.serviceStatus,
				testData.automaticallyStartServiceWhenStopped
			);
			monitorsHelper.toggleTicketResolution(testData.enableInverse);

			monitorsHelper.baseValidationForMonitorCreation();
		});

		it('THEN Verify user is able to create Monitor of type: Custom Field (Dropdown)', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1588');

			monitorsHelper.createMonitorTestDataBasedOnType(txt.customField);
			const testData = monitorsHelper.getData();

			monitorsHelper.baseStepsForMonitorCreation();
			monitorsHelper.selectFromResourceSelectorAndSave(testData.resourceType);

			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.setValueForCustomFieldTypeMonitor(
				txt.dropdown,
				{ filter: 'Equals', condition: 'AND' }
			);

			monitorsHelper.toggleTicketResolution(testData.enableInverse);

			monitorsHelper.baseValidationForMonitorCreation();
		});

		it('THEN Verify user is able to create Monitor of type: CPU with Automation', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1589');
			
			monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
			const testData = monitorsHelper.getData();

			monitorsHelper.baseStepsForMonitorCreation();
			monitorsHelper.selectFromResourceSelectorAndSave(testData.resourceType);

			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.setValuesForCpuTypeMonitor(
				testData.cpuUtilization,
				testData.cpuUsage,
				testData.cpuMinute
			);

			monitorsHelper.clickOnAutomationButton();
			monitorsHelper.clickFirstAutomation();
			monitorsHelper.clickOnSelectAutomationButton();
			monitorsHelper.validateAutomationIsAdded();

			monitorsHelper.toggleTicketResolution(testData.enableInverse);

			monitorsHelper.baseValidationForMonitorCreation();
		});

	});

});