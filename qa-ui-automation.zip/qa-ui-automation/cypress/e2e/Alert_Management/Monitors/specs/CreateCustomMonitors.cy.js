import { envTag } from '../../../../constants';
import MonitorsHelper from '../helper/MonitorsHelper';
import { moduleMetaData, txt } from '../helper/constants';


describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		monitorsHelper.setupHooks();
		monitorsHelper.cleanupHooks();

		monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
		const testData = monitorsHelper.dataHelper.getData();

		// Phase II scenarios 

		it('Verify user is able to create Custom Monitor of Port type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typePort);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectPortType();
			monitorsHelper.typePortNumber();
			monitorsHelper.selectPortState();
			monitorsHelper.typePortTryCount();
			monitorsHelper.typePortVerifyEvery();
			monitorsHelper.selectPortVerifyPeriod();
			monitorsHelper.selectPortTrigger();
			monitorsHelper.selectPortTypeReverse();
			monitorsHelper.typePortNumberReverse();
			monitorsHelper.selectPortStateReverse();
			monitorsHelper.typePortTryCountReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of Process type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeProcess);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.typeProcessName();
			monitorsHelper.selectProcessState();
			monitorsHelper.selectProcessDuration();
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of Registry type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeRegistry);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectRegistry();
			monitorsHelper.typeRegistryKey();
			monitorsHelper.typeRegistryValue();
			monitorsHelper.selectRegistryOperator();
			monitorsHelper.selectRegistryReverse();
			monitorsHelper.typeRegistryKeyReverse();
			monitorsHelper.typeRegistryValueReverse();
			monitorsHelper.selectRegistryOperatorReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of Script type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeScript);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectScriptRunOn();
			monitorsHelper.typescriptRepeatEvery();
			monitorsHelper.selectScriptRepeatPeriod();
			monitorsHelper.selectScriptLanguage();
			monitorsHelper.typeScriptBody();
			monitorsHelper.selectScriptCriteria();
			monitorsHelper.selectScriptDescriptionOperator();
			monitorsHelper.typeScriptOutput();
			monitorsHelper.selectScriptTriggerReverse();
			monitorsHelper.selectScriptRunOnReverse();
			monitorsHelper.typeScriptRepeatEveryReverse();
			monitorsHelper.selectScriptRepeatPeriodReverse();
			monitorsHelper.selectScriptLanguageReverse();
			monitorsHelper.typeScriptBodyReverse();
			monitorsHelper.selectScriptCriteriaReverse();
			monitorsHelper.selectScriptDescriptionOperatorReverse();
			monitorsHelper.typeScriptOutputReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of SNMP type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeSNMP);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectSnmpMetricType();
			monitorsHelper.selectSnmpDeviceAvailability();
			monitorsHelper.selectSnmpUnit();
			monitorsHelper.selectSnmpTimeWindowMinutes();
			monitorsHelper.selectSnmpMetricTypeReverse();
			monitorsHelper.selectSnmpDeviceAvailabilityReverse();
			monitorsHelper.selectSnmpUnitReverse();
			monitorsHelper.selectSnmpTimeWindowMinutesReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of VMware type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeVMware);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectVmMachineType();
			monitorsHelper.selectVmMachineFilter();
			monitorsHelper.selectVmMachineState();
			monitorsHelper.selectVmMachineTypeReverse();
			monitorsHelper.selectVmMachineFilterReverse();
			monitorsHelper.selectVmMachineStateReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of Asset type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeAsset);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectAssetCategory();
			monitorsHelper.selectAssetParameter();
			monitorsHelper.selectAssetDpCondition();
			monitorsHelper.typeAssetValue();
			monitorsHelper.selectAssetCategoryReverse();
			monitorsHelper.selectAssetParameterReverse();
			monitorsHelper.selectAssetDpConditionReverse();
			monitorsHelper.typeAssetValueReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of Device Availability type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeDeviceAvailability);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectDeviceStatus();
			monitorsHelper.selectDeviceStatusTime();
			monitorsHelper.selectDeviceStatusReverse();
			monitorsHelper.selectDeviceStatusTimeReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		// Phase I scenarios

		it('Verify user is able to create Custom Monitor of Application type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7009');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeApplication);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();			
			monitorsHelper.selectApplicationStatus();
			monitorsHelper.selectApplicationName();
			monitorsHelper.typeConditionValue();
			monitorsHelper.selectApplicationStatusReverse();
			monitorsHelper.selectApplicationNameReverse();
			monitorsHelper.typeConditionValueReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of Disk type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7010');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeDisk);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.typeAvailableSpaceBelow();
			monitorsHelper.typeAvailableSpaceAboveReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of Event type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7011');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.typeEventIds();
			monitorsHelper.selectEventLevelSeverity();
			monitorsHelper.typeEventIdsReverse();
			monitorsHelper.selectEventLevelSeverityReverse();
			monitorsHelper.typeEventProviderName();
			monitorsHelper.typeEventProviderNameReverse();
			monitorsHelper.typeEventKeywords();
			monitorsHelper.typeEventKeywordsReverse();			
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);			
		});

		it('Verify user is able to create Custom Monitor of File System type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7012');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeFileSystem);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.typeFileSystemTargetPath();
			monitorsHelper.typeFileSystemTargetPathReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);	
		});

		it('Verify user is able to create Custom Monitor of Hyper V type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7013');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeHyperV);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Verify user is able to create Custom Monitor of ICMP type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7014');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeICMP);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.typeRemoteHostField();
			monitorsHelper.typeRemoteHostFieldReverse();
			monitorsHelper.typeVerifyEveryCondition();			
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);	
		});

		it('Verify user is able to create Custom Monitor of Integration Field type', { tags: ['@Regression', '@CustomMonitor', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			// Comment : Creation of custom monitor of Integration Field Type
			cy.allure().tms('ALERT-T7015');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeIntegrationField);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();	
			monitorsHelper.selectIntegrationVendorName();
			monitorsHelper.selectIntegrationVendorNameReverse();
			monitorsHelper.selectIntegrationFieldName();
			monitorsHelper.selectIntegrationFieldNameReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);		
		});

		it('Verify user is able to create Custom Monitor of Memory type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7016');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeMemory);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.typeMemoryPercent();
			monitorsHelper.typeMemoryPercentReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		// it.skip('Verify user is able to create Custom Monitor of Performance Counter type', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
		// 	cy.allure().tms('ALERT-T7017');
		// 	monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		// 	monitorsHelper.clickOnCreateMonitorButton();
		// 	monitorsHelper.typeMonitorName(testData.name);
		// 	monitorsHelper.typeMonitorDescription(testData.description);
		// 	monitorsHelper.selectMonitorType(testData.typePerformanceCounter);
		// 	monitorsHelper.selectMonitorSeverity(testData.severity);
		// 	monitorsHelper.selectMonitorFamily(testData.family);
		// 	monitorsHelper.clickOnSelectTargetButton();
		// 	monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			
		// 	// Test Data is NOT AVAILABLE for CWDAS USER

		// 	monitorsHelper.selectPerformanceCounterType();
		// 	monitorsHelper.selectPerformanceCounterObject();
		// 	monitorsHelper.selectPerformanceCounter();
		// 	monitorsHelper.typePerformanceCounterValue();
		// 	monitorsHelper.selectPerformanceCounterTypeReverse();
		// 	monitorsHelper.selectPerformanceCounterObjectReverse();
		// 	monitorsHelper.selectPerformanceCounterReverse();
		// 	monitorsHelper.typePerformanceCounterValueReverse();
		// 	monitorsHelper.clickOnSaveChanges();
		// 	monitorsHelper.validateMonitorToastMessage(testData.message);
		// 	monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
		// 	monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		// });		

	});

});