import MonitorsHelper from '../helper/MonitorsHelper';
import { txt } from '../helper/constants';
import { envTag } from '../../../../constants';

describe('GIVEN Monitors Landing Page', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();

	// Define global hook for describe block
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: [envTag.Regression, envTag.Migrated] }, () => {

		/** 
		 * Base hooks defined for pre and post conditions
		 * before, beforeEach, after, afterEach
		 * NOTE: Add custom conditions to specific test cases only
		 */
		monitorsHelper.setupHooks();
		monitorsHelper.cleanupHooks();


		// Test cases start here
		it('THEN Verify Monitors Grid is loading', { tags: [envTag.Regression, envTag.CTS] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1591');

			monitorsHelper.checkMonitorsGridIsVisible();
		});

		it( 'THEN Verify Monitors Grid have default sorting on Name Field', { tags: [envTag.Regression, envTag.CTS] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1592');

			monitorsHelper.checkIfNameFieldHasDefaultSortingEnabled('ascending');
			monitorsHelper.sortApiDataBasedOnGivenField('Name', 'ascending');
			monitorsHelper.validateFirstNSortedDataOnGrid(10);
		});

		it( 'THEN Verify user is able to disable and then enable Monitor', { tags: [envTag.Regression, envTag.CTS] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1593');

			monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
			const testData = monitorsHelper.getData();

			monitorsHelper.baseStepsForMonitorCreation();
			monitorsHelper.selectFromResourceSelectorAndSave(testData.resourceType);
			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.toggleTicketResolution(testData.enableInverse);
			monitorsHelper.baseValidationForMonitorCreation();

			monitorsHelper.selectMonitorGridRow(0);
			monitorsHelper.toggleMonitorStatus(false);
			monitorsHelper.validateMonitorToastMessage(txt.disabledSuccessMessage);
			monitorsHelper.validateMonitorRowStatus(0, txt.disableStatus);

			monitorsHelper.toggleMonitorStatus(true);
			monitorsHelper.validateMonitorToastMessage(txt.enabledSuccessMessage);
			monitorsHelper.validateMonitorRowStatus(0, txt.enableStatus);

			monitorsHelper.deselectMonitorGridRow(0);

		});

		it( 'THEN Verify user is able to select all monitors', { tags: [envTag.Regression, envTag.CTS] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1594');

			monitorsHelper.checkSelectAllCheckboxOnGrid();
			monitorsHelper.validateCountOfSelectedRows();
		});

		it('Verify breadcrumbs is displayed on Monitors listing page', { tags: [envTag.Regression] }, function () {
			cy.allure().tms('ALERT-T7489');
			monitorsHelper.checkMonitorsListingBreadcrumbIsVisible();
		});

		it('Verify text of breadcrumbs displayed is correct on monitors listing page', { tags: [envTag.Regression] }, function () {
			cy.allure().tms('ALERT-T7491');
			monitorsHelper.checkEndpointsTextIsVisibleInBreadcrumbMonitorsListing();
			monitorsHelper.checkAlertsTextIsVisibleInBreadcrumbMonitorsListing();
			monitorsHelper.checkMonitorsTextIsVisibleInBreadcrumbMonitorsListing();
		});

		it('Verify clicking monitors breadcrumbs link navigates to listing page.', { tags: [envTag.Regression] }, function () {
			cy.allure().tms('ALERT-T7493');
			monitorsHelper.clickOnFirstMonitorForEdit();
			monitorsHelper.checkEditMonitorsBreadcrumbIsVisible();
			monitorsHelper.clickMonitorsLinkInBreadcrumb();
			monitorsHelper.checkMonitorsListingBreadcrumbIsVisible();
		});
	});

	context('WHERE test requires external API call', { tags: [envTag.Migrated] }, () => {

		// Define hooks for pre and post conditions
		monitorsHelper.setupHooks();
		monitorsHelper.setupApiHooks();

		monitorsHelper.cleanupHooks();

		
		it( 'THEN Verify Card view has Data for CPU type Monitor', { tags: [envTag.Regression, envTag.CTS] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1595');

			monitorsHelper.createMonitorUsingApi();
			const testDataApi = monitorsHelper.dataHelper.getDataForApi();

			cy.reload();
			monitorsHelper.searchMonitorAndClickOnFirstRow(testDataApi.displayName);
			monitorsHelper.validateCardHasValueBasedOnType(txt.cpu, testDataApi);
		});

		it( 'THEN Verify user is able to delete a monitor', { tags: [envTag.Regression, envTag.CTS] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1596');

			monitorsHelper.createMonitorUsingApi();
			const testDataApi = monitorsHelper.dataHelper.getDataForApi();

			cy.reload();
			monitorsHelper.searchMonitorAndSelectRow(testDataApi.displayName);
			monitorsHelper.clickOnDeleteButton();
			monitorsHelper.clickOnDeleteButtonOnModal();
			monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);
		});

		it( 'THEN Verify Card view has Data for CPU type Monitor with Suspension Rule added and Suspension link is working', { tags: [envTag.Regression, envTag.CTS] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1597');

			monitorsHelper.createMonitorUsingApi(null, true);
			const testDataApi = monitorsHelper.dataHelper.getDataForApi();		
			
			cy.reload();
			monitorsHelper.searchMonitorAndClickOnFirstRow(testDataApi.displayName);
			monitorsHelper.validateCardHasValueBasedOnType(txt.cpu, testDataApi);

			cy.get('@suspensionRuleBody').then((body) => {
				console.log(body);
				monitorsHelper.validateMonitorCardHasSuspensionValue(body.rulename);
				monitorsHelper.validateSuspensionRedirectionWithMonitorValue(body.rulename, testDataApi.displayName);

				monitorsHelper.navigateBackToMonitorsPage();
			});
		});

	});


});