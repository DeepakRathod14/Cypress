import MonitorsHelper from '../helper/MonitorsHelper';
import { moduleMetaData, txt } from '../helper/constants';


describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		monitorsHelper.setupHooks();
		// monitorsHelper.cleanupHooks();

		monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
		const testData = monitorsHelper.dataHelper.getData();

		it('Condition: Verify user is able to see all fields related to generating ai script for Script monitor', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7338');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeScript);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);

			// Check fields displayed when toggle button is clicked for condition.
			monitorsHelper.checkToggleButtonDisplayedForCondition();
			monitorsHelper.checkToggleButtonLableDisplayedForCondition(txt.GenerateScriptToggleLabel);
			monitorsHelper.clickOnConditionsGenerativeAIToggleButton();
			monitorsHelper.verifyAllFieldsDisplayedForGenerativeAI(txt.AcceptAIScriptLabel);
		});

		it('Inverse: Verify user is able to see all fields related to generating ai script for Script monitor', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7339');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeScript);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);

			// Check fields displayed when toggle button is clicked for inverse conditions
			monitorsHelper.checkToggleButtonDisplayedForInverseCondition();
			monitorsHelper.checkToggleButtonLableDisplayedForInverseCondition(txt.GenerateScriptToggleLabel);
			monitorsHelper.clickOnInverseConditionsGenerativeAIToggleButton();
			monitorsHelper.verifyAllFieldsDisplayedForGenerativeAIInverse(txt.AcceptAIScriptLabel);

		});

		it('Condition: Verify user is able to generating ai script and copy to script editor for Script monitor', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7340');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeScript);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			
			monitorsHelper.clickOnConditionsGenerativeAIToggleButton();

			monitorsHelper.typeCommandInPromptBox(txt.InputCommand);
			monitorsHelper.clickOnGenerateScriptButton();
			monitorsHelper.checkScriptOutputBoxContainsText();
			monitorsHelper.clickCopyToScriptEditorButton();
		});

		it('Inverse: Verify user is able to generating ai script and copy to script editor for Script monitor', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7341');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeScript);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			
			monitorsHelper.clickOnInverseConditionsGenerativeAIToggleButton();

			monitorsHelper.typeCommandInPromptBoxInverse(txt.InputCommand);
			monitorsHelper.clickOnGenerateScriptButtonInverse();
			monitorsHelper.checkScriptOutputBoxContainsTextInverse();
			monitorsHelper.clickCopyToScriptEditorButtonInverse();
		});

		it('Condition: Verify user is able to create Custom Monitor of Script type with ai generated script for condition', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7342');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeScript);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectScriptRunOn();
			monitorsHelper.typescriptRepeatEvery();
			monitorsHelper.selectScriptRepeatPeriod();
			monitorsHelper.selectScriptLanguage();

			monitorsHelper.clickOnConditionsGenerativeAIToggleButton();
			monitorsHelper.typeCommandInPromptBox(txt.InputCommand);
			monitorsHelper.clickOnGenerateScriptButton();
			monitorsHelper.checkScriptOutputBoxContainsText();
			monitorsHelper.clickCopyToScriptEditorButton();
			monitorsHelper.clickIAgreeCheckboxButton();

			monitorsHelper.selectScriptCriteria();
			monitorsHelper.selectScriptDescriptionOperator();
			monitorsHelper.typeScriptOutput();
			monitorsHelper.selectScriptTriggerReverse();
			monitorsHelper.selectScriptRunOnReverse();
			monitorsHelper.typeScriptRepeatEveryReverse();
			monitorsHelper.selectScriptRepeatPeriodReverse();
			monitorsHelper.selectScriptLanguageReverse();
			monitorsHelper.typeScriptBodyReverse();
			monitorsHelper.selectScriptCriteriaReverse();
			monitorsHelper.selectScriptDescriptionOperatorReverse();
			monitorsHelper.typeScriptOutputReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Inverse: Verify user is able to create Custom Monitor of Script type with ai generated script for inverse', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7343');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeScript);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectScriptRunOn();
			monitorsHelper.typescriptRepeatEvery();
			monitorsHelper.selectScriptRepeatPeriod();
			monitorsHelper.selectScriptLanguage();
			monitorsHelper.typeScriptBody();
			monitorsHelper.selectScriptCriteria();
			monitorsHelper.selectScriptDescriptionOperator();
			monitorsHelper.typeScriptOutput();
			monitorsHelper.selectScriptTriggerReverse();
			monitorsHelper.selectScriptRunOnReverse();
			monitorsHelper.typeScriptRepeatEveryReverse();
			monitorsHelper.selectScriptRepeatPeriodReverse();
			monitorsHelper.selectScriptLanguageReverse();

			monitorsHelper.clickOnInverseConditionsGenerativeAIToggleButton();
			monitorsHelper.typeCommandInPromptBoxInverse(txt.InputCommand);
			monitorsHelper.clickOnGenerateScriptButtonInverse();
			monitorsHelper.checkScriptOutputBoxContainsTextInverse();
			monitorsHelper.clickCopyToScriptEditorButtonInverse();
			monitorsHelper.clickIAgreeCheckboxButtonInverse();

			monitorsHelper.selectScriptCriteriaReverse();
			monitorsHelper.selectScriptDescriptionOperatorReverse();
			monitorsHelper.typeScriptOutputReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

	});
});