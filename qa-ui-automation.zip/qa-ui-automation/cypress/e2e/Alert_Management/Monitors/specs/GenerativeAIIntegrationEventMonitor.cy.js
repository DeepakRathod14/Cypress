import MonitorsHelper from '../helper/MonitorsHelper';
import { moduleMetaData, txt } from '../helper/constants';


describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		monitorsHelper.setupHooks();
		// monitorsHelper.cleanupHooks();

		monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
		const testData = monitorsHelper.dataHelper.getData();

		it('Condition: Verify user is able to see all fields related to generating ai script for Event monitor', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7431');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);

			// Check fields displayed when toggle button is clicked for condition.
			monitorsHelper.checkToggleButtonDisplayedEventMonitor();
			monitorsHelper.checkToggleButtonLableDisplayedEventMonitor(txt.eventLogAIToggleLabel);
			monitorsHelper.clickGenerativeAIToggleButtonEventMonitor();
			monitorsHelper.verifyGenerativeAIFieldsDisplayedEventMonitor(txt.eventLogAITAcceptLabel);
		});

		it('Inverse: Verify user is able to see all fields related to generating ai script for Event monitor', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7432');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);

			// Check fields displayed when toggle button is clicked for inverse conditions
			monitorsHelper.checkToggleButtonDisplayedEventMonitorInverse();
			monitorsHelper.checkToggleButtonLableDisplayedEventMonitorInverse(txt.eventLogAIToggleLabel);
			monitorsHelper.clickGenerativeAIToggleButtonEventMonitorInverse();
			monitorsHelper.verifyGenerativeAIFieldsDisplayedEventMonitorInverse(txt.eventLogAITAcceptLabel);
		});

		it('Condition: Verify user is able to generate ai script and copy for Event monitor', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7433');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			
			monitorsHelper.clickGenerativeAIToggleButtonEventMonitor();

			monitorsHelper.typeCommandInPromptBoxEventMonitor(txt.eventLogAITInput);
			monitorsHelper.clickOnGenerateAndApplyButtonEventMonitor();

			//code to check generated event details
			monitorsHelper.verifyEventLogValueDisplayedEventMonitor(txt.eventLogText);
			monitorsHelper.verifyEventIdValueDisplayedEventMonitor(txt.eventIdText);
			monitorsHelper.verifyEventSeverityValueDisplayedEventMonitor(txt.eventSeverityText);
			monitorsHelper.verifyEventSourceValueDisplayedEventMonitor(txt.eventSourceText);
		});

		it('Inverse: Verify user is able to generating ai script and copy Event monitor', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7434');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			
			monitorsHelper.clickGenerativeAIToggleButtonEventMonitorInverse();

			monitorsHelper.typeCommandInPromptBoxEventMonitorInverse(txt.eventLogAITInput);
			monitorsHelper.clickOnGenerateAndApplyButtonEventMonitorInverse();

			//code to check generated event details
			monitorsHelper.verifyEventLogValueDisplayedEventMonitorInverse(txt.eventLogText);
			monitorsHelper.verifyEventIdValueDisplayedEventMonitorInverse(txt.eventIdText);
			monitorsHelper.verifyEventSeverityValueDisplayedEventMonitorInverse(txt.eventSeverityText);
			monitorsHelper.verifyEventSourceValueDisplayedEventMonitorInverse(txt.eventSourceText);
		});

		it.only('Condition: Verify user is able to create Custom Monitor of Event type with ai generated details.', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7436');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();

			monitorsHelper.clickGenerativeAIToggleButtonEventMonitor();
			monitorsHelper.typeCommandInPromptBoxEventMonitor(txt.eventLogAITInput);
			monitorsHelper.clickOnGenerateAndApplyButtonEventMonitor();
			monitorsHelper.clickIAgreeCheckboxButtonEventMonitor();

			monitorsHelper.verifyEventLogValueDisplayedEventMonitor(txt.eventLogText);
			monitorsHelper.verifyEventIdValueDisplayedEventMonitor(txt.eventIdText);
			monitorsHelper.verifyEventSeverityValueDisplayedEventMonitor(txt.eventSeverityText);
			monitorsHelper.verifyEventSourceValueDisplayedEventMonitor(txt.eventSourceText);

			monitorsHelper.typeEventKeywords();
			monitorsHelper.typeEventIdsReverse();
			monitorsHelper.selectEventLevelSeverityReverse();
			monitorsHelper.typeEventProviderNameReverse();
			monitorsHelper.typeEventKeywordsReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Inverse: Verify user is able to create Custom Monitor of Event type with ai generated details', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7436');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.typeEventIds();
			monitorsHelper.selectEventLevelSeverity();
			monitorsHelper.typeEventProviderName();
			monitorsHelper.typeEventKeywords();

			monitorsHelper.clickGenerativeAIToggleButtonEventMonitorInverse();
			monitorsHelper.typeCommandInPromptBoxEventMonitorInverse(txt.eventLogAITInput);
			monitorsHelper.clickOnGenerateAndApplyButtonEventMonitorInverse();
			monitorsHelper.clickIAgreeCheckboxButtonEventMonitorInverse();

			monitorsHelper.verifyEventLogValueDisplayedEventMonitorInverse(txt.eventLogText);
			monitorsHelper.verifyEventIdValueDisplayedEventMonitorInverse(txt.eventIdText);
			monitorsHelper.verifyEventSeverityValueDisplayedEventMonitorInverse(txt.eventSeverityText);
			monitorsHelper.verifyEventSourceValueDisplayedEventMonitorInverse(txt.eventSourceText);

			monitorsHelper.typeEventKeywordsReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		it('Condition: Verify validation message triggered when user save monitor without selecting checkbox', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7435');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();

			monitorsHelper.clickGenerativeAIToggleButtonEventMonitor();
			monitorsHelper.typeCommandInPromptBoxEventMonitor(txt.eventLogAITInput);
			monitorsHelper.clickOnGenerateAndApplyButtonEventMonitor();

			monitorsHelper.typeEventKeywords();
			monitorsHelper.typeEventIdsReverse();
			monitorsHelper.selectEventLevelSeverityReverse();
			monitorsHelper.typeEventProviderNameReverse();
			monitorsHelper.typeEventKeywordsReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.checkAIAcceptanceValidationMessageEventMonitor(txt.checkboxValidation);
		});

		it('Inverse: Verify validation message triggered when user save monitor without selecting checkbox', { tags: ['@Regression'] }, () => {
			cy.allure().tms('ALERT-T7435');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeEvent);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.typeEventIds();
			monitorsHelper.selectEventLevelSeverity();
			monitorsHelper.typeEventProviderName();
			monitorsHelper.typeEventKeywords();

			monitorsHelper.clickGenerativeAIToggleButtonEventMonitorInverse();
			monitorsHelper.typeCommandInPromptBoxEventMonitorInverse(txt.eventLogAITInput);
			monitorsHelper.clickOnGenerateAndApplyButtonEventMonitorInverse();

			monitorsHelper.typeEventKeywordsReverse();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.checkAIAcceptanceValidationMessageEventMonitorInverse(txt.checkboxValidation);
		});

	});
});