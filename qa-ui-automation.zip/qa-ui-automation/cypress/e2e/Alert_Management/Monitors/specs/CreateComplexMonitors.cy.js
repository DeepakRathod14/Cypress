import MonitorsHelper from '../helper/MonitorsHelper';
import { moduleMetaData, txt } from '../helper/constants';
import { envTag } from '../../../../constants';

describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		monitorsHelper.setupHooks();
		monitorsHelper.cleanupHooks();
		
		monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
		const testData = monitorsHelper.dataHelper.getData();

		it('Verify user is able to create and Edit complex monitors (CPU)', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T6933');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.monitorType);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.selectComplexMonitorCondition(testData.type);			
			monitorsHelper.selectComplexMonitorConditionReversal(testData.type);
			monitorsHelper.selectTargetResourceAndSave('Companies');
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);	
			// Edit Monitor 
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.validateBaseFieldsHaveValues(testData);
			const editedMonitorName = testData.name + '_Edited';
			monitorsHelper.typeMonitorName('_Edited');
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateNewMonitorIsPresentOnGrid(editedMonitorName);			
		});

		it('Verify user is able to create complex monitors (CPU) at Company Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T6928');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.monitorType);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.selectComplexMonitorCondition(testData.type);			
			monitorsHelper.selectComplexMonitorConditionReversal(testData.type);
			monitorsHelper.selectTargetResourceAndSave('Companies');
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);			
		});	
		
		it('Verify user is able to create complex monitors (CPU) at Site Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T6929');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.monitorType);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.selectComplexMonitorCondition(testData.type);			
			monitorsHelper.selectComplexMonitorConditionReversal(testData.type);
			monitorsHelper.selectTargetResourceAndSave('Sites');
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);			
		});

		it('Verify user is able to create complex monitors (CPU) at Device Groups Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T6930');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.monitorType);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.selectComplexMonitorCondition(testData.type);			
			monitorsHelper.selectComplexMonitorConditionReversal(testData.type);
			monitorsHelper.selectTargetResourceAndSave('Device Groups');
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);			
		});

		it('Verify user is able to create complex monitors (CPU) at Devices Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T6931');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.monitorType);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.selectComplexMonitorCondition(testData.type);			
			monitorsHelper.selectComplexMonitorConditionReversal(testData.type);
			monitorsHelper.selectTargetResourceAndSave('Devices');
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);			
		});

		it('Verify user is able to create complex monitors (CPU) at Partner Level', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T6932');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.monitorType);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.selectComplexMonitorCondition(testData.type);			
			monitorsHelper.selectComplexMonitorConditionReversal(testData.type);
			monitorsHelper.selectTargetResourceAtCompanyLevel('All Resources');
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);						
		});	

		it('Verify user is able to create and verify metadata card for complex monitors (CPU)', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, function () {
			cy.allure().tms('ALERT-T6934');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.monitorType);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.selectComplexMonitorCondition(testData.type);			
			monitorsHelper.selectComplexMonitorConditionReversal(testData.type);
			monitorsHelper.selectTargetResourceAndSave('Companies');
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);			
			monitorsHelper.clickMonitorforMetadata();
			monitorsHelper.checkMetaDataCardExist();
			monitorsHelper.checkMetaDataCardData(testData.name);
		});

	});

});