import { envTag } from '../../../../constants';
import MonitorsHelper from '../helper/MonitorsHelper';
import { txt } from '../helper/constants';


describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		monitorsHelper.setupHooksMonitorFromDeviceDetails();
		monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);		
		const testData = monitorsHelper.dataHelper.getData();		

		it('Verify user can create monitor from Applications Tab and verify the details', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7098');			
			monitorsHelper.clickOnApplicationTab();
			monitorsHelper.clickOnCreateMonitorActionForApplication();	
			monitorsHelper.verifySelectedMonitorType(testData.typeApplication);
			monitorsHelper.verifySelectedApplicationStatus();	
			monitorsHelper.verifySelectedApplicationNameFilter();
			monitorsHelper.verifyAppNameField();
		});
		
		it('Verify user can create monitor from Service Tab and verify the details', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7099');			
			monitorsHelper.clickOnServiceTab();	
			monitorsHelper.clickOnCreateMonitorActionForService();
			monitorsHelper.verifyServiceNameField();
			monitorsHelper.verifySelectedMonitorType(testData.typeService);
			monitorsHelper.verifySelectedServiceConditionName();
			monitorsHelper.verifySelectedServiceState();			
		});

	});

});