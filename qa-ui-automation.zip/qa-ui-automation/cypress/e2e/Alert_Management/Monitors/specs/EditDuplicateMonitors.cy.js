import MonitorsHelper from '../helper/MonitorsHelper';
import { txt } from '../helper/constants';


describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();

	// Define global hook for describe block
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		/** 
		 * Base hooks defined for pre and post conditions
		 * before, beforeEach, after, afterEach
		 * NOTE: Add custom conditions to specific test cases only
		 */
		monitorsHelper.setupHooks();
		monitorsHelper.cleanupHooks();

		it('THEN Verify user is able to edit monitor', { tags: ['@Regression', '@CTS'] }, () => {
			// mandatory to link JIRA test case ID
			cy.allure().tms('ALERT-T1590');

			monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
			const testData = monitorsHelper.getData();

			// creating a monitor
			monitorsHelper.baseStepsForMonitorCreation();
			monitorsHelper.selectFromResourceSelectorAndSave(testData.resourceType);
			monitorsHelper.selectMonitorType(testData.type);
			monitorsHelper.toggleTicketResolution(testData.enableInverse);
			monitorsHelper.baseValidationForMonitorCreation();

			// editing a monitor
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.validateBaseFieldsHaveValues(testData);

			const editedMonitorName = testData.name + '_Edited';
			monitorsHelper.typeMonitorName('_Edited');
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage('Monitor "' + editedMonitorName + '" has been saved');
			monitorsHelper.validateNewMonitorIsPresentOnGrid(editedMonitorName);
		});

		
	});

});