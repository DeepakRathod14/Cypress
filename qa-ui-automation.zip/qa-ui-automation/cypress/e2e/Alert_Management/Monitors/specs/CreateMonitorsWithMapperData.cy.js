import { envTag } from '../../../../constants';
import MonitorsHelper from '../helper/MonitorsHelper';
import { moduleMetaData, txt } from '../helper/constants';


describe('GIVEN Monitors', { tags: ['@Monitors', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	var monitorsHelper = new MonitorsHelper();
	monitorsHelper.setupApiIntercepts();

	context('WHERE user is migrated/SSO', { tags: ['@Regression', '@Migrated'] }, () => {

		monitorsHelper.setupHooks();
		monitorsHelper.cleanupHooks();

		monitorsHelper.createMonitorTestDataBasedOnType(txt.cpu);
		const testData = monitorsHelper.dataHelper.getData();	
		
		it('Verify Mapper Toggle button is displayed and Mapper Fields exists', { tags: ['@Regression', '@Mapper', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7128');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			//Check Monitor Toggle button is unchecked by default
			monitorsHelper.checkMapperToggleButtonUncheckedByDefault();	
			//Check Mapper Data Fields exist
			monitorsHelper.checkMapperToggleButtonExist();
			monitorsHelper.clickOnTheMapperToggleButton();			
			monitorsHelper.checkMapperServiceBoardExist();
			//Check Service Board is shwon with asteric mark
			monitorsHelper.checkMapperServiceBoardExistWithAstericMark();
			monitorsHelper.checkMapperTypeExist();
			monitorsHelper.checkMapperSubTypeExist();
			monitorsHelper.checkMapperItemExist();
		});

		it('Verify Mapper Mandatory Fields exists for Mapper Service Board', { tags: ['@Regression', '@Mapper', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7132');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();			
			monitorsHelper.checkMapperToggleButtonExist();			 
			monitorsHelper.clickOnTheMapperToggleButton();			
			monitorsHelper.checkMapperServiceBoardExist();
			monitorsHelper.clickOnSaveChanges();			
			monitorsHelper.checkMapperServiceBoardExistAsMandatoryField();
		});

		it('Verify user is able to create Custom Monitor of Port type with all resources and Mapper Data', 
			{ tags: ['@Regression', '@Mapper', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7129');
				monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
				monitorsHelper.clickOnCreateMonitorButton();
				monitorsHelper.typeMonitorName(testData.name);
				monitorsHelper.typeMonitorDescription(testData.description);
				monitorsHelper.selectMonitorType(testData.typePort);
				monitorsHelper.selectMonitorSeverity(testData.severity);
				monitorsHelper.selectMonitorFamily(testData.family);
				monitorsHelper.clickOnSelectTargetButton();
				monitorsHelper.selectAllRsourcesSelectorValueAndSave();
				monitorsHelper.selectPortType();
				monitorsHelper.typePortNumber();
				monitorsHelper.selectPortState();
				monitorsHelper.typePortTryCount();
				monitorsHelper.typePortVerifyEvery();
				monitorsHelper.selectPortVerifyPeriod();
				monitorsHelper.selectPortTrigger();
				monitorsHelper.selectPortTypeReverse();
				monitorsHelper.typePortNumberReverse();
				monitorsHelper.selectPortStateReverse();
				monitorsHelper.typePortTryCountReverse();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();
				monitorsHelper.selectMapperType();
				monitorsHelper.selectMapperSubType();
				monitorsHelper.selectMapperItem();
				monitorsHelper.clickOnSaveChanges();
				monitorsHelper.validateMonitorToastMessage(testData.message);
				monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
				monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
				//Verify the added Mapper Data 
				monitorsHelper.searchMonitor(testData.name);
				monitorsHelper.clickOnMonitorName(testData.name);
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifySelectedMapperType();
				monitorsHelper.verifySelectedMapperSubType();
				monitorsHelper.verifySelectedMapperItem();
				//Delete Monitor with Mapper Data
				monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
				monitorsHelper.searchMonitorAndSelectRow(testData.name);
				monitorsHelper.clickOnDeleteButton();
				monitorsHelper.clickOnDeleteButtonOnModal();
				monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);	
			});

		it('Verify user is able to create Custom Monitor of Port type with only Service Board Mapper Data', 
			{ tags: ['@Regression', '@Mapper', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
				cy.allure().tms('ALERT-T7133');
				monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
				monitorsHelper.clickOnCreateMonitorButton();
				monitorsHelper.typeMonitorName(testData.name);
				monitorsHelper.typeMonitorDescription(testData.description);
				monitorsHelper.selectMonitorType(testData.typePort);
				monitorsHelper.selectMonitorSeverity(testData.severity);
				monitorsHelper.selectMonitorFamily(testData.family);
				monitorsHelper.clickOnSelectTargetButton();
				monitorsHelper.selectSiteLevelResourceSelectorValueAndSave();
				monitorsHelper.selectPortType();
				monitorsHelper.typePortNumber();
				monitorsHelper.selectPortState();
				monitorsHelper.typePortTryCount();
				monitorsHelper.typePortVerifyEvery();
				monitorsHelper.selectPortVerifyPeriod();
				monitorsHelper.selectPortTrigger();
				monitorsHelper.selectPortTypeReverse();
				monitorsHelper.typePortNumberReverse();
				monitorsHelper.selectPortStateReverse();
				monitorsHelper.typePortTryCountReverse();
				//Enter Mapper Data 
				monitorsHelper.clickOnTheMapperToggleButton();
				monitorsHelper.selectMapperServiceBoard();			
				monitorsHelper.clickOnSaveChanges();
				monitorsHelper.validateMonitorToastMessage(testData.message);
				monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
				monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
				//Verify the added Mapper Data 
				monitorsHelper.searchMonitor(testData.name);
				monitorsHelper.clickOnMonitorName(testData.name);
				monitorsHelper.verifySelectedMapperServiceBoard();
				monitorsHelper.verifyBlankSelectedMapperType();
				monitorsHelper.verifyBlankSelectedMapperSubType();
				monitorsHelper.verifyBlankSelectedMapperItem();
				//Delete Monitor with Mapper Data
				monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
				monitorsHelper.searchMonitorAndSelectRow(testData.name);
				monitorsHelper.clickOnDeleteButton();
				monitorsHelper.clickOnDeleteButtonOnModal();
				monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);	
			});
		
		it('Verify user is able to edit mapper data of created Custom Monitor of Port type', { tags: ['@Regression', '@Mapper', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7130');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typePort);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectPortType();
			monitorsHelper.typePortNumber();
			monitorsHelper.selectPortState();
			monitorsHelper.typePortTryCount();
			monitorsHelper.typePortVerifyEvery();
			monitorsHelper.selectPortVerifyPeriod();
			monitorsHelper.selectPortTrigger();
			monitorsHelper.selectPortTypeReverse();
			monitorsHelper.typePortNumberReverse();
			monitorsHelper.selectPortStateReverse();
			monitorsHelper.typePortTryCountReverse();
			//Enter Mapper Data 
			monitorsHelper.clickOnTheMapperToggleButton();
			monitorsHelper.selectMapperServiceBoard();
			monitorsHelper.selectMapperType();
			monitorsHelper.selectMapperSubType();
			monitorsHelper.selectMapperItem();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			//Verify the added Mapper Data 
			monitorsHelper.searchMonitor(testData.name);
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.verifySelectedMapperServiceBoard();
			monitorsHelper.verifySelectedMapperType();
			monitorsHelper.verifySelectedMapperSubType();
			monitorsHelper.verifySelectedMapperItem();
			//Edit Mapper Data
			monitorsHelper.selectMapperTypeNewValue();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			//Verify Edited Mapper Data
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.searchMonitor(testData.name);
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.verifySelectedMapperServiceBoard();
			monitorsHelper.verifySelectedMapperTypeWithNewValue();
			monitorsHelper.verifySelectedMapperSubType();
			monitorsHelper.verifySelectedMapperItem();
			//Delete Monitor with Mapper Data
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.searchMonitorAndSelectRow(testData.name);
			monitorsHelper.clickOnDeleteButton();
			monitorsHelper.clickOnDeleteButtonOnModal();
			monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);			
		});	

		it('Verify user is able to delete created Custom Monitor of Port type with Mapper Data', { tags: ['@Regression', '@Mapper', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7131');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typePort);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectPortType();
			monitorsHelper.typePortNumber();
			monitorsHelper.selectPortState();
			monitorsHelper.typePortTryCount();
			monitorsHelper.typePortVerifyEvery();
			monitorsHelper.selectPortVerifyPeriod();
			monitorsHelper.selectPortTrigger();
			monitorsHelper.selectPortTypeReverse();
			monitorsHelper.typePortNumberReverse();
			monitorsHelper.selectPortStateReverse();
			monitorsHelper.typePortTryCountReverse();
			//Enter Mapper Data 
			monitorsHelper.clickOnTheMapperToggleButton();
			monitorsHelper.selectMapperServiceBoard();
			monitorsHelper.selectMapperType();
			monitorsHelper.selectMapperSubType();
			monitorsHelper.selectMapperItem();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);						
			//Delete Monitor with Mapper Data
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.searchMonitorAndSelectRow(testData.name);
			monitorsHelper.clickOnDeleteButton();
			monitorsHelper.clickOnDeleteButtonOnModal();
			monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);	
		});

		it('Verify Monitor created with Mapper Data when toggled off then values are shown as blank', { tags: ['@Regression', '@Mapper', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7138');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typePort);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectPortType();
			monitorsHelper.typePortNumber();
			monitorsHelper.selectPortState();
			monitorsHelper.typePortTryCount();
			monitorsHelper.typePortVerifyEvery();
			monitorsHelper.selectPortVerifyPeriod();
			monitorsHelper.selectPortTrigger();
			monitorsHelper.selectPortTypeReverse();
			monitorsHelper.typePortNumberReverse();
			monitorsHelper.selectPortStateReverse();
			monitorsHelper.typePortTryCountReverse();
			//Enter Mapper Data 
			monitorsHelper.clickOnTheMapperToggleButton();
			monitorsHelper.selectMapperServiceBoard();
			monitorsHelper.selectMapperType();
			monitorsHelper.selectMapperSubType();
			monitorsHelper.selectMapperItem();		
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);			
			//Verify the added Mapper Data 
			monitorsHelper.searchMonitor(testData.name);
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.verifySelectedMapperServiceBoard();
			monitorsHelper.verifySelectedMapperType();
			monitorsHelper.verifySelectedMapperSubType();
			monitorsHelper.verifySelectedMapperItem();
			//Verify the added Mapper Data 			
			monitorsHelper.clickOnTheMapperToggleButton();
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			//Verify the Mapper Data should be blank after toggle
			monitorsHelper.searchMonitor(testData.name);
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.checkMapperToggleButtonUncheckedByDefault();
			monitorsHelper.clickOnTheMapperToggleButton();
			monitorsHelper.verifyBlankSelectedMapperServiceBoard();
			monitorsHelper.verifyBlankSelectedMapperType();
			monitorsHelper.verifyBlankSelectedMapperSubType();
			monitorsHelper.verifyBlankSelectedMapperItem();
			//Delete Monitor with Mapper Data
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.searchMonitorAndSelectRow(testData.name);
			monitorsHelper.clickOnDeleteButton();
			monitorsHelper.clickOnDeleteButtonOnModal();
			monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);	
		});

		it('Verify Monitor created with Mapper Data and toggled off before saving then values are shown as blank', { tags: ['@Regression', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7139');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typePort);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();
			monitorsHelper.selectPortType();
			monitorsHelper.typePortNumber();
			monitorsHelper.selectPortState();
			monitorsHelper.typePortTryCount();
			monitorsHelper.typePortVerifyEvery();
			monitorsHelper.selectPortVerifyPeriod();
			monitorsHelper.selectPortTrigger();
			monitorsHelper.selectPortTypeReverse();
			monitorsHelper.typePortNumberReverse();
			monitorsHelper.selectPortStateReverse();
			monitorsHelper.typePortTryCountReverse();
			//Enter Mapper Data 
			monitorsHelper.clickOnTheMapperToggleButton();
			monitorsHelper.selectMapperServiceBoard();
			monitorsHelper.selectMapperType();
			monitorsHelper.selectMapperSubType();
			monitorsHelper.selectMapperItem();
			// Toggle Mapper Button
			monitorsHelper.clickOnTheMapperToggleButton();
			// Save Monitor and verify
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);			
			//Verify the Mapper Data should be blank after toggle
			monitorsHelper.searchMonitor(testData.name);
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.checkMapperToggleButtonUncheckedByDefault();
			monitorsHelper.clickOnTheMapperToggleButton();
			monitorsHelper.verifyBlankSelectedMapperServiceBoard();
			monitorsHelper.verifyBlankSelectedMapperType();
			monitorsHelper.verifyBlankSelectedMapperSubType();
			monitorsHelper.verifyBlankSelectedMapperItem();
			//Delete Monitor with Mapper Data
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.searchMonitorAndSelectRow(testData.name);
			monitorsHelper.clickOnDeleteButton();
			monitorsHelper.clickOnDeleteButtonOnModal();
			monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);	
		});

		it('Verify user is able to create Complex Monitor with Mapper Data', { tags: ['@Regression', '@Mapper', envTag.CTS, envTag.Prod_NA, envTag.Prod_EU] }, () => {
			cy.allure().tms('ALERT-T7140');
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.clickOnCreateMonitorButton();
			monitorsHelper.typeMonitorName(testData.name);
			monitorsHelper.typeMonitorDescription(testData.description);
			monitorsHelper.selectMonitorType(testData.typeComplex);
			monitorsHelper.selectMonitorSeverity(testData.severity);
			monitorsHelper.selectMonitorFamily(testData.family);
			monitorsHelper.clickOnSelectTargetButton();
			monitorsHelper.selectCompanyLevelResourceSelectorValueAndSave();

			monitorsHelper.selectComplexConditionType();
			monitorsHelper.selectComplexConditionServiceName();
			monitorsHelper.selectComplexConditionServiceState();

			monitorsHelper.clickOnTheComplexMonitorsTicketResolutionToggle();

			// monitorsHelper.selectComplexConditionInverseType();
			// monitorsHelper.selectComplexConditionServiceNameInverse();
			// monitorsHelper.selectComplexConditionServiceStateInverse();

			//Enter Mapper Data 
			monitorsHelper.clickOnTheMapperToggleButton();
			monitorsHelper.selectMapperServiceBoard();
			monitorsHelper.selectMapperType();
			monitorsHelper.selectMapperSubType();
			monitorsHelper.selectMapperItem();
			//Save Monitor 
			monitorsHelper.clickOnSaveChanges();
			monitorsHelper.validateMonitorToastMessage(testData.message);
			monitorsHelper.validateNewMonitorIsPresentOnGrid(testData.name);
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			//Verify the added Mapper Data 
			monitorsHelper.searchMonitor(testData.name);
			monitorsHelper.clickOnMonitorName(testData.name);
			monitorsHelper.verifySelectedMapperServiceBoard();
			monitorsHelper.verifySelectedMapperType();
			monitorsHelper.verifySelectedMapperSubType();
			monitorsHelper.verifySelectedMapperItem();
			//Delete Monitor with Mapper Data
			monitorsHelper.navigateToPageOnCheck(moduleMetaData.name);
			monitorsHelper.searchMonitorAndSelectRow(testData.name);
			monitorsHelper.clickOnDeleteButton();
			monitorsHelper.clickOnDeleteButtonOnModal();
			monitorsHelper.validateMonitorToastMessage(txt.singleDeleteSuccessMessage);	
			
		});

	});

});