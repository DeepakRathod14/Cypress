export const moduleMetaData = {
	name: 'Agent Report',
	customUser: 'user_2'
};

export const txt = {
	'approve': 'Approve',
	'desktopType' : 'Desktop',
	'serverType' : 'Server',
	'positionL' : 'left',
	'positionR' : 'right',
	'deviceColName' : 'Name',
	'frindlyNameColumn': 'Friendly Name',
	'deviceTypeColumn': 'Device Type',
	'siteNameColumn' : 'Site Name',
	'siteFrindlyNameColumn': 'Site Friendly Name',
	'companyFriendlyNameColumn':'Company Friendly Name',
	'companyNameColumn':'Company Name',
	'IpAddressColumn': 'IP Address',
	'agentVersionColumn': 'Agent Version',
	'agentVersionStatusColumn': 'Agent Version Status',
	'lastOnlineColumn': 'Last Online',
	'lastLoggedOnUserColumn': 'Last Logged On User',
	'lastBootTimeColumn': 'Last Boot Time',
	'deviceTimeZoneColumn': 'Device Time Zone',
	'gatewayCacheColumn': 'Gateway Cache',
	'installedDateColumn': 'Installed Date',
	'osColName' : 'OS',

};

export const operator = {
	'is': 'is',
	'isNot': 'is not',
	'isAnyOf': 'is any of',
	'equals': 'equals',
	'contains': 'contains',
};

export const ltr = {
	'columns': '.MuiDataGrid-columnHeader.MuiDataGrid-withBorderColor',
	'gridRow': '.MuiDataGrid-row',
	'gridVirtualScroller': '.MuiDataGrid-virtualScroller',
	'selectColumn': '.MuiDataGrid-columnHeaderTitleContainer',
	'searchIcon': '.MuiButtonBase-root.MuiIconButton-root.MuiIconButton-sizeMedium.css-w9aoya',
	'nativeSelect': '.MuiNativeSelect-select',
	'valueTextField': '.MuiInputBase-input.css-16rhzhe',
	'reportTitle': '.css-q7hzx0',
	'deviceType': 'div[data-field="ENDPOINT_TYPE"] .MuiDataGrid-cellContent',
	'closeIcon': '.MuiButtonBase-root.MuiIconButton-root.MuiIconButton-sizeSmall.css-51mpi5',
	'nameColumn': 'div[data-field="SYSTEM_NAME"] .MuiDataGrid-cellContent',
	'osList': '[data-rowindex="0"]>[data-field="OS_PRODUCT"] .MuiDataGrid-cellContent',
	'siteList': '[data-rowindex="0"]>div[data-field="SITE_NAME"] .MuiDataGrid-cellContent',
	'filterIcon': 'FilterAltOutlinedIcon',
	'toogleIcon': '.PrivateSwitchBase-input.css-1m9pwf3',
	'viewColumnIcon': 'ViewColumnOutlinedIcon',
	'dataViewIcon': 'ViewStreamIcon',
	'list': '.MuiList-root',
	'deviceName': '[data-rowindex="0"]>[data-field="SYSTEM_NAME"] .MuiDataGrid-cellContent',
	'agentUninstallButton': 'agent-report-uninstall-button',
	'endpointCheckbox':'.css-1m9pwf3',
	'agentUninstallGrid':'agent-management-uninstall-grid',
	'hardReference':'button.css-18relo',
	'reasonDropdown':'agent-uninstall-reason-dropdown',
	'reasonList':'li.css-p9mmq8',
	'uninstallAgentButton':'agent-uninstall-modal-uninstall-button',
	'confirmButton':'button.css-16i0xqd',
	'confirmationMessage':'.css-3liyom'
};