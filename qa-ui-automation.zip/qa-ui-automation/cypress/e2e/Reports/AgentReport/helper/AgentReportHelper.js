/* eslint-disable no-empty */
import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper }
from '../../../../fixtures';
import { txt, ltr, moduleMetaData } from './constants';
 
class AgentReportHelper extends CommonHelper{
 
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.CommonHelper =  new CommonHelper();
	}

	validateReportsColumn() {
		cy.get(ltr.gridRow, { timeout: 40000 });
		cy.contains(ltr.columns, txt.deviceColName);
		cy.contains(ltr.columns, txt.frindlyNameColumn);
		cy.contains(ltr.columns, txt.deviceTypeColumn);
		cy.contains(ltr.columns, txt.siteNameColumn);
		cy.contains(ltr.columns, txt.osColName);
		cy.contains(ltr.columns, txt.siteFrindlyNameColumn);
		cy.contains(ltr.columns, txt.companyFriendlyNameColumn);
		cy.contains(ltr.columns, txt.companyNameColumn);
		cy.contains(ltr.columns, txt.IpAddressColumn);
		cy.contains(ltr.columns, txt.agentVersionColumn);
		cy.contains(ltr.columns, txt.agentVersionStatusColumn);
		cy.contains(ltr.columns, txt.lastOnlineColumn);
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionR);
		cy.contains(ltr.columns, txt.lastBootTimeColumn);
		cy.contains(ltr.columns, txt.lastLoggedOnUserColumn);
		cy.contains(ltr.columns, txt.deviceTimeZoneColumn);
		cy.contains(ltr.columns, txt.gatewayCacheColumn);
		cy.contains(ltr.columns, txt.installedDateColumn);
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionL);
	}	

	validateReportTitle()
	{
		this.getLastElement(ltr.reportTitle).should('have.text', moduleMetaData.name);
	}
	searchInTheGridAndValidateDeviceName(deviceNameLocator) {
		this.getTextFromList(deviceNameLocator).then((elementText) => {
			this.gridHelper.searchEntryInGrid(ltr.searchIcon, elementText);
			this.gridHelper.getRowByIndex(ltr.nameColumn, 0).should('have.text', elementText);
			this.getList(ltr.deviceName).contains(elementText);
			this.buttonHelper.clickButton(ltr.closeIcon);
		});
	}

	searchInTheGridAndValidateDeviceType(deviceType) {
		this.gridHelper.searchEntryInGrid(ltr.searchIcon, deviceType);
		this.gridHelper.getRowByIndex(ltr.deviceType,0).should('have.text', deviceType);
		this.getList(ltr.deviceType).contains(txt.desktopType);
		this.buttonHelper.clickButton(ltr.closeIcon);
	}

	sortTheColumn(colIndex){
		this.getRowByIndex(ltr.gridRow, colIndex).invoke('text').as('initialText')
			.then((initialText) => {
				this.validateFirstRowExists(ltr.gridRow);
				this.sortColumn(ltr.selectColumn, colIndex);
				this.getRowByIndex(ltr.gridRow, colIndex)
					.invoke('text')
					.then((newText) => {
						expect(newText).to.not.equal(initialText);
					});
			});
	}
	filterUsingSiteName(siteNameColumn, operator, siteNameListLocator) {
		this.clickFilterIcon();
		this.getTextFromList(siteNameListLocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,siteNameColumn);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.siteList).contains(elementText);
		});
		
	}
	filterUsingOS(osColname, operator, osListLocator) {
		this.clickFilterIcon();
		this.getTextFromList(osListLocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,osColname);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.osList).should('not.contain', elementText);
		});
	}
	filterUsingDeviceName(deviceNameColumn, operator, deviceNameListlocator) {
		this.clickFilterIcon();
		this.getTextFromList(deviceNameListlocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,deviceNameColumn);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.inputFieldHelper.typeIntoInputField(ltr.valueTextField, elementText);
			cy.wait(3000);
			this.getList(ltr.nameColumn).contains(elementText);
		});
	}
	agentUninstallButtonDisabledStatus() {
		cy.log('Without selecting the endpoint checkbox the agent uninstall button should be disabled');
		this.getAgentUninstallButton().should('be.disabled');
	}
	agentUninstallButtonEnabledStatus() {
		cy.wait(1000);
		this.getLastElement(ltr.endpointCheckbox).check();
		cy.log('agent uninstall button is enabled after selecting single endpoint');
		this.getAgentUninstallButton().should('be.enabled');
		cy.reload();
		this.getElementWithIndex(ltr.endpointCheckbox,1).check();
		cy.wait(1000);
		this.getElementWithIndex(ltr.endpointCheckbox,2).check();
		cy.wait(1000);
		this.getElementWithIndex(ltr.endpointCheckbox,3).check();
		cy.wait(1000);
		this.getElementWithIndex(ltr.endpointCheckbox,4).check();
		cy.wait(1000);
		this.getElementWithIndex(ltr.endpointCheckbox,5).check();
		cy.wait(1000);
		cy.log('agent uninstall button is enabled after selecting 5 endpoints');
		this.getAgentUninstallButton().should('be.enabled');

	}
	agentUninstallButtonDisabledStatusForMoreThenFiveEndpoints() {
		this.getFirstElement(ltr.endpointCheckbox).check();
		cy.log('agent uninstall button is disabled after selecting all endpoints checkbox');
		this.getAgentUninstallButton().should('be.disabled');
	}

	agentUninstallation(){
		cy.wait(1000);
		const endpoint = this.getElementWithIndex(ltr.endpointCheckbox,1);
		endpoint.check();
		this.getAgentUninstallButton().click();
		const agentUninstallModal = this.wrapDataTestId(ltr.agentUninstallGrid);
		this.getElementWithWait(agentUninstallModal, 10000);
		const reasonDropdown= this.wrapDataTestId(ltr.reasonDropdown);
		this.dropdownHelper.getDropDownAndSelectValue(reasonDropdown, ltr.reasonList, 'Maintenance (plan to re-install)' );
		const uninstallAgentButton = this.wrapDataTestId(ltr.uninstallAgentButton);
		this.buttonHelper.clickButton(uninstallAgentButton);
		this.buttonHelper.clickButton(ltr.confirmButton);
		this.getElementWithText(ltr.confirmationMessage,'1 Agent(s) successfully uninstalled.');

	}
	agentUninstallationForMultipleEndpoint(){
		cy.wait(1000);
		const endpoint1 = this.getElementWithIndex(ltr.endpointCheckbox,1);
		endpoint1.check();
		const endpoint2 = this.getElementWithIndex(ltr.endpointCheckbox,2);
		endpoint2.check();
		const endpoint3 = this.getElementWithIndex(ltr.endpointCheckbox,3);
		endpoint3.check();
		this.getAgentUninstallButton().click();
		const agentUninstallModal = this.wrapDataTestId(ltr.agentUninstallGrid);
		this.getElementWithWait(agentUninstallModal, 10000);
		const reasonDropdown= this.wrapDataTestId(ltr.reasonDropdown);
		this.dropdownHelper.getDropDownAndSelectValue(reasonDropdown, ltr.reasonList, 'Maintenance (plan to re-install)' );
		const uninstallAgentButton = this.wrapDataTestId(ltr.uninstallAgentButton);
		this.buttonHelper.clickButton(uninstallAgentButton);
		this.buttonHelper.clickButton(ltr.confirmButton);
		this.getElementWithText(ltr.confirmationMessage,'3 Agent(s) successfully uninstalled.');

	}

	getAgentUninstallButton = () => {
		const dataTestId = this.wrapDataTestId(ltr.agentUninstallButton);
		return this.getElement(dataTestId);
	}
	clickAgentUninstallButton = () => {
		return this.getAgentUninstallButton().click();
	}

	scrollGridToRight(gridVirtualScroller, position) {
		this.getElement(gridVirtualScroller).scrollTo(position);
	}

	getRowByIndex = (gridRowLocator, index) => {
		return this.gridHelper.getRowByIndex(gridRowLocator, index);
	}
	validateFirstRowExists = (gridRowLocator) => {
		return this.gridHelper.validateFirstRowExists(gridRowLocator);
	}
	sortColumn = (columnHeaderLocator, columnIndex) => {
		return this.gridHelper.sortColumn(columnHeaderLocator, columnIndex);
	}
	getFilterIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.filterIcon);
		return this.getElement(dataTestId);
	}
	selectDropdownValue = (dropdownSelector, index, value) => {
		return this.dropdownHelper.selectDropdownValue(dropdownSelector, index, value);
	}
	clickFilterIcon = () => {
		return this.getFilterIcon().click();
	}
	
	getViewColumnIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.viewColumnIcon);
		return this.getElement(dataTestId);
	}
	clickViewColumnIcon = () => {
		return this.getViewColumnIcon().click();
	}
	getDataViewIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.dataViewIcon);
		return this.getElement(dataTestId);
	}
	clickDataViewIcon = () => {
		return this.getDataViewIcon().click();
	}
	changeView = (rowSelector, view) => {
		return this.gridHelper.changeGridView(rowSelector, view);
	}
	getList = (listLocator) => {
		return this.getElement(listLocator);
	}
	getTextFromList = (locator) => {
		return cy.get(locator).invoke('text').then((text) => {
			const elementText = text;
			return cy.wrap(elementText);
		});
	}


}

export default AgentReportHelper;
