import AgentReportHelper from '../helper/AgentReportHelper';

import { moduleMetaData, txt, ltr, operator } from '../helper/constants';

describe('GIVEN Agent Report', { tags: ['@Regression', '@MUI'] }, () => {

	var agentReportHelper = new AgentReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => { });

		beforeEach(() => {
			agentReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN validate report title for the report', function () {
			cy.allure().tms('CMD-T8872');
			agentReportHelper.validateReportTitle();
		});

		it('THEN validate the columns available in the report', function () {
			cy.allure().tms('CMD-T8873');
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.validateReportsColumn();
		});

		it('THEN validate the sorting for column', function () {
			cy.allure().tms('CMD-T8874');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.sortTheColumn(1);
			agentReportHelper.sortTheColumn(1);
			cy.reload();
			agentReportHelper.sortTheColumn(2);
			agentReportHelper.sortTheColumn(2);
			cy.reload();
			//agentReportHelper.sortTheColumn(4);
			//agentReportHelper.sortTheColumn(4);
		});

		it('THEN validate the data filtering in the grid for OS name', function () {
			cy.allure().tms('CMD-T8879');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.filterUsingOS(txt.osColName, operator.isNot, ltr.osList);
		});

		it('THEN validate the data filtering in the grid for device name', function () {
			cy.allure().tms('CMD-T8880');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.filterUsingDeviceName(txt.deviceColName, operator.equals, ltr.deviceName);
		});

		it('THEN validate the different view of data in the grid', function () {
			cy.allure().tms('CMD-T8881');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.clickDataViewIcon();
			agentReportHelper.getList(ltr.list).children().eq(0).click();
			agentReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.clickDataViewIcon();
			agentReportHelper.getList(ltr.list).children().eq(1).click();
			agentReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.clickDataViewIcon();
			agentReportHelper.getList(ltr.list).children().eq(2).click();
			agentReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate the functionality to hide or show the columns in the grid', function () {
			cy.allure().tms('CMD-T8882');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.clickViewColumnIcon();
			agentReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			agentReportHelper.clickViewColumnIcon();
			agentReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');

		});
		
		it('THEN validate the search functionality in the report for device name', function () {
			cy.allure().tms('CMD-T8883');
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});
		
		it('THEN validate the search functionality in the report for device type', function () {
			cy.allure().tms('CMD-T8884');
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.searchInTheGridAndValidateDeviceType(txt.desktopType);
		});

		it('THEN validate the agent uninstall button is available and is disabled by default', function () {
			//cy.allure().tms('CMD-T8884');
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.agentUninstallButtonDisabledStatus();
		});
		it('THEN validate the agent uninstall button is enabled after selecting min 1 endpoint or max 5 endpoints', function () {
			//cy.allure().tms('CMD-T8884');
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.agentUninstallButtonEnabledStatus();
		});
		it('THEN validate the agent uninstall button is disabled after selecting more than 5 endpoints', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.agentUninstallButtonDisabledStatusForMoreThenFiveEndpoints();
		});
		it('THEN validate the agent uninstallation triggered for a specific endpoint', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.agentUninstallation();
		});
		it('THEN validate the agent uninstallation triggered for more than one endpoint', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentReportHelper.agentUninstallationForMultipleEndpoint();
		});
		
	});
});

