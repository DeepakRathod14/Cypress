export const moduleMetaData = {
	name: 'Automation Execution Detail Report',
	customUser: 'user_1'
};

export const txt = {
	'approve': 'Approve',
	'reportTitle' : 'Automation Execution Detail Report',
	'desktopType' : 'Desktop',
	'serverType' : 'Server',
	'positionL' : 'left',
	'positionR' : 'right',
	'nameColumn':'Name',
	'friendlyNameColumn':'Friendly Name',
	'companyNameColumn':'Company Name',
	'companyFriendlyName':'Company Friendly Name',
	'siteNameColumn':'Site Name',
	'siteFriendlyName':'Site Friendly Name',
	'taskNameColumn': 'Task Name',
	'taskDescriptionColumn':'Task Description',
	'taskTypeColumn':'Task Type',
	'taskFrequencyColumn':'Task Frequency',
	'taskStatusColumn':'Task Status',
	'failureReasonColumn':'Failure Reason',
	'executionOutputColumn':'Execution Output',
	'lastExecutedColumn' : 'Last Executed On',
	'createdByColumn': 'Created By',
	'createdOnColumn' : 'Created On',
	'deviceTimeZoneColumn':'Device Time Zone',
	'expectedRows' : 'expectedRows',
	'noRows' : 'noRows'
};

export const operator = {
	'is': 'is',
	'isNot': 'is not',
	'isAnyOf': 'is any of',
	'equals': 'equals',
	'contains': 'contains',
};

export const ltr = {
	'reportTitle': '.css-q7hzx0',
	'gridRow': '.MuiDataGrid-row',
	'columns': '.MuiDataGrid-columnHeader.MuiDataGrid-withBorderColor',
	'taskName': '[data-rowindex="0"]>[data-field="TASK_NAME"] .MuiDataGrid-cellContent',
	'taskNameList': '[data-field="TASK_NAME"] .MuiDataGrid-cellContent',
	'taskType': '[data-rowindex="0"]>[data-field="TASK_TYPE"] .MuiDataGrid-cellContent',
	'taskTypeList':'[data-field="TASK_TYPE"] .MuiDataGrid-cellContent',
	'searchIcon': 'SearchOutlinedIcon',
	'closeIcon': 'CloseIcon',
	'selectColumn': '.MuiDataGrid-columnHeaderTitleContainer',
	'list': '.MuiList-root',
	'dataViewIcon': 'ViewStreamIcon',
	'lastExecutedOnList':'[data-field="LAST_EXECUTED_ON"] .MuiDataGrid-cellContent',
	'calendarLocator':'CalendarIcon',
	'arrowLeftIconLocator':'ArrowLeftIcon',
	'arrowRightIconLocator': 'ArrowRightIcon',
	'GoButton': 'reporting-date-go-button',
	'dateLocator':'.css-183nxzx',
	'goButton': 'reporting-date-go-button',
	'toggleColumnIcon': 'ViewColumnOutlinedIcon',
	'filterIcon': 'FilterAltOutlinedIcon',
	'nativeSelect': '.MuiNativeSelect-select',
	'gridVirtualScroller': '.MuiDataGrid-virtualScroller',
	'hideColumnSelector': '.MuiDataGrid-columnsPanelRow input',
	'globalDownload':'.css-d2jjfw',
	'noDataDisplayMessage':'.css-134robw'
};