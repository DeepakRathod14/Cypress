import AutomationExecutionDetailReportHelper from '../helper/AutomationExecutionDetailReportHelper';

import { moduleMetaData, txt, ltr, operator } from '../helper/constants';

describe('GIVEN Automation Execution Detail Report validation', { tags: ['@Regression', '@MUI'] }, () => {

	var automationExecutionDetailReportHelper = new AutomationExecutionDetailReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here

	context('WHEN user is migrated/SSO', { tags: ['@Migrated'] }, () => {

		// define hooks for pre and post conditions
		before(() => { });

		beforeEach(() => {
			automationExecutionDetailReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		// Validate the title of the report
		it('THEN validate the report title', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.validateReportTitle();
		});

		//validate the columns available in the report
		it('THEN validate the columns available in the report', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.validateReportsColumn();
		});
		
		// validate the search for task name
		it('THEN validate the search functionality in the report for task name', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.searchInTheGridAndValidateTaskName(ltr.taskName);
		});
		// validate the search for task type
		it('THEN validate the search functionality in the report for task type', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.searchInTheGridAndValidateTaskType(ltr.taskType);
	
		});
		// Sorting
		it('THEN validate the sorting for column', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			//ascending order
			automationExecutionDetailReportHelper.sortTheColumn(2);
			//descending order
			automationExecutionDetailReportHelper.sortTheColumn(2);
			cy.reload();
			//ascending order
			automationExecutionDetailReportHelper.sortTheColumn(3);
			//descending order
			automationExecutionDetailReportHelper.sortTheColumn(3);
			cy.reload();
			
		});
		//filter
		it('THEN validate the data filtering in the grid for task type', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.filterUsingTaskType(txt.taskTypeColumn, operator.is, ltr.taskType);
		});

		it('THEN validate the data filtering in the grid for task name', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.filterUsingTaskName(txt.taskNameColumn, operator.isNot, ltr.taskName);
		});

		// find the column
		it('THEN validate the functionality to hide the columns in the grid', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.hideColumnsInGrid();
		});
		
		it('THEN validate the different view of data in the grid', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.clickDataViewIcon();
			automationExecutionDetailReportHelper.getList(ltr.list).children().eq(0).click();
			automationExecutionDetailReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.clickDataViewIcon();
			automationExecutionDetailReportHelper.getList(ltr.list).children().eq(1).click();
			automationExecutionDetailReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionDetailReportHelper.clickDataViewIcon();
			automationExecutionDetailReportHelper.getList(ltr.list).children().eq(2).click();
			automationExecutionDetailReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate that report is showing the records in the grid as per selected date in top filter', function () {
			cy.reload();
			automationExecutionDetailReportHelper.ReportDateYearFilter();
			automationExecutionDetailReportHelper.ExecutionDateFilter();
		});

		it('THEN validate that report has a global download button to download a large amount of data ', function () {
			cy.reload();
			automationExecutionDetailReportHelper.globalDownload(txt.expectedRows);
		});
	});

});

