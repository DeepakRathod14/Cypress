import SystemInformationReportHelper from '../helper/SystemInformationReportHelper';

import { moduleMetaData, txt, ltr, operator } from '../helper/constants';

describe('GIVEN System Information Report', { tags: ['@Regression', '@MUI'] }, () => {

	var systemInformationReportHelper = new SystemInformationReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => { });

		beforeEach(() => {
			systemInformationReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN validate title for the report', function () {
			cy.allure().tms('CMD-T9105');
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.validateReportTitle();
		});

		it('THEN validate the columns available in the report', function () {
			cy.allure().tms('CMD-T9114');
			systemInformationReportHelper.validateReportsColumn();
		});

		it('THEN validate the sorting for column', function () {
			cy.allure().tms('CMD-T9113');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.sortTheColumn(1);
			systemInformationReportHelper.sortTheColumn(1);
			cy.reload();
			systemInformationReportHelper.sortTheColumn(2);
			systemInformationReportHelper.sortTheColumn(2);
			cy.reload();
			systemInformationReportHelper.sortTheColumn(7);
			systemInformationReportHelper.sortTheColumn(7);
		});

		it('THEN validate the data filtering in the grid for OS name', function () {
			cy.allure().tms('CMD-T8879');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.filterUsingOS(txt.osColumn, operator.isNot, ltr.osList);
		});

		it('THEN validate the data filtering in the grid for device name', function () {
			cy.allure().tms('CMD-T8880');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.filterUsingDeviceName(txt.nameColumn, operator.equals, ltr.deviceName);
		});

		it('THEN validate the different view of data in the grid', function () {
			cy.allure().tms('CMD-T8881');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.clickDataViewIcon();
			systemInformationReportHelper.getList(ltr.list).children().eq(0).click();
			systemInformationReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.clickDataViewIcon();
			systemInformationReportHelper.getList(ltr.list).children().eq(1).click();
			systemInformationReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.clickDataViewIcon();
			systemInformationReportHelper.getList(ltr.list).children().eq(2).click();
			systemInformationReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate the functionality to hide or show the columns in the grid', function () {
			cy.allure().tms('CMD-T8882');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.clickViewColumnIcon();
			systemInformationReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			systemInformationReportHelper.clickViewColumnIcon();
			systemInformationReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');

		});
		
		it('THEN validate the search functionality in the report for device name', function () {
			cy.allure().tms('CMD-T8883');
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});
		
		it('THEN validate the search functionality in the report for device type', function () {
			cy.allure().tms('CMD-T8884');
			cy.get(ltr.gridRow, { timeout: 40000 });
			systemInformationReportHelper.searchInTheGridAndValidateDeviceType(txt.desktopType);
		});		
	});
});

