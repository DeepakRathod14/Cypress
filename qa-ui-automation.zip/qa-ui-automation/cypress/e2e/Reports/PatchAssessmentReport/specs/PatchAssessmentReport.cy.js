import PatchAssessmentReportHelper from '../helper/PatchAssessmentReportHelper';

import { moduleMetaData, ltr, txt, operator } from '../helper/constants';

describe('GIVEN Patch Assessment Report', { tags: ['@Regression', '@MUI'] }, () => {

	var patchAssessmentReportHelper = new PatchAssessmentReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => { });

		beforeEach(() => {
			patchAssessmentReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});
		afterEach(() => { 
			cy.reload();
			cy.wait(2000);
		});
		// test cases start here
		it('THEN validate report title for the report', { tags: ['@Reporting', '@Sanity'] }, () => {
			cy.allure().tms('CMD-T9260');
			patchAssessmentReportHelper.validateReportTitle();
		});

		it('THEN validate the columns available in the report', { tags: ['@Reporting', '@Sanity'] }, () => {
			cy.allure().tms('CMD-T9267');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.validateReportsColumn();
		});

		it('THEN validate the sorting for column', { tags: ['@Reporting'] }, () => {
			cy.allure().tms('CMD-T9266');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.sortTheColumn(8);
			patchAssessmentReportHelper.sortTheColumn(8);

		});

		
		it('THEN validate the data filtering in the grid for OS name', { tags: ['@Reporting'] }, () => {
			cy.allure().tms('CMD-T9264');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.filterUsingOS(txt.osNameColumn, operator.isNot, ltr.osName);
		});

		it('THEN validate the data filtering in the grid for device name', { tags: ['@Reporting'] }, () => {
			cy.allure().tms('CMD-T9263');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.filterUsingDeviceName(txt.deviceNameColumn, operator.equals, ltr.deviceName);
		});

		it('THEN validate the data filtering in the grid for classification', { tags: ['@Reporting'] }, () => {
			cy.allure().tms('CMD-T9265');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.filterUsingClassificationPercentage(txt.classificationColumn, operator.is, ltr.classificationValue);
		});

		it('THEN validate the different view of data in the grid', { tags: ['@Reporting', '@Sanity'] }, () => {
			cy.allure().tms('CMD-T9259');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.clickDataViewIcon();
			patchAssessmentReportHelper.getList(ltr.list).children().eq(0).click();
			patchAssessmentReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.wait(2000);
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.clickDataViewIcon();
			patchAssessmentReportHelper.getList(ltr.list).children().eq(1).click();
			patchAssessmentReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.wait(2000);
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.clickDataViewIcon();
			patchAssessmentReportHelper.getList(ltr.list).children().eq(2).click();
			patchAssessmentReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate the functionality to hide or show the columns in the grid', { tags: ['@Reporting', '@Sanity'] }, () => {
			cy.allure().tms('CMD-T9258');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.clickViewColumnIcon();
			patchAssessmentReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			patchAssessmentReportHelper.clickViewColumnIcon();
			patchAssessmentReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');

		});
		
		it('THEN validate the search functionality in the report for device name', { tags: ['@Reporting', '@Sanity'] }, () => {
			cy.allure().tms('CMD-T9261');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});
		
		it('THEN validate the search functionality in the report for device type', { tags: ['@Reporting'] }, () => {
			cy.allure().tms('CMD-T8884');
			patchAssessmentReportHelper.loadGridData();
			patchAssessmentReportHelper.searchInTheGridAndValidateDeviceType(txt.desktopType);
		});

		
	});
});

