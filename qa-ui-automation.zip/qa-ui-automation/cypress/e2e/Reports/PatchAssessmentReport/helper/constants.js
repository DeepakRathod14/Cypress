export const moduleMetaData = {
	name: 'Patch Assessment Report',
	customUser: 'user_2'
};

export const txt = {
	'approve': 'Approve',
	'desktopType' : 'Desktop',
	'serverType' : 'Server',
	'positionL' : 'left',
	'positionR' : 'right',

	'deviceNameColumn' : 'Name',
	'frindlyNameColumn': 'Friendly Name',
	'deviceTypeColumn': 'Device Type',
	'siteNameColumn' : 'Site Name',
	'siteFrindlyNameColumn': 'Site Friendly Name',
	'companyFriendlyNameColumn':'Company Friendly Name',
	'companyNameColumn':'Company Name',
	'osNameColumn' : 'OS',
	'classificationColumn':'Classification',
	'kbArticleColumn': 'KB Article',
	'latestPatchTitleColumn':'Latest Patch Title',
	'installedByColumn':'Installed By',
	'installedDateColumn':'Installed Date',
	'lastAssessedColumn':'Last Assessed',
	'latestPatchReleaseDateColumn':'Latest Patch Release Date',
	'patchStatusColumn':'Patch Status',
	'latestRebootBehaviorNameColumn':'Latest Reboot Behavior Name',
	'nocRecommendsColumn':'NOC Recommends',
	'patchApprovalColumn':'Patch Approval',
	'severityColumn':'Severity',
	'deviceTimeZoneColumn': 'Device Time Zone',

};

export const operator = {
	'is': 'is',
	'isNot': 'is not',
	'isAnyOf': 'is any of',
	'equals': 'equals',
	'contains': 'contains',
	'equalTo':'=',
};

export const ltr = {

	'companyFilter':'reporting-company-filter-component',
	'siteFilter':'reporting-site-filter-component',
	'showResultsButton':'OSPatchAssessmentReport-go-button',
	'checkboxesInTopFilters':'.css-1m9pwf3',
	'frindlyNameColumn':'[data-field="FRIENDLY_NAME"] .MuiDataGrid-cellContent',
	'grid':'.css-1u6e7ki',

	'columns': '.MuiDataGrid-columnHeader.MuiDataGrid-withBorderColor',
	'columnHeader':'.css-k008qs',
	'gridRow': '.MuiDataGrid-row',
	'gridVirtualScroller': '.MuiDataGrid-virtualScroller',
	'selectColumn': '.MuiDataGrid-columnHeaderTitleContainer',
	'searchIcon': '.MuiButtonBase-root.MuiIconButton-root.MuiIconButton-sizeMedium.css-w9aoya',
	'nativeSelect': '.MuiNativeSelect-select',
	'valueTextField': '.MuiInputBase-input.css-16rhzhe',
	'reportTitle': '.css-q7hzx0',
	'deviceType': 'div[data-field="ENDPOINT_TYPE"] .MuiDataGrid-cellContent',
	'closeIcon': '.MuiButtonBase-root.MuiIconButton-root.MuiIconButton-sizeSmall.css-51mpi5',
	'nameColumn': 'div[data-field="SYSTEM_NAME"] .MuiDataGrid-cellContent',
	'osName': '[data-rowindex="0"]>[data-field="OS_PRODUCT"] .MuiDataGrid-cellContent',
	'siteList': '[data-rowindex="0"]>div[data-field="SITE_NAME"] .MuiDataGrid-cellContent',
	'filterIcon': 'FilterAltOutlinedIcon',
	'toogleIcon': '.PrivateSwitchBase-input.css-1m9pwf3',
	'viewColumnIcon': 'ViewColumnOutlinedIcon',
	'dataViewIcon': 'ViewStreamIcon',
	'list': '.MuiList-root',
	'deviceName': '[data-rowindex="0"]>[data-field="SYSTEM_NAME"] .MuiDataGrid-cellContent',
	'classificationValue':'[data-rowindex="0"]>div[data-field="CLASSIFICATION"] .MuiDataGrid-cellContent',
	'classificationList':'div[data-field="CLASSIFICATION"] .MuiDataGrid-cellContent'
};