import PatchComplianceReportHelper from '../helper/PatchComplianceReportHelper';

import { moduleMetaData, txt, ltr, operator } from '../helper/constants';

describe('GIVEN Patch Compliance Report', { tags: ['@Regression', '@MUI'] }, () => {

	var patchComplianceReportHelper = new PatchComplianceReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => { });

		beforeEach(() => {
			patchComplianceReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN validate report title for the report', function () {
			cy.allure().tms('CMD-T8872');
			patchComplianceReportHelper.validateReportTitle();
		});

		it('THEN validate the columns available in the report', function () {
			cy.allure().tms('CMD-T8873');
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.validateReportsColumn();
		});

		it('THEN validate the sorting for column', function () {
			cy.allure().tms('CMD-T8874');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.sortTheColumn(1);
			patchComplianceReportHelper.sortTheColumn(1);
			cy.reload();
			patchComplianceReportHelper.sortTheColumn(7);
			patchComplianceReportHelper.sortTheColumn(7);
			cy.reload();
		});

		it('THEN validate the data filtering in the grid for OS name', function () {
			cy.allure().tms('CMD-T8879');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.filterUsingOS(txt.osNameColumn, operator.isNot, ltr.osName);
		});

		it('THEN validate the data filtering in the grid for device name', function () {
			cy.allure().tms('CMD-T8880');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.filterUsingDeviceName(txt.deviceNameColumn, operator.equals, ltr.deviceName);
		});

		it('THEN validate the data filtering in the grid for Patch Compliance percentage', function () {
			cy.allure().tms('CMD-T8880');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.filterUsingPatchCompliancePercentage(txt.policyCompliancePercentageColumn, operator.equalTo, ltr.patchCompliancePercentageValue);
		});

		it('THEN validate the different view of data in the grid', function () {
			cy.allure().tms('CMD-T8881');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.clickDataViewIcon();
			patchComplianceReportHelper.getList(ltr.list).children().eq(0).click();
			patchComplianceReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.clickDataViewIcon();
			patchComplianceReportHelper.getList(ltr.list).children().eq(1).click();
			patchComplianceReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.clickDataViewIcon();
			patchComplianceReportHelper.getList(ltr.list).children().eq(2).click();
			patchComplianceReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate the functionality to hide or show the columns in the grid', function () {
			cy.allure().tms('CMD-T8882');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.clickViewColumnIcon();
			patchComplianceReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			patchComplianceReportHelper.clickViewColumnIcon();
			patchComplianceReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');

		});
		
		it('THEN validate the search functionality in the report for device name', function () {
			cy.allure().tms('CMD-T8883');
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});
		
		it('THEN validate the search functionality in the report for device type', function () {
			cy.allure().tms('CMD-T8884');
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchComplianceReportHelper.searchInTheGridAndValidateDeviceType(txt.desktopType);
		});
		
	});
});

