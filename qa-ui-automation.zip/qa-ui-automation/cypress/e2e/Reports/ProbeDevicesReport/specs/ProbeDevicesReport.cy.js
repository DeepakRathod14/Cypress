import ProbeDevicesReportHelper from '../helper/ProbeDevicesReportHelper';
import { moduleMetaData, ltr, txt, operator} from '../helper/constants';

describe('GIVEN Probe Devices Report', { tags: ['@Regression', '@MUI'] }, () => {

	var probeDevicesReportHelper = new ProbeDevicesReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {

		before(() => {

		});

		beforeEach(() => {
			probeDevicesReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN Validate the report title', { tags: ['@Sanity'] }, () => {
			probeDevicesReportHelper.validateReportTitle();
		});

		it('THEN Validate the columns available in the report', { tags: ['@Sanity'] }, () => {
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.validateReportsColumn();
		});

		it('THEN Validate the sorting for column', { tags: ['@Sanity'] }, () => {
			//cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.sortTheColumn(4);
			probeDevicesReportHelper.sortTheColumn(4);
			cy.reload();
			probeDevicesReportHelper.sortTheColumn(7);
			probeDevicesReportHelper.sortTheColumn(7);
			cy.reload();
			probeDevicesReportHelper.sortTheColumn(6);
			probeDevicesReportHelper.sortTheColumn(6);
		});

		it('THEN validate the data filtering in the grid for site name', { tags: ['@Sanity'] }, () => {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.filterUsingSiteName(txt.siteNameColumn, operator.is, ltr.site);
		});
		
		it('THEN validate the data filtering in the grid for OS name', function () {
			cy.allure().tms('CMD-T8879');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.filterUsingOS(txt.osNameColumn, operator.isNot, ltr.OS);
		});

		it('THEN validate the data filtering in the grid for Status', { tags: ['@Sanity'] }, () => {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.filterUsingStatus(txt.statusColumn, operator.is, ltr.status);
		});
		
		it('THEN validate the different view of data in the grid', { tags: ['@Sanity'] }, () => {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.clickDataViewIcon();
			probeDevicesReportHelper.getList(ltr.list).children().eq(0).click();
			probeDevicesReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.clickDataViewIcon();
			probeDevicesReportHelper.getList(ltr.list).children().eq(1).click();
			probeDevicesReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.clickDataViewIcon();
			probeDevicesReportHelper.getList(ltr.list).children().eq(2).click();
			probeDevicesReportHelper.changeView(ltr.gridRow, 2);
		});
	
		it('THEN validate the functionality to hide or show the columns in the grid', { tags: ['@Sanity'] }, () => {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.clickViewColumnIcon();
			probeDevicesReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			probeDevicesReportHelper.clickViewColumnIcon();
			probeDevicesReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');
		});
		
		it('THEN validate the search functionality in the report for device name', { tags: ['@Sanity'] }, () => {
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});

		it('THEN validate the search functionality in the report for device type', { tags: ['@Sanity'] }, () => {
			cy.get(ltr.gridRow, { timeout: 40000 });
			probeDevicesReportHelper.searchInTheGridAndValidateDeviceType(ltr.deviceType);
		});
	});
});
