import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper }
from '../../../../fixtures';
import { txt, ltr } from './constants';
 
class AutomationExecutionSummaryReportHelper extends CommonHelper{
 
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.CommonHelper =  new CommonHelper();
	}

	validateReportsColumn() {
		cy.contains(ltr.columns, txt.nameColumn);
		cy.contains(ltr.columns, txt.friendlyNameColumn);
		cy.contains(ltr.columns, txt.deviceTypeColumn);
		cy.contains(ltr.columns, txt.siteNameColumn);
		cy.contains(ltr.columns, txt.siteFriendlyNameColumn);
		cy.contains(ltr.columns, txt.companyNameColumn);
		cy.contains(ltr.columns, txt.companyFriendlyNameColumn);
		cy.contains(ltr.columns, txt.userNameColumn);
		cy.contains(ltr.columns, txt.reasonColumn);
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionR);
		cy.contains(ltr.columns, txt.sessionStartTimeColumn);
		cy.contains(ltr.columns, txt.sessionEndTimeColumn);
		cy.contains(ltr.columns, txt.deviceTimeZone);
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionL);
	}	

	validateReportTitle()
	{
		this.getLastElement(ltr.reportTitle).should('have.text', txt.reportTitle);
	}
	searchInTheGridAndValidateDeviceName(endpointNameLocator) {
		this.getTextFromList(endpointNameLocator).then((elementText) => {
			var searchIconLocator = this.wrapDataTestId(ltr.searchIcon);
			this.gridHelper.searchEntryInGrid(searchIconLocator, elementText);
			cy.wait(1000);
			this.getList(ltr.nameList).contains(elementText);
			var closeIcon = this.wrapDataTestId(ltr.closeIcon);
			this.buttonHelper.clickButton(closeIcon);
		});
	}

	searchInTheGridAndValidateDeviceType(deviceTypeLocator) {
		this.getTextFromList(deviceTypeLocator).then((elementText) => {
			var searchIconLocator = this.wrapDataTestId(ltr.searchIcon);
			this.gridHelper.searchEntryInGrid(searchIconLocator, elementText);
			cy.wait(1000);
			this.getList(ltr.deviceTypeList).contains(elementText);
			var closeIcon = this.wrapDataTestId(ltr.closeIcon);
			this.buttonHelper.clickButton(closeIcon);
		});
	}
	

	sortTheColumn(colIndex){
		this.getRowByIndex(ltr.gridRow, colIndex).invoke('text').as('initialText')
			.then((initialText) => {
				this.validateFirstRowExists(ltr.gridRow);
				this.sortColumn(ltr.selectColumn, colIndex);
				this.sortColumn(ltr.selectColumn, colIndex);
				this.getRowByIndex(ltr.gridRow, colIndex)
					.invoke('text')
					.then((newText) => {
						expect(newText).to.not.equal(initialText);
					});
			});
	}
	filterUsingdeviceType(deviceTypeColName, operator, deviceType) {
		this.clickFilterIcon();
		this.getTextFromList(deviceType).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,deviceTypeColName);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.deviceTypeList).should('contain',elementText);
		});	
	}
	
	filterUsingEndpointName(endpointNameColumn, operator, nameLocator) {
		this.clickFilterIcon();
		this.getTextFromList(nameLocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,endpointNameColumn);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.inputFieldHelper.typeIntoInputField(ltr.valueTextField, elementText);
			cy.wait(3000);
			this.getList(ltr.nameList).should('contain',elementText);
		});

	}

	hideColumnsInGrid() {
		this.getColumnHeaders(ltr.columns)
			.invoke('text')
			.as('initialText')
			.then((initialText) => {
				cy.wait(3000);
				this.clickToggleColumnIcon();
				cy.wait(3000);
				this.hideColumn(1);
				this.hideColumn(2);
				this.hideColumn(5);
				this.getColumnHeaders(ltr.columns)
					.invoke('text')
					.then((newText) => {
						expect(newText).to.not.equal(initialText);
					});
			});
	}

	ReportDateFilter() {
		cy.get(ltr.gridRow, { timeout: 40000 });
		this.getColumnHeaders(ltr.sessionStartTimeList)
			.invoke('text')
			.as('initialText')
			.then((initialText) => {
		        var calendarIcon = this.wrapDataTestId(ltr.calendarLocator);
		        this.getFirstElement(calendarIcon).click();
		        this.getElement(ltr.dateLocator).eq(0).click();
		        cy.wait(2000);
		        this.getElement(this.wrapDataTestId(ltr.GoButton)).click();
				cy.wait(5000);
		        cy.get(ltr.gridRow, { timeout: 40000 });
		        this.getColumnHeaders(ltr.sessionStartTimeList)
					.invoke('text')
					.then((newText) => {
						expect(newText).to.equal(initialText);
					});
			});
	}

	ReportDateYearFilter() {
		var calendarIcon = this.wrapDataTestId(ltr.calendarLocator);
		var arrowLeftIcon = this.wrapDataTestId(ltr.arrowLeftIconLocator);
		this.getFirstElement(calendarIcon).click();
		Cypress._.times(2, () => {
			cy.get(arrowLeftIcon).click();
		});
		this.getElement(ltr.dateLocator).eq(0).click();
		cy.wait(2000);
		const GoButton = this.wrapDataTestId(ltr.GoButton);
		cy.log(GoButton);
		this.getElement(GoButton).click();
		cy.get(ltr.gridRow, { timeout: 40000 });
		cy.wait(2000);
	}


	
	clickToggleColumnIcon = () => {
		return this.getToggleColumnIcon().click();
	}
	getToggleColumnIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.toggleColumnIcon);
		return this.getElement(dataTestId);
	}

	scrollGridToRight(gridVirtualScroller, position) {
		this.getElement(gridVirtualScroller).scrollTo(position);
	}

	getRowByIndex = (gridRowLocator, index) => {
		return this.gridHelper.getRowByIndex(gridRowLocator, index);
	}
	validateFirstRowExists = (gridRowLocator) => {
		return this.gridHelper.validateFirstRowExists(gridRowLocator);
	}
	sortColumn = (columnHeaderLocator, columnIndex) => {
		return this.gridHelper.sortColumn(columnHeaderLocator, columnIndex);
	}
	getFilterIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.filterIcon);
		return this.getElement(dataTestId);
	}
	selectDropdownValue = (dropdownSelector, index, value) => {
		return this.dropdownHelper.selectDropdownValue(dropdownSelector, index, value);
	}
	clickFilterIcon = () => {
		return this.getFilterIcon().click();
	}
	getViewColumnIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.viewColumnIcon);
		return this.getElement(dataTestId);
	}
	clickViewColumnIcon = () => {
		return this.getViewColumnIcon().click();
	}
	getColumnHeaders = (gridColumnHeadersLocator) => {
		return this.getElement(gridColumnHeadersLocator);
	}
	clickToggleColumnIcon = () => {
		return this.getToggleColumnIcon().click();
	}
	getDataViewIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.dataViewIcon);
		return this.getElement(dataTestId);
	}
	clickDataViewIcon = () => {
		return this.getDataViewIcon().click();
	}
	hideColumn = (columnIndex) => {
		return this.gridHelper.hideColumn(ltr.hideColumnSelector, columnIndex);
	}
	changeView = (rowSelector, view) => {
		return this.gridHelper.changeGridView(rowSelector, view);
	}
	getList = (listLocator) => {
		return this.getElement(listLocator);
	}
	getTextFromList = (locator) => {
		return cy.get(locator).invoke('text').then((text) => {
			const elementText = text;
			return cy.wrap(elementText);
		});
	}
}

export default AutomationExecutionSummaryReportHelper;
