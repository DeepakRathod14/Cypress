export const moduleMetaData = {
	name: 'Remote Access Report',
	customUser: 'user_1'
};

export const txt = {
	'approve': 'Approve',
	'reportTitle' : 'Remote Access Report',
	'deviceName' : 'QA1-PSA124-64-14',
	'desktopType' : 'Desktop',
	'serverType' : 'Server',
	'osName' : 'UBUNTU 11 6.0.6002',
	'positionL' : 'left',
	'positionR' : 'right',
	'nameColumn': 'Name',
	'friendlyNameColumn':'Friendly Name',
	'deviceTypeColumn':'Device Type',
	'siteNameColumn' : 'Site Name',
	'siteFriendlyNameColumn' : 'Site Friendly Name',
	'companyNameColumn':'Company Name',
	'companyFriendlyNameColumn':'Company Friendly Name',
	'userNameColumn' : 'User Name',
	'reasonColumn': 'Reason',
	'sessionStartTimeColumn':'Session Start Time',
	'sessionEndTimeColumn':'Session End Time',
	'deviceTimeZone':'Device Time Zone'
};

export const operator = {
	'is': 'is',
	'isNot': 'is not',
	'isAnyOf': 'is any of',
	'equals': 'equals',
	'contains': 'contains',
};
export const ltr = {
	'reportTitle': '.css-jlpfkj',
	'columns': '.MuiDataGrid-columnHeader.MuiDataGrid-withBorderColor',
	'gridVirtualScroller': '.MuiDataGrid-virtualScroller',
	'dataViewIcon': 'ViewStreamIcon',
	'list': '.MuiList-root',
	'calendarLocator':'CalendarIcon',
	'arrowLeftIconLocator':'ArrowLeftIcon',
	'dateLocator':'.css-183nxzx',
	'GoButton': 'reporting-date-go-button',
	'nameList': '[data-field="SYSTEM_NAME"] .MuiDataGrid-cellContent',
	'name': '[data-rowindex="0"]>[data-field="SYSTEM_NAME"] .MuiDataGrid-cellContent',
	'deviceType': '[data-rowindex="0"]>[data-field="ENDPOINT_TYPE"] .MuiDataGrid-cellContent',
	'deviceTypeList':'[data-field="ENDPOINT_TYPE"] .MuiDataGrid-cellContent',
	'sessionStartTimeList':'[data-field="SESSION_START_TIME"] .MuiDataGrid-cellContent',
	
	//'columnsHeaders':'.MuiDataGrid-columnHeaderTitle.css-1ksjxj5',
	'toggleColumnIcon': 'ViewColumnOutlinedIcon',
	'hideColumnSelector': '.MuiDataGrid-columnsPanelRow input',
	//'grid': 'automation-execution-summary-report',
	'gridRow': '.MuiDataGrid-row',
	'closeIcon': 'CloseIcon',
	'searchIcon': 'SearchOutlinedIcon',
	'nativeSelect': '.MuiNativeSelect-select',
	'valueTextField': '.MuiInputBase-input.css-16rhzhe',
	'filterIcon': 'FilterAltOutlinedIcon',
	'viewColumnIcon': 'ViewColumnOutlinedIcon',



	//'nameCol': '.MuiDataGrid-cell > div',
	
	'selectColumn': '.MuiDataGrid-columnHeaderTitleContainer',
	
	//'button': '.MuiButtonBase-root.css-2xu4n5 > span > span',
	//'colDropDown': '.MuiFormControl-root.css-15dhifk > .MuiInputBase-root.css-1p2w63q > .MuiNativeSelect-select',
	//'operatorDropDown': '.MuiFormControl-root.css-vjhqg8 > .MuiInputBase-root.css-1p2w63q > .MuiNativeSelect-select',
	//'valueDropDown': '.MuiFormControl-root.css-1d6r6nx > .MuiInputBase-root.css-1p2w63q > .MuiNativeSelect-select',
	
	//'searchInputField': 'input[class=\'MuiInputBase-input MuiInput-input MuiInputBase-inputTypeSearch MuiInputBase-inputAdornedStart MuiInputBase-inputAdornedEnd css-16lpr25\']',
	
	
	//'taskNameColumn': 'div.MuiDataGrid-virtualScroller.css-1u6e7ki > div > div > div > div:nth-child(1) > div',

	//'toogleIcon': '.PrivateSwitchBase-input.css-1m9pwf3',
	
	//'columnNameDropDown': 'div.css-15dhifk > div > select',
	//'gridSelector': '.MuiDataGrid-root.css-1swv4vk',
	//'sortIcon': '.MuiButtonBase-root.css-xnzk18 > svg[data-testid=\'ArrowUpwardIcon\']',
	
};