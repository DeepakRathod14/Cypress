import RemoteAccessReportHelper from '../helper/RemoteAccessReportHelper';

import { moduleMetaData, txt, ltr, operator } from '../helper/constants';

describe('GIVEN Remote Access Report validation', { tags: ['@Regression', '@MUI'] }, () => {

	var remoteAccessReportHelper = new RemoteAccessReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here

	context('WHEN user is migrated/SSO', { tags: ['@Migrated'] }, () => {

		// define hooks for pre and post conditions
		before(() => { });

		beforeEach(() => {
			remoteAccessReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		// Validate the title of the report
		it('THEN validate report title', function () {
			remoteAccessReportHelper.validateReportTitle();
		});

		//validate the columns available in the report
		it('THEN validate the columns available in the report', function () {
			remoteAccessReportHelper.validateReportsColumn();
		});
		
		// validate the search for task name
		it('THEN validate the search functionality in the report for endpoint name', function () {
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.searchInTheGridAndValidateDeviceName(ltr.name);
		});
		// validate the search for task type
		it('THEN validate the search functionality in the report for endpoint type', function () {
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.searchInTheGridAndValidateDeviceType(ltr.deviceType);
	
		});
		// Sorting
		it('THEN validate the sorting for column', function () {
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.sortTheColumn(0);
			remoteAccessReportHelper.sortTheColumn(0);
			cy.reload();
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.sortTheColumn(1);
			remoteAccessReportHelper.sortTheColumn(1);
			cy.reload();
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.sortTheColumn(2);
			remoteAccessReportHelper.sortTheColumn(2);
		});
		
		//filter
		it('THEN validate the data filtering in the grid for device type', function () {
			cy.reload();
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.filterUsingdeviceType(txt.deviceTypeColumn, operator.is, ltr.deviceType);
		});

		it('THEN validate the data filtering in the grid for device name', function () {
			cy.reload();
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.filterUsingEndpointName(txt.nameColumn, operator.equals, ltr.name);
		});

		// find the column
		it('THEN validate the functionality to hide the columns in the grid', function () {
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.hideColumnsInGrid();
		});
		
		it('THEN validate the different view of data in the grid', function () {
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.clickDataViewIcon();
			remoteAccessReportHelper.getList(ltr.list).children().eq(0).click();
			remoteAccessReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.clickDataViewIcon();
			remoteAccessReportHelper.getList(ltr.list).children().eq(1).click();
			remoteAccessReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.clickDataViewIcon();
			remoteAccessReportHelper.getList(ltr.list).children().eq(2).click();
			remoteAccessReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate that report is showing the records in the grid as per selected date in top filter', function () {
			remoteAccessReportHelper.ReportDateYearFilter();
			remoteAccessReportHelper.ReportDateFilter();
		});
	});

});

