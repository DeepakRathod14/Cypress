import DiskSpaceReportHelper from '../helper/DiskSpaceReportHelper';

import { moduleMetaData, txt, ltr, operator } from '../helper/constants';

describe('GIVEN Disk Space Report', { tags: ['@Regression', '@MUI'] }, () => {

	var diskSpaceReportHelper = new DiskSpaceReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => { });

		beforeEach(() => {
			diskSpaceReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN validate report title', function () {
			cy.allure().tms('CMD-T9082');
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.validateReportTitle();
		});

		it('THEN validate the columns available in the report', function () {
			cy.allure().tms('CMD-9091');
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.validateReportsColumn();
		});

		it('THEN validate the sorting for column', function () {
			cy.allure().tms('CMD-T9090');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.sortTheColumn(1);
			diskSpaceReportHelper.sortTheColumn(1);
			cy.reload();
			diskSpaceReportHelper.sortTheColumn(5);
			diskSpaceReportHelper.sortTheColumn(5);
			cy.reload();
			diskSpaceReportHelper.sortTheColumn(7);
			diskSpaceReportHelper.sortTheColumn(7);
		});

		it('THEN validate the data filtering in the grid for site name', function () {
			cy.allure().tms('CMD-T9086');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.filterUsingSiteName(txt.siteNameColumn, operator.is, ltr.siteList);
		});

		it('THEN validate the data filtering in the grid for OS name', function () {
			cy.allure().tms('CMD-T9088');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.filterUsingOS(txt.osNameolumn, operator.isNot, ltr.osList);
		});

		it('THEN validate the data filtering in the grid for device name', function () {
			cy.allure().tms('CMD-T9087');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.filterUsingDeviceName(txt.deviceNameColumn, operator.equals, ltr.deviceName);
		});

		it('THEN validate the different view of data in the grid', function () {
			cy.allure().tms('CMD-T9084');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.clickDataViewIcon();
			diskSpaceReportHelper.getList(ltr.list).children().eq(0).click();
			diskSpaceReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.clickDataViewIcon();
			diskSpaceReportHelper.getList(ltr.list).children().eq(1).click();
			diskSpaceReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.clickDataViewIcon();
			diskSpaceReportHelper.getList(ltr.list).children().eq(2).click();
			diskSpaceReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate the functionality to hide or show the columns in the grid', function () {
			cy.allure().tms('CMD-T9083');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.clickViewColumnIcon();
			diskSpaceReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			diskSpaceReportHelper.clickViewColumnIcon();
			diskSpaceReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');

		});
		
		it('THEN validate the search functionality in the report for device name', function () {
			cy.allure().tms('CMD-T9085');
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});
		
		it('THEN validate the search functionality in the report for device type', function () {
			cy.allure().tms('CMD-T9089');
			cy.get(ltr.gridRow, { timeout: 40000 });
			diskSpaceReportHelper.searchInTheGridAndValidateDeviceType(txt.desktopType);
		});
	});
});

