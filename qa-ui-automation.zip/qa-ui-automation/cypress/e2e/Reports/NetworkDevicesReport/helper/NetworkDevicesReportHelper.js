import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper }
from '../../../../fixtures';
import { txt, ltr, moduleMetaData } from './constants';
 
class NetworkDevicesReportHelper extends CommonHelper{
 
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.CommonHelper =  new CommonHelper();
	}
	validateReportTitle()
	{
		this.getLastElement(ltr.reportTitle).should('have.text', moduleMetaData.name);
	}

	validateReportsColumn() {
		cy.get(ltr.gridRow, { timeout: 40000 });
		cy.contains(ltr.columns, txt.deviceNameColumn);
		cy.contains(ltr.columns, txt.frindlyNameColumn);
		cy.contains(ltr.columns, txt.siteNameColumn);
		cy.contains(ltr.columns, txt.osNameColumn);
		cy.contains(ltr.columns, txt.siteFriendlyNameColumn);
		cy.contains(ltr.columns, txt.companyNameColumn);
		cy.contains(ltr.columns, txt.companyFriendlyNameColumn);
		cy.contains(ltr.columns, txt.ipAddressColumn);
		cy.contains(ltr.columns, txt.deviceTypeColumn);
		cy.contains(ltr.columns, txt.osNameColumn);
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionR);
		cy.contains(ltr.columns, txt.statusColumn);
		cy.contains(ltr.columns, txt.descriptionColumn);
		cy.contains(ltr.columns, txt.bootTImeColumn);
		cy.contains(ltr.columns, txt.lastReportedColumn);
		cy.contains(ltr.columns, txt.networksColumn);
		cy.contains(ltr.columns, txt.InterfacesColumn);
		cy.contains(ltr.columns, txt.deviceTimeZoneColumn);
	}	

	searchInTheGridAndValidateDeviceName(deviceNameLocator) {
		this.getTextFromList(deviceNameLocator).then((elementText) => {
			this.gridHelper.searchEntryInGrid(ltr.searchIcon, elementText);
			this.gridHelper.getRowByIndex(ltr.nameColumn, 0).should('have.text', elementText);
			this.getList(ltr.deviceName).contains(elementText);
			this.buttonHelper.clickButton(ltr.closeIcon);
		});
	}

	searchInTheGridAndValidateDeviceType(deviceTypeLocator) {
		this.getTextFromList(deviceTypeLocator).then((elementText) => {
			this.gridHelper.searchEntryInGrid(ltr.searchIcon, elementText);
			this.gridHelper.getRowByIndex(ltr.nameColumn, 0).should('have.text', elementText);
			this.getList(ltr.deviceType).contains(elementText);
			this.buttonHelper.clickButton(ltr.closeIcon);
		});
	}

	sortTheColumn(colIndex){
		this.getRowByIndex(ltr.gridRow, colIndex).invoke('text').as('initialText')
			.then((initialText) => {
				this.validateFirstRowExists(ltr.gridRow);
				this.sortColumn(ltr.selectColumn, colIndex);
				this.getRowByIndex(ltr.gridRow, colIndex)
					.invoke('text')
					.then((newText) => {
						expect(newText).equal(initialText);
					});
			});
	}
	filterUsingSiteName(siteColName, operator, siteNameListLocator) {
		this.clickFilterIcon();
		this.getTextFromList(siteNameListLocator).then((elementText) => {
			cy.log(elementText);
			this.selectDropdownValue(ltr.nativeSelect,1,siteColName);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.site).contains(elementText);
		});
		
	}
	filterUsingStatus(statusColname, operator, statusLocator) {
		this.clickFilterIcon();
		this.getTextFromList(statusLocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,statusColname);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.status).contains(elementText);
		});
	}
	filterUsingInterfaces(interfaceNameColumn, operator, interfaceListlocator) {
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionR);
		this.clickFilterIcon();
		this.getTextFromList(interfaceListlocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,interfaceNameColumn);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.interfaceList).contains(elementText);
		});
	}

	scrollGridToRight(gridVirtualScroller, position) {
		this.getElement(gridVirtualScroller).scrollTo(position);
	}

	getRowByIndex = (gridRowLocator, index) => {
		return this.gridHelper.getRowByIndex(gridRowLocator, index);
	}
	validateFirstRowExists = (gridRowLocator) => {
		return this.gridHelper.validateFirstRowExists(gridRowLocator);
	}
	sortColumn = (columnHeaderLocator, columnIndex) => {
		return this.gridHelper.sortColumn(columnHeaderLocator, columnIndex);
	}
	getFilterIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.filterIcon);
		return this.getElement(dataTestId);
	}
	selectDropdownValue = (dropdownSelector, index, value) => {
		return this.dropdownHelper.selectDropdownValue(dropdownSelector, index, value);
	}
	clickFilterIcon = () => {
		return this.getFilterIcon().click();
	}
	getViewColumnIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.viewColumnIcon);
		return this.getElement(dataTestId);
	}
	clickViewColumnIcon = () => {
		return this.getViewColumnIcon().click();
	}
	getDataViewIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.dataViewIcon);
		return this.getElement(dataTestId);
	}
	clickDataViewIcon = () => {
		return this.getDataViewIcon().click();
	}
	changeView = (rowSelector, view) => {
		return this.gridHelper.changeGridView(rowSelector, view);
	}
	getList = (listLocator) => {
		return this.getElement(listLocator);
	}
	getTextFromList = (locator) => {
		return cy.get(locator).invoke('text').then((text) => {
			const elementText = text;
			return cy.wrap(elementText);
		});
	}


}

export default NetworkDevicesReportHelper;
