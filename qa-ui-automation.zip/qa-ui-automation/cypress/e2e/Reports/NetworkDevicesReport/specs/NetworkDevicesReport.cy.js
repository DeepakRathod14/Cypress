import NetworkDevicesReportHelper from '../helper/NetworkDevicesReportHelper';
import { moduleMetaData, ltr, txt, operator} from '../helper/constants';

describe('GIVEN Network devices Report', { tags: ['@Regression', '@MUI'] }, () => {

	var networkDevicesReportHelper = new NetworkDevicesReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {

		before(() => {

		});

		beforeEach(() => {
			networkDevicesReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN Validate the report title', function () {
			networkDevicesReportHelper.validateReportTitle();
		});

		it('THEN Validate the columns available in the report', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.validateReportsColumn();
		});

		it('THEN Validate the sorting for column', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.sortTheColumn(0);
			networkDevicesReportHelper.sortTheColumn(0);
			cy.reload();
			networkDevicesReportHelper.sortTheColumn(1);
			networkDevicesReportHelper.sortTheColumn(1);
			cy.reload();
			networkDevicesReportHelper.sortTheColumn(3);
			networkDevicesReportHelper.sortTheColumn(3);
		});

		it('THEN validate the data filtering in the grid for site name', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.filterUsingSiteName(txt.siteNameColumn, operator.is, ltr.site);
		});

		it('THEN validate the data filtering in the grid for Status', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.filterUsingStatus(txt.statusColumn, operator.is, ltr.status);
		});
		
		it('THEN validate the different view of data in the grid', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.clickDataViewIcon();
			networkDevicesReportHelper.getList(ltr.list).children().eq(0).click();
			networkDevicesReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.clickDataViewIcon();
			networkDevicesReportHelper.getList(ltr.list).children().eq(1).click();
			networkDevicesReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.clickDataViewIcon();
			networkDevicesReportHelper.getList(ltr.list).children().eq(2).click();
			networkDevicesReportHelper.changeView(ltr.gridRow, 2);
		});
	
		it('THEN validate the functionality to hide or show the columns in the grid', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.clickViewColumnIcon();
			networkDevicesReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			networkDevicesReportHelper.clickViewColumnIcon();
			networkDevicesReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');
		});
		
		it('THEN validate the search functionality in the report for device name', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});

		it('THEN validate the search functionality in the report for device type', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			networkDevicesReportHelper.searchInTheGridAndValidateDeviceType(ltr.deviceType);
		});
	});
});
