import AutomationExecutionSummaryReportHelper from '../helper/AutomationExecutionSummaryReportHelper';

import { moduleMetaData, txt, ltr, operator } from '../helper/constants';

describe('GIVEN Automation Execution Summary Report validation', { tags: ['@Regression', '@MUI'] }, () => {

	var automationExecutionSummaryReportHelper = new AutomationExecutionSummaryReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here

	context('WHEN user is migrated/SSO', { tags: ['@Migrated'] }, () => {

		// define hooks for pre and post conditions
		before(() => { });

		beforeEach(() => {
			automationExecutionSummaryReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		// Validate the title of the report
		it('THEN validate report title', function () {
			automationExecutionSummaryReportHelper.validateReportTitle();
		});

		//validate the columns available in the report
		it('THEN validate the columns available in the report', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.validateReportsColumn();
		});
		
		// validate the search for task name
		it('THEN validate the search functionality in the report for task name', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.searchInTheGridAndValidateTaskName(ltr.taskName);
		});
		// validate the search for task type
		it('THEN validate the search functionality in the report for task type', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.searchInTheGridAndValidateTaskType(ltr.taskType);
	
		});
		// Sorting
		it('THEN validate the sorting for column', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			//ascending order
			automationExecutionSummaryReportHelper.sortTheColumn(0);
			//descending order
			automationExecutionSummaryReportHelper.sortTheColumn(0);
			cy.reload();
			//ascending order
			automationExecutionSummaryReportHelper.sortTheColumn(1);
			//descending order
			automationExecutionSummaryReportHelper.sortTheColumn(1);
		
		});
		//filter
		it('THEN validate the data filtering in the grid for task type', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.filterUsingTaskType(txt.taskTypeColumn, operator.is, ltr.taskType);
		});

		it('THEN validate the data filtering in the grid for task name', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.filterUsingTaskName(txt.taskNameColumn, operator.equals, ltr.taskName);
		});

		// find the column
		it('THEN validate the functionality to hide the columns in the grid', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.hideColumnsInGrid();
		});
		
		it('THEN validate the different view of data in the grid', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.clickDataViewIcon();
			automationExecutionSummaryReportHelper.getList(ltr.list).children().eq(0).click();
			automationExecutionSummaryReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.clickDataViewIcon();
			automationExecutionSummaryReportHelper.getList(ltr.list).children().eq(1).click();
			automationExecutionSummaryReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.clickDataViewIcon();
			automationExecutionSummaryReportHelper.getList(ltr.list).children().eq(2).click();
			automationExecutionSummaryReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate that report is showing the records in the grid as per selected date in top filter', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			automationExecutionSummaryReportHelper.ReportDateYearFilter();
			automationExecutionSummaryReportHelper.ExecutionDateFilter();
		});

		it('THEN validate that report has a global download button to download a large amount of data ', function () {
			cy.reload();
			automationExecutionSummaryReportHelper.globalDownload(txt.expectedRows);
		});
	});

});

