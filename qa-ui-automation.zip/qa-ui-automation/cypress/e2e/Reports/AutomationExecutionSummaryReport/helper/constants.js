export const moduleMetaData = {
	name: 'Automation Execution Summary Report',
	customUser: 'user_1'
};

export const txt = {
	'approve': 'Approve',
	'reportTitle' : 'Automation Execution Summary Report',
	'deviceName' : 'QA1-PSA124-64-14',
	'desktopType' : 'Desktop',
	'serverType' : 'Server',
	'osName' : 'UBUNTU 11 6.0.6002',
	'positionL' : 'left',
	'positionR' : 'right',
	'taskNameColumn': 'Task Name',
	'taskTypeColumn':'Task Type',
	'lastExecutedColumn' : 'Last Executed On',
	'totalExecutionColumn' : 'Total Executions',
	'successfulExectionColumn' : 'Successful',
	'runningExecutionColumn': 'Running',
	'failedExecutionColumn': 'Failed',
	'cancelledExecutionsColumn': 'Cancelled',
	'waitingExecutionsColumn': 'Waiting',
	'createdByColumn': 'Created By',
	'createdOnColumn' : 'Created On',
	'expectedRows' : 'expectedRows',
	'noRows' : 'noRows'

};

export const operator = {
	'is': 'is',
	'isNot': 'is not',
	'isAnyOf': 'is any of',
	'equals': 'equals',
	'contains': 'contains',
};

export const ltr = {
	'reportTitle': '.css-jlpfkj',
	'gridRow': '.MuiDataGrid-row',
	'columns': '.MuiDataGrid-columnHeader.MuiDataGrid-withBorderColor',
	'taskName': '[data-rowindex="0"]>[data-field="TASK_NAME"] .MuiDataGrid-cellContent',
	'taskNameList': '[data-field="TASK_NAME"] .MuiDataGrid-cellContent',
	'taskType': '[data-rowindex="0"]>[data-field="TASK_TYPE"] .MuiDataGrid-cellContent',
	'taskTypeList':'[data-field="TASK_TYPE"] .MuiDataGrid-cellContent',
	'searchIcon': 'SearchOutlinedIcon',
	'closeIcon': 'CloseIcon',
	'selectColumn': '.MuiDataGrid-columnHeaderTitleContainer',
	'list': '.MuiList-root',
	'dataViewIcon': 'ViewStreamIcon',
	'lastExecutedOnList':'[data-field="LAST_EXECUTED_ON"] .MuiDataGrid-cellContent',
	'calendarLocator':'CalendarIcon',
	'arrowRightIconLocator': 'ArrowRightIcon',
	'GoButton': 'reporting-date-go-button',
	'dateLocator':'.css-183nxzx',
	'goButton': 'reporting-date-go-button',
	'toggleColumnIcon': 'ViewColumnOutlinedIcon',
	'filterIcon': 'FilterAltOutlinedIcon',
	'nativeSelect': '.MuiNativeSelect-select',
	'gridVirtualScroller': '.MuiDataGrid-virtualScroller',
	'hideColumnSelector': '.MuiDataGrid-columnsPanelRow input',
	'valueTextField': '.MuiInputBase-input.css-16rhzhe',
	'globalDownload':'.css-d2jjfw',
	'noDataDisplayMessage':'.css-134robw'
};