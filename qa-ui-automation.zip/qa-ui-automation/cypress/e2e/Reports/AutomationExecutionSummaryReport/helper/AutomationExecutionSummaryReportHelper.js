import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper }
from '../../../../fixtures';
import { txt, ltr } from './constants';
 
class AutomationExecutionSummaryReportHelper extends CommonHelper{
 
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.CommonHelper =  new CommonHelper();
	}

	validateReportsColumn() {
		cy.get(ltr.gridRow, { timeout: 40000 });
		cy.contains(ltr.columns, txt.taskNameColumn);
		cy.contains(ltr.columns, txt.taskTypeColumn);
		cy.contains(ltr.columns, txt.lastExecutedColumn);
		cy.contains(ltr.columns, txt.totalExecutionColumn);
		cy.contains(ltr.columns, txt.successfulExectionColumn);
		cy.contains(ltr.columns, txt.runningExecutionColumn);
		cy.contains(ltr.columns, txt.failedExecutionColumn);
		cy.contains(ltr.columns, txt.cancelledExecutionsColumn);
		cy.contains(ltr.columns, txt.waitingExecutionsColumn);
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionR);
		cy.contains(ltr.columns, txt.createdByColumn);
		cy.contains(ltr.columns, txt.createdOnColumn);
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionL);
	}	

	validateReportTitle()
	{
		this.getLastElement(ltr.reportTitle).should('have.text', txt.reportTitle);
	}
	searchInTheGridAndValidateTaskName(taskNameLocator) {
		this.getTextFromList(taskNameLocator).then((elementText) => {
			var searchIconLocator = this.wrapDataTestId(ltr.searchIcon);
			this.gridHelper.searchEntryInGrid(searchIconLocator, elementText);
			cy.wait(1000);
			this.getList(ltr.taskNameList).contains(elementText);
			var closeIcon = this.wrapDataTestId(ltr.closeIcon);
			this.buttonHelper.clickButton(closeIcon);
		});
	}

	searchInTheGridAndValidateTaskType(taskTypeLocator) {
		this.getTextFromList(taskTypeLocator).then((elementText) => {
			var searchIconLocator = this.wrapDataTestId(ltr.searchIcon);
			this.gridHelper.searchEntryInGrid(searchIconLocator, elementText);
			cy.wait(1000);
			this.getList(ltr.taskTypeList).contains(elementText);
			var closeIcon = this.wrapDataTestId(ltr.closeIcon);
			this.buttonHelper.clickButton(closeIcon);
		});
	}
	

	sortTheColumn(colIndex){
		this.getRowByIndex(ltr.gridRow, colIndex).invoke('text').as('initialText')
			.then((initialText) => {
				this.validateFirstRowExists(ltr.gridRow);
				this.sortColumn(ltr.selectColumn, colIndex);
				this.getRowByIndex(ltr.gridRow, colIndex)
					.invoke('text')
					.then((newText) => {
						expect(newText).to.not.equal(initialText);
					});
			});
	}
	filterUsingTaskType(taskTypeColName, operator, taskType) {
		this.clickFilterIcon();
		this.getTextFromList(taskType).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,taskTypeColName);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.taskTypeList).contains(elementText);
		});	
	}
	
	filterUsingTaskName(taskNameColumn, operator, taskNameListLocator) {
		this.clickFilterIcon();
		this.getTextFromList(taskNameListLocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,taskNameColumn);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.inputFieldHelper.typeIntoInputField(ltr.valueTextField, elementText);
			cy.wait(3000);
			this.getList(ltr.taskNameList).contains(elementText);
		});

	}

	hideColumnsInGrid() {
		this.getColumnHeaders(ltr.columns)
			.invoke('text')
			.as('initialText')
			.then((initialText) => {
				cy.wait(3000);
				this.clickToggleColumnIcon();
				cy.wait(3000);
				this.hideColumn(1);
				this.getColumnHeaders(ltr.columns)
					.invoke('text')
					.then((newText) => {
						expect(newText).to.not.equal(initialText);
					});
			});
	}
	ReportDateYearFilter() {
		var calendarIcon = this.wrapDataTestId(ltr.calendarLocator);
		var arrowRightIcon = this.wrapDataTestId(ltr.arrowRightIconLocator);
		this.getFirstElement(calendarIcon).click();
		Cypress._.times(1, () => {
			cy.get(arrowRightIcon).click();
		});
		this.getElement(ltr.dateLocator).eq(0).click();
		cy.wait(2000);
		const GoButton = this.wrapDataTestId(ltr.GoButton);
		cy.log(GoButton);
		this.getElement(GoButton).click();
		cy.get(ltr.gridRow, { timeout: 40000 });
		cy.wait(2000);
	}

	ExecutionDateFilter() {
		cy.get(ltr.gridRow, { timeout: 40000 });
		this.getColumnHeaders(ltr.lastExecutedOnList)
			.invoke('text')
			.as('initialText')
			.then((initialText) => {
		        var calendarIcon = this.wrapDataTestId(ltr.calendarLocator);
		        this.getFirstElement(calendarIcon).click();
		        this.getElement(ltr.dateLocator).eq(19).click();
		        cy.wait(5000);
		        this.getElement(this.wrapDataTestId(ltr.goButton)).click();
		        cy.get(ltr.gridRow, { timeout: 40000 });
		        cy.wait(2000);
		        this.getColumnHeaders(ltr.lastExecutedOnList)
					.invoke('text')
					.then((newText) => {
						expect(newText).to.not.equal(initialText);
					});
			});
	}

	globalDownload(parameter) {
		if(parameter == 'expectedRows')
		{
			cy.get(ltr.gridRow).then((rows) => {
				cy.log('The rows length', rows.length);
				expect(rows.length).to.be.greaterThan(0);
			});	
			cy.log('Data is below 100k so not getting download button in the grid');
		}
		else if(parameter == 'noRows')
		{
			const displayMessage = this.getElement(ltr.noDataDisplayMessage).text();
			cy.log(displayMessage);
		}
		else 
		{
			cy.log('Need to download data because available data is more than  100k');
			this.getElement(ltr.globalDownload).should('be.visible').click();
			cy.get(ltr.globalDownload, { timeout: 15000 });
			cy.wait(3000);
		}
		
		
	}
	
	clickToggleColumnIcon = () => {
		return this.getToggleColumnIcon().click();
	}
	getToggleColumnIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.toggleColumnIcon);
		return this.getElement(dataTestId);
	}

	scrollGridToRight(gridVirtualScroller, position) {
		this.getElement(gridVirtualScroller).scrollTo(position);
	}

	getRowByIndex = (gridRowLocator, index) => {
		return this.gridHelper.getRowByIndex(gridRowLocator, index);
	}
	validateFirstRowExists = (gridRowLocator) => {
		return this.gridHelper.validateFirstRowExists(gridRowLocator);
	}
	sortColumn = (columnHeaderLocator, columnIndex) => {
		return this.gridHelper.sortColumn(columnHeaderLocator, columnIndex);
	}
	getFilterIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.filterIcon);
		return this.getElement(dataTestId);
	}
	selectDropdownValue = (dropdownSelector, index, value) => {
		return this.dropdownHelper.selectDropdownValue(dropdownSelector, index, value);
	}
	clickFilterIcon = () => {
		return this.getFilterIcon().click();
	}
	getViewColumnIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.viewColumnIcon);
		return this.getElement(dataTestId);
	}
	clickViewColumnIcon = () => {
		return this.getViewColumnIcon().click();
	}
	getColumnHeaders = (gridColumnHeadersLocator) => {
		return this.getElement(gridColumnHeadersLocator);
	}
	clickToggleColumnIcon = () => {
		return this.getToggleColumnIcon().click();
	}
	getDataViewIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.dataViewIcon);
		return this.getElement(dataTestId);
	}
	clickDataViewIcon = () => {
		return this.getDataViewIcon().click();
	}
	hideColumn = (columnIndex) => {
		return this.gridHelper.hideColumn(ltr.hideColumnSelector, columnIndex);
	}
	changeView = (rowSelector, view) => {
		return this.gridHelper.changeGridView(rowSelector, view);
	}
	getList = (listLocator) => {
		return this.getElement(listLocator);
	}
	getTextFromList = (locator) => {
		return cy.get(locator).invoke('text').then((text) => {
			const elementText = text;
			return cy.wrap(elementText);
		});
	}
}

export default AutomationExecutionSummaryReportHelper;
