import AgentUninstallReportHelper from '../helper/AgentUninstallReportHelper';
import { moduleMetaData, ltr, txt, operator} from '../helper/constants';

describe('GIVEN Agent Uninstall Report', { tags: ['@Regression', '@MUI'] }, () => {

	var agentUninstallReportHelper = new AgentUninstallReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {

		before(() => {

		});

		beforeEach(() => {
			agentUninstallReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN Validate the report title', function () {
			agentUninstallReportHelper.validateReportTitle();
		});

		it('THEN Validate the columns available in the report', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.validateReportsColumn();
		});

		it('THEN Validate the sorting for column', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.sortTheColumn(0);
			agentUninstallReportHelper.sortTheColumn(0);
			cy.reload();
			agentUninstallReportHelper.sortTheColumn(1);
			agentUninstallReportHelper.sortTheColumn(1);
			cy.reload();
			agentUninstallReportHelper.sortTheColumn(3);
			agentUninstallReportHelper.sortTheColumn(3);
		});

		it('THEN validate the data filtering in the grid for site name', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.filterUsingSiteName(txt.siteNameColumn, operator.is, ltr.site);
		});

		it('THEN validate the data filtering in the grid for OS name', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.filterUsingOS(txt.osNameColumn, operator.isNot, ltr.OS);
		});

		it('THEN validate the data filtering in the grid for device name', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.filterUsingDeviceName(txt.deviceNameColumn, operator.equals, ltr.deviceName);
		});
		
		it('THEN validate the data filtering in the grid for additional comment', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.filterUsingIsEmptyOperator(txt.additionlaCommentColumn, operator.isEmpty,ltr.additionalComment);
		});
		
		it('THEN validate the different view of data in the grid', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.clickDataViewIcon();
			agentUninstallReportHelper.getList(ltr.list).children().eq(0).click();
			agentUninstallReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.clickDataViewIcon();
			agentUninstallReportHelper.getList(ltr.list).children().eq(1).click();
			agentUninstallReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.clickDataViewIcon();
			agentUninstallReportHelper.getList(ltr.list).children().eq(2).click();
			agentUninstallReportHelper.changeView(ltr.gridRow, 2);
		});
	
		it('THEN validate the functionality to hide or show the columns in the grid', function () {
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.clickViewColumnIcon();
			agentUninstallReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			agentUninstallReportHelper.clickViewColumnIcon();
			agentUninstallReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');
		});
		
		it('THEN validate the search functionality in the report for device name', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});

		it('THEN validate the search functionality in the report for device type', function () {
			cy.get(ltr.gridRow, { timeout: 40000 });
			agentUninstallReportHelper.searchInTheGridAndValidateDeviceType(txt.desktopType);
		});
	});
});
