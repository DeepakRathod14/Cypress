import EndpointProtectionReportHelper from '../helper/EndpointProtectionReportHelper';

import { moduleMetaData, txt, ltr, operator } from '../helper/constants';

describe('GIVEN Endpoint Protection Report', { tags: ['@Regression', '@MUI'] }, () => {

	var endpointProtectionReportHelper = new EndpointProtectionReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => { });

		beforeEach(() => {
			endpointProtectionReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN validate report title for the report', function () {
			cy.allure().tms('CMD-T9127');
			endpointProtectionReportHelper.validateReportTitle();
		});

		it('THEN validate the columns available in the report', function () {
			cy.allure().tms('CMD-T9128');
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.validateReportsColumn();
		});

		it('THEN validate the sorting for column', function () {
			cy.allure().tms('CMD-T9129');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.sortTheColumn(1);
			endpointProtectionReportHelper.sortTheColumn(1);
			cy.reload();
			endpointProtectionReportHelper.sortTheColumn(7);
			endpointProtectionReportHelper.sortTheColumn(7);
			cy.reload();
			//agentReportHelper.sortTheColumn(4);
			//agentReportHelper.sortTheColumn(4);
		});

		it('THEN validate the data filtering in the grid for OS name', function () {
			cy.allure().tms('CMD-T9133');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.filterUsingOS(txt.osNameColumn, operator.isNot, ltr.osName);
		});

		it('THEN validate the data filtering in the grid for device name', function () {
			cy.allure().tms('CMD-T9132');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.filterUsingDeviceName(txt.deviceNameColumn, operator.equals, ltr.deviceName);
		});

		it('THEN validate the data filtering in the grid for endpoint protection', function () {
			cy.allure().tms('CMD-T9131');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.filterUsingEndpointProtectionSoftware(txt.endpointProtectionColumn, operator.equals, ltr.endpointProtectionName);
		});

		it('THEN validate the different view of data in the grid', function () {
			cy.allure().tms('CMD-T9129');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.clickDataViewIcon();
			endpointProtectionReportHelper.getList(ltr.list).children().eq(0).click();
			endpointProtectionReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.clickDataViewIcon();
			endpointProtectionReportHelper.getList(ltr.list).children().eq(1).click();
			endpointProtectionReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.clickDataViewIcon();
			endpointProtectionReportHelper.getList(ltr.list).children().eq(2).click();
			endpointProtectionReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate the functionality to hide or show the columns in the grid', function () {
			cy.allure().tms('CMD-T9128');
			cy.reload();
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.clickViewColumnIcon();
			endpointProtectionReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			endpointProtectionReportHelper.clickViewColumnIcon();
			endpointProtectionReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');

		});
		
		it('THEN validate the search functionality in the report for device name', function () {
			cy.allure().tms('CMD-T9130');
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});
		
		it('THEN validate the search functionality in the report for device type', function () {
			cy.allure().tms('CMD-T9134');
			cy.get(ltr.gridRow, { timeout: 40000 });
			endpointProtectionReportHelper.searchInTheGridAndValidateDeviceType(txt.desktopType);
		});
		
	});
});

