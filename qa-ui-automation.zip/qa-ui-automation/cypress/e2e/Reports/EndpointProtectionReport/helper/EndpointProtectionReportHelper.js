/* eslint-disable no-empty */
import { CommonHelper, ButtonHelper, InputButtonHelper, InputFieldHelper, GridHelper, DropDownHelper }
from '../../../../fixtures';
import { txt, ltr, moduleMetaData } from './constants';
 
class EndpointProtectionReportHelper extends CommonHelper{
 
	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.inputButtonHelper = new InputButtonHelper();
		this.inputFieldHelper = new InputFieldHelper();
		this.gridHelper = new GridHelper();
		this.dropdownHelper = new DropDownHelper();
		this.CommonHelper =  new CommonHelper();
	}

	validateReportsColumn() {
		cy.get(ltr.gridRow, { timeout: 40000 });
		cy.contains(ltr.columns, txt.deviceNameColumn);
		cy.contains(ltr.columns, txt.frindlyNameColumn);
		cy.contains(ltr.columns, txt.siteNameColumn);
		cy.contains(ltr.columns, txt.siteFrindlyNameColumn);
		cy.contains(ltr.columns, txt.companyFriendlyNameColumn);
		cy.contains(ltr.columns, txt.companyNameColumn);
		cy.contains(ltr.columns, txt.deviceTypeColumn);
		cy.contains(ltr.columns, txt.osNameColumn);
		cy.contains(ltr.columns, txt.endpointProtectionColumn);
		cy.contains(ltr.columns, txt.lastCheckDateColumn);
		cy.contains(ltr.columns, txt.deviceTimeZoneColumn);

		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionR);
		
		//this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionL);
	}	

	validateReportTitle()
	{
		this.getLastElement(ltr.reportTitle).should('have.text', moduleMetaData.name);
	}
	searchInTheGridAndValidateDeviceName(deviceNameLocator) {
		this.getTextFromList(deviceNameLocator).then((elementText) => {
			this.gridHelper.searchEntryInGrid(ltr.searchIcon, elementText);
			this.gridHelper.getRowByIndex(ltr.nameColumn, 0).should('have.text', elementText);
			this.getList(ltr.deviceName).contains(elementText);
			this.buttonHelper.clickButton(ltr.closeIcon);
		});
	}

	searchInTheGridAndValidateDeviceType(deviceType) {
		this.gridHelper.searchEntryInGrid(ltr.searchIcon, deviceType);
		this.gridHelper.getRowByIndex(ltr.deviceType,0).should('have.text', deviceType);
		this.getList(ltr.deviceType).contains(txt.desktopType);
		this.buttonHelper.clickButton(ltr.closeIcon);
	}

	sortTheColumn(colIndex){
		this.getRowByIndex(ltr.gridRow, colIndex).invoke('text').as('initialText')
			.then((initialText) => {
				this.validateFirstRowExists(ltr.gridRow);
				this.sortColumn(ltr.selectColumn, colIndex);
				this.getRowByIndex(ltr.gridRow, colIndex)
					.invoke('text')
					.then((newText) => {
						expect(newText).to.not.equal(initialText);
					});
			});
	}
	filterUsingSiteName(siteNameColumn, operator, siteNameListLocator) {
		this.clickFilterIcon();
		this.getTextFromList(siteNameListLocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,siteNameColumn);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.siteList).contains(elementText);
		});
		
	}
	filterUsingOS(osColname, operator, osListLocator) {
		this.clickFilterIcon();
		this.getTextFromList(osListLocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,osColname);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.selectDropdownValue(ltr.nativeSelect,3,elementText);
			cy.wait(3000);
			this.getList(ltr.osName).should('not.contain', elementText);
		});
	}
	filterUsingDeviceName(deviceNameColumn, operator, deviceNameListlocator) {
		this.clickFilterIcon();
		this.getTextFromList(deviceNameListlocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,deviceNameColumn);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.inputFieldHelper.typeIntoInputField(ltr.valueTextField, elementText);
			cy.wait(3000);
			this.getList(ltr.nameColumn).contains(elementText);
		});
	}

	filterUsingEndpointProtectionSoftware(endpointProtectionNameColumn, operator, endpointProtectionNameListlocator) {
		this.scrollGridToRight(ltr.gridVirtualScroller, txt.positionR);
		this.sortColumn(ltr.selectColumn, 8);
		this.sortColumn(ltr.selectColumn, 8);
		this.clickFilterIcon();
		this.getTextFromList(endpointProtectionNameListlocator).then((elementText) => {
			this.selectDropdownValue(ltr.nativeSelect,1,endpointProtectionNameColumn);
			this.selectDropdownValue(ltr.nativeSelect,2,operator);
			this.inputFieldHelper.typeIntoInputField(ltr.valueTextField, elementText);
			cy.wait(3000);
			this.getList(ltr.endpointProtectionColumn).contains(elementText);
		});

	}
	
	scrollGridToRight(gridVirtualScroller, position) {
		this.getElement(gridVirtualScroller).scrollTo(position);
	}

	getRowByIndex = (gridRowLocator, index) => {
		return this.gridHelper.getRowByIndex(gridRowLocator, index);
	}
	validateFirstRowExists = (gridRowLocator) => {
		return this.gridHelper.validateFirstRowExists(gridRowLocator);
	}
	sortColumn = (columnHeaderLocator, columnIndex) => {
		return this.gridHelper.sortColumn(columnHeaderLocator, columnIndex);
	}
	getFilterIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.filterIcon);
		return this.getElement(dataTestId);
	}
	selectDropdownValue = (dropdownSelector, index, value) => {
		return this.dropdownHelper.selectDropdownValue(dropdownSelector, index, value);
	}
	clickFilterIcon = () => {
		return this.getFilterIcon().click();
	}
	
	getViewColumnIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.viewColumnIcon);
		return this.getElement(dataTestId);
	}
	clickViewColumnIcon = () => {
		return this.getViewColumnIcon().click();
	}
	getDataViewIcon = () => {
		const dataTestId = this.wrapDataTestId(ltr.dataViewIcon);
		return this.getElement(dataTestId);
	}
	clickDataViewIcon = () => {
		return this.getDataViewIcon().click();
	}
	changeView = (rowSelector, view) => {
		return this.gridHelper.changeGridView(rowSelector, view);
	}
	getList = (listLocator) => {
		return this.getElement(listLocator);
	}
	getTextFromList = (locator) => {
		return cy.get(locator).invoke('text').then((text) => {
			const elementText = text;
			return cy.wrap(elementText);
		});
	}


}

export default EndpointProtectionReportHelper;
