export const moduleMetaData = {
	name: 'Endpoint Protection Report',
	customUser: 'user_2'
};

export const txt = {
	'approve': 'Approve',
	'desktopType' : 'Desktop',
	'serverType' : 'Server',
	'positionL' : 'left',
	'positionR' : 'right',

	'deviceNameColumn' : 'Name',
	'frindlyNameColumn': 'Friendly Name',
	'siteNameColumn' : 'Site Name',
	'siteFrindlyNameColumn': 'Site Friendly Name',
	'companyFriendlyNameColumn':'Company Friendly Name',
	'companyNameColumn':'Company Name',
	'deviceTypeColumn': 'Device Type',
	'osNameColumn' : 'OS',
	'endpointProtectionColumn':'Endpoint Protection',
	'lastCheckDateColumn': 'Last Check Date',
	'deviceTimeZoneColumn': 'Device Time Zone',
};

export const operator = {
	'is': 'is',
	'isNot': 'is not',
	'isAnyOf': 'is any of',
	'equals': 'equals',
	'contains': 'contains',
};

export const ltr = {
	'columns': '.MuiDataGrid-columnHeader.MuiDataGrid-withBorderColor',
	'gridRow': '.MuiDataGrid-row',
	'gridVirtualScroller': '.MuiDataGrid-virtualScroller',
	'selectColumn': '.MuiDataGrid-columnHeaderTitleContainer',
	'searchIcon': '.MuiButtonBase-root.MuiIconButton-root.MuiIconButton-sizeMedium.css-w9aoya',
	'nativeSelect': '.MuiNativeSelect-select',
	'valueTextField': '.MuiInputBase-input.css-16rhzhe',
	'reportTitle': '.css-q7hzx0',
	'deviceType': 'div[data-field="ENDPOINT_TYPE"] .MuiDataGrid-cellContent',
	'closeIcon': '.MuiButtonBase-root.MuiIconButton-root.MuiIconButton-sizeSmall.css-51mpi5',
	'nameColumn': 'div[data-field="SYSTEM_NAME"] .MuiDataGrid-cellContent',
	'osName': '[data-rowindex="0"]>[data-field="OS_PRODUCT"] .MuiDataGrid-cellContent',
	'siteList': '[data-rowindex="0"]>div[data-field="SITE_NAME"] .MuiDataGrid-cellContent',
	'filterIcon': 'FilterAltOutlinedIcon',
	'toogleIcon': '.PrivateSwitchBase-input.css-1m9pwf3',
	'viewColumnIcon': 'ViewColumnOutlinedIcon',
	'dataViewIcon': 'ViewStreamIcon',
	'list': '.MuiList-root',
	'deviceName': '[data-rowindex="0"]>[data-field="SYSTEM_NAME"] .MuiDataGrid-cellContent',
	'endpointProtectionName':'[data-rowindex="0"]>[data-field="ENDPOINT_PROTECTION_SOFTWARE"] .MuiDataGrid-cellContent',
	'endpointProtectionColumn':'div[data-field="ENDPOINT_PROTECTION_SOFTWARE"] .MuiDataGrid-cellContent'
};