import PatchDeploymentReportHelper from '../helper/PatchDeploymentReportHelper';

import { moduleMetaData, ltr, txt, operator } from '../helper/constants';

describe('GIVEN Patch Deployment Report', { tags: ['@Regression', '@MUI'] }, () => {

	var patchDeploymentReportHelper = new PatchDeploymentReportHelper();

	Cypress.on('uncaught:exception', () => {
		return false;
	});
	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => { });

		beforeEach(() => {
			patchDeploymentReportHelper.navigateToPageOnCheck(moduleMetaData.name);
		});

		after(() => { });

		afterEach(() => { 
			cy.go('back');
		});

		// test cases start here
		it('THEN validate report title for the report', function () {
			cy.allure().tms('CMD-T8872');
			patchDeploymentReportHelper.validateReportTitle();
		});

		it('THEN validate the columns available in the report', function () {
			cy.allure().tms('CMD-T8873');
			patchDeploymentReportHelper.validateReportsColumn();
		});

		it('THEN validate the sorting for column', function () {
			cy.allure().tms('CMD-T8874');
			patchDeploymentReportHelper.loadGridData();
			patchDeploymentReportHelper.sortTheColumn(7);
			patchDeploymentReportHelper.sortTheColumn(7);
			cy.reload();
			patchDeploymentReportHelper.loadGridData();
			patchDeploymentReportHelper.sortTheColumn(8);
			patchDeploymentReportHelper.sortTheColumn(8);

		});

		
		it('THEN validate the data filtering in the grid for OS name', function () {
			cy.allure().tms('CMD-T8879');
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.filterUsingOS(txt.osNameColumn, operator.isNot, ltr.osName);
		});

		it('THEN validate the data filtering in the grid for device name', function () {
			cy.allure().tms('CMD-T8880');
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.filterUsingDeviceName(txt.deviceNameColumn, operator.equals, ltr.deviceName);
		});

		it('THEN validate the data filtering in the grid for classification', function () {
			cy.allure().tms('CMD-T8880');
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.filterUsingClassificationPercentage(txt.classificationColumn, operator.is, ltr.classificationValue);
		});

		it('THEN validate the different view of data in the grid', function () {
			cy.allure().tms('CMD-T8881');
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.clickDataViewIcon();
			patchDeploymentReportHelper.getList(ltr.list).children().eq(0).click();
			patchDeploymentReportHelper.changeView(ltr.gridRow, 0);
			cy.reload();
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.clickDataViewIcon();
			patchDeploymentReportHelper.getList(ltr.list).children().eq(1).click();
			patchDeploymentReportHelper.changeView(ltr.gridRow, 1);
			cy.reload();
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.clickDataViewIcon();
			patchDeploymentReportHelper.getList(ltr.list).children().eq(2).click();
			patchDeploymentReportHelper.changeView(ltr.gridRow, 2);
		});

		it('THEN validate the functionality to hide or show the columns in the grid', function () {
			cy.allure().tms('CMD-T8882');
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.clickViewColumnIcon();
			patchDeploymentReportHelper.gridHelper.hideColumn(ltr.toogleIcon, 0);
			patchDeploymentReportHelper.clickViewColumnIcon();
			patchDeploymentReportHelper.getElement(ltr.columns)
				.not()
				.contains('Name');

		});
		
		it('THEN validate the search functionality in the report for device name', function () {
			cy.allure().tms('CMD-T8883');
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.searchInTheGridAndValidateDeviceName(ltr.deviceName);
		});
		
		it('THEN validate the search functionality in the report for device type', function () {
			cy.allure().tms('CMD-T8884');
			patchDeploymentReportHelper.loadGridData();
			cy.get(ltr.gridRow, { timeout: 40000 });
			patchDeploymentReportHelper.searchInTheGridAndValidateDeviceType(txt.desktopType);
		});

		
	});
});

