import BackupDashboardHelper from '../helper/BackupDashboardHelper';
import { moduleMetaData } from '../helper/constants';

describe('GIVEN Backup Dashboard Protected Devices', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var backDashboardHelper = new BackupDashboardHelper();

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => {
			backDashboardHelper.setup(moduleMetaData);
		});

		after(() => { backDashboardHelper.cleanup(); });

		beforeEach(() => {
			backDashboardHelper.navigateToBackupDashboard();
		});

		afterEach(() => { });

		it('should visible protected devices count not equal to zero', () => {
			backDashboardHelper.protectedDevicesCountShouldVisible();
		});

		it('should visible protected all devices types', () => {
			backDashboardHelper.protectedDevicesTypeShouldVisible();
		});

	});

});
