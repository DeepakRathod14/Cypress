import BackupDashboardHelper from '../helper/BackupDashboardHelper';
import { moduleMetaData, ltr } from '../helper/constants';

describe('GIVEN Backup Dashboard Alart data grid', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var backDashboardHelper = new BackupDashboardHelper();

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => {
			backDashboardHelper.setup(moduleMetaData);
		});

		after(() => { backDashboardHelper.cleanup(); });

		beforeEach(() => {
			backDashboardHelper.navigateToBackupDashboard();
		});

		afterEach(() => { });

		it('should visible monitor & exempt devices tab', () => {
			backDashboardHelper.navigateToTab(ltr.deviceTab);
			backDashboardHelper.shouldMonitoredDevicesTabVisible();
			backDashboardHelper.shouldExemptDevicesTabVisible();
		});

		it('should disable exempt from monitoring button after selecting protected devices', () => {
			backDashboardHelper.navigateToTab(ltr.deviceTab);
			backDashboardHelper.checkGridsDataPresent(0, 'companyName');
			backDashboardHelper.selectGridFilter('protectionStatus', 2);
			backDashboardHelper.checkGridsDataPresent(0, 'companyName');
			backDashboardHelper.selectRowByIndex(5);
			backDashboardHelper.checkElementIsDisabled(ltr.exemptFromMonitoring);
		});

		it('should visible exempt from monitoring button after selecting unprotected devices', () => {
			backDashboardHelper.navigateToTab(ltr.monitorTab);
			backDashboardHelper.navigateToTab(ltr.monitorTab);
			backDashboardHelper.selectGridFilter('protectionStatus', 1);
			backDashboardHelper.selectRowByIndex(5);
			backDashboardHelper.checkElementIsVisible(ltr.exemptFromMonitoring);
			backDashboardHelper.buttonHelper.clickButton(ltr.exemptFromMonitoring);
			backDashboardHelper.checkAlertMessageShouldVisible(ltr.exemptSuccessMsg);
		});

		it('should visible add back to monitoring button after selecting unprotected devices', () => {
			backDashboardHelper.navigateToTab(ltr.exemptTab);
			backDashboardHelper.selectRowByIndex(1);
			backDashboardHelper.checkElementIsVisible(ltr.addToMonitoring);
			backDashboardHelper.buttonHelper.clickButton(ltr.addToMonitoring);
			backDashboardHelper.checkAlertMessageShouldVisible(ltr.monitoringSuccessMsg);
		});

	});
});