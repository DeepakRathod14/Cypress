import BackupDashboardHelper from '../helper/BackupDashboardHelper';
import { moduleMetaData } from '../helper/constants';

describe('GIVEN Backup Dashboard Alarms By Severity', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var backDashboardHelper = new BackupDashboardHelper();

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => {
			backDashboardHelper.setup(moduleMetaData);
		});

		after(() => { backDashboardHelper.cleanup(); });

		beforeEach(() => {
			backDashboardHelper.navigateToBackupDashboard();
		});

		afterEach(() => { });

		it('should visible severity total count not equal to zero', () => {
			backDashboardHelper.alarmsBySeverityCountShouldVisible();
		});

		it('should visible all severity status', () => {
			backDashboardHelper.severityStatusShouldVisible();
		});

	});

});
