import BackupDashboardHelper from '../helper/BackupDashboardHelper';
import { moduleMetaData, ltr } from '../helper/constants';

describe('GIVEN Backup Dashboard Alart data grid', { tags: ['@Regression', '@MUI'] }, () => {

	Cypress.on('uncaught:exception', () => {
		return false;
	});

	//Add helpers here
	var backDashboardHelper = new BackupDashboardHelper();

	context('WHERE user is migrated/SSO', { tags: ['@Migrated'] }, () => {
		before(() => {
			backDashboardHelper.setup(moduleMetaData);
		});

		after(() => { backDashboardHelper.cleanup(); });

		beforeEach(() => {
			backDashboardHelper.navigateToBackupDashboard();
		});

		afterEach(() => { });

		it('should visible alarms tab & grid', () => {
			backDashboardHelper.navigateToTab(ltr.alarmsTab);
			backDashboardHelper.shouldAlarmsTabVisible();
			backDashboardHelper.checkGridsDataPresent(0, 'companyName');
		});

		it('should filter the product column on alarm grid', () => {
			backDashboardHelper.navigateToTab(ltr.alarmsTab);
			backDashboardHelper.shouldValidateFiltering('product');
		});

		it('should default sort by last refreshed', () => {
			backDashboardHelper.navigateToTab(ltr.alarmsTab);
			backDashboardHelper.checkDefaultSorting('lastRefreshed');
		});

		it('should remove the active filters', () => {
			backDashboardHelper.removeFilters();
			backDashboardHelper.checkGridsDataPresent(0, 'companyName');
		});

		it('should sort with severity column', () => {
			backDashboardHelper.checkGridSortingShouldWork('severity');
		});
	});
});