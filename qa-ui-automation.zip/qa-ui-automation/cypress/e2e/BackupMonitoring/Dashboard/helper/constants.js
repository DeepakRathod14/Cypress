export const moduleMetaData = {
	name: 'BackupMonitoring',
	customUser: 'user_backupDashboard'
};
export const ltr = {
	alarmsTab: 'button[data-testid="alarms-tab"]',
	deviceTab: 'div[data-testid="backup-data-grid"] .MuiTabs-flexContainer > :nth-child(2)',
	monitorTab: 'button[value="relevantDevices"]',
	exemptTab: 'button[value="exemptDevices"]',
	exemptFromMonitoring: 'button[title="Exempt from Monitoring"]',
	addToMonitoring: 'button[title="Add to Monitoring"]',
	exemptSuccessMsg: 'Device successfully exempted from monitoring.',
	monitoringSuccessMsg: 'Device successfully added back to monitoring.' ,
	protectedPodCount: 'div[data-testid="device-protection-pod"]  div.highcharts-data-labels  span > div:nth-child(1) > div:nth-child(2)',
	muiAlert: 'div.MuiAlert-message div',
	firstElement: '//*[@id="bdash-tabpanel-1"]/div/div[2]/div/div[2]/div[2]/div/div/div[1]/div[1]/span/svg',
	protectedDevices: 'protected-device-pod-heading',
	desktop: 'Workstation',
	server: 'Server',
	vm: 'VM',
	monitoredDevices: 'button[value="Monitored Devices"]',
	alarmsBySeverity: 'alarams-by-severity-pod-heading',
	alarmsStatus: {
		critical: 'Critical',
		high: 'High',
		medium: 'Medium',
		low: 'Low',
		info: 'Info'
	}
};
