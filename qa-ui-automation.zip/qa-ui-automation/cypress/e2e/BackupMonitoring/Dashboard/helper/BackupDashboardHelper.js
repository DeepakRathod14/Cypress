import { ButtonHelper, CommonHelper, GridHelper } from '../../../../fixtures';
import { moduleMetaData, ltr } from './constants';

class BackupDashboardHelper extends CommonHelper {

	constructor() {
		super();
		this.buttonHelper = new ButtonHelper();
		this.gridHelper = new GridHelper();
	}

	navigateToBackupDashboard() {
		this.navigateToPageOnCheck(moduleMetaData.name);
	}
	shouldAlarmsTabVisible() {
		return this.checkElementIsVisible(ltr.alarmsTab);
	}

	checkGridsDataPresent(row, colName) {
		this.gridHelper.checkGridsDataPresent(row, colName);
	}
	navigateToTab(tab) {
		this.buttonHelper.clickButton(tab);
	}
	shouldValidateFiltering(columnName) {
		this.gridHelper.validateGridCollectionFilters(columnName, 1);
	}
	selectGridFilter(columnName, optionIndex) {
		this.gridHelper.validateGridCollectionFilters(columnName, optionIndex);
	}
	selectRowByIndex(index) {
		this.gridHelper.checkMuiDataGridRowByIndex(index);
	}
	checkDefaultSorting(columnName) {
		this.gridHelper.checkSortingIsVisible(columnName, 'descending');
	}
	checkGridSortingShouldWork(columnName) {
		this.buttonHelper.clickButton(this.gridHelper.wrapGridColumn(columnName));
		this.gridHelper.checkSortingIsVisible(columnName, 'ascending');
	}
	checkElementIsDisabled(selectors) {
		this.buttonHelper.checkButtonIsDisabled(selectors);
	}
	removeFilters() {
		this.gridHelper.removeAllFilters();
	}

	protectedDevicesCountShouldVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(ltr.protectedDevices));
		this.checkElementIsVisible(`${this.wrapDataTestId(ltr.protectedDevices)} p`);

		// cy.get(`${this.wrapDataTestId(ltr.protectedDevices)} p`).invoke('attr', 'data-value').then(val => {
		// 	expect(parseInt(val)).to.be.greaterThan(0);
		// });
	}

	protectedDevicesTypeShouldVisible() {
		this.getElementWithText(this.wrapDataTestId(ltr.desktop), 'Workstations');
		this.getElementWithText(this.wrapDataTestId(ltr.server), 'Server');
		this.getElementWithText(this.wrapDataTestId(ltr.vm), 'Virtual Machine');
	}

	alarmsBySeverityCountShouldVisible() {
		this.checkElementIsVisible(this.wrapDataTestId(ltr.alarmsBySeverity));
		this.checkElementIsVisible(`${this.wrapDataTestId(ltr.alarmsBySeverity)} p`);
	}

	severityStatusShouldVisible() {
		this.getElementWithText(this.wrapDataTestId(ltr.alarmsStatus.critical), 'Critical');
		this.getElementWithText(this.wrapDataTestId(ltr.alarmsStatus.high), 'High');
		this.getElementWithText(this.wrapDataTestId(ltr.alarmsStatus.medium), 'Medium');
		this.getElementWithText(this.wrapDataTestId(ltr.alarmsStatus.low), 'Low');
		this.getElementWithText(this.wrapDataTestId(ltr.alarmsStatus.info), 'Info');
	}

	shouldMonitoredDevicesTabVisible() {
		this.checkElementIsVisible(ltr.monitorTab);
	}
	shouldExemptDevicesTabVisible() {
		this.checkElementIsVisible(ltr.exemptTab);
	}
	checkAlertMessageShouldVisible(message) {
		this.checkElementIsVisible(ltr.muiAlert);
		this.getTextOfElement(ltr.muiAlert).then((text) => {
			expect(text.trim()).to.be.equal(message);
		});
	}

}

export default BackupDashboardHelper;