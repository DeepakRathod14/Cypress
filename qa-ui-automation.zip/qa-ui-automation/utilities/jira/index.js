const fs = require('fs');
const path = require('path');

const moduleMapping = require('./module-mapping.json');
const projects = require('./projects.json');

const { resolveTestCaseCycle, postTestCaseData, createNewTestCycleWithBulkTestCaseData } = require('./testCycle');
const { getTestCaseCycleObject } = require('./testCase');

/**
 * argv[2] = folder name
 * argv[3] = module name
 * argv[4] = MR number
 */

const folderPath = path.join(__dirname, process.argv[2]); // replace with your folder path
const projectBasedOnModule = projects[moduleMapping[process.argv[3]]];

if (!projectBasedOnModule.EnableJiraReporter) {
	console.log('JIRA Reporting is not enabled for current module');
	return;
}

let items = [];

fs.readdir(folderPath, (err, files) => {
	if (err) {
		console.error('An error occurred: ', err);
		return;
	}

	files.forEach(file => {
		const fileData = require(path.join(folderPath, file));
		var templateData = getTestCaseCycleObject(fileData);
		if (templateData) {
			items.push(templateData);
		}
	});

	console.log('Total test cases found with JIRA-ID: ' + items.length);
	
	if(items.length === 0) {
		console.log('No test cases found with JIRA-ID');
		return;
	}

	resolveTestCaseCycle(projectBasedOnModule.ProjectKey, projectBasedOnModule.TestCycleThreshold).then(response => {
		if (response === 0) {
			console.log('No test cycle found within threshold');
			console.log('Creating New Test Cycle for Project: ' + projectBasedOnModule.ProjectKey + '!');
			createNewTestCycleWithBulkTestCaseData(projectBasedOnModule.TestCycle, items, process.argv[4]);
			return;
		} else {
			console.log('Updating Test Cycle: ' + response);
			for (const item of items) {
				postTestCaseData(response, item);
			}
		}
	});


});
