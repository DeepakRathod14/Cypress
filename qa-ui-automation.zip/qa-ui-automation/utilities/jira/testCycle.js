const axios = require('axios');
const projects = require('./projects.json');

const jiraDetails = projects.JIRA;
const backslash = '/';

async function resolveTestCaseCycle(projectKey, threshold) {
	try {
		const response = await axios({
			method: 'get',
			url: jiraDetails.url + jiraDetails.searchTestRun + projectKey + jiraDetails.doubleQuotes,
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + jiraDetails.key,
			},
		});
		return checkDateWithinThreshold(response.data[0].createdOn, threshold) ? response.data[0].key : 0 ;
	} catch (error) {
		console.log(error);
	}
}

async function postTestCaseData(testCycleKey, data) {
	try{
		const response = await axios({
			method: 'post',
			url: jiraDetails.url + jiraDetails.testrun + backslash + testCycleKey + backslash + jiraDetails.testcase + backslash + data.testCaseKey + backslash + jiraDetails.testresult,
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + jiraDetails.key,
			},
			data: data,
		});
		if (response.status !== 201) {
			console.log('Error in posting test case data');
		} else {
			console.log(data.testCaseKey + ' data posted successfully');
		}
		
		return response.data;

	} catch (error) {
		console.log(error);
	}
}

async function createNewTestCycleWithBulkTestCaseData(projectTestCycle, items, mrNumber) {
	try{
		const response = await axios({
			method: 'post',
			url: jiraDetails.url + jiraDetails.testrun,
			headers: {
				'Content-Type': 'application/json',
				'Authorization': 'Bearer ' + jiraDetails.key,
			},
			data: {
				projectKey: projectTestCycle.projectKey,
				name: projectTestCycle.name + ' | QA | ' + new Date().toISOString() + ' | MR#' + mrNumber,
				items: items,
			},
		});

		if (response.status !== 201) {
			console.log('Error in posting test cycle with bulk test case data');
		} else {
			console.log('New test cycle created: ' + response.data.key );
		}
		
		return response.data;

	} catch (error) {
		console.log(error);
	}
}


function checkDateWithinThreshold(date, threshold) {
	const date1 = new Date(date);
	const date2 = new Date();
	const diffTime = Math.abs(date2 - date1);
	const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
	return diffDays <= threshold;
}


module.exports = { resolveTestCaseCycle, postTestCaseData, createNewTestCycleWithBulkTestCaseData };