function getTestCaseCycleObject(testCaseObj) {
	if (!testCaseObj.status || !testCaseObj.links[0]?.name) {
		console.log('No test case key found');
		return;
	}

	return {
		testCaseKey: testCaseObj.links[0].name,
		status: testCaseObj.status === 'passed' ? 'Pass' : 'Fail',
		executionDate: new Date(testCaseObj.time.start).toISOString(),
		executionTime: testCaseObj.time.duration,
		environment: 'QA',
		comment: '',
	};
}

module.exports = { getTestCaseCycleObject };