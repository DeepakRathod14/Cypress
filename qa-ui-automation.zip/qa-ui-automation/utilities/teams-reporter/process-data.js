function getUpdatedChartCondig(resultDataMap, chartConfig) {
	chartConfig.data.datasets[0].data = [resultDataMap.Passed, resultDataMap.Failed, resultDataMap.Skipped];
	chartConfig.data.labels = ['Passed', 'Failed', 'Skipped'];

	// console.log(chartConfig.options.pl);
	chartConfig.options.plugins.doughnutlabel.labels[0].text = resultDataMap.Total;

	return chartConfig;
}

function getResultsDataMap(resultData) {
	let resultsDataMap = {};

	resultsDataMap['Passed'] = resultData.statistic.passed;
	resultsDataMap['Failed'] = resultData.statistic.failed;
	resultsDataMap['Skipped'] = resultData.statistic.skipped;
	resultsDataMap['Total'] = resultData.statistic.total;

	resultsDataMap['Minimum Time'] = (Math.round(resultData.time.minDuration / 600) / 100) + 'm';
	resultsDataMap['Maximum Time'] = (Math.round(resultData.time.maxDuration / 600) / 100) + 'm';
	resultsDataMap['Total Time'] = (Math.round(resultData.time.duration / 600) / 100 ) + 'm';

	return resultsDataMap;

}

function getUpdatedTeamsCardConfig(resultDataMap, chartUrl, teamsCardConfig) {
	let headerItems = [];
	let valueItems = [];

	teamsCardConfig.attachments[0].content.body[2].url = chartUrl;

	for (const [key, value] of Object.entries(resultDataMap)) {
		if (key === 'Total') continue;

		headerItems.push({
			'type': 'TextBlock',
			'text': key,
			'size': 'Large'
		});

		valueItems.push({
			'type': 'TextBlock',
			'text': value,
			'size': 'Large',
			'horizontalAlignment': 'Right'
		});
	}

	teamsCardConfig.attachments[0].content.body[3].columns[0].items = headerItems;
	teamsCardConfig.attachments[0].content.body[3].columns[1].items = valueItems;

	return teamsCardConfig;
}

module.exports = { getUpdatedChartCondig, getResultsDataMap, getUpdatedTeamsCardConfig };