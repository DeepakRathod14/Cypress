const axios = require('axios');
const QuickChart = require('quickchart-js');

let chartConfig = require('./chart-config.json');
let teamsCardConfig = require('./teams-card-config.json');

const processData = require('./process-data');

const result = require(process.argv[2]);

const resultDataMap = processData.getResultsDataMap(result);
chartConfig = processData.getUpdatedChartCondig(resultDataMap, chartConfig);

// Create a new chart
const myChart = new QuickChart();
myChart.setConfig(chartConfig);

// Get the URL of the chart
const chartUrl = myChart.getUrl();

teamsCardConfig = processData.getUpdatedTeamsCardConfig(resultDataMap, chartUrl, teamsCardConfig);
teamsCardConfig.attachments[0].content.body[1].text += process.argv[3] + ' / Stage: ' + process.argv[5];
teamsCardConfig.attachments[0].content.body[4].actions[0].url = 'https://qa.gitlab-pages.connectwisedev.com/-/qa-ui-automation/-/jobs/' + process.argv[4] + '/artifacts/public/index.html'; 


// Send a POST request with the chart URL
axios.post('https://connectwise.webhook.office.com/webhookb2/82fbef58-8f58-45e3-8f61-e15e2eb1f2c1@f2ddb62f-8335-4cc9-9886-175b834e4bf3/IncomingWebhook/cae3c3077fa44b3e84991c7a84bc15a8/3c4138da-d5be-44f5-8c54-eeac083f5aa6', teamsCardConfig)
	.then(response => {
		console.log(response.status);
	})
	.catch(error => {
		console.error(error);
	});