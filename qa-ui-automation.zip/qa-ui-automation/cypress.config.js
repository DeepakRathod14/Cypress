// require('dotenv').config()
const { defineConfig } = require('cypress');
const { verifyDownloadTasks } = require('cy-verify-downloads');
const allureWriter = require('@shelex/cypress-allure-plugin/writer');
const { beforeRunHook } = require('cypress-mochawesome-reporter/lib');
// const getspecFiles = require("cypress-gitlab-parallel-runner")

module.exports = defineConfig({
	chromeWebSecurity: false,
	defaultCommandTimeout: 25000,
	pageLoadTimeout: 60000,
	viewportHeight: 1080,
	viewportWidth: 1920,
	requestTimeout: 60000,
	responseTimeout: 90000,

	env: {
		environment: 'QA',
		grepFilterSpecs: true,
		grepOmitFiltered: true,
	},
	

	downloadsFolder: 'cypress/output/downloads',
	screenshotsFolder: 'cypress/output/screenshots',
	videosFolder: 'cypress/output/videos',
  
	retries: {
		runMode: 1,
		openMode: 0,
	},

	video: true,

	experimentalStudio: true,

	reporter: 'cypress-mochawesome-reporter',
	reporterOptions: {
		reportDir: 'cypress/output/reports',
		charts: true,
		reportPageTitle: 'UI Automation Test Result',
		embeddedScreenshots: true,
		inlineAssets: true,
		saveAllAttempts: false,
		saveJson: true,
	},
	e2e: {
		setupNodeEvents(on, config) {
			// implement node event listeners here

			require('cypress-mochawesome-reporter/plugin')(on);
			require('@cypress/grep/src/plugin')(config);
			allureWriter(on, config);

			on('task', verifyDownloadTasks);
			on('task', {
				log(message) {
				  console.log(message +'\n\n');
				  return null;
					// eslint-disable-next-line indent
					}
			});

			on('before:run', async (details) => {
				await beforeRunHook(details);
			});

			// getspecFiles("./cypress/e2e",false)

			return config;
		},
		
		// baseUrl: 'https://control.qa.itsupport247.net',
		
		testIsolation: false,

	},


});
