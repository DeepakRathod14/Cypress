require('dotenv').config()
const { defineConfig } = require("cypress");
const { configureAllureAdapterPlugins } = require('@mmisty/cypress-allure-adapter/plugins');
const { verifyDownloadTasks } = require('cy-verify-downloads');
// const getspecFiles = require("cypress-gitlab-parallel-runner")

module.exports = defineConfig({
  chromeWebSecurity: false,
  defaultCommandTimeout: 25000,
  pageLoadTimeout: 60000,
  viewportHeight: 1080,
  viewportWidth: 1920,

  env: {
    environment: 'QA',
    
    grepFilterSpecs: true,
    grepOmitFiltered: true,

    allure: true,
    allureCleanResults: true,
    allureAttachRequests: true,
    allureAddVideoOnPass: true,
    allureShowTagsInTitle: true,

    tmsPrefix: 'https://jira.connectwisedev.com/secure/Tests.jspa#/testCase',
    issuePrefix: 'https://jira.connectwisedev.com/browse',
  },
  
  downloadsFolder: 'cypress/output/downloads',
  screenshotsFolder: 'cypress/output/screenshots',
  videosFolder: 'cypress/output/videos',
  
  retries: {
    runMode: 1,
    openMode: 1,
  },

  video: true,

  experimentalStudio: true,

  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here

      require('@cypress/grep/src/plugin')(config)
      configureAllureAdapterPlugins(on, config);

      on('task', verifyDownloadTasks);

      // getspecFiles("./cypress/e2e",false)

      return config
    },
    
    // baseUrl: 'https://control.qa.itsupport247.net',
    
    testIsolation: false,

  },


});
