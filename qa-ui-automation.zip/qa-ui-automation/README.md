# qa-ui-automation

[[_TOC_]]

<h4>UI Automation Project for Automation Testing ITSPlatform RMM</h4>

## Prerequisite Software

- Node js: download and install Node js version [14.21.3](https://nodejs.org/download/release/v14.21.3/). Follow the setup and install it. Post installation verify node version using command: `node --version`
- Npm: this will be downloaded with Node js. No additional setup is required for Npm. Make sure that Npm has following version: 6.14.17. Verify npm version post installtion of node js using following command: `npm --version`
- IDE: [Visual Studio Code](https://code.visualstudio.com/) is the preferred IDE for this project.
- Git: Install the latest version of [Git](https://git-scm.com/download/win).

### Extensions required for IDE

Install below plugins in your IDE:

- JavaScript (ES6) code snippets (charalampos karypidis)
- ESlint (Microsoft)
- Inline Parameters for VSCode (Liam Hammett)
- GitLens — Git supercharged (GitKraken)
- Cypress Helper (Oleksandr Shevtsov)
- GitHub Copilot (GitHub)
- GitLab Workflow (GitLab)
- Fold Plus (dakara)

# Project Description

### 1. Modules

#### 1.1. Full Project Structure Schema

    .
    ├── .vscode                                             # Custom Snippets
    ├── cypress                                             # Main folder
        ├── e2e                                             # Main Tests folder
          ├── Alert_Management                              # Module/Page Folder
                ├── api                                     # API Calls needed for tests (Optional)
                    ├── AlertingApi.js
                    └── constants.js
                ├── Monitors
                    ├── helper                              # Helpers for Monitors Page
                        ├── constants.js                    # Object locators file
                        ├── MonitorDataHelper.js            # Data Helper class to supply data in tests (Optional)
                        └── MonitorsHelper.js               # Page Helper class for carrying out operations
                    └── specs                               # Test Case files
                        ├── CreateMonitors.cy.js
                        ├── EditDuplicateMonitors.cy.js
                        └── ViewDeleteMonitors.cy.js
                ├── Intelligent Alerts
                ├── Suspensions
                └── index.js
            ├── Base_Sanity                                 # Checks whether portal is loading properly
            ├── Communicator
            └── OS_Patching
        ├── fixtures                                        # Data supplier for entire respository, should be accessed using cy.fixture()
            ├── data                                        # Contains static data to be loaded
                ├── DT
                    ├── api.json
                    └── user-credentials.json
                ├── QA
                    ├── api.json
                    └── user-credentials.json
                └── PROD
                    ├── api.json
                    └── user-credentials.json
            ├── helper                                      # Helpers based on Components
                ├── CWComponentHelper                       # CW common component helpers
                    └── ResourceSelectorHelper.js
                ├── ApiHelper.js
                ├── ButtonHelper.js
                ├── CommonHelper.js
                ├── DropDownHelper.js
                ├── GridHelper.js
                ├── InputButtonHelper.js
                ├── InputFieldHelper.js
                ├── LoginHelper.js
                └── ToastHelper.js
            └── index.js
        ├── support                                         # Extends support to cypress frameworks, by enabling package addition, custom commands, etc.
            ├── commands.js
            ├── customCommands.d.ts
            └── e2e.js
        ├── constants.js
        └── tsconfig.json
    ├── utilities                                           # External utilities for communicating test results
        ├── jira
        └── teams-reporter
    ├── .eslintignore
    ├── .eslintrc.json                                      # Linting rles
    ├── .gitignore                                          # Folders/Files to be excluded
    ├── .gitlab-ci.yml                                      # CI/CD pipeline stages
    ├── babel.config.json
    ├── cypress.config.allure.js                            # Config file for allure reports (for CI/CD)
    ├── cypress.config.js                                   # Config file for local development
    ├── extractModuleName.js
    ├── package-lock.json
    ├── package.json                                        # packages repository file (Important)
    └── README.md

#### 1.2. GitLab Repository rules

1. Commit messages: There is a strict rule for commiting and change to the repository. The synatx for the same is give as:
   ```
   [module: <module_name>] <commit_message>
   ```
   **Note**: Module name could be the folder name or the sub-folder name. If commit messages do not follow this rule, then commits will be denied. In case your MR contains only framework imporvements, then in module name you can write any module name or "Base_Sanity".
2. Branch name: Branch name must be JIRA-ID that is generated on your Team Board on JIRA. Failing which branch will not be created.
3. Merge Request Approvals: As of now every Merge Request requires 2 mandatory approvals from the UNM-QA rule. Later new rule will be added.

### 2. Setup

Using VS Code

1. Follow the steps as given in [Prerequisite Software](#Prerequisite-Software).
2. Clone **qa-ui-automation** respository on your local system using git clone ssh.
3. Open VS Code IDE.
4. File -> Open Folder -> Select the cloned folder.
5. Open Terminal and type the following command: `npm install`
6. Check **node_modules** folder has been below cypress folder.

#### 2.1 Code style

It is mandatory to follow code style and conventions. Modules will fail to build, resulting into failed pipeline.
Follow few simple steps to apply code style:

1. Start VS Code
2. Download extensions
   - JavaScript (ES6) code snippets (charalampos karypidis)
   - ESlint (Microsoft)
3. On writing code, errors will be shown based on lint rules as specified in .eslintrc.json

#### 2.2 Running tests using Cypress

Cypress offers 2 modes of executing tests, **run** and **open** mode. Each mode has its own functionality.

- **Run Mode**: Cypress run mode, enables to run all the test files in a headless mode. This mode is usually used to run all test after tests have been written and verified. There are other flags that can also be set to modify the run mode such as, --specs (provide spec files path which you want to run), --browser (specifiy browser to be used while running), --headless (specify if you want to run the tests on a headless browser). Other flags can be seen here, [Cypress Command line arguments](https://docs.cypress.io/guides/guides/command-line).\
  **Example**: `npx cypress run --browser chrome --spec "cypress/e2e/**/<module_name>/**/*.cy.js"`
- **Open Mode**: Cypress open mode, allows user to watch the execution of tests and control these execution by using the stop, play, reply options. One thing to note here is the fact that under open mode, you can run only one spec file at a time by selecting the files from the open mode specs list.  
  **Example**: `npx cypress open`

**Note**: In packages.json, there is an object scripts wich contains more commands to run cypress. These commands are wrappers of the above 2 commands and usage of either will give the same result unless any other parameters are sepcified.

#### 2.3. Cypress Config Description:

1. baseUrl: URL used as prefix for cy.visit() or cy.request() command's URL.
2. setupNodeEvents: Function in which node events can be registered and config can be modified. Takes the place of the (removed) pluginFile option. Please read the notes for examples on using this.
3. slowTestThreshold: Time, in milliseconds, to consider a test "slow" during cypress run. A slow test will display in orange text in the default reporter.
4. testIsolation: Whether or not test isolation is enabled to ensure a clean browser context between tests.
5. viewportHeight: Default height in pixels for the application under tests' viewport.
6. viewportWidth: Default width in pixels for the application under tests' viewport.
7. defaultCommandTimeout: Time, in milliseconds, to wait until most DOM based commands are considered timed out.
8. execTimeout: Time, in milliseconds, to wait for a system command to finish executing during a cy.exec() command.
9. taskTimeout: Time, in milliseconds, to wait for a task to finish executing during a cy.task() command.
10. pageLoadTimeout: Time, in milliseconds, to wait for page transition events or cy.visit(), cy.go(), cy.reload() commands to fire their page load events. Network requests are limited by the underlying operating system, and may still time out if this value is increased.
11. requestTimeout: Time, in milliseconds, to wait for a request to go out in a cy.wait() command.
12. responseTimeout: Time, in milliseconds, to wait until a response in a cy.request(), cy.wait(), cy.fixture(), cy.getCookie(), cy.getCookies(), cy.setCookie(), cy.clearCookie(), cy.clearCookies(), and cy.screenshot() commands.

Other configuration settings can be seen here in detail: [Cypress Config Details](https://docs.cypress.io/guides/references/configuration#Options).

### 3. Report Generation

UI Automation framework generates reports in 2 formats namely:

- **Allure Reports** With Jira IDs mappings - These reports are generated only in the case of Gitlab CI/CD pipeline. JIRA ids can be mapped in these reports. If you want to setup allure reports locally, then follow the steps as given here: [Steps to add allure reports for local setup](https://www.npmjs.com/package/@mmisty/cypress-allure-adapter).
- **Mochawesome Reports** - These reports are light weight and do not require any extra setup. These report get setup when you build the project using `npm install`.

**Note**: Both these reports have screenshots/videos attached to them for each test case if any failure. This is setup in the config file.

### 4. Reporting

#### 4.1 Reporting to Jira Zephyr Scale

Integration with Jira Zephyr Scale is implemented for creating/updating test cycles during execution or adding new test cases.

Configuration of Jira is straightforward. Open utilities/jira/projects.json file and add needed record:

      "Alert_Management": {
        "EnableJiraReporter": false,
        "ProjectID": 15515,
        "ProjectKey": "UMMDASH",
        "TestCycle": {
            "name": "Alert Management | UI Automation ",
            "projectKey": "UMMDASH"
        },
        "TestCycleThreshold": 5
    }

Properties Descriptions:

- EnableJiraReporter: true/false - enable/disable Reporting to Jira
- ProjectID - is ID (number) of project (usually this one is can be taken from URL when opening project in Jira)
- ProjectKey - is Project key (first letters of test id)
- TestCycle - information about Test Cycle to create
- TestCycle.name - Name of Test Cycle, preferably prefix
- TestCycle.projectKey - Project key (first letters of test id)
- TestCycleThreshold: threshold to decide whether to create a new cycle or continue with the latest test cycle.

#### 4.2 Reporting using MS-Teams

Automation Framework sends status of GitLab CI/CD Pipeline to the teams Channel: [UI Automation Pipeline Status](https://teams.microsoft.com/l/team/19%3Avv-TS0NPKdlQTilzpl2H6mUnILuU6Qg-axESiWzZH7w1%40thread.tacv2/conversations?groupId=82fbef58-8f58-45e3-8f61-e15e2eb1f2c1&tenantId=f2ddb62f-8335-4cc9-9886-175b834e4bf3).  
Status of Regression, Sanity and MR Review is sent to teams channel along with link to the allure report.

#### 4.3 Reporting to ReportPortal

[TBD]

### 5. GitLab CI/CD Pipeline structure

Gitlab Pipeline for Automation Project will be executed on 2 events: **Merge Request** and **Main Branch** Execution. The stages under these can be described as:

1. Merge Request: On creating a new merge request, pipeline is triggered with the following stages:
   - Build: build the project with cypress browser image.
   - Lint: checks whether project code follows lint rules as specified in the project.
   - Review: Review stage has 2 jobs:
     - review:cy:module - runs specs based on module specified in the commit message. This module is the folder name you have made changes to in the current MR.
     - review:generate:allure - generates allure report based on previous execution of review:cy:module. Post this, status is reported to Teams Channel.
   - Sanity: Sanity stages runs only if Review stage is passed. Sanity will run test cases which have "@sanity" tags assigned to them. This will be across modules/folder and help determine if all modules sanity test cases are working fine and not affected by the MR changes. Sanity also has the same jobs as Review Stage i.e. sanity:cy:run and sanity:generate:allure.
2. Main Branch: On merging the MR to the main branch, this pipeline will be triggered which have the following jobs:
   - Build: build the project with cypress browser image.
   - Lint: checks whether project code follows lint rules as specified in the project.
   - Regression: Regression stage has 2 jobs:
     - regression:cy:run - runs specs which have "@Regression" tags assigned to them across modules.
     - regression:generate:allure - generates allure report based on previous execution of regression:cy:run. Post this, status is reported to Teams Channel.
